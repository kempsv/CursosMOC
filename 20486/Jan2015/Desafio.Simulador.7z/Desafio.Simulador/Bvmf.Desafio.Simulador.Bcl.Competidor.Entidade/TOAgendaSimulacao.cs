using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Agendamento.Simulacao.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOAgendaSimulacao
    {
        // Declara��o de atributos
        private int _codigoAgendaSimulacao;
        private int _codigoParametroAgenda;
        private int _codigoSistemaOrigem;
        private DateTime _dataHoraAgendamento;
        private DateTime _dataHoraCriacao;
        private short _identificadorSemana;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoAgendaSimulacao
        {
            get
            {
                return _codigoAgendaSimulacao;
            }
            set
            {
                _codigoAgendaSimulacao = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoParametroAgenda
        {
            get
            {
                return _codigoParametroAgenda;
            }
            set
            {
                _codigoParametroAgenda = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoSistemaOrigem
        {
            get
            {
                return _codigoSistemaOrigem;
            }
            set
            {
                _codigoSistemaOrigem = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public DateTime DataHoraAgendamento
        {
            get
            {
                return _dataHoraAgendamento;
            }
            set
            {
                _dataHoraAgendamento = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public DateTime DataHoraCriacao
        {
            get
            {
                return _dataHoraCriacao;
            }
            set
            {
                _dataHoraCriacao = value;
            }
        }
        
        /// <summary>
        /// 1 = 1� Semana, 2 = 2� Semana, 3 = 3� Semana, 4 = 4� Semana
        /// </summary>
        public short IdentificadorSemana
        {
            get
            {
                return _identificadorSemana;
            }
            set
            {
                _identificadorSemana = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOAgendaSimulacao()
        {
            _codigoAgendaSimulacao = int.MinValue;
            _codigoParametroAgenda = int.MinValue;
            _codigoSistemaOrigem = int.MinValue;
            _dataHoraAgendamento = DateTime.MinValue;
            _dataHoraCriacao = DateTime.MinValue;
            _identificadorSemana = short.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOAgendaSimulacao" );
            sb.Append( "\n\tCodigoAgendaSimulacao = " );
            sb.Append( _codigoAgendaSimulacao );
            sb.Append( "\n\tCodigoParametroAgenda = " );
            sb.Append( _codigoParametroAgenda );
            sb.Append( "\n\tCodigoSistemaOrigem = " );
            sb.Append( _codigoSistemaOrigem );
            sb.Append( "\n\tDataHoraAgendamento = " );
            sb.Append( _dataHoraAgendamento );
            sb.Append( "\n\tDataHoraCriacao = " );
            sb.Append( _dataHoraCriacao );
            sb.Append( "\n\tIdentificadorSemana = " );
            sb.Append( _identificadorSemana );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOAgendaSimulacao) )
            {
                return false;
            }
            
            TOAgendaSimulacao convertedParam = (TOAgendaSimulacao) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoAgendaSimulacao
            if( !CodigoAgendaSimulacao.Equals( convertedParam.CodigoAgendaSimulacao ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoParametroAgenda
            if( !CodigoParametroAgenda.Equals( convertedParam.CodigoParametroAgenda ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoSistemaOrigem
            if( !CodigoSistemaOrigem.Equals( convertedParam.CodigoSistemaOrigem ) )
            {
                return false;
            }
            
            // Compara o atributo DataHoraAgendamento
            if( !DataHoraAgendamento.Equals( convertedParam.DataHoraAgendamento ) )
            {
                return false;
            }
            
            // Compara o atributo DataHoraCriacao
            if( !DataHoraCriacao.Equals( convertedParam.DataHoraCriacao ) )
            {
                return false;
            }
            
            // Compara o atributo IdentificadorSemana
            if( !IdentificadorSemana.Equals( convertedParam.IdentificadorSemana ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //AgendaSimulacao
}
