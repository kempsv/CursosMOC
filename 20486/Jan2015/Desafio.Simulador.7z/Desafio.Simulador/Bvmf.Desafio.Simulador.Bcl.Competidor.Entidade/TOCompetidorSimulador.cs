using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Competidor.Entidade
{
    
    public enum TipoCompetidor
    {
        Aluno = 1,
        Professor = 2
    }
    
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOCompetidorSimulador
    {
        // Declara��o de atributos
        private int _codigoCompetidor;
        private int _codigoGrupoEscolar;
        private int _codigoSistemaOrigem;
        private int _codigoTipoCompetidor;
        private string _nomeCompetidor;
        private string _emailCompetidor;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoCompetidor
        {
            get
            {
                return _codigoCompetidor;
            }
            set
            {
                _codigoCompetidor = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoGrupoEscolar
        {
            get
            {
                return _codigoGrupoEscolar;
            }
            set
            {
                _codigoGrupoEscolar = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoSistemaOrigem
        {
            get
            {
                return _codigoSistemaOrigem;
            }
            set
            {
                _codigoSistemaOrigem = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoTipoCompetidor
        {
            get
            {
                return _codigoTipoCompetidor;
            }
            set
            {
                _codigoTipoCompetidor = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NomeCompetidor
        {
            get
            {
                return _nomeCompetidor;
            }
            set
            {
                _nomeCompetidor = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string EmailCompetidor
        {
            get
            {
                return _emailCompetidor;
            }
            set
            {
                _emailCompetidor = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOCompetidorSimulador()
        {
            _codigoCompetidor = int.MinValue;
            _codigoGrupoEscolar = int.MinValue;
            _codigoSistemaOrigem = int.MinValue;
            _codigoTipoCompetidor = int.MinValue;
            _nomeCompetidor = null;
            _emailCompetidor = null;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOCompetidorSimulador" );
            sb.Append( "\n\tCodigoCompetidor = " );
            sb.Append( _codigoCompetidor );
            sb.Append( "\n\tCodigoGrupoEscolar = " );
            sb.Append( _codigoGrupoEscolar );
            sb.Append( "\n\tCodigoSistemaOrigem = " );
            sb.Append( _codigoSistemaOrigem );
            sb.Append( "\n\tCodigoTipoCompetidor = " );
            sb.Append( _codigoTipoCompetidor );
            sb.Append( "\n\tNomeCompetidor = " );
            sb.Append( _nomeCompetidor );
            sb.Append( "\n\tEmailCompetidor = " );
            sb.Append( _emailCompetidor );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOCompetidorSimulador) )
            {
                return false;
            }
            
            TOCompetidorSimulador convertedParam = (TOCompetidorSimulador) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoCompetidor
            if( !CodigoCompetidor.Equals( convertedParam.CodigoCompetidor ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoGrupoEscolar
            if( !CodigoGrupoEscolar.Equals( convertedParam.CodigoGrupoEscolar ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoSistemaOrigem
            if( !CodigoSistemaOrigem.Equals( convertedParam.CodigoSistemaOrigem ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoTipoCompetidor
            if( !CodigoTipoCompetidor.Equals( convertedParam.CodigoTipoCompetidor ) )
            {
                return false;
            }
            
            // Compara o atributo NomeCompetidor
            if( !NomeCompetidor.Equals( convertedParam.NomeCompetidor ) )
            {
                return false;
            }
            
            // Compara o atributo EmailCompetidor
            if( !EmailCompetidor.Equals( convertedParam.EmailCompetidor ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //CompetidorSimulador
}
