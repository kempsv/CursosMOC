using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Competidor.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TODiretor
    {
        // Declara��o de atributos
        private int _codigoDiretor;
        private string _nomeDiretor;
        private string _nomeDiretoriaEnsino;
        private string _emailContato;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoDiretor
        {
            get
            {
                return _codigoDiretor;
            }
            set
            {
                _codigoDiretor = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NomeDiretor
        {
            get
            {
                return _nomeDiretor;
            }
            set
            {
                _nomeDiretor = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NomeDiretoriaEnsino
        {
            get
            {
                return _nomeDiretoriaEnsino;
            }
            set
            {
                _nomeDiretoriaEnsino = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string EmailContato
        {
            get
            {
                return _emailContato;
            }
            set
            {
                _emailContato = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TODiretor()
        {
            _codigoDiretor = int.MinValue;
            _nomeDiretor = null;
            _nomeDiretoriaEnsino = null;
            _emailContato = null;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TODiretor" );
            sb.Append( "\n\tCodigoDiretor = " );
            sb.Append( _codigoDiretor );
            sb.Append( "\n\tNomeDiretor = " );
            sb.Append( _nomeDiretor );
            sb.Append( "\n\tNomeDiretoriaEnsino = " );
            sb.Append( _nomeDiretoriaEnsino );
            sb.Append( "\n\tEmailContato = " );
            sb.Append( _emailContato );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TODiretor) )
            {
                return false;
            }
            
            TODiretor convertedParam = (TODiretor) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoDiretor
            if( !CodigoDiretor.Equals( convertedParam.CodigoDiretor ) )
            {
                return false;
            }
            
            // Compara o atributo NomeDiretor
            if( !NomeDiretor.Equals( convertedParam.NomeDiretor ) )
            {
                return false;
            }
            
            // Compara o atributo NomeDiretoriaEnsino
            if( !NomeDiretoriaEnsino.Equals( convertedParam.NomeDiretoriaEnsino ) )
            {
                return false;
            }
            
            // Compara o atributo EmailContato
            if( !EmailContato.Equals( convertedParam.EmailContato ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //Diretor
}
