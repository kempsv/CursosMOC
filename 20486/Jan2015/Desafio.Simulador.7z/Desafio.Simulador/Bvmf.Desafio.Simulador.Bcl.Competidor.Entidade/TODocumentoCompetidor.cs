using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Competidor.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TODocumentoCompetidor
    {
        // Declara��o de atributos
        private int _codigoCompetidor;
        private int _codigoTipoDocumento;
        private string _numeroDocumento;
        
        public int CodigoCompetidor
        {
            get
            {
                return _codigoCompetidor;
            }
            set
            {
                _codigoCompetidor = value;
            }
        }
        
        public int CodigoTipoDocumento
        {
            get
            {
                return _codigoTipoDocumento;
            }
            set
            {
                _codigoTipoDocumento = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NumeroDocumento
        {
            get
            {
                return _numeroDocumento;
            }
            set
            {
                _numeroDocumento = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TODocumentoCompetidor()
        {
            _codigoCompetidor = int.MinValue;
            _codigoTipoDocumento = int.MinValue;
            _numeroDocumento = null;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TODocumentoCompetidor" );
            sb.Append( "\n\tCodigoCompetidor = " );
            sb.Append( _codigoCompetidor );
            sb.Append( "\n\tCodigoTipoDocumento = " );
            sb.Append( _codigoTipoDocumento );
            sb.Append( "\n\tNumeroDocumento = " );
            sb.Append( _numeroDocumento );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TODocumentoCompetidor) )
            {
                return false;
            }
            
            TODocumentoCompetidor convertedParam = (TODocumentoCompetidor) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoCompetidor
            if( !CodigoCompetidor.Equals( convertedParam.CodigoCompetidor ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoTipoDocumento
            if( !CodigoTipoDocumento.Equals( convertedParam.CodigoTipoDocumento ) )
            {
                return false;
            }
            
            // Compara o atributo NumeroDocumento
            if( !NumeroDocumento.Equals( convertedParam.NumeroDocumento ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //DocumentoCompetidor
}
