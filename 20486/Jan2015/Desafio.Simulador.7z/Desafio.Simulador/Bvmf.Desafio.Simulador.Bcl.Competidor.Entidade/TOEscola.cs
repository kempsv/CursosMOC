using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Competidor.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOEscola
    {
        // Declara��o de atributos
        private int _codigoEscola;
        private int _codigoDiretor;
        private int _codigoSistemaOrigem;
        private bool _indicadorEscolaPrivada;
        private string _emailEscola;
        private string _nomeEscola;
        private string _numeroCNPJ;
        private bool _indicadorSorteioPendente;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoEscola
        {
            get
            {
                return _codigoEscola;
            }
            set
            {
                _codigoEscola = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoDiretor
        {
            get
            {
                return _codigoDiretor;
            }
            set
            {
                _codigoDiretor = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoSistemaOrigem
        {
            get
            {
                return _codigoSistemaOrigem;
            }
            set
            {
                _codigoSistemaOrigem = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public bool IndicadorEscolaPrivada
        {
            get
            {
                return _indicadorEscolaPrivada;
            }
            set
            {
                _indicadorEscolaPrivada = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string EmailEscola
        {
            get
            {
                return _emailEscola;
            }
            set
            {
                _emailEscola = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NomeEscola
        {
            get
            {
                return _nomeEscola;
            }
            set
            {
                _nomeEscola = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NumeroCNPJ
        {
            get
            {
                return _numeroCNPJ;
            }
            set
            {
                _numeroCNPJ = value;
            }
        }
        
        public bool IndicadorSorteioPendente
        {
            get
            {
                return _indicadorSorteioPendente;
            }
            set
            {
                _indicadorSorteioPendente = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOEscola()
        {
            _codigoEscola = int.MinValue;
            _codigoDiretor = int.MinValue;
            _codigoSistemaOrigem = int.MinValue;
            _indicadorEscolaPrivada = false;
            _emailEscola = null;
            _nomeEscola = null;
            _numeroCNPJ = null;
            _indicadorSorteioPendente = false;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOEscola" );
            sb.Append( "\n\tCodigoEscola = " );
            sb.Append( _codigoEscola );
            sb.Append( "\n\tCodigoDiretor = " );
            sb.Append( _codigoDiretor );
            sb.Append( "\n\tCodigoSistemaOrigem = " );
            sb.Append( _codigoSistemaOrigem );
            sb.Append( "\n\tIndicadorEscolaPrivada = " );
            sb.Append( _indicadorEscolaPrivada );
            sb.Append( "\n\tEmailEscola = " );
            sb.Append( _emailEscola );
            sb.Append( "\n\tNomeEscola = " );
            sb.Append( _nomeEscola );
            sb.Append( "\n\tNumeroCNPJ = " );
            sb.Append( _numeroCNPJ );
            sb.Append( "\n\tIndicadorSorteioPendente = " );
            sb.Append( _indicadorSorteioPendente );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOEscola) )
            {
                return false;
            }
            
            TOEscola convertedParam = (TOEscola) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoEscola
            if( !CodigoEscola.Equals( convertedParam.CodigoEscola ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoDiretor
            if( !CodigoDiretor.Equals( convertedParam.CodigoDiretor ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoSistemaOrigem
            if( !CodigoSistemaOrigem.Equals( convertedParam.CodigoSistemaOrigem ) )
            {
                return false;
            }
            
            // Compara o atributo IndicadorEscolaPrivada
            if( !IndicadorEscolaPrivada.Equals( convertedParam.IndicadorEscolaPrivada ) )
            {
                return false;
            }
            
            // Compara o atributo EmailEscola
            if( !EmailEscola.Equals( convertedParam.EmailEscola ) )
            {
                return false;
            }
            
            // Compara o atributo NomeEscola
            if( !NomeEscola.Equals( convertedParam.NomeEscola ) )
            {
                return false;
            }
            
            // Compara o atributo NumeroCNPJ
            if( !NumeroCNPJ.Equals( convertedParam.NumeroCNPJ ) )
            {
                return false;
            }
            
            // Compara o atributo IndicadorSorteioPendente
            if( !IndicadorSorteioPendente.Equals( convertedParam.IndicadorSorteioPendente ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //Escola
}
