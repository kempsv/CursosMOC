using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Competidor.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOGrupoEscolar
    {
        // Declara��o de atributos
        private int _codigoGrupoEscolar;
        private int _codigoEscola;
        private int _codigoSistemaOrigem;
        private bool _indicadorDesclassificado;
        private string _nomeGrupoEscolar;
        private decimal _valorInvestimentoInicial;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoGrupoEscolar
        {
            get
            {
                return _codigoGrupoEscolar;
            }
            set
            {
                _codigoGrupoEscolar = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoEscola
        {
            get
            {
                return _codigoEscola;
            }
            set
            {
                _codigoEscola = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoSistemaOrigem
        {
            get
            {
                return _codigoSistemaOrigem;
            }
            set
            {
                _codigoSistemaOrigem = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public bool IndicadorDesclassificado
        {
            get
            {
                return _indicadorDesclassificado;
            }
            set
            {
                _indicadorDesclassificado = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NomeGrupoEscolar
        {
            get
            {
                return _nomeGrupoEscolar;
            }
            set
            {
                _nomeGrupoEscolar = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal ValorInvestimentoInicial
        {
            get
            {
                return _valorInvestimentoInicial;
            }
            set
            {
                _valorInvestimentoInicial = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOGrupoEscolar()
        {
            _codigoGrupoEscolar = int.MinValue;
            _codigoEscola = int.MinValue;
            _codigoSistemaOrigem = int.MinValue;
            _indicadorDesclassificado = false;
            _nomeGrupoEscolar = null;
            _valorInvestimentoInicial = decimal.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOGrupoEscolar" );
            sb.Append( "\n\tCodigoGrupoEscolar = " );
            sb.Append( _codigoGrupoEscolar );
            sb.Append( "\n\tCodigoEscola = " );
            sb.Append( _codigoEscola );
            sb.Append( "\n\tCodigoSistemaOrigem = " );
            sb.Append( _codigoSistemaOrigem );
            sb.Append( "\n\tIndicadorDesclassificado = " );
            sb.Append( _indicadorDesclassificado );
            sb.Append( "\n\tNomeGrupoEscolar = " );
            sb.Append( _nomeGrupoEscolar );
            sb.Append( "\n\tValorInvestimentoInicial = " );
            sb.Append( _valorInvestimentoInicial );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOGrupoEscolar) )
            {
                return false;
            }
            
            TOGrupoEscolar convertedParam = (TOGrupoEscolar) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoGrupoEscolar
            if( !CodigoGrupoEscolar.Equals( convertedParam.CodigoGrupoEscolar ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoEscola
            if( !CodigoEscola.Equals( convertedParam.CodigoEscola ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoSistemaOrigem
            if( !CodigoSistemaOrigem.Equals( convertedParam.CodigoSistemaOrigem ) )
            {
                return false;
            }
            
            // Compara o atributo IndicadorDesclassificado
            if( !IndicadorDesclassificado.Equals( convertedParam.IndicadorDesclassificado ) )
            {
                return false;
            }
            
            // Compara o atributo NomeGrupoEscolar
            if( !NomeGrupoEscolar.Equals( convertedParam.NomeGrupoEscolar ) )
            {
                return false;
            }
            
            // Compara o atributo ValorInvestimentoInicial
            if( !ValorInvestimentoInicial.Equals( convertedParam.ValorInvestimentoInicial ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //GrupoEscolar
}
