using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Agendamento.Simulacao.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOPrecoPapelAgendamento
    {
        // Declara��o de atributos
        private short _codigoTipoSemana;
        private int _codigoPapel;
        private decimal _valorPrecoPapel;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public short CodigoTipoSemana
        {
            get
            {
                return _codigoTipoSemana;
            }
            set
            {
                _codigoTipoSemana = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoPapel
        {
            get
            {
                return _codigoPapel;
            }
            set
            {
                _codigoPapel = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal ValorPrecoPapel
        {
            get
            {
                return _valorPrecoPapel;
            }
            set
            {
                _valorPrecoPapel = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOPrecoPapelAgendamento()
        {
            _codigoTipoSemana = short.MinValue;
            _codigoPapel = int.MinValue;
            _valorPrecoPapel = decimal.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOPrecoPapelAgendamento" );
            sb.Append( "\n\tCodigoTipoSemana = " );
            sb.Append( _codigoTipoSemana );
            sb.Append( "\n\tCodigoPapel = " );
            sb.Append( _codigoPapel );
            sb.Append( "\n\tValorPrecoPapel = " );
            sb.Append( _valorPrecoPapel );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOPrecoPapelAgendamento) )
            {
                return false;
            }
            
            TOPrecoPapelAgendamento convertedParam = (TOPrecoPapelAgendamento) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoTipoSemana
            if( !CodigoTipoSemana.Equals( convertedParam.CodigoTipoSemana ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoPapel
            if( !CodigoPapel.Equals( convertedParam.CodigoPapel ) )
            {
                return false;
            }
            
            // Compara o atributo ValorPrecoPapel
            if( !ValorPrecoPapel.Equals( convertedParam.ValorPrecoPapel ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //PrecoPapelAgendamento
}
