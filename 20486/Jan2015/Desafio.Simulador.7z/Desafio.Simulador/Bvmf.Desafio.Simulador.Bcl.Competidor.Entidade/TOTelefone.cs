using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Competidor.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOTelefone
    {
        // Declara��o de atributos
        private int _codigoTelefone;
        private int _codigoTipoTelefone;
        private string _nomeContato;
        private string _numeroTelefone;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoTelefone
        {
            get
            {
                return _codigoTelefone;
            }
            set
            {
                _codigoTelefone = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoTipoTelefone
        {
            get
            {
                return _codigoTipoTelefone;
            }
            set
            {
                _codigoTipoTelefone = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NomeContato
        {
            get
            {
                return _nomeContato;
            }
            set
            {
                _nomeContato = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NumeroTelefone
        {
            get
            {
                return _numeroTelefone;
            }
            set
            {
                _numeroTelefone = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOTelefone()
        {
            _codigoTelefone = int.MinValue;
            _codigoTipoTelefone = int.MinValue;
            _nomeContato = null;
            _numeroTelefone = null;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOTelefone" );
            sb.Append( "\n\tCodigoTelefone = " );
            sb.Append( _codigoTelefone );
            sb.Append( "\n\tCodigoTipoTelefone = " );
            sb.Append( _codigoTipoTelefone );
            sb.Append( "\n\tNomeContato = " );
            sb.Append( _nomeContato );
            sb.Append( "\n\tNumeroTelefone = " );
            sb.Append( _numeroTelefone );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOTelefone) )
            {
                return false;
            }
            
            TOTelefone convertedParam = (TOTelefone) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoTelefone
            if( !CodigoTelefone.Equals( convertedParam.CodigoTelefone ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoTipoTelefone
            if( !CodigoTipoTelefone.Equals( convertedParam.CodigoTipoTelefone ) )
            {
                return false;
            }
            
            // Compara o atributo NomeContato
            if( !NomeContato.Equals( convertedParam.NomeContato ) )
            {
                return false;
            }
            
            // Compara o atributo NumeroTelefone
            if( !NumeroTelefone.Equals( convertedParam.NumeroTelefone ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //Telefone
}
