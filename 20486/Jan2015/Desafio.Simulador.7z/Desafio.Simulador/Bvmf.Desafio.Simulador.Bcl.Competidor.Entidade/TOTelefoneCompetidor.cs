using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Competidor.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOTelefoneCompetidor
    {
        // Declara��o de atributos
        private int _codigoCompetidor;
        private int _codigoTelefone;
        
        public int CodigoCompetidor
        {
            get
            {
                return _codigoCompetidor;
            }
            set
            {
                _codigoCompetidor = value;
            }
        }
        
        public int CodigoTelefone
        {
            get
            {
                return _codigoTelefone;
            }
            set
            {
                _codigoTelefone = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOTelefoneCompetidor()
        {
            _codigoCompetidor = int.MinValue;
            _codigoTelefone = int.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOTelefoneCompetidor" );
            sb.Append( "\n\tCodigoCompetidor = " );
            sb.Append( _codigoCompetidor );
            sb.Append( "\n\tCodigoTelefone = " );
            sb.Append( _codigoTelefone );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOTelefoneCompetidor) )
            {
                return false;
            }
            
            TOTelefoneCompetidor convertedParam = (TOTelefoneCompetidor) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoCompetidor
            if( !CodigoCompetidor.Equals( convertedParam.CodigoCompetidor ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoTelefone
            if( !CodigoTelefone.Equals( convertedParam.CodigoTelefone ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //TelefoneCompetidor
}
