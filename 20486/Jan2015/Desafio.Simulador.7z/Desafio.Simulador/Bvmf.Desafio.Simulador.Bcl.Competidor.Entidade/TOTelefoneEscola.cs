using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Competidor.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOTelefoneEscola
    {
        // Declara��o de atributos
        private int _codigoEscola;
        private int _codigoTelefone;
        
        public int CodigoEscola
        {
            get
            {
                return _codigoEscola;
            }
            set
            {
                _codigoEscola = value;
            }
        }
        
        public int CodigoTelefone
        {
            get
            {
                return _codigoTelefone;
            }
            set
            {
                _codigoTelefone = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOTelefoneEscola()
        {
            _codigoEscola = int.MinValue;
            _codigoTelefone = int.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOTelefoneEscola" );
            sb.Append( "\n\tCodigoEscola = " );
            sb.Append( _codigoEscola );
            sb.Append( "\n\tCodigoTelefone = " );
            sb.Append( _codigoTelefone );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOTelefoneEscola) )
            {
                return false;
            }
            
            TOTelefoneEscola convertedParam = (TOTelefoneEscola) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoEscola
            if( !CodigoEscola.Equals( convertedParam.CodigoEscola ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoTelefone
            if( !CodigoTelefone.Equals( convertedParam.CodigoTelefone ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //TelefoneEscola
}
