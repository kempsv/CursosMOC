using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Competidor.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOTipoCompetidor
    {
        // Declara��o de atributos
        private int _codigoTipoCompetidor;
        private string _nomeTipoCompetidor;
        
        public int CodigoTipoCompetidor
        {
            get
            {
                return _codigoTipoCompetidor;
            }
            set
            {
                _codigoTipoCompetidor = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NomeTipoCompetidor
        {
            get
            {
                return _nomeTipoCompetidor;
            }
            set
            {
                _nomeTipoCompetidor = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOTipoCompetidor()
        {
            _codigoTipoCompetidor = int.MinValue;
            _nomeTipoCompetidor = null;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOTipoCompetidor" );
            sb.Append( "\n\tCodigoTipoCompetidor = " );
            sb.Append( _codigoTipoCompetidor );
            sb.Append( "\n\tNomeTipoCompetidor = " );
            sb.Append( _nomeTipoCompetidor );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOTipoCompetidor) )
            {
                return false;
            }
            
            TOTipoCompetidor convertedParam = (TOTipoCompetidor) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoTipoCompetidor
            if( !CodigoTipoCompetidor.Equals( convertedParam.CodigoTipoCompetidor ) )
            {
                return false;
            }
            
            // Compara o atributo NomeTipoCompetidor
            if( !NomeTipoCompetidor.Equals( convertedParam.NomeTipoCompetidor ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //TipoCompetidor
}
