using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Competidor.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOTipoDocumento
    {
        // Declara��o de atributos
        private int _codigoTipoDocumento;
        private string _nomeTipoDocumento;
        
        public int CodigoTipoDocumento
        {
            get
            {
                return _codigoTipoDocumento;
            }
            set
            {
                _codigoTipoDocumento = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NomeTipoDocumento
        {
            get
            {
                return _nomeTipoDocumento;
            }
            set
            {
                _nomeTipoDocumento = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOTipoDocumento()
        {
            _codigoTipoDocumento = int.MinValue;
            _nomeTipoDocumento = null;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOTipoDocumento" );
            sb.Append( "\n\tCodigoTipoDocumento = " );
            sb.Append( _codigoTipoDocumento );
            sb.Append( "\n\tNomeTipoDocumento = " );
            sb.Append( _nomeTipoDocumento );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOTipoDocumento) )
            {
                return false;
            }
            
            TOTipoDocumento convertedParam = (TOTipoDocumento) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoTipoDocumento
            if( !CodigoTipoDocumento.Equals( convertedParam.CodigoTipoDocumento ) )
            {
                return false;
            }
            
            // Compara o atributo NomeTipoDocumento
            if( !NomeTipoDocumento.Equals( convertedParam.NomeTipoDocumento ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //TipoDocumento
}
