using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Competidor.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOTipoTelefone
    {
        // Declara��o de atributos
        private int _codigoTipoTelefone;
        private string _nomeTipoTelefone;
        
        public int CodigoTipoTelefone
        {
            get
            {
                return _codigoTipoTelefone;
            }
            set
            {
                _codigoTipoTelefone = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NomeTipoTelefone
        {
            get
            {
                return _nomeTipoTelefone;
            }
            set
            {
                _nomeTipoTelefone = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOTipoTelefone()
        {
            _codigoTipoTelefone = int.MinValue;
            _nomeTipoTelefone = null;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOTipoTelefone" );
            sb.Append( "\n\tCodigoTipoTelefone = " );
            sb.Append( _codigoTipoTelefone );
            sb.Append( "\n\tNomeTipoTelefone = " );
            sb.Append( _nomeTipoTelefone );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOTipoTelefone) )
            {
                return false;
            }
            
            TOTipoTelefone convertedParam = (TOTipoTelefone) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoTipoTelefone
            if( !CodigoTipoTelefone.Equals( convertedParam.CodigoTipoTelefone ) )
            {
                return false;
            }
            
            // Compara o atributo NomeTipoTelefone
            if( !NomeTipoTelefone.Equals( convertedParam.NomeTipoTelefone ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //TipoTelefone
}
