using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Agendamento.Simulacao.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOVinculoAgendaRodadaGrupoEscolar
    {
        // Declara��o de atributos
        private int _codigoGrupoEscolar;
        private int _codigoAgendaSimulacao;
        private int _codigoRodada;
        private short _contadorRodadaContingencia;
        private bool _indicadorSimulacaoConcluida;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoGrupoEscolar
        {
            get
            {
                return _codigoGrupoEscolar;
            }
            set
            {
                _codigoGrupoEscolar = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoAgendaSimulacao
        {
            get
            {
                return _codigoAgendaSimulacao;
            }
            set
            {
                _codigoAgendaSimulacao = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoRodada
        {
            get
            {
                return _codigoRodada;
            }
            set
            {
                _codigoRodada = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public short ContadorRodadaContingencia
        {
            get
            {
                return _contadorRodadaContingencia;
            }
            set
            {
                _contadorRodadaContingencia = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public bool IndicadorSimulacaoConcluida
        {
            get
            {
                return _indicadorSimulacaoConcluida;
            }
            set
            {
                _indicadorSimulacaoConcluida = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOVinculoAgendaRodadaGrupoEscolar()
        {
            _codigoGrupoEscolar = int.MinValue;
            _codigoAgendaSimulacao = int.MinValue;
            _codigoRodada = int.MinValue;
            _contadorRodadaContingencia = short.MinValue;
            _indicadorSimulacaoConcluida = false;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOVinculoAgendaRodadaGrupoEscolar" );
            sb.Append( "\n\tCodigoGrupoEscolar = " );
            sb.Append( _codigoGrupoEscolar );
            sb.Append( "\n\tCodigoAgendaSimulacao = " );
            sb.Append( _codigoAgendaSimulacao );
            sb.Append( "\n\tCodigoRodada = " );
            sb.Append( _codigoRodada );
            sb.Append( "\n\tContadorRodadaContingencia = " );
            sb.Append( _contadorRodadaContingencia );
            sb.Append( "\n\tIndicadorSimulacaoConcluida = " );
            sb.Append( _indicadorSimulacaoConcluida );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOVinculoAgendaRodadaGrupoEscolar) )
            {
                return false;
            }
            
            TOVinculoAgendaRodadaGrupoEscolar convertedParam = (TOVinculoAgendaRodadaGrupoEscolar) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoGrupoEscolar
            if( !CodigoGrupoEscolar.Equals( convertedParam.CodigoGrupoEscolar ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoAgendaSimulacao
            if( !CodigoAgendaSimulacao.Equals( convertedParam.CodigoAgendaSimulacao ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoRodada
            if( !CodigoRodada.Equals( convertedParam.CodigoRodada ) )
            {
                return false;
            }
            
            // Compara o atributo ContadorRodadaContingencia
            if( !ContadorRodadaContingencia.Equals( convertedParam.ContadorRodadaContingencia ) )
            {
                return false;
            }
            
            // Compara o atributo IndicadorSimulacaoConcluida
            if( !IndicadorSimulacaoConcluida.Equals( convertedParam.IndicadorSimulacaoConcluida ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //VinculoAgendaRodadaGrupoEscolar
}
