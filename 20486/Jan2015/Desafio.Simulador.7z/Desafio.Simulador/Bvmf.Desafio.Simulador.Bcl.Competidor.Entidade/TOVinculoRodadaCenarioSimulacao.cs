using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Agendamento.Simulacao.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOVinculoRodadaCenarioSimulacao
    {
        // Declara��o de atributos
        private int _codigoRodada;
        private int _codigoCenario;
        private int _codigoAgendaSimulacao;
        private int _codigoGrupoEscolar;
        private bool _indicadorCenarioContingencia;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoRodada
        {
            get
            {
                return _codigoRodada;
            }
            set
            {
                _codigoRodada = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoCenario
        {
            get
            {
                return _codigoCenario;
            }
            set
            {
                _codigoCenario = value;
            }
        }
        
        public int CodigoAgendaSimulacao
        {
            get
            {
                return _codigoAgendaSimulacao;
            }
            set
            {
                _codigoAgendaSimulacao = value;
            }
        }
        
        public int CodigoGrupoEscolar
        {
            get
            {
                return _codigoGrupoEscolar;
            }
            set
            {
                _codigoGrupoEscolar = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public bool IndicadorCenarioContingencia
        {
            get
            {
                return _indicadorCenarioContingencia;
            }
            set
            {
                _indicadorCenarioContingencia = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOVinculoRodadaCenarioSimulacao()
        {
            _codigoRodada = int.MinValue;
            _codigoCenario = int.MinValue;
            _codigoAgendaSimulacao = int.MinValue;
            _codigoGrupoEscolar = int.MinValue;
            _indicadorCenarioContingencia = false;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOVinculoRodadaCenarioSimulacao" );
            sb.Append( "\n\tCodigoRodada = " );
            sb.Append( _codigoRodada );
            sb.Append( "\n\tCodigoCenario = " );
            sb.Append( _codigoCenario );
            sb.Append( "\n\tCodigoAgendaSimulacao = " );
            sb.Append( _codigoAgendaSimulacao );
            sb.Append( "\n\tCodigoGrupoEscolar = " );
            sb.Append( _codigoGrupoEscolar );
            sb.Append( "\n\tIndicadorCenarioContingencia = " );
            sb.Append( _indicadorCenarioContingencia );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOVinculoRodadaCenarioSimulacao) )
            {
                return false;
            }
            
            TOVinculoRodadaCenarioSimulacao convertedParam = (TOVinculoRodadaCenarioSimulacao) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoRodada
            if( !CodigoRodada.Equals( convertedParam.CodigoRodada ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoCenario
            if( !CodigoCenario.Equals( convertedParam.CodigoCenario ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoAgendaSimulacao
            if( !CodigoAgendaSimulacao.Equals( convertedParam.CodigoAgendaSimulacao ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoGrupoEscolar
            if( !CodigoGrupoEscolar.Equals( convertedParam.CodigoGrupoEscolar ) )
            {
                return false;
            }
            
            // Compara o atributo IndicadorCenarioContingencia
            if( !IndicadorCenarioContingencia.Equals( convertedParam.IndicadorCenarioContingencia ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //VinculoRodadaCenarioSimulacao
}
