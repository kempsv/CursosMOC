﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity;

using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Interfaces;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Impl.Dao;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Entidade;
using Desafio.Simulador.Bcl.Configuracao.Parametros.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain.Enum;
using Desafio.Simulador.Bcl.Configuracao.Cenario.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.TaxaLucratividade.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Rodada.Interfaces;
using Desafio.Simulador.Util.Excecao;
//using Framework.Excecao;
using Desafio.Simulador.Bcl.Competidor.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Papel.Interfaces;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Interfaces;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Agendamento.Simulacao.Impl
{
    public class BCAgendaSimulacaoImpl : BCAgendaSimulacao
    {
        //private static Dictionary<int, CenarioSimulacao> _cenariosSorteados = new Dictionary<int, CenarioSimulacao>();
        //private static bool _indicadorContingencia = false;

        //private delegate void SorteioCenariosAsyncDelegate(List<AgendaSimulacao> agenda, List<CenarioSimulacao> cenariosSimulacao);

        //private static void SorteioCenariosAsync(List<AgendaSimulacao> agendas, List<CenarioSimulacao> cenariosSimulacao)
        //{
        //    System.Threading.Thread.Sleep(4000);
        //    foreach (AgendaSimulacao agenda in agendas)
        //    {
        //        //Ordena a lista de Rodadas pelo identificador
        //        List<AgendaSimulacaoRodadas> query = agenda.AgendaSimulacaoRodadas.OrderBy(orderBy => orderBy.Rodada.IdentificadorRodada).ToList<AgendaSimulacaoRodadas>();
        //        query.ForEach(delegate(AgendaSimulacaoRodadas agendaRodadas)
        //        {
        //            agendaRodadas.RodadaCenario = new List<RodadaCenario>();

        //            //Se for 2º rodada, os cenários serão negativos
        //            if (agendaRodadas.Rodada.IdentificadorRodada == 2)
        //            {
        //                cenariosSimulacao.ForEach(delegate(CenarioSimulacao cenarioNegativo)
        //                {
        //                    if (!_cenariosSorteados.ContainsKey(cenarioNegativo.Codigo))
        //                        _cenariosSorteados.Add(cenarioNegativo.Codigo, cenarioNegativo);

        //                    agendaRodadas.RodadaCenario.Add(new RodadaCenario()
        //                    {
        //                        CenarioSimulacao = new CenarioSimulacao()
        //                        {
        //                            Codigo = cenarioNegativo.Codigo
        //                        },
        //                        IndicadorCenarioContingencia = _indicadorContingencia
        //                    });
        //                    if (_indicadorContingencia == false) _indicadorContingencia = true;
        //                });
        //            }
        //            else
        //            {
        //                //_cenariosPositivos.ForEach(delegate(CenarioSimulacao cenarioNegativo) { });
        //            }
        //        });
        //        //
        //        //Faz o vínculo na base de dados dos cenários às Rodadas de Simulacao e Grupos Escolares
        //        //
        //        //this.VincularAgendaRodadasCenarioSimulacao(agenda);
        //    }
        //}

        #region | Campos
        //Membros Auxiliares para Sorteio Automático e Manual de Cenários
        private Dictionary<int, List<CenarioSimulacao>> _cenariosRodadas = null; //Lista de Cenários Sorteados para Cada Rodada
        private List<int> _cenariosPrincipais = null;  //Lista de Cenários Principais Selecionados
        private List<int> _cenariosSelecionados = null; //Lista de Cenários Selecionados
        private List<GrupoEscolar> _gruposClassificados = null; //Lista de Grupos
        private List<AgendaSimulacao> _agendaSimulacaoExistente = null; //Lista de Agendas para Simulação
        private List<TOVinculoAgendaRodadaGrupoEscolar> _vinculosAgendaRodadaGrupoEscolar = null; //Vinculos de Agens e Grupos
        private List<CenarioSimulacao> _cenariosSimulacao = null; //Lista de Todos os Cenários
        private List<CenarioSimulacao> _cenariosPositivos = null; //Lista de Todos os Cenários com Rentabilidade Positiva
        private List<CenarioSimulacao> _cenariosNegativos = null; //Lista de Todos os Cenários com Rentabilidade Negativa
        private bool _camposSorteioInicializados = false;
        private bool _indicadorSorteioAutomatico = false;
        #endregion

        #region | Propriedades Injetadas
        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCConfiguracaoParametroAgenda BCConfiguracaoParametroAgenda { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCConfiguracaoCenarios BCConfiguracaoCenarios { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCConfiguracaoRodada BCConfiguracaoRodada { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCConfiguracaoPapel BCConfiguracaoPapel { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCTermoAceiteSimulacao BCTermoAceiteSimulacao { get; set; }
        #endregion

        #region | Construtores
        public BCAgendaSimulacaoImpl(AgendaSimulacaoDAO agendaSimulacaoDAO) 
        {
            _persistence = agendaSimulacaoDAO;
            //InicializarCamposSorteio();
        }
        #endregion

        #region | Membros Públicos
        public override bool VerificarPeriodoSimulacao(DateTime dataSimulacao)
        {
            var periodoVedacao = _persistence.FindAll().Where(ag =>
                ag.DataHoraAgendamento.Year.Equals(dataSimulacao.Year)
                && ag.DataHoraAgendamento.Month.Equals(dataSimulacao.Month)
                && ag.DataHoraAgendamento.Day.Equals(dataSimulacao.Day)).FirstOrDefault<AgendaSimulacao>();

            if (periodoVedacao == null)
                return false;
            else
                return true;
        }

        public override List<AgendaSimulacao> ListarAgendaSimulacao(TipoSemanaSimulacao tipoSemanaSimulacao)
        {
            return ((AgendaSimulacaoDAO)_persistence).FindAgendaBySemanaSimulacao((int)tipoSemanaSimulacao);
        }

        public override List<AgendaSimulacao> ListarAgendaSimulacaoGrupoEscolar(int codigoGrupoEscolar)
        {
            var _agendaGrupo = ((AgendaSimulacaoDAO)_persistence).FindAgendaGrupoEscolar(codigoGrupoEscolar);

            this.PreencherAgregacaoByGrupoEscolar(_agendaGrupo, new GrupoEscolar() { Codigo = codigoGrupoEscolar });

            return _agendaGrupo;
        }

        public override AgendaSimulacao ObterAgendaSimulacaoGrupoEscolar(DateTime dataHoraAgendamento, int codigoGrupoEscolar)
        {
            var _agendaGrupo = ((AgendaSimulacaoDAO)_persistence).FindAgendaGrupoEscolar(codigoGrupoEscolar, dataHoraAgendamento);

            this.PreencherAgregacaoByGrupoEscolar(_agendaGrupo, new GrupoEscolar() { Codigo = codigoGrupoEscolar });
            
            return _agendaGrupo;
        }

        public override void VincularAgendaSimulacaoRodadas(AgendaSimulacao agendaSimulacao)
        {
            this.DesvincularAgendaSimulacaoRodadas(agendaSimulacao);

            VinculoAgendaRodadaGrupoEscolarDAO _daoVinculo = VinculoAgendaRodadaGrupoEscolarDAO.GetInstance();
            foreach (AgendaSimulacaoRodadas simulacaoRodadas in agendaSimulacao.AgendaSimulacaoRodadas)
            {
                //Faz o vínculo do Fato Relevante com o Cenário de Simulação de Investimento
                _daoVinculo.Create(new TOVinculoAgendaRodadaGrupoEscolar()
                {
                    CodigoRodada = simulacaoRodadas.Rodada.Codigo,
                    CodigoAgendaSimulacao = agendaSimulacao.Codigo,
                    CodigoGrupoEscolar = simulacaoRodadas.GrupoEscolar.Codigo,
                    ContadorRodadaContingencia = simulacaoRodadas.ContadorRodadaContingencia,
                    IndicadorSimulacaoConcluida = simulacaoRodadas.IndicadorSimulacaoConcluida
                });
            }
        }

        public override void RealizarSorteioCenarios(ref List<Escola> escolas)
        {
            string nomeMetodoLog = "BCAgendaSimulacaoImpl.RealizarSorteioCenarios";
            LogManager.InicioMetodo(nomeMetodoLog);

            InicializarCamposSorteio();

            //Informa que o tipo de Sorteio é automático
            //Não realiza a atualização dos indicadores de pendência
            //das escolas para cada chamada do sorteio automático
            _indicadorSorteioAutomatico = true;

            LogManager.Trace(nomeMetodoLog, "Realizando Sorteio para Agendas de Primeira Semana...");
            RealizarSorteioCenarios(ref escolas, TipoSemanaSimulacao.PrimeiraSemana, false, false);
            LogManager.Trace(nomeMetodoLog, "Sorteio para Agendas de Primeira Semana Realizado!");

            LogManager.Trace(nomeMetodoLog, nomeMetodoLog, "Realizando Sorteio para Agendas de Segunda Semana...");
            RealizarSorteioCenarios(ref escolas, TipoSemanaSimulacao.SegundaSemana, false, false);
            LogManager.Trace(nomeMetodoLog, "Sorteio para Agendas de Segunda Semana Realizado!");

            LogManager.Trace(nomeMetodoLog, "Realizando Sorteio para Agendas de Terceira Semana...");
            RealizarSorteioCenarios(ref escolas, TipoSemanaSimulacao.TerceiraSemana, false, false);
            LogManager.Trace(nomeMetodoLog, "Sorteio para Agendas de Terceira Semana Realizado!");

            LogManager.Trace(nomeMetodoLog, "Realizando Sorteio para Agendas de Quarta Semana...");
            RealizarSorteioCenarios(ref escolas, TipoSemanaSimulacao.QuartaSemana, false, false);
            LogManager.Trace(nomeMetodoLog, "Sorteio para Agendas de Quarta Semana Realizado!");

            //Valida se as escolas continuam pendentes ou não
            ValidarIndicadorSorteioEscolas(ref escolas);

            LogManager.FimMetodo(nomeMetodoLog);
        }

        public override void RealizarSorteioCenarios(ref List<Escola> escolas,
                                                     TipoSemanaSimulacao tipoSemanaSimulacao,
                                                     bool indicadorGruposNaoSorteados,
                                                     bool indicadorSorteioManual)
        {
            string nomeMetodoLog = "BCAgendaSimulacaoImpl.RealizarSorteioCenarios";
            LogManager.InicioMetodo(nomeMetodoLog, tipoSemanaSimulacao, indicadorGruposNaoSorteados);


            if (indicadorSorteioManual)
                InicializarCamposSorteio();

            //if (!_camposSorteioInicializados)
            /*if (!_indicadorSorteioAutomatico)
            {
                InicializarCamposSorteio();
                _camposSorteioInicializados = true;
            }*/

            //**********************************************************
            //Implemantação Passo 2: Selecionar os Grupos Classificados
            //**********************************************************
            if (_gruposClassificados == null || _gruposClassificados.Count == 0) //Cache de Grupos
                _gruposClassificados = ObterGruposEscolares(escolas, indicadorGruposNaoSorteados);

            if (_gruposClassificados == null || _gruposClassificados.Count == 0) GerenciadorExcecao.TratarExcecao(new Exception("Não existem grupos para os parametros informados!"));

            //***********************************************************************************
            //Implementação Passo 3: Obtêm a lista de todas as agenda de simulação cadastradas
            //***********************************************************************************
            if (_agendaSimulacaoExistente == null || _agendaSimulacaoExistente.Count == 0) //Cache de Agendas
                _agendaSimulacaoExistente = ObterAgendas();

            if (_agendaSimulacaoExistente == null || _agendaSimulacaoExistente.Count == 0) GerenciadorExcecao.TratarExcecao(new Exception("Não existem agendas cadastradas!"));

            //*************************************************************************************************
            //Implementação Passo 4: Obtêm a lista de todos os vinculos da Agenda com Grupo Escolar e Rodadas
            //*************************************************************************************************
            if (_vinculosAgendaRodadaGrupoEscolar == null || _vinculosAgendaRodadaGrupoEscolar.Count == 0) //Cache de Vinculos de Agendas e Grupos 
                _vinculosAgendaRodadaGrupoEscolar = VinculoAgendaRodadaGrupoEscolarDAO.GetInstance().FindAll();

            if (_vinculosAgendaRodadaGrupoEscolar == null || _vinculosAgendaRodadaGrupoEscolar.Count == 0) GerenciadorExcecao.TratarExcecao(new Exception("Não existem vinculos entre agendas, grupos e rodadas cadastrados!"));

            //*************************************************************************************
            //Implementação Passo 5: Obtêm a lista de todos os cenários de simulação cadastrados
            //*************************************************************************************                
            if (_cenariosSimulacao == null || _cenariosSimulacao.Count == 0)
                _cenariosSimulacao = BCConfiguracaoCenarios.FindAll().OrderBy(cenario => cenario.Codigo).ToList<CenarioSimulacao>();

            if (_cenariosSimulacao == null || _cenariosSimulacao.Count == 0) GerenciadorExcecao.TratarExcecao(new Exception("Não existem cenários cadastrados!"));

            //Agrupa os cenários por rentabilidade média positiva e negativa            
            if (_cenariosPositivos == null || _cenariosPositivos.Count == 0) //Cache de Cenários Positivos
                _cenariosPositivos = ObterCenariosPositivos();

            if (_cenariosNegativos == null || _cenariosNegativos.Count == 0) //Cache de Cenários Negativos
                _cenariosNegativos = ObterCenariosNegativos();

            //Separa e Agrupa as Agendas por semana de simulação e filtra por grupo            
            var agenda = FiltrarAgendasPorGrupoSemana(_agendaSimulacaoExistente,
                                                      _vinculosAgendaRodadaGrupoEscolar,
                                                      _gruposClassificados,
                                                      tipoSemanaSimulacao);

            //*************************************************************************
            //Implementação Passo 6: Realiza o sorteio e embaralhamento dos cenários
            //*************************************************************************
            if (_cenariosSelecionados == null)
                _cenariosSelecionados = new List<int>();

            if (_cenariosPrincipais == null)
                _cenariosPrincipais = new List<int>();

            if (
                _cenariosRodadas == null ||
                (_cenariosRodadas.ContainsKey(1) && _cenariosRodadas[1].Count < 3) ||
                (_cenariosRodadas.ContainsKey(2) && _cenariosRodadas[2].Count < 3) ||
                (_cenariosRodadas.ContainsKey(3) && _cenariosRodadas[3].Count < 3) ||
                (_cenariosRodadas.ContainsKey(4) && _cenariosRodadas[4].Count < 3)
                )
            {
                SortearCenariosRodadas();
                ImprimirCenariosSorteados();
            }


            //Embaralha Cenários para Grupos por Semana
            LogManager.Trace(nomeMetodoLog, "Embaralhando Cenários para [{0}] semana.", tipoSemanaSimulacao);
            EmbaralharCenarios(ref agenda);
            LogManager.Trace(nomeMetodoLog, "Cenários para [{0}] semana embaralhados.", tipoSemanaSimulacao);

            //Vinculação dos Cenarios aos Grupos, Rodadas e Semanas no Banco de Dados            
            foreach (AgendaSimulacao agendaSimulacao in agenda)
            {
                LogManager.Trace(nomeMetodoLog, "Vinculando Cenários à Agenda [{0}]", agendaSimulacao.Codigo);
                this.VincularAgendaRodadasCenarioSimulacao(agendaSimulacao);
                LogManager.Trace(nomeMetodoLog, "Cenários vinculados à Agenda [{0}]", agendaSimulacao.Codigo);
            }

            //Caso seja sorteio manual chama o método de validação 
            if (!_indicadorSorteioAutomatico)
            {
                //Valida se as escolas continuam pendentes ou não
                ValidarIndicadorSorteioEscolas(ref escolas);
            }

            LogManager.FimMetodo(nomeMetodoLog);
        }            

        public override void FinalizarRodada(AgendaSimulacaoRodadas agendaSimulacaoRodada)
        {
            VinculoAgendaRodadaGrupoEscolarDAO _daoVinculo = VinculoAgendaRodadaGrupoEscolarDAO.GetInstance();
            _daoVinculo.Update(new TOVinculoAgendaRodadaGrupoEscolar()
            {
                CodigoRodada = agendaSimulacaoRodada.Rodada.Codigo,
                CodigoAgendaSimulacao = agendaSimulacaoRodada.AgendaSimulacao.Codigo,
                CodigoGrupoEscolar = agendaSimulacaoRodada.GrupoEscolar.Codigo,
                IndicadorSimulacaoConcluida = agendaSimulacaoRodada.IndicadorSimulacaoConcluida,
                ContadorRodadaContingencia = agendaSimulacaoRodada.ContadorRodadaContingencia
            });

            if (agendaSimulacaoRodada.Rodada.CarteiraInvestimento != null)
            {
                //Obtêm a agenda de simulação atual
                var _agendaAtual = _persistence.FindByKey(agendaSimulacaoRodada.AgendaSimulacao.Codigo);

                //Obtêm a agenda da próxima semana
                //var _agendaProximaSemanaSimulacao = ((AgendaSimulacaoDAO)_persistence).FindAgendaBySemanaSimulacao(((int)_agendaAtual.TipoSemanaSimulacao + 1)).FirstOrDefault<AgendaSimulacao>();

                //if (_agendaProximaSemanaSimulacao != null)
                if (_agendaAtual != null)
                {
                    //_listaAgendaSimulacao.ForEach(delegate(AgendaSimulacao agenda)
                    //{
                    agendaSimulacaoRodada.Rodada.CarteiraInvestimento.AtivosCarteiraPapeis.ForEach(delegate(AtivosCarteiraPapeis papelAtivosCarteira)
                    {

                        /*PrecoPapelAgendamentoDAO.GetInstance().Delete(new TOPrecoPapelAgendamento()
                        {
                            CodigoAgenda = agenda.Codigo,
                            CodigoPapel = papelAtivosCarteira.PapelCarteira.Codigo
                        });*/

                        this.AtualizarPrecoInicialSimulacao(new TOPrecoPapelAgendamento()
                        {
                            CodigoTipoSemana = (short)((int)_agendaAtual.TipoSemanaSimulacao + 1),
                            CodigoPapel = papelAtivosCarteira.PapelCarteira.Codigo,
                            ValorPrecoPapel = papelAtivosCarteira.ValorPrecoFinal
                        });
                    });
                    //});
                }
            }
        }

        public override void IncrementarContadorContingencia(AgendaSimulacaoRodadas agendaSimulacaoRodada)
        {
            VinculoAgendaRodadaGrupoEscolarDAO _daoVinculo = VinculoAgendaRodadaGrupoEscolarDAO.GetInstance();
            _daoVinculo.UpdateContadorContingencia(new TOVinculoAgendaRodadaGrupoEscolar()
            {
                CodigoRodada = agendaSimulacaoRodada.Rodada.Codigo,
                CodigoAgendaSimulacao = agendaSimulacaoRodada.AgendaSimulacao.Codigo,
                CodigoGrupoEscolar = agendaSimulacaoRodada.GrupoEscolar.Codigo,
                ContadorRodadaContingencia = agendaSimulacaoRodada.ContadorRodadaContingencia
            });
        }

        public override void AtualizarPrecoInicialSimulacao(PapelCarteira papelCarteira)
        {
            //
            //Lista todas os agendamento da semana de simulação
            //
            //var _listaAgendamento = this.ListarAgendaSimulacao(papelCarteira.TipoSemanaSimulacao);

            //
            //Para cada data e hora de agendamento, atualiza o preço inicial do Papel
            //
            //_listaAgendamento.ForEach(delegate(AgendaSimulacao agenda)
            //{
                this.AtualizarPrecoInicialSimulacao(new TOPrecoPapelAgendamento()
                {
                    CodigoTipoSemana = (short)papelCarteira.TipoSemanaSimulacao,
                    CodigoPapel = papelCarteira.Codigo,
                    ValorPrecoPapel = papelCarteira.PrecoCompraInicial
                });
            //});
        }

        public override List<PapelCarteira> ListarPrecosIniciaisSimulacao(TipoSemanaSimulacao tipoSemanaSimulacao)
        {
            //
            // Lista todos os preços iniciais da semana de simulação
            //
            var _papeisPrecosIniciaisSimulacao = this.ListarPrecosIniciais(tipoSemanaSimulacao);

            //
            // Lista todos os Pápeis cadastrados
            //
            var _papeis = this.BCConfiguracaoPapel.FindAll();
            _papeis.ForEach(delegate(PapelCarteira papelCarteira)
            {
                var _precoPapelAgenda = _papeisPrecosIniciaisSimulacao.Where(pp => pp.CodigoPapel == papelCarteira.Codigo).FirstOrDefault<TOPrecoPapelAgendamento>();

                if (_precoPapelAgenda != null)
                    papelCarteira.PrecoCompraInicial = _precoPapelAgenda.ValorPrecoPapel;

                papelCarteira.TipoSemanaSimulacao = tipoSemanaSimulacao;
            });
            return _papeis;
        }

        public override void ReagendarSimuladoGrupoEscolar(AgendaSimulacao agendaSimulacao)
        {
            //Verifica a quantidade de grupos vinculados a agenda de simulação
            if (agendaSimulacao.GrupoEscolar.Count == 1)
            {
                base.Update(agendaSimulacao);
            }
            else
            {
                this.DesvincularAgendaSimulacaoRodadas(agendaSimulacao);
                this.DesvincularAgendaRodadasCenarioSimulacao(agendaSimulacao);
                base.Create(agendaSimulacao);
                this.VincularAgendaSimulacaoRodadas(agendaSimulacao);
                this.VincularAgendaRodadasCenarioSimulacao(agendaSimulacao);
            }
        }

        ///// <summary>
        ///// Obtêm Detalhes da Rodada
        ///// </summary>
        ///// <param name="codigoRodada"></param>
        ///// <returns></returns>
        //public override List<RodadaCenario> ListarDetalhesRodada(int codigoRodada)
        //{
        //    var vinculosCenariosCadastrados = VinculoRodadaCenarioSimulacaoDAO.GetInstance().FindAll().Where(p => p.CodigoRodada == codigoRodada).ToList<TOVinculoRodadaCenarioSimulacao>().ToList<TOVinculoRodadaCenarioSimulacao>();
        //    RodadaSimulacao rodada = BCConfiguracaoRodada.FindByKey(codigoRodada);

        //    var listaRodadaCenarios = new List<RodadaCenario>();
        //    foreach (TOVinculoRodadaCenarioSimulacao vinculo in vinculosCenariosCadastrados)
        //    {
        //        listaRodadaCenarios.Add(new RodadaCenario()
        //        {
        //            //RodadaSimulacao = rodada,
        //            CenarioSimulacao = BCConfiguracaoCenarios.FindByKey(vinculo.CodigoCenario),
        //            IndicadorCenarioContingencia = vinculo.IndicadorCenarioContingencia
        //        });
        //    }
        //    return listaRodadaCenarios;
        //}
        #endregion

        #region | Membros Privados

        private List<TOPrecoPapelAgendamento> ListarPrecosIniciais(TipoSemanaSimulacao tipoSemanaSimulacao)
        {
            //
            //Lista os preços iniciais dos papeis cadastradados para a semana de simulação atual
            //
            return PrecoPapelAgendamentoDAO.GetInstance().FindPapeisBySemanaSimulacao((int)tipoSemanaSimulacao);
        }

        private void DesvincularAgendaSimulacaoRodadas(AgendaSimulacao agendaSimulacao)
        {
            VinculoAgendaRodadaGrupoEscolarDAO _daoVinculoRodadas = VinculoAgendaRodadaGrupoEscolarDAO.GetInstance();

            foreach (AgendaSimulacaoRodadas simulacaoRodadas in agendaSimulacao.AgendaSimulacaoRodadas)
            {
                _daoVinculoRodadas.Delete(new TOVinculoAgendaRodadaGrupoEscolar()
                {
                    CodigoAgendaSimulacao = agendaSimulacao.Codigo,
                    CodigoGrupoEscolar = simulacaoRodadas.GrupoEscolar.Codigo
                });
            }
        }

        private void DesvincularAgendaRodadasCenarioSimulacao(AgendaSimulacao agendaSimulacao)
        {
            VinculoRodadaCenarioSimulacaoDAO _daoVinculoRodadaCenario = VinculoRodadaCenarioSimulacaoDAO.GetInstance();

            foreach (AgendaSimulacaoRodadas simulacaoRodadas in agendaSimulacao.AgendaSimulacaoRodadas)
            {
                _daoVinculoRodadaCenario.Delete(new TOVinculoRodadaCenarioSimulacao()
                {
                    CodigoRodada = simulacaoRodadas.Rodada.Codigo,
                    CodigoAgendaSimulacao = agendaSimulacao.Codigo,
                    CodigoGrupoEscolar = simulacaoRodadas.GrupoEscolar.Codigo
                });
            }
        }

        private void VincularAgendaRodadasCenarioSimulacao(AgendaSimulacao agendaSimulacao)
        {
            this.DesvincularAgendaRodadasCenarioSimulacao(agendaSimulacao);

            VinculoRodadaCenarioSimulacaoDAO _daoVinculo = VinculoRodadaCenarioSimulacaoDAO.GetInstance();

            foreach (AgendaSimulacaoRodadas simulacaoRodadas in agendaSimulacao.AgendaSimulacaoRodadas)
            {
                foreach (RodadaCenario rodadaCenario in simulacaoRodadas.RodadaCenario)
                {
                    //Faz o vínculo do Fato Relevante com o Cenário de Simulação de Investimento
                    _daoVinculo.Create(new TOVinculoRodadaCenarioSimulacao()
                    {
                        CodigoCenario = rodadaCenario.CenarioSimulacao.Codigo,
                        CodigoRodada = simulacaoRodadas.Rodada.Codigo,
                        CodigoAgendaSimulacao = agendaSimulacao.Codigo,
                        CodigoGrupoEscolar = simulacaoRodadas.GrupoEscolar.Codigo,
                        IndicadorCenarioContingencia = rodadaCenario.IndicadorCenarioContingencia
                    });
                }
            }
        }

        private void AtualizarPrecoInicialSimulacao(TOPrecoPapelAgendamento toPrecoPapelAgendamento)
        {
            //Exclui o preço atual
            PrecoPapelAgendamentoDAO.GetInstance().Delete(toPrecoPapelAgendamento);

            //Adiciona o novo o preço inicial
            PrecoPapelAgendamentoDAO.GetInstance().Create(toPrecoPapelAgendamento);
        }

        #region | Agregações

        private void PreencherAgregacaoByGrupoEscolar(List<AgendaSimulacao> agendaSimulacao, GrupoEscolar grupoEscolar)
        {
            agendaSimulacao.ForEach(delegate(AgendaSimulacao agenda)
            {
                this.PreencherAgregacaoByGrupoEscolar(agenda, grupoEscolar);
            });
        }

        private void PreencherAgregacaoByGrupoEscolar(AgendaSimulacao agendaSimulacao, GrupoEscolar grupoEscolar)
        {
            //
            //Não gera exceptions, retorna objeto como NULL
            //
            if (agendaSimulacao == null) return;

            agendaSimulacao.TermoAceiteSimulacao = this.BCTermoAceiteSimulacao.ObterTermoAceiteSimulacao(agendaSimulacao, grupoEscolar);
            agendaSimulacao.ParametrizacaoAgenda = this.BCConfiguracaoParametroAgenda.FindByKey(agendaSimulacao.ParametrizacaoAgenda.Codigo);
            agendaSimulacao.AgendaSimulacaoRodadas = new List<AgendaSimulacaoRodadas>();

            //
            //Lista todos os vínculos cadastrados do Grupo e da Agenda de Simulação
            //
            var _vinculosAgendaRodadaGrupoEscolar = VinculoAgendaRodadaGrupoEscolarDAO.GetInstance().FindVinculosAgendaGrupoEscolar(grupoEscolar.Codigo, agendaSimulacao.Codigo);

            //
            //Filtro os vínculos pelo código do Grupo e código da Agenda
            //
            /*var _vinculosAgendaRodadaGrupoEscolar = (from vinculos in _vinculosCadastrados
                                                     where (vinculos.CodigoGrupoEscolar.Equals(grupoEscolar.Codigo)
                                                            && vinculos.CodigoAgendaSimulacao.Equals(agendaSimulacao.Codigo))
                                                     select vinculos).ToList<TOVinculoAgendaRodadaGrupoEscolar>();*/

            //
            //Percorre a Lista e adiciona as Rodadas de Simulação
            //
            _vinculosAgendaRodadaGrupoEscolar.ForEach(delegate(TOVinculoAgendaRodadaGrupoEscolar toVinculoAgendaRodadaGrupoEscolar)
            {
                agendaSimulacao.AgendaSimulacaoRodadas.Add(new AgendaSimulacaoRodadas()
                {
                    Rodada = this.BCConfiguracaoRodada.FindByKey(toVinculoAgendaRodadaGrupoEscolar.CodigoRodada),
                    ContadorRodadaContingencia = toVinculoAgendaRodadaGrupoEscolar.ContadorRodadaContingencia,
                    IndicadorSimulacaoConcluida = toVinculoAgendaRodadaGrupoEscolar.IndicadorSimulacaoConcluida,
                    GrupoEscolar = grupoEscolar,
                    RodadaCenario = new List<RodadaCenario>(),
                    AgendaSimulacao = new AgendaSimulacao()
                    {
                        Codigo = agendaSimulacao.Codigo,
                        DataHoraAgendamento = agendaSimulacao.DataHoraAgendamento,
                        TipoSemanaSimulacao = agendaSimulacao.TipoSemanaSimulacao,
                        ParametrizacaoAgenda = agendaSimulacao.ParametrizacaoAgenda
                    }
                });
            });

            var _papeisPrecosIniciaisSimulacao = this.ListarPrecosIniciais(agendaSimulacao.TipoSemanaSimulacao);

            //
            //Lista todos os vínculos de cenários Sorteados Cadastrados
            //
            //var _vinculosCenariosCadastrados = this.SelecionarVinculosAgendasCenariosGrupo();

            agendaSimulacao.AgendaSimulacaoRodadas.ForEach(delegate(AgendaSimulacaoRodadas agendaRodadas)
            {
                //
                //Filtra os vínculos de Cenário Sorteados pelo código do Grupo, Código da Agenda e Códido da Rodada
                //
                /*var _vinculosCenariosAgenda = (from vinculos in _vinculosCenariosCadastrados
                                               where (vinculos.CodigoAgendaSimulacao.Equals(agendaSimulacao.Codigo)
                                                    && vinculos.CodigoGrupoEscolar.Equals(grupoEscolar.Codigo)
                                                    && vinculos.CodigoRodada.Equals(agendaRodadas.Rodada.Codigo))
                                               select vinculos).ToList<TOVinculoRodadaCenarioSimulacao>();*/

                var _vinculosCenariosAgenda = VinculoRodadaCenarioSimulacaoDAO.GetInstance().FindVinculosAgendaGrupoRodada(grupoEscolar.Codigo, 
                                                                                                                           agendaSimulacao.Codigo, 
                                                                                                                           agendaRodadas.Rodada.Codigo);

                //
                //Percorre a Lista e adiciona os Cenários de Simulação
                //
                _vinculosCenariosAgenda.ForEach(delegate(TOVinculoRodadaCenarioSimulacao toVinculoRodadaCenarioSimulacao)
                {
                    agendaRodadas.RodadaCenario.Add(new RodadaCenario()
                    {
                        CenarioSimulacao = new CenarioSimulacao() { Codigo = toVinculoRodadaCenarioSimulacao.CodigoCenario },// this.BCConfiguracaoCenarios.FindByKey(toVinculoRodadaCenarioSimulacao.CodigoCenario),
                        IndicadorCenarioContingencia = toVinculoRodadaCenarioSimulacao.IndicadorCenarioContingencia
                    });
                });


                //
                // Se existir preços iniciais para a simulação, atualiza o valor do preço inicial de compra
                // dos papéis vinculados aos fatos relevantes.
                //
                if (_papeisPrecosIniciaisSimulacao != null)
                {
                    agendaRodadas.RodadaCenario.ForEach(delegate(RodadaCenario rodadaCenario)
                    {
                        if (rodadaCenario.CenarioSimulacao.FatosRelavantes != null)
                        {
                            rodadaCenario.CenarioSimulacao.FatosRelavantes.ForEach(delegate(FatoRelevante fatoRelevante)
                                {
                                    var _precoInicialSimulacao = (from preco in _papeisPrecosIniciaisSimulacao
                                                                  where (preco.CodigoPapel.Equals(fatoRelevante.Papel.Codigo))
                                                                  select preco).FirstOrDefault<TOPrecoPapelAgendamento>();

                                    if (_precoInicialSimulacao != null)
                                        fatoRelevante.Papel.PrecoCompraInicial = _precoInicialSimulacao.ValorPrecoPapel;
                                });
                        }
                    });
                }
            });
        }

        private void PreencherAgregacaoAgendaGrupoRodadas(ref List<AgendaSimulacao> agendaSimulacao, List<TOVinculoAgendaRodadaGrupoEscolar> toVinculoAgendaRodadaGrupoEscolar)
        {
            agendaSimulacao.ForEach(delegate(AgendaSimulacao agenda)
            {
                var _vinculos = toVinculoAgendaRodadaGrupoEscolar.Where(v => v.CodigoAgendaSimulacao == agenda.Codigo).ToList<TOVinculoAgendaRodadaGrupoEscolar>();
                agenda.AgendaSimulacaoRodadas = new List<AgendaSimulacaoRodadas>();
                foreach (TOVinculoAgendaRodadaGrupoEscolar vinculo in _vinculos)
                {
                    agenda.AgendaSimulacaoRodadas.Add(new AgendaSimulacaoRodadas()
                    {
                        GrupoEscolar = new GrupoEscolar() { Codigo = vinculo.CodigoGrupoEscolar },
                        Rodada = BCConfiguracaoRodada.FindByKey(vinculo.CodigoRodada),
                        ContadorRodadaContingencia = vinculo.ContadorRodadaContingencia,
                        IndicadorSimulacaoConcluida = vinculo.IndicadorSimulacaoConcluida
                    });
                }
            });
        }

        //private void PreencherAgregacaoAgendaGrupoRodadas(ref List<AgendaSimulacao> agendaSimulacao, List<TOVinculoRodadaCenarioSimulacao> toVinculoRodadaCenarioSimulacao)
        //{
        //    agendaSimulacao.ForEach(delegate(AgendaSimulacao agenda)
        //    {
        //        var _vinculos = toVinculoRodadaCenarioSimulacao.Where(v => v.CodigoAgendaSimulacao == agenda.Codigo).ToList<TOVinculoRodadaCenarioSimulacao>();
        //        agenda.AgendaSimulacaoRodadas = new List<AgendaSimulacaoRodadas>();
        //        foreach (TOVinculoRodadaCenarioSimulacao vinculo in _vinculos)
        //        {
        //            agenda.AgendaSimulacaoRodadas.Add(new AgendaSimulacaoRodadas()
        //            {
        //                GrupoEscolar = new GrupoEscolar() { Codigo = vinculo.CodigoGrupoEscolar },
        //                Rodada = BCConfiguracaoRodada.FindByKey(vinculo.CodigoRodada), 
        //                //ContadorRodadaContingencia = (short)vinculo.CodigoAgendaSimulacao
        //            });
        //        }
        //    });
        //}

        #endregion

        #region | Sorteio Automátivo e Manual

        /// <summary>
        /// Inicializa/Reseta o estado dos campos para Sorteio
        /// </summary>
        private void InicializarCamposSorteio()
        {
            _cenariosRodadas = null;
            _cenariosPrincipais = null;
            _cenariosSelecionados = null;
            _gruposClassificados = null;
            _agendaSimulacaoExistente = null;
            _vinculosAgendaRodadaGrupoEscolar = null;
            _cenariosSimulacao = null;
            _cenariosPositivos = null;
            _cenariosNegativos = null;
            _camposSorteioInicializados = false;
        }

        /// <summary>
        /// Obtêm a Lista de Todas as Agendas Disponíveis
        /// </summary>
        /// <returns></returns>
        /// <remarks>Método Auxiliar para o Processo do Sorteio</remarks>
        private List<AgendaSimulacao> ObterAgendas()
        {

            //LogManager.Trace(nomeMetodoLog, "Selecionado Agendas de Simulação");
            var agendaSimulacaoExistente = FindAll().OrderBy(agenda => agenda.Codigo).ToList<AgendaSimulacao>();
            //LogManager.Trace(nomeMetodoLog, "Agendas Simulação Selecionadas!");

            agendaSimulacaoExistente.ForEach(delegate(AgendaSimulacao agenda)
            {
                //Obtêm os dados da parâmetrização da Agenda                
                agenda.ParametrizacaoAgenda = BCConfiguracaoParametroAgenda.FindByKey(agenda.ParametrizacaoAgenda.Codigo);

            });
            return agendaSimulacaoExistente;
        }

        /// <summary>
        /// Obtêm a lista de Grupos Classificados das Escolas Informadas
        /// </summary>
        /// <param name="escolas">Lista de Escolas para Extração dos Grupos</param>
        /// <param name="considerarSorteioPendente">Indicador para Computar Escolas Pendentes de Sorteio ou Não</param>
        /// <returns></returns>
        /// <remarks>Método Auxiliar para o Processo do Sorteio</remarks>
        private List<GrupoEscolar> ObterGruposEscolares(List<Escola> escolas,
                                                        bool considerarSorteioPendente)
        {
            string nomeMetodoLog = "BCAgendaSimulacaoImpl.ObterGruposEscolares";

            List<GrupoEscolar> gruposClassificados = new List<GrupoEscolar>();

            //var gruposDao = Desafio.Simulador.Bcl.Competidor.Impl.Dao.GrupoEscolarDAO.GetInstance();

            foreach (Escola escola in escolas)
            {
                if (considerarSorteioPendente)
                {
                    if (escola.TipoStatusSorteioCenarios == TipoStatusSorteioCenarios.OK)
                    {
                        continue;
                    }
                }
                //Filtrar grupos por escolas informadas (parâmetro)
                //var grupos = gruposDao.FindGruposEcolaresByEscola(escola.Codigo);
                //LogManager.Trace(nomeMetodoLog, "Grupos da Escola Codigo:[{0}], CodigoLMS:[{1}] selecionados", escola.Codigo, escola.CodigoOriginalLMS);

                //if (grupos != null)
                if (escola.GruposEscolares != null)
                {
                    //Filtrar grupos classificados 
                    //gruposClassificados.AddRange(grupos.Where(grupo => grupo.IndicadorGrupoDesclassificado == false));
                    gruposClassificados.AddRange(escola.GruposEscolares.Where(grupo => grupo.IndicadorGrupoDesclassificado == false));
                    LogManager.Trace(nomeMetodoLog, "Grupos Classificados da Escola Codigo:[{0}], CodigoLMS:[{1}] selecionados", escola.Codigo, escola.CodigoOriginalLMS);
                }
                else
                {
                    LogManager.Trace(nomeMetodoLog, "Não existem grupos para a escola Codigo:[{0}], CodigoLMS:[{1}] informada!", escola.Codigo, escola.CodigoOriginalLMS);
                }
            }

            if (gruposClassificados.Count == 0)
            {
                //TODO:Implementar Tratamento para caso não existam grupos?
                LogManager.Trace(nomeMetodoLog, "Não existem grupos classificados para seleção!");
            }

            return gruposClassificados.OrderBy(grupo => grupo.Codigo).ToList<GrupoEscolar>(); ;
        }

        /// <summary>
        /// Obtêm/Agrupa os Cenários com Rentabilidade Média Positiva
        /// </summary>
        /// <returns></returns>
        /// <remarks>Método Auxiliar para o Processo do Sorteio</remarks>
        private List<CenarioSimulacao> ObterCenariosPositivos()
        {
            if (_cenariosPositivos != null)
            {
                return _cenariosPositivos;
            }
            else
            {
                return _cenariosSimulacao.Where(c => c.ValorRentabilidadeMedia >= 0).OrderBy(cenario => cenario.Codigo).ToList<CenarioSimulacao>();
            }
        }

        /// <summary>
        /// Obtêm/Agrupa os Cenários com Rentabilidade Média Negativa
        /// </summary>
        /// <returns></returns>
        /// <remarks>Método Auxiliar para o Processo do Sorteio</remarks>
        private List<CenarioSimulacao> ObterCenariosNegativos()
        {
            if (_cenariosNegativos != null)
            {
                return _cenariosNegativos;
            }
            else
            {
                return _cenariosSimulacao.Where(c => c.ValorRentabilidadeMedia < 0).OrderBy(cenario => cenario.Codigo).ToList<CenarioSimulacao>();
            }
        }

        /// <summary>
        /// Filtra as Agenda de Simulação por Grupo e Semana
        /// </summary>
        /// <param name="agendas">Lista de Agendas de Simulação para aplicar o Filtros</param>
        /// <param name="vinculos">Vinculos entre Agendas, Rodadas e Grupos</param>
        /// <param name="grupos">Lista de Grupos para filtro</param>
        /// <param name="tipoSemana">Tipo de Semana para Filtro</param>
        /// <returns></returns>
        /// <remarks>Método Principal do Sorteio</remarks>
        private List<AgendaSimulacao> FiltrarAgendasPorGrupoSemana(List<AgendaSimulacao> agendas,
                                                                   List<TOVinculoAgendaRodadaGrupoEscolar> vinculos,
                                                                   List<GrupoEscolar> grupos,
                                                                   TipoSemanaSimulacao tipoSemana)
        {
            string nomeMetodoLog = "BCAgendaSimulacaoImpl.FiltrarAgendasPorGrupoSemana";

            LogManager.InicioMetodo(nomeMetodoLog, tipoSemana);

            //Filtra Agendas por Semana
            var agendaSemana = agendas.Where(ag => ag.TipoSemanaSimulacao == tipoSemana).ToList<AgendaSimulacao>();
            this.PreencherAgregacaoAgendaGrupoRodadas(ref agendaSemana, vinculos);

            //Filtra Agenda da Semana por Grupos Selecionados e Classificados
            var agendaSemanaFiltro = new List<AgendaSimulacao>();
            agendaSemana.ForEach(delegate(AgendaSimulacao agenda)
            {
                agenda.AgendaSimulacaoRodadas.ForEach(delegate(AgendaSimulacaoRodadas agendaRodada)
                {
                    grupos.ForEach(delegate(GrupoEscolar grupo)
                    {
                        if (agendaRodada.GrupoEscolar.Codigo == grupo.Codigo &&
                           !agendaSemanaFiltro.Contains(agenda))
                        {
                            agendaSemanaFiltro.Add(agenda);
                        }
                    });
                });
            });

            LogManager.FimMetodo(nomeMetodoLog);

            return agendaSemanaFiltro;
        }

        /// <summary>
        /// Sorteia os cenários para todas as Rodadas
        /// </summary>
        /// <remarks>Método Secundário do Sorteio</remarks>
        private void SortearCenariosRodadas()
        {
            List<CenarioSimulacao> cenariosRodada;
            bool indicadorSelecaoDuplicados;

            string nomeMetodoLog = "BCAgendaSimulacaoImpl.SortearCenariosRodadas";
            LogManager.InicioMetodo(nomeMetodoLog);

            //TODO: Verificar mecanismo para recuparação de vinculos pré-existentes
            //RecuperarVinculosCenariosRodadas();                    

            LogManager.Trace(nomeMetodoLog, "Selecionando Cenários para Rodadas");

            _cenariosRodadas = new Dictionary<int, List<CenarioSimulacao>>();
            _cenariosRodadas.Add(1, new List<CenarioSimulacao>());
            _cenariosRodadas.Add(2, new List<CenarioSimulacao>());
            _cenariosRodadas.Add(3, new List<CenarioSimulacao>());
            _cenariosRodadas.Add(4, new List<CenarioSimulacao>());

            //Sorteio dos Cenários para 1º Rodada
            if (_cenariosRodadas[1].Count < 3)
            {
                _cenariosRodadas[1] = new List<CenarioSimulacao>();
                cenariosRodada = new List<CenarioSimulacao>();
                indicadorSelecaoDuplicados = (_cenariosPositivos.Count < 3);
                SortearCenariosRodada(null, _cenariosPositivos, ref cenariosRodada, indicadorSelecaoDuplicados);
                _cenariosRodadas[1] = cenariosRodada;
            }

            //Sorteio dos Cenários para 2º Rodada
            if (_cenariosRodadas[2].Count < 3)
            {
                _cenariosRodadas[2] = new List<CenarioSimulacao>();
                cenariosRodada = new List<CenarioSimulacao>();
                indicadorSelecaoDuplicados = (_cenariosNegativos.Count < 3);
                SortearCenariosRodada(null, _cenariosNegativos, ref cenariosRodada, indicadorSelecaoDuplicados);
                _cenariosRodadas[2] = cenariosRodada;
            }

            //Sorteio dos Cenários para 3º Rodada
            if (_cenariosRodadas[3].Count < 3)
            {
                _cenariosRodadas[3] = new List<CenarioSimulacao>();
                cenariosRodada = new List<CenarioSimulacao>();
                indicadorSelecaoDuplicados = (_cenariosPositivos.Count < 3 * 2);
                SortearCenariosRodada(null, _cenariosPositivos, ref cenariosRodada, indicadorSelecaoDuplicados);
                _cenariosRodadas[3] = cenariosRodada;
            }

            //Sorteio dos Cenários para 4º Rodada
            if (_cenariosRodadas[4].Count < 3)
            {
                _cenariosRodadas[4] = new List<CenarioSimulacao>();
                cenariosRodada = new List<CenarioSimulacao>();
                indicadorSelecaoDuplicados = (_cenariosPositivos.Count < 3 * 3);
                SortearCenariosRodada(null, _cenariosPositivos, ref cenariosRodada, indicadorSelecaoDuplicados);
                _cenariosRodadas[4] = cenariosRodada;
            }

            LogManager.Trace(nomeMetodoLog, "Cenários para Rodadas Selecionados!");
        }

        /// <summary>
        /// Imprime a Lista de Cenários Sorteados para Cada Rodada 
        /// </summary>    
        private void ImprimirCenariosSorteados()
        {
            string nomeMetodoLog = "BCAgendaSimulacaoImpl.ImprimirCenariosSorteados";
            LogManager.InicioMetodo(nomeMetodoLog);

            LogManager.Trace(nomeMetodoLog, "***** Cenários Sorteados *****");
            for (int idxRodada = 1; idxRodada <= 4; idxRodada++)
            {
                LogManager.Trace(nomeMetodoLog, "[Rodada {0}]", idxRodada);
                if (_cenariosRodadas != null &&
                    _cenariosRodadas.ContainsKey(idxRodada))
                {
                    foreach (CenarioSimulacao cenario in _cenariosRodadas[idxRodada])
                    {
                        LogManager.Trace(nomeMetodoLog, cenario.Codigo.ToString());
                    }
                }
                else
                {
                    LogManager.Trace(nomeMetodoLog, "Não foram sorteados");
                }
            }
            LogManager.Trace(nomeMetodoLog, "***** Cenários Sorteados *****");
            LogManager.FimMetodo(nomeMetodoLog);
        }

        ///// <summary>
        ///// Recupera Vinculos entre Rodadas e Cenários sorteados anteriormente
        ///// </summary>
        //private void RecuperarVinculosCenariosRodadas()
        //{
        //    //Valida Vinculos Pré-Existentes                                        
        //    //Com AnonymousType não funciona, pois os membros são read only
        //    //var cenariosExistentes = new[] {
        //    //                                new {PrincipalSelecionado=false,Conntigencias=0},
        //    //                                new {PrincipalSelecionado=false,Conntigencias=0},
        //    //                                new {PrincipalSelecionado=false,Conntigencias=0},
        //    //                                new {PrincipalSelecionado=false,Conntigencias=0}
        //    //                             };
        //    Dictionary<int, int[]> cenariosExistentes = new Dictionary<int, int[]>();
        //    cenariosExistentes[0] = new int[2] { 0, 0 };
        //    cenariosExistentes[1] = new int[2] { 0, 0 };
        //    cenariosExistentes[2] = new int[2] { 0, 0 };
        //    cenariosExistentes[3] = new int[2] { 0, 0 };

        //    _cenariosRodadas = new Dictionary<int, List<CenarioSimulacao>>();
        //    _cenariosRodadas.Add(1, new List<CenarioSimulacao>());
        //    _cenariosRodadas.Add(2, new List<CenarioSimulacao>());
        //    _cenariosRodadas.Add(3, new List<CenarioSimulacao>());
        //    _cenariosRodadas.Add(4, new List<CenarioSimulacao>());

        //    var vinculos = this.SelecionarVinculosAgendasCenariosGrupo();
        //    bool vinculoGrupoSelecionado = false;

        //    foreach (TOVinculoRodadaCenarioSimulacao vinculo in vinculos)
        //    {
        //        //Filtra os vinculos dos grupos selecionados
        //        vinculoGrupoSelecionado = false;
        //        foreach (GrupoEscolar grupo in _gruposClassificados)
        //        {
        //            if (vinculo.CodigoGrupoEscolar == grupo.Codigo)
        //            {
        //                vinculoGrupoSelecionado = true;
        //                break;
        //            }
        //        }

        //        if (vinculoGrupoSelecionado)
        //        {
        //            var rodada = this.BCConfiguracaoRodada.FindByKey(vinculo.CodigoRodada);
        //            var cenario = this.BCConfiguracaoCenarios.FindByKey(vinculo.CodigoCenario);

        //            if (_cenariosRodadas[rodada.IdentificadorRodada].Count < 3)
        //            {
        //                if (!vinculo.IndicadorCenarioContingencia &&
        //                    cenariosExistentes[rodada.IdentificadorRodada - 1][0] == 0)
        //                {
        //                    _cenariosRodadas[rodada.IdentificadorRodada].Add(cenario);
        //                    _cenariosPrincipais.Add(cenario.Codigo);
        //                    _cenariosSelecionados.Add(cenario.Codigo);
        //                    cenariosExistentes[rodada.IdentificadorRodada - 1][0] = 1;
        //                }
        //                else
        //                {
        //                    if (cenariosExistentes[rodada.IdentificadorRodada - 1][1] < 2)
        //                    {
        //                        _cenariosRodadas[rodada.IdentificadorRodada].Add(cenario);
        //                        _cenariosSelecionados.Add(cenario.Codigo);
        //                        cenariosExistentes[rodada.IdentificadorRodada - 1][1] = cenariosExistentes[rodada.IdentificadorRodada - 1][1]++;
        //                    }
        //                }
        //            }
        //        }

        //        if (_cenariosRodadas[1].Count >= 3 &&
        //            _cenariosRodadas[2].Count >= 3 &&
        //            _cenariosRodadas[3].Count >= 3 &&
        //            _cenariosRodadas[4].Count >= 3) break;
        //    }
        //}

        /// <summary>
        /// Sorteio os cenários para uma Rodada
        /// </summary>
        /// <param name="cenariosSorteio"></param>
        /// <returns></returns>
        /// <remarks>Método Principal do Sorteio</remarks>
        private void SortearCenariosRodada(CenarioSimulacao principal,
                                           List<CenarioSimulacao> cenariosSorteio,
                                           ref List<CenarioSimulacao> cenariosRodada,
                                           bool indicadorSelecaoDuplicados)
        {
            string nomeMetodoLog = "BCAgendaSimulacaoImpl.SortearCenariosRodada";

            LogManager.InicioMetodo(nomeMetodoLog, indicadorSelecaoDuplicados);

            CenarioSimulacao cenarioPrincipal = null;

            //Campos para validação RN3 - Semelhança entre cenários
            double rentabilidadeCenarioPrincipal = 0;
            double rentabilidadeCenarioAtual = 0;
            double deltaDiferencaRetanbilidades = 0;

            if (_cenariosSelecionados == null)
                _cenariosSelecionados = new List<int>();

            if (cenariosRodada == null)
                cenariosRodada = new List<CenarioSimulacao>();

            if (_cenariosPrincipais == null)
                _cenariosPrincipais = new List<int>();

            //Considera Cenário Principal Anteriormente Selecionado na Recursividade
            if (principal != null)
            {
                cenarioPrincipal = principal;
                rentabilidadeCenarioPrincipal = Convert.ToDouble(cenarioPrincipal.ValorRentabilidadeMedia);

                if (!cenariosRodada.Contains(cenarioPrincipal)) cenariosRodada.Add(cenarioPrincipal);
                if (!_cenariosSelecionados.Contains(cenarioPrincipal.Codigo)) _cenariosSelecionados.Add(cenarioPrincipal.Codigo);
                if (!_cenariosPrincipais.Contains(cenarioPrincipal.Codigo)) _cenariosPrincipais.Add(cenarioPrincipal.Codigo);
            }
            //Não pode ser implementado, pois não existem cenários suficientes 
            //else //Sortear o Cenário Principal Aleatoriamente
            //{                        
            //int contador=0;
            //while (cenarioPrincipal == null || contador >= cenariosSorteio.Count)
            //{
            //    Random rnd = new Random();
            //    var indiceCenarioPrincipal = rnd.Next(0, cenariosSorteio.Count - 1);
            //    var cenarioSorteado = cenariosSorteio[indiceCenarioPrincipal];

            //    if (
            //        (!_cenariosSelecionados.Contains(cenarioSorteado.Codigo) && !_cenariosPrincipais.Contains(cenarioSorteado.Codigo)) || 
            //        indicadorSelecaoDuplicados)
            //    {
            //        cenarioPrincipal = cenarioSorteado;
            //    }

            //    contador++;
            //}                        

            //if (indicadorSelecaoDuplicados)
            //{
            //    GerenciadorExcecao.TratarExcecao(new Exception("Não existem cenários suficientes para seleção do cenário principal!"));
            //}
            //}

            //Implementação da RN1 a RN4
            foreach (CenarioSimulacao cenario in cenariosSorteio.OrderBy(c => c.Codigo).ToList<CenarioSimulacao>())
            {
                //seleção do cenário principal
                if (
                     cenarioPrincipal == null &&
                     (!_cenariosSelecionados.Contains(cenario.Codigo) || indicadorSelecaoDuplicados) &&
                     !_cenariosPrincipais.Contains(cenario.Codigo) &&
                     cenario.ValorRentabilidadeMedia != 0
                    )
                { //Validação da Regra definida em "Relacionamentos Simulação Rodadas e Cenários"
                    cenarioPrincipal = cenario;
                    rentabilidadeCenarioPrincipal = Convert.ToDouble(cenario.ValorRentabilidadeMedia);
                    cenariosRodada.Add(cenario);
                    _cenariosSelecionados.Add(cenario.Codigo);
                    _cenariosPrincipais.Add(cenario.Codigo);

                    LogManager.Trace(nomeMetodoLog, "Cenário Principal [{0}] selecionado!", cenario.Codigo);
                }
                //seleção dos cenários de contingência
                else
                {
                    //Obtêm dados para cálculo da semelhança entre o cenário principal
                    rentabilidadeCenarioAtual = Convert.ToDouble(cenario.ValorRentabilidadeMedia);
                    deltaDiferencaRetanbilidades = (rentabilidadeCenarioPrincipal - rentabilidadeCenarioAtual) / rentabilidadeCenarioPrincipal;

                    //Valida RN1, RN3 e RN4
                    if (
                        //(deltaDiferencaRetanbilidades >= -0.03 && deltaDiferencaRetanbilidades <= 0.03) && //RN3 (rentabilidade semelhante)
                        ((!cenariosRodada.Contains(cenario) && !_cenariosSelecionados.Contains(cenario.Codigo)) || indicadorSelecaoDuplicados) //RN1 e RN4 (não repetidos)                        
                       )
                    {
                        //Validação RN1 e RN4 (não consecutivos)
                        foreach (CenarioSimulacao cenarioRodada in cenariosRodada.ToList<CenarioSimulacao>())
                        {
                            TimeSpan ts = new DateTime(cenarioPrincipal.AnoReferencia, cenarioPrincipal.MesReferencia, 1) -
                                          new DateTime(cenario.AnoReferencia, cenario.MesReferencia, 1);
                            if (Math.Abs(ts.Days) > 30 &&
                                (!cenariosRodada.Contains(cenario))) //RN1 e RN4 || indicadorSelecaoDuplicados
                            {
                                cenariosRodada.Add(cenario);
                                _cenariosSelecionados.Add(cenario.Codigo);
                                LogManager.Trace(nomeMetodoLog, "Cenário de Contingência [{0}] selecionado!", cenario.Codigo);
                            }
                        }
                    }
                }

                //Cenários Selecionados?
                //Dúvida: Verificar se o número de rodadas não deve ser um parâmetro
                //        Ex: AgendaSimulacao.ParametrizacaoAgenda.QuantidadeRodadas
                if (cenariosRodada.Count == 3)
                {
                    LogManager.Trace(nomeMetodoLog, "3 cenários selecionados. Sucesso!");
                    break;
                }
            }

            //Caso não existam cenários suficentes, pode selecionar duplicados
            if (cenariosRodada.Count < 3 &&
                indicadorSelecaoDuplicados == false)
            {
                LogManager.Trace(nomeMetodoLog, "Não existem cenários suficientes para seleção. Selecionando cenários duplicados");
                //No momento só realiza uma chamada recursiva, pois devemos definir a
                //regra finalizar a recursividade (else abaixo)
                SortearCenariosRodada(cenarioPrincipal, cenariosSorteio, ref cenariosRodada, true);
            }
            else
            {
                if (indicadorSelecaoDuplicados)
                {
                    //TODO: Deve realizar tratamento para condição de não possuir cenários suficientes ou só logar o erro
                    LogManager.Trace(nomeMetodoLog, "Não existem cenários suficientes para seleção. Fim da Seleção");
                    return;
                }
            }

            LogManager.FimMetodo(nomeMetodoLog);
        }

        /// <summary>
        /// Realiza o embaralhamento dos Cenários nas Agendas Informadas atribuindo
        /// cenários sorteados aleatóriamente ao agendamentos para cada rodada
        /// </summary>
        /// <param name="agendas">Lista de Agendas para Embaralhamento</param>
        /// <remarks>Método Principal do Sorteio. Esse método possui a </remarks>
        private void EmbaralharCenarios(ref List<AgendaSimulacao> agendas)
        {
            string nomeMetodoLog = "BCAgendaSimulacaoImpl.EmbaralharCenarios";

            LogManager.Trace(nomeMetodoLog, "Embaralhando Cenários!");

            if (_cenariosRodadas == null || _cenariosRodadas.Count <= 0)
            {
                //TODO:Implementar tratamento de erro
                LogManager.Trace(nomeMetodoLog, "Não existem cenários para sorteio");
            }

            //TODO: Filtar Grupos Já Atribuidos? Ou sobreescrevê-los.

            Dictionary<int, List<CenarioSimulacao>> cenariosRodadas;

            //Para cada agenda
            foreach (AgendaSimulacao agenda in agendas)
            {
                //Para cada Rodada
                foreach (AgendaSimulacaoRodadas agendaRodada in agenda.AgendaSimulacaoRodadas)
                {
                    int numeroCenarios;
                    CenarioSimulacao cenario;
                    Random rndCenario;
                    int indiceCenario;
                    StringBuilder textoLog;

                    cenariosRodadas = new Dictionary<int, List<CenarioSimulacao>>();
                    foreach (int key in _cenariosRodadas.Keys)
                    {
                        cenariosRodadas.Add(key, new List<CenarioSimulacao>());
                        foreach (CenarioSimulacao cenarioLista in _cenariosRodadas[key])
                        {
                            cenariosRodadas[key].Add(cenarioLista);
                        }
                    }

                    textoLog = new StringBuilder();
                    textoLog = textoLog.AppendFormat("Código Agendamento [{0}], Código Rodada [{1}], Id Rodada [{2}], Grupo [{3}], Semana [{4}]",
                                                     agenda.Codigo,
                                                     agendaRodada.Rodada.Codigo,
                                                     agendaRodada.Rodada.IdentificadorRodada,
                                                     agendaRodada.GrupoEscolar.Codigo,
                                                     agenda.TipoSemanaSimulacao);

                    LogManager.Trace(nomeMetodoLog, "Embaralhando cenários para " + textoLog);

                    if (agendaRodada.RodadaCenario == null)
                        agendaRodada.RodadaCenario = new List<RodadaCenario>();

                    //Cenário Principal
                    if (cenariosRodadas.Count == 0 ||
                       !cenariosRodadas.ContainsKey(agendaRodada.Rodada.IdentificadorRodada))
                    {
                        numeroCenarios = 0;
                    }
                    else
                    {
                        numeroCenarios = cenariosRodadas[agendaRodada.Rodada.IdentificadorRodada].Count;
                    }

                    if (numeroCenarios > 0)
                    {
                        rndCenario = new Random();
                        indiceCenario = rndCenario.Next(0, numeroCenarios);
                        cenario = cenariosRodadas[agendaRodada.Rodada.IdentificadorRodada][indiceCenario];

                        agendaRodada.RodadaCenario.Add(
                            new RodadaCenario()
                            {
                                CenarioSimulacao = cenario,
                                IndicadorCenarioContingencia = false
                            }
                        );

                        cenariosRodadas[agendaRodada.Rodada.IdentificadorRodada].RemoveAt(indiceCenario);
                        LogManager.Trace(nomeMetodoLog, "Cenário Principal Embaralhado. Cenário Selecionado [{0}]", cenario.Codigo);
                    }
                    else
                    {
                        LogManager.Trace(nomeMetodoLog, "Não existem cenários suficientes para atribuir o Cenário Principal, para Rodada");// {1}", agendaRodada.Rodada.Codigo);
                    }

                    //Cenário Contingência 1
                    if (cenariosRodadas.Count == 0 ||
                       !cenariosRodadas.ContainsKey(agendaRodada.Rodada.IdentificadorRodada))
                    {
                        numeroCenarios = 0;
                    }
                    else
                    {
                        numeroCenarios = cenariosRodadas[agendaRodada.Rodada.IdentificadorRodada].Count;
                    }
                    if (numeroCenarios > 0)
                    {
                        rndCenario = new Random();
                        indiceCenario = rndCenario.Next(0, numeroCenarios);
                        cenario = cenariosRodadas[agendaRodada.Rodada.IdentificadorRodada][indiceCenario];

                        agendaRodada.RodadaCenario.Add(
                            new RodadaCenario()
                            {
                                CenarioSimulacao = cenario,
                                IndicadorCenarioContingencia = true
                            }
                        );

                        cenariosRodadas[agendaRodada.Rodada.IdentificadorRodada].RemoveAt(indiceCenario);
                        LogManager.Trace(nomeMetodoLog, "Cenário Contingência 1 Embaralhado. Cenário Selecionado [{0}]", cenario.Codigo);
                    }
                    else
                    {
                        LogManager.Trace(nomeMetodoLog, "Não existem cenários suficientes para atribuir o Cenário de Contingência {0}, para Rodada {1}", 1, agendaRodada.Rodada.Codigo);
                    }

                    //Cenário Contingência 2                            
                    if (cenariosRodadas.Count == 0 ||
                       !cenariosRodadas.ContainsKey(agendaRodada.Rodada.IdentificadorRodada))
                    {
                        numeroCenarios = 0;
                    }
                    else
                    {
                        numeroCenarios = cenariosRodadas[agendaRodada.Rodada.IdentificadorRodada].Count;
                    }
                    if (numeroCenarios > 0)
                    {
                        rndCenario = new Random();
                        indiceCenario = rndCenario.Next(0, numeroCenarios);
                        cenario = cenariosRodadas[agendaRodada.Rodada.IdentificadorRodada][indiceCenario];

                        agendaRodada.RodadaCenario.Add(
                            new RodadaCenario()
                            {
                                CenarioSimulacao = cenario,
                                IndicadorCenarioContingencia = true
                            }
                        );

                        cenariosRodadas[agendaRodada.Rodada.IdentificadorRodada].RemoveAt(indiceCenario);

                        LogManager.Trace(nomeMetodoLog, "Cenário Contingência 2 Embaralhado. Cenário Selecionado [{0}]", cenario.Codigo);
                    }
                    else
                    {
                        LogManager.Trace(nomeMetodoLog, "Não existem cenários suficientes para atribuir o Cenário de Contingência {0}, para Rodada {1}", 2, agendaRodada.Rodada.Codigo);
                    }

                    //Sleep adicionado para que o geração de números aleatórios funcione melhor, pois o mesmo trabalha com o clock do relógio
                    //e sem o sleep estava sorteando sempre os mesmos cenários para todas as rodadas
                    //Os testes demonstraram que 10ms foram suficientes para o mecanismo de geração de números aleatórios funcionassem
                    //Além disso 10ms para cada agenda, não impoe impacto significativo no tempo de resposta do sorteio.
                    //Ex: Para cada 100 agendas, será adicionado 1 segundo.
                    //    Assumindo que o sorteio seja realizado para 20 grupos, 4 semanas, 4 Rodadas com datas de simulaçõ distintas
                    //    temos 20 x 4 x 4 = 320 agendas, ou 3,2 segundos de impacto 
                    System.Threading.Thread.Sleep(10);
                }
            }
        }

        private void ValidarIndicadorSorteioEscolas(ref List<Escola> escolasPendente)
        {
            //Obter todos os Vinculos de Agendamentos/Cenarios/Grupos            
            //var vinculos = SelecionarVinculosAgendasCenariosGrupo();
            bool indicadorEscolaPendente = false;
            indicadorEscolaPendente = false;

            foreach (Escola escola in escolasPendente)
            {
                foreach (GrupoEscolar grupo in escola.GruposEscolares)
                {
                    var agendas = this.ListarAgendaSimulacaoGrupoEscolar(grupo.Codigo);

                    //PreencherAgregacaoAgendaGrupoRodadas(ref agendas, vinculos);

                    foreach (AgendaSimulacao agenda in agendas)
                    {
                        //Verificar se todos os agendamentos disponíveis foram vinculados                                                
                        foreach (AgendaSimulacaoRodadas agendaRodada in agenda.AgendaSimulacaoRodadas)
                        {
                            /*var vinculosGrupo = vinculos.Where(vinculo => vinculo.CodigoGrupoEscolar == grupo.Codigo &&
                                                                          vinculo.CodigoAgendaSimulacao == agenda.Codigo &&
                                                                          vinculo.CodigoRodada == agendaRodada.Rodada.Codigo);*/
                            
                            //Verifica se formam vinculados 3 cenários (1 principal + 2 contingencia) 
                            //if (vinculosGrupo == null || vinculosGrupo.Count<TOVinculoRodadaCenarioSimulacao>() < 3)
                            if (agendaRodada.RodadaCenario == null || agendaRodada.RodadaCenario.Count<RodadaCenario>() < 3)
                            {
                                indicadorEscolaPendente = true;
                            }
                            else
                            {
                                //TODO:Logar se não existe
                            }

                            if (indicadorEscolaPendente) break;
                        }

                        if (indicadorEscolaPendente) break;
                    }

                    if (indicadorEscolaPendente) break;
                }

                //Se todos os agendamentos de todos os grupos das escolas foram vinculados
                //atualizar o status da escola para OK, caso contrário atualizar para pendente    
                escola.TipoStatusSorteioCenarios = indicadorEscolaPendente ? TipoStatusSorteioCenarios.Pendente : TipoStatusSorteioCenarios.OK;
            }
        }

        /*private List<TOVinculoRodadaCenarioSimulacao> SelecionarVinculosAgendasCenariosGrupo()
        {
            return VinculoRodadaCenarioSimulacaoDAO.GetInstance().FindAll();
        }*/

        /*private List<TOVinculoRodadaCenarioSimulacao> SelecionarVinculosAgendasCenariosGrupo(int codigoGrupoEscolar, int codigoAgenda, int codigoRadada)
        {
            return VinculoRodadaCenarioSimulacaoDAO.GetInstance().FindVinculosAgendaGrupoRodada(codigoGrupoEscolar, codigoAgenda, codigoRadada);
        }*/

        #endregion

        #endregion        
    }
}
