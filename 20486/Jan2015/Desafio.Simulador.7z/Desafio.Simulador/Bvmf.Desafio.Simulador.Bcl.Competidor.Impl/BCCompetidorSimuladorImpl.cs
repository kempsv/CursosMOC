﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Competidor.Interfaces;
using Desafio.Simulador.Bcl.Competidor.Impl.Dao;
using Desafio.Simulador.Bcl.Competidor.Entidade;
using Desafio.Simulador.Bcl.Core.Domain.Enum;

namespace Desafio.Simulador.Bcl.Competidor.Impl
{
    public class BCCompetidorSimuladorImpl : BCCompetidorSimulador
    {
        public BCCompetidorSimuladorImpl(CompetidorSimuladorDAO competidorSimuladorDAO) 
        {
            _persistence = competidorSimuladorDAO;
        }

        private void PreencherAgregacao(List<CompetidorSimulador> entities)
        {
            entities.ForEach(delegate(CompetidorSimulador competidor)
            {
                this.PreencherAgregacao(competidor);
            });
        }

        private void PreencherAgregacao(CompetidorSimulador entity)
        {
            if (null != entity)
            {
                entity.GrupoEscolar = GrupoEscolarDAO.GetInstance().FindByKey(entity.GrupoEscolar.Codigo);

                #region Telefones do Competidor
                var _telefones = TelefoneCompetidorDAO.GetInstance().FindTelefonesByCompetidor(entity.Codigo);
                entity.Telefones = new List<Telefone>();
                _telefones.ForEach(delegate(TOTelefoneCompetidor toTelefone)
                {
                    //Obtêm dados do telefone
                    var _toTelefoneCompetidor = TelefoneDAO.GetInstance().FindByKey(toTelefone.CodigoTelefone);

                    var _telefoneCompetidor = new Telefone()
                    {
                        Codigo = _toTelefoneCompetidor.CodigoTelefone,
                        NomeContato = _toTelefoneCompetidor.NomeContato,
                        Numero = _toTelefoneCompetidor.NumeroTelefone
                    };

                    //
                    // Código do Switch fazem referência a tabela no banco
                    //
                    switch (_toTelefoneCompetidor.CodigoTipoTelefone)
                    {
                        //TipoTelefone.Residencial
                        case 1:
                            _telefoneCompetidor.TipoTelefone = TipoTelefone.Residencial;
                            break;
                        //TipoTelefone.Celular
                        case 2:
                            _telefoneCompetidor.TipoTelefone = TipoTelefone.Celular;
                            break;
                        //TipoTelefone.Comercial
                        case 3:
                            _telefoneCompetidor.TipoTelefone = TipoTelefone.Comercial;
                            break;
                        //TipoTelefone.Fax
                        case 4:
                            _telefoneCompetidor.TipoTelefone = TipoTelefone.Fax;
                            break;
                    }
                    entity.Telefones.Add(_telefoneCompetidor);
                });
                #endregion

                #region Documentos do Competidor
                var _documentos = DocumentoCompetidorDAO.GetInstance().FindDocumentosByCompetidor(entity.Codigo);
                entity.Documentos = new List<Documento>();
                _documentos.ForEach(delegate(TODocumentoCompetidor toDocumento)
                {
                    var _documento = new Documento()
                    {
                        Codigo = toDocumento.CodigoCompetidor,
                        NumeroDocumento = toDocumento.NumeroDocumento
                    };

                    //
                    // Código do Switch fazem referência a tabela no banco
                    //
                    switch (toDocumento.CodigoTipoDocumento)
                    {
                        //TipoDocumento.RG
                        case 1:
                            _documento.TipoDocumento = TipoDocumento.RG;
                            break;
                        //TipoDocumento.Passaporte
                        case 2:
                            _documento.TipoDocumento = TipoDocumento.Passaporte;
                            break;
                        //TipoDocumento.CPF
                        case 3:
                            _documento.TipoDocumento = TipoDocumento.CPF;
                            break;
                    }
                    entity.Documentos.Add(_documento);
                });
                #endregion
            }
        }

        public override List<CompetidorSimulador> ListarAlunosGrupoEscolar(int codigoGrupoEscolar)
        {
            List<CompetidorSimulador> _returnEntitie = ((CompetidorSimuladorDAO)this._persistence).ListarAlunosGrupoEscolar(codigoGrupoEscolar);

            this.PreencherAgregacao(_returnEntitie);

            return _returnEntitie;
        }

        public override CompetidorSimulador ObterProfessorByCodigoOrigemLMS(int codigoOrigemLMS)
        {
            var _returnEntitie = ((CompetidorSimuladorDAO)this._persistence).ObterProfessorByCodigoOrigemLMS(codigoOrigemLMS);

            this.PreencherAgregacao(_returnEntitie);

            return _returnEntitie;
        }

        public override CompetidorSimulador ObterProfessorGrupoEscolar(int codigoGrupoEscolar)
        {
            var _returnEntitie = ((CompetidorSimuladorDAO)this._persistence).ObterProfessorGrupoEscolar(codigoGrupoEscolar);

            this.PreencherAgregacao(_returnEntitie);

            return _returnEntitie;
        }

        public override CompetidorSimulador FindByKey(int key)
        {
            var _competidor = base.FindByKey(key);

            this.PreencherAgregacao(_competidor);

            return _competidor;
        }

        public override void Create(CompetidorSimulador entity)
        {
            //
            //Adicionar o Grupo Escolar
            //
            base.Create(entity);

            #region Adiciona os telefones do Competidor
            //
            //Obtêm os telefones relacionados do Competidor existente antes de excluir
            //
            var _telefonesRelacionados = TelefoneCompetidorDAO.GetInstance().FindAll().Where(cod => cod.CodigoCompetidor == entity.Codigo);

            //
            // Exclui os telefones relacionados do Competidor 
            //
            TelefoneCompetidorDAO.GetInstance().DeleteByCompetidor(entity.Codigo);

            //
            //Exclui todos os telefones existentes
            //
            _telefonesRelacionados.ToList<TOTelefoneCompetidor>().ForEach(delegate(TOTelefoneCompetidor toTelefoneCompetidor)
            {
                TelefoneDAO.GetInstance().Delete(new TOTelefone() { CodigoTelefone = toTelefoneCompetidor.CodigoTelefone });
            });

            //
            // Adiciona os novos telefones do Competidor
            //
            entity.Telefones.ForEach(delegate(Telefone telefone)
            {
                var _toNovoTelefoneEscola = new TOTelefone()
                {
                    CodigoTipoTelefone = (int)telefone.TipoTelefone,
                    NomeContato = telefone.NomeContato,
                    NumeroTelefone = telefone.Numero
                };
                // 
                // Adiciona os novo telefones da escola
                //
                TelefoneDAO.GetInstance().Create(_toNovoTelefoneEscola);
                // 
                // Relaciona os telefones adicionados à PK da Escola
                //
                TelefoneCompetidorDAO.GetInstance().Create(new TOTelefoneCompetidor()
                {
                    CodigoCompetidor = entity.Codigo,
                    CodigoTelefone = _toNovoTelefoneEscola.CodigoTelefone
                });
            });
            #endregion

            #region Adiciona os documentos do Competidor
            //
            //Exclui todos os documentos existentes
            //
            DocumentoCompetidorDAO.GetInstance().DeleteByCompetidor(entity.Codigo);

            //
            //Adiciona os novos documentos do Competidor
            //
            entity.Documentos.ForEach(delegate(Documento documento)
            {
                var _toDocumentoCompetidor = new TODocumentoCompetidor()
                {
                    CodigoCompetidor = entity.Codigo,
                    CodigoTipoDocumento = (int)documento.TipoDocumento,
                    NumeroDocumento = documento.NumeroDocumento
                };
                // 
                // Adiciona os novo telefones da escola
                //
                DocumentoCompetidorDAO.GetInstance().Create(_toDocumentoCompetidor);
            });
            #endregion

        }
    }
}
