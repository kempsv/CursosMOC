﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Competidor.Interfaces;
using Desafio.Simulador.Bcl.Competidor.Impl.Dao;
using Desafio.Simulador.Bcl.Core.Domain;
using Microsoft.Practices.Unity;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Rodada.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Parametros.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain.Enum;
using System.Transactions;
using Desafio.Simulador.Bcl.Competidor.Entidade;
using Desafio.Simulador.Util.Excecao;
//using Framework.Excecao;

namespace Desafio.Simulador.Bcl.Competidor.Impl
{
    public class BCEscolasSimuladorImpl : BCEscolasSimulador
    {
        #region Propriedade Injetadas
        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCConfiguracaoRodada BCConfiguracaoRodada { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCConfiguracaoParametroAgenda BCConfiguracaoParametroAgenda { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCAgendaSimulacao BCAgendaSimulacao { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCCompetidorSimulador BCCompetidorSimulador { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCGrupoEscolarSimulador BCGrupoEscolarSimulador { get; set; }
        #endregion

        public BCEscolasSimuladorImpl(EscolaDAO escolaDAO) 
        {
            _persistence = escolaDAO;
        }

        private void PreencherAgregacao(List<Escola> escolas)
        {
            escolas.ForEach(delegate(Escola escola) 
            {
                this.PreencherAgregacao(escola);
            });
        }

        private void PreencherAgregacao(Escola escola)
        {
            //Preenche as agregações somente se for necessário
            if (!this.LazyLoad)
            {
                //
                //Adiciona valores no objeto Diretor.
                //Obtjeto Diretor já vem instânciado da classe DAO de Escola
                //
                var _toDiretor = DiretorDAO.GetInstance().FindByKey(escola.Diretor.Codigo);
                escola.Diretor.DiretoriaEnsino = _toDiretor.NomeDiretoriaEnsino;
                escola.Diretor.EmailContato = _toDiretor.EmailContato;
                escola.Diretor.Nome = _toDiretor.NomeDiretor;

                var _vinculosTelefonesEscola = TelefoneEscolaDAO.GetInstance().FindTelefonesByEscola(escola.Codigo);
                escola.Telefones = new List<Telefone>();
                _vinculosTelefonesEscola.ForEach(delegate(TOTelefoneEscola vinculoTelefoneEscola)
                {
                    //Obtêm dados do telefone
                    var _toTelefoneEscola = TelefoneDAO.GetInstance().FindByKey(vinculoTelefoneEscola.CodigoTelefone);

                    var _telefoneEscola = new Telefone()
                    {
                        Codigo = _toTelefoneEscola.CodigoTelefone,
                        NomeContato = _toTelefoneEscola.NomeContato,
                        Numero = _toTelefoneEscola.NumeroTelefone
                    };

                    //
                    // Código do Switch fazem referência a tabela no banco
                    //
                    switch (_toTelefoneEscola.CodigoTipoTelefone)
                    {
                        //TipoTelefone.Residencial
                        case 1:
                            _telefoneEscola.TipoTelefone = TipoTelefone.Residencial;
                            break;
                        //TipoTelefone.Celular
                        case 2:
                            _telefoneEscola.TipoTelefone = TipoTelefone.Celular;
                            break;
                        //TipoTelefone.Comercial
                        case 3:
                            _telefoneEscola.TipoTelefone = TipoTelefone.Comercial;
                            break;
                        //TipoTelefone.Fax
                        case 4:
                            _telefoneEscola.TipoTelefone = TipoTelefone.Fax;
                            break;
                    }
                    escola.Telefones.Add(_telefoneEscola);
                });
            }
            //Grupos Escolares não é considerado no LazyLoad
            escola.GruposEscolares = this.BCGrupoEscolarSimulador.ListarGruposEscolaresByEscola(escola.Codigo);
        }

        public override List<Escola> ListarEscolasSorteadas(TipoSemanaSimulacao tipoSemanaSimulacao)
        {
            var _escolas = ((EscolaDAO)_persistence).FindEscolasSorteadasSimulacao((int)tipoSemanaSimulacao);

            this.PreencherAgregacao(_escolas);

            return _escolas;
        }

        public override Escola ObterEscolaSorteada(int codigoEscola, TipoSemanaSimulacao? tipoSemanaSimulacao)
        {
            var _escola = ((EscolaDAO)_persistence).FindEscolasSorteadasSimulacao((int)tipoSemanaSimulacao, codigoEscola);

            this.PreencherAgregacao(_escola);

            return _escola;
        }

        public override void AdicionarEscolasClassificadas(List<Escola> escolas)
        {
            //
            //Defini dicionário para armazenar as datas e horas de agendamento do simulado
            //
            var _dicionarioDatasAgendamento = new Dictionary<DateTime, int>();
            //
            //Obtêm os agendamentos existens na base de dados
            //
            var _agendaSimulacaoExistentes = this.BCAgendaSimulacao.FindAll();
            //
            //Obtêm todas as escolas cadastradas
            //
            var _escolasCadastradas = this.FindAll();

            //
            //Obtêm o parâmetro de Agenda de Simulação
            //
            var _paramAgenda = this.BCConfiguracaoParametroAgenda.FindAll().Where(pr => pr.TipoModoSimulacao == TipoModoSimulacao.Web).First<ParametrizacaoAgenda>();

            //-----------------------------------------------------------------------
            //1º - Integra as Escolas, Diretor e Telefones
            //-----------------------------------------------------------------------
            foreach (Escola novaEscola in escolas)
            {
                var _escolaExistente = _escolasCadastradas.Where(es => es.CodigoOriginalLMS == novaEscola.CodigoOriginalLMS).FirstOrDefault<Escola>();

                if (_escolaExistente == null)
                {

                    //
                    //Adiciona Diretor da Escola
                    //
                    var _toDiretor = new TODiretor()
                    {
                        EmailContato = novaEscola.Diretor.EmailContato,
                        NomeDiretor = novaEscola.Diretor.Nome,
                        NomeDiretoriaEnsino = novaEscola.Diretor.DiretoriaEnsino != null ? novaEscola.Diretor.DiretoriaEnsino : string.Empty
                    };
                    DiretorDAO.GetInstance().Create(_toDiretor);
                    //
                    //Preenche FK da tabela da Escola
                    //
                    novaEscola.Diretor.Codigo = _toDiretor.CodigoDiretor;

                    //
                    // Adiciona uma nova Escola
                    //
                    Create(novaEscola);
                }
                else
                {
                    #region Exclui todos os telefones existentes da Escola!
                    //
                    // Adiciona a PK existente
                    //
                    novaEscola.Codigo = _escolaExistente.Codigo;

                    //
                    //Obtêm os telefones relacionados à escola existente antes de excluir
                    //
                    var _telefonesRelacionados = TelefoneEscolaDAO.GetInstance().FindAll().Where(cod => cod.CodigoEscola == novaEscola.Codigo);

                    //
                    //Exclui a tabela de relacionamentos
                    //
                    TelefoneEscolaDAO.GetInstance().DeleteByEscola(novaEscola.Codigo);

                    //
                    // Exclui os telefones existentes
                    //
                    _telefonesRelacionados.ToList<TOTelefoneEscola>().ForEach(delegate(TOTelefoneEscola toTelefoneEscola)
                    {
                        TelefoneDAO.GetInstance().Delete(new TOTelefone() { CodigoTelefone = toTelefoneEscola.CodigoTelefone });
                    });
                    #endregion
                }

                #region Adiciona os novos telefones da Escola, caso existam!
                if (novaEscola.Telefones != null)
                {
                    //
                    // Adiciona os novos telefones da Escola
                    //
                    novaEscola.Telefones.ForEach(delegate(Telefone telefone)
                    {
                        var _toNovoTelefoneEscola = new TOTelefone()
                        {
                            CodigoTipoTelefone = (int)telefone.TipoTelefone,
                            NomeContato = telefone.NomeContato,
                            NumeroTelefone = telefone.Numero
                        };
                        // 
                        // Adiciona os novo telefones da escola
                        //
                        TelefoneDAO.GetInstance().Create(_toNovoTelefoneEscola);
                        // 
                        // Relaciona os telefones adicionados à PK da Escola
                        //
                        TelefoneEscolaDAO.GetInstance().Create(new TOTelefoneEscola()
                        {
                            CodigoEscola = novaEscola.Codigo,
                            CodigoTelefone = _toNovoTelefoneEscola.CodigoTelefone
                        });
                    });
                }
                #endregion

                //-----------------------------------------------------------------------
                // 2º - Integra os Grupos escolares
                //-----------------------------------------------------------------------
                novaEscola.GruposEscolares.ForEach(delegate(GrupoEscolar grupoEscolar)
                {
                    var _grupoExistente = this.BCGrupoEscolarSimulador.ObterGrupoEscolarSimulacao(grupoEscolar.CodigoOriginalLMS);
                    //
                    //Se não existir grupo...
                    //
                    if (_grupoExistente == null)
                    {
                        //Adiciona o código da Escola ao Grupo Escolar
                        grupoEscolar.Escola = new Escola() { Codigo = novaEscola.Codigo };


                        #region Grupo Escolar
                        //
                        //Adiciona o Grupo Escolar
                        //
                        this.BCGrupoEscolarSimulador.Create(grupoEscolar);
                        #endregion

                        #region Competidores Professor e Aluno
                        //
                        //Adiciona o Professor do Grupo Escolar
                        //
                        grupoEscolar.Professor.GrupoEscolar = new GrupoEscolar() { Codigo = grupoEscolar.Codigo };
                        this.BCCompetidorSimulador.Create(grupoEscolar.Professor);

                        //
                        //Adiciona os Alunos do Grupo Escolar
                        //
                        grupoEscolar.Alunos.ForEach(delegate(Aluno aluno)
                        {
                            aluno.GrupoEscolar = new GrupoEscolar() { Codigo = grupoEscolar.Codigo };
                            this.BCCompetidorSimulador.Create(aluno);
                        });
                        #endregion

                        #region Agenda de Simulado do Grupo Escolar
                        //
                        //Adiciona a Agenda do Simulado do Grupo Escolar
                        //
                        grupoEscolar.AgendaSimulacao.ForEach(delegate(AgendaSimulacao agendaSimulacao)
                        {
                            #region Gera as Rodadas de Simulação
                            //
                            //Gera as rodadas de simulação para cada Data e Hora de agendamento do Simulado
                            //
                            var _rodadasSimulacao = new List<RodadaSimulacao>();
                            this.BCConfiguracaoRodada.GerarRodadasSimulacao(_paramAgenda.QuantidadeRodadas, out _rodadasSimulacao);

                            agendaSimulacao.AgendaSimulacaoRodadas = new List<AgendaSimulacaoRodadas>();
                            _rodadasSimulacao.ForEach(delegate(RodadaSimulacao rodadaSimulacao)
                            {
                                agendaSimulacao.AgendaSimulacaoRodadas.Add(new AgendaSimulacaoRodadas()
                                {
                                    GrupoEscolar = new GrupoEscolar() { Codigo = grupoEscolar.Codigo },
                                    ContadorRodadaContingencia = 0,
                                    IndicadorSimulacaoConcluida = false,
                                    Rodada = rodadaSimulacao
                                });
                            });
                            _rodadasSimulacao = null;
                            #endregion

                            #region Adiciona Agenda do Simulado para cada Grupo Escolar
                            // Verifica se existe agenda na lista do Banco de Dados
                            var _agendaExistente = _agendaSimulacaoExistentes.Where(dt => dt.DataHoraAgendamento == agendaSimulacao.DataHoraAgendamento).FirstOrDefault<AgendaSimulacao>();
                            if (_agendaExistente == null)
                            {
                                //Verifica se existe agenda no dicionário em mémória
                                if (!_dicionarioDatasAgendamento.ContainsKey(agendaSimulacao.DataHoraAgendamento))
                                {
                                    //
                                    //Adiciona a agenda do simulado
                                    //
                                    agendaSimulacao.ParametrizacaoAgenda = _paramAgenda;
                                    this.BCAgendaSimulacao.Create(agendaSimulacao);
                                    _dicionarioDatasAgendamento.Add(agendaSimulacao.DataHoraAgendamento, agendaSimulacao.Codigo);
                                }
                                else
                                    //Adicionar PK existente para ser reutilizada
                                    agendaSimulacao.Codigo = _dicionarioDatasAgendamento[agendaSimulacao.DataHoraAgendamento];
                            }
                            else
                                //Adicionar PK existente para ser reutilizada
                                agendaSimulacao.Codigo = _agendaExistente.Codigo;

                            //
                            //Víncula à Agenda de Simulação com as rodadas geradas Rodadas
                            //
                            this.BCAgendaSimulacao.VincularAgendaSimulacaoRodadas(agendaSimulacao);
                            #endregion
                        });
                        #endregion
                    }
                });
            }
        }

        public override List<Escola> FindAll()
        {
            var _escolas = base.FindAll();

            //this.PreencherAgregacao(_escolas);

            return _escolas;
        }

        public override List<Escola> ListarEscolasPendenteSorteioCenarios()
        {
            this.LazyLoad = true;
            var _escolasPendentes = ((EscolaDAO)_persistence).FindEscolasPendenteSorteio();
            
            this.PreencherAgregacao(_escolasPendentes);

            return _escolasPendentes;
        }

        public override Escola FindByKey(int key)
        {
            var _escola = base.FindByKey(key);

            this.PreencherAgregacao(_escola);

            return _escola;
        }

        public override void AtualizarIndicadorSorteioCenarios(List<Escola> escolasPendentesSorteio)
        {
            //Obter todos os agendamentos para escolas/grupos informados            
            foreach (Escola escola in escolasPendentesSorteio)
            {
                EscolaDAO.GetInstance().Update(escola);
            }
        }
    }
}
