﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Competidor.Interfaces;
using Desafio.Simulador.Bcl.Competidor.Impl.Dao;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Interfaces;
using Microsoft.Practices.Unity;

namespace Desafio.Simulador.Bcl.Competidor.Impl
{
    public class BCGrupoEscolarSimuladorImpl : BCGrupoEscolarSimulador
    {
        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCAgendaSimulacao BCAgendaSimulacao { get; set; }

        public BCGrupoEscolarSimuladorImpl(GrupoEscolarDAO grupoEscolarDAO) 
        {
            _persistence = grupoEscolarDAO;
        }

        public override void DesclassificarGrupoEscolar(GrupoEscolar grupoEscolar)
        {
            var _grupoEscolar = base.FindByKey(grupoEscolar.Codigo);

            //Desclassifica grupo Escolar
            _grupoEscolar.IndicadorGrupoDesclassificado = true;
            base.Update(_grupoEscolar);
        }

        public override List<GrupoEscolar> ListarGruposEscolaresByEscola(int codigoEscola)
        {
            var _grupoEscolares = ((GrupoEscolarDAO)_persistence).FindGruposEcolaresByEscola(codigoEscola);

            /*_grupoEscolares.ForEach(delegate(GrupoEscolar grupoEscolar)
            {
                grupoEscolar.AgendaSimulacao = BCAgendaSimulacao.ListarAgendaSimulacaoGrupoEscolar(grupoEscolar.Codigo);
            });*/

            return _grupoEscolares;
        }

        public override GrupoEscolar ObterGrupoEscolarSimulacao(int codigoOrigemLMS)
        {
            return ((GrupoEscolarDAO)_persistence).FindGrupoEscolarSimulacaoByCodigoLMS(codigoOrigemLMS);
        }

        public override List<GrupoEscolar> ListarGruposEscolaresByAgendaSimulacao(int codigoAgendaSimulacao)
        {
            return ((GrupoEscolarDAO)_persistence).FindGrupoEscolarByAgendaSimulacao(codigoAgendaSimulacao);
        }
    }
}
