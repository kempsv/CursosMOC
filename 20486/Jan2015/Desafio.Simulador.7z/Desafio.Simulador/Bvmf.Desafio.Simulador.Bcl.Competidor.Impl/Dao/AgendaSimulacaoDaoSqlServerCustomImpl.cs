﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
using System.Collections.Generic;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Entidade;

//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Core.Domain.Enum;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Agendamento.Simulacao.Impl.Dao
{
    public class AgendaSimulacaoDAOSqlServerCustomImpl : AgendaSimulacaoDAOSqlServerImpl
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "AgendaSimulacaoDAOSqlServerCustomImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<AgendaSimulacao> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOAgendaSimulacao> result = new List<TOAgendaSimulacao>();
            TOAgendaSimulacao transferObject = null;

            try
            {
                statement = "SELECT TSDBAGDA_SIMU.COD_AGDA_SIMU, TSDBAGDA_SIMU.COD_PARM_AGDA_SIMU, TSDBAGDA_SIMU.COD_SIST_ORIG, TSDBAGDA_SIMU.DTHR_AGDA, TSDBAGDA_SIMU.DTHR_CRIA, TSDBAGDA_SIMU.COD_TIPO_SEMA_SIMU FROM TSDBAGDA_SIMU TSDBAGDA_SIMU WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOAgendaSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoAgendaSimulacao = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoParametroAgenda = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.DataHoraAgendamento = dataReader.GetDateTime(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.DataHoraCriacao = dataReader.GetDateTime(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.IdentificadorSemana = dataReader.GetInt16(5);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override AgendaSimulacao FindByKey(int codigoAgendaSimulacao)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOAgendaSimulacao transferObject = null;

            try
            {
                statement = "SELECT TSDBAGDA_SIMU.COD_AGDA_SIMU, TSDBAGDA_SIMU.COD_PARM_AGDA_SIMU, TSDBAGDA_SIMU.COD_SIST_ORIG, TSDBAGDA_SIMU.DTHR_AGDA, TSDBAGDA_SIMU.DTHR_CRIA, TSDBAGDA_SIMU.COD_TIPO_SEMA_SIMU FROM TSDBAGDA_SIMU TSDBAGDA_SIMU WITH(NOLOCK) WHERE TSDBAGDA_SIMU.COD_AGDA_SIMU = @codigoAgendaSimulacao";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open();
                            using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", codigoAgendaSimulacao));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOAgendaSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoAgendaSimulacao = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoParametroAgenda = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.DataHoraAgendamento = dataReader.GetDateTime(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.DataHoraCriacao = dataReader.GetDateTime(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.IdentificadorSemana = dataReader.GetInt16(5);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Obtêm a agenda de simulação de um determinado grupo escolar
        /// </summary>
        public override AgendaSimulacao FindAgendaGrupoEscolar(int codigoGrupoEscolar, DateTime dataHoraAgenda)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOAgendaSimulacao transferObject = null;

            try
            {
                //statement = "SELECT distinct TSDBAGDA_SIMU.COD_AGDA_SIMU, TSDBAGDA_SIMU.COD_PARM_AGDA_SIMU, TSDBAGDA_SIMU.COD_SIST_ORIG, TSDBAGDA_SIMU.DTHR_AGDA, TSDBAGDA_SIMU.DTHR_CRIA, TSDBAGDA_SIMU.NUM_IDT_SEMA       FROM TSDBAGDA_SIMU TSDBAGDA_SIMU WITH(NOLOCK)  INNER JOIN TSDBVINC_AGDA_RDAD_GRUP_ESCL Vinculo WITH(NOLOCK)  ON TSDBAGDA_SIMU.COD_AGDA_SIMU = Vinculo.COD_AGDA_SIMU WHERE vinculo.COD_GRUP_ESCL = " + codigoGrupoEscolar + " and TSDBAGDA_SIMU.DTHR_AGDA between '" + dataHoraAgenda.ToString("yyyy-MM-dd 00:00:00") + "' and '" + dataHoraAgenda.ToString("yyyyMMdd 23:59:59") + "'";
                statement = "SELECT distinct TSDBAGDA_SIMU.COD_AGDA_SIMU, TSDBAGDA_SIMU.COD_PARM_AGDA_SIMU, TSDBAGDA_SIMU.COD_SIST_ORIG, TSDBAGDA_SIMU.DTHR_AGDA, TSDBAGDA_SIMU.DTHR_CRIA, TSDBAGDA_SIMU.COD_TIPO_SEMA_SIMU FROM TSDBAGDA_SIMU TSDBAGDA_SIMU WITH(NOLOCK)  INNER JOIN TSDBVINC_AGDA_RDAD_GRUP_ESCL Vinculo WITH(NOLOCK)  ON TSDBAGDA_SIMU.COD_AGDA_SIMU = Vinculo.COD_AGDA_SIMU WHERE vinculo.COD_GRUP_ESCL = " + codigoGrupoEscolar + " and TSDBAGDA_SIMU.DTHR_AGDA between '" + dataHoraAgenda.ToString("yyyyMMdd 00:00:00") + "' and '" + dataHoraAgenda.ToString("yyyyMMdd 23:59:59") + "'";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open();
                            using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {
                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOAgendaSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoAgendaSimulacao = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoParametroAgenda = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.DataHoraAgendamento = dataReader.GetDateTime(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.DataHoraCriacao = dataReader.GetDateTime(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.IdentificadorSemana = dataReader.GetInt16(5);
                                    }
                                }
                                dataReader.Close();

                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Lista todas as agendas de simulação de um determinado grupo escolar
        /// </summary>
        public override List<AgendaSimulacao> FindAgendaGrupoEscolar(int codigoGrupoEscolar)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOAgendaSimulacao> result = new List<TOAgendaSimulacao>();
            TOAgendaSimulacao transferObject = null;

            try
            {
                //statement = "SELECT DISTINCT TSDBAGDA_SIMU.COD_AGDA_SIMU, TSDBAGDA_SIMU.COD_PARM_AGDA_SIMU, TSDBAGDA_SIMU.COD_SIST_ORIG, TSDBAGDA_SIMU.DTHR_AGDA, TSDBAGDA_SIMU.DTHR_CRIA, TSDBAGDA_SIMU.NUM_IDT_SEMA       FROM TSDBAGDA_SIMU TSDBAGDA_SIMU WITH(NOLOCK)  INNER JOIN TSDBVINC_AGDA_RDAD_GRUP_ESCL Vinculo WITH(NOLOCK)  ON TSDBAGDA_SIMU.COD_AGDA_SIMU = Vinculo.COD_AGDA_SIMU WHERE vinculo.COD_GRUP_ESCL = " + codigoGrupoEscolar + "";
                statement = "SELECT DISTINCT TSDBAGDA_SIMU.COD_AGDA_SIMU, TSDBAGDA_SIMU.COD_PARM_AGDA_SIMU, TSDBAGDA_SIMU.COD_SIST_ORIG, TSDBAGDA_SIMU.DTHR_AGDA, TSDBAGDA_SIMU.DTHR_CRIA, TSDBAGDA_SIMU.COD_TIPO_SEMA_SIMU FROM TSDBAGDA_SIMU TSDBAGDA_SIMU WITH(NOLOCK)  INNER JOIN TSDBVINC_AGDA_RDAD_GRUP_ESCL Vinculo WITH(NOLOCK)  ON TSDBAGDA_SIMU.COD_AGDA_SIMU = Vinculo.COD_AGDA_SIMU WHERE vinculo.COD_GRUP_ESCL = " + codigoGrupoEscolar + "";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open();
                            using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {



                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOAgendaSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoAgendaSimulacao = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoParametroAgenda = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.DataHoraAgendamento = dataReader.GetDateTime(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.DataHoraCriacao = dataReader.GetDateTime(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.IdentificadorSemana = dataReader.GetInt16(5);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();

                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Lista todas os agendamentos por uma determinada semana de simulação
        /// </summary>
        public override List<AgendaSimulacao> FindAgendaBySemanaSimulacao(int identificadorSemanaSimulacao)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOAgendaSimulacao> result = new List<TOAgendaSimulacao>();
            Desafio.Simulador.Bcl.Agendamento.Simulacao.Entidade.TOAgendaSimulacao transferObject = null;

            try
            {
                //statement = "SELECT TSDBAGDA_SIMU.COD_AGDA_SIMU, TSDBAGDA_SIMU.COD_PARM_AGDA_SIMU, TSDBAGDA_SIMU.COD_SIST_ORIG, TSDBAGDA_SIMU.DTHR_AGDA, TSDBAGDA_SIMU.DTHR_CRIA, TSDBAGDA_SIMU.NUM_IDT_SEMA       FROM TSDBAGDA_SIMU TSDBAGDA_SIMU WITH(NOLOCK)  WHERE NUM_IDT_SEMA = " + identificadorSemanaSimulacao + "";
                statement = "SELECT TSDBAGDA_SIMU.COD_AGDA_SIMU, TSDBAGDA_SIMU.COD_PARM_AGDA_SIMU, TSDBAGDA_SIMU.COD_SIST_ORIG, TSDBAGDA_SIMU.DTHR_AGDA, TSDBAGDA_SIMU.DTHR_CRIA, TSDBAGDA_SIMU.COD_TIPO_SEMA_SIMU FROM TSDBAGDA_SIMU TSDBAGDA_SIMU WITH(NOLOCK)  WHERE NUM_IDT_SEMA = " + identificadorSemanaSimulacao + "";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open();
                            using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {



                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOAgendaSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoAgendaSimulacao = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoParametroAgenda = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.DataHoraAgendamento = dataReader.GetDateTime(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.DataHoraCriacao = dataReader.GetDateTime(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.IdentificadorSemana = dataReader.GetInt16(5);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();

                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Remove uma entidade pela sua chave primária.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(AgendaSimulacao entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOAgendaSimulacao transferObject = TranslateToDTO(entity);

                //statement = "DELETE FROM TSDBAGDA_SIMU WHERE COD_AGDA_SIMU = @codigoAgendaSimulacao";
                statement = "DELETE FROM TSDBAGDA_SIMU WHERE COD_AGDA_SIMU = @codigoAgendaSimulacao";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {
                            // Chave primária
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", transferObject.CodigoAgendaSimulacao));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }
            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma instância em memória na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(AgendaSimulacao entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOAgendaSimulacao transferObject = TranslateToDTO(entity);

                //statement = "UPDATE TSDBAGDA_SIMU SET cOD_PARM_AGDA_SIMU = @codigoParametroAgenda, cOD_SIST_ORIG = @codigoSistemaOrigem, dTHR_AGDA = @dataHoraAgendamento, dTHR_CRIA = @dataHoraCriacao, nUM_IDT_SEMA = @identificadorSemana WHERE COD_AGDA_SIMU = @codigoAgendaSimulacao";
                statement = "UPDATE TSDBAGDA_SIMU SET cOD_PARM_AGDA_SIMU = @codigoParametroAgenda, cOD_SIST_ORIG = @codigoSistemaOrigem, dTHR_AGDA = @dataHoraAgendamento, dTHR_CRIA = @dataHoraCriacao, cOD_TIPO_SEMA_SIMU = @identificadorSemana WHERE COD_AGDA_SIMU = @codigoAgendaSimulacao";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que não estão na chave
                            if (transferObject.CodigoParametroAgenda == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoParametroAgenda", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoParametroAgenda", transferObject.CodigoParametroAgenda));
                            }

                            if (transferObject.CodigoSistemaOrigem == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", transferObject.CodigoSistemaOrigem));
                            }

                            if (transferObject.DataHoraAgendamento == DateTime.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@dataHoraAgendamento", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@dataHoraAgendamento", transferObject.DataHoraAgendamento));
                            }

                            if (transferObject.DataHoraCriacao == DateTime.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@dataHoraCriacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@dataHoraCriacao", transferObject.DataHoraCriacao));
                            }

                            if (transferObject.IdentificadorSemana == short.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@identificadorSemana", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@identificadorSemana", transferObject.IdentificadorSemana));
                            }

                            // Chave primária
                            command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", transferObject.CodigoAgendaSimulacao));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma instância em memória na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(AgendaSimulacao entity)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                TOAgendaSimulacao transferObject = TranslateToDTO(entity);

                //statement = "INSERT INTO TSDBAGDA_SIMU ( COD_PARM_AGDA_SIMU, COD_SIST_ORIG, DTHR_AGDA, DTHR_CRIA, NUM_IDT_SEMA ) VALUES ( @codigoParametroAgenda, @codigoSistemaOrigem, @dataHoraAgendamento, @dataHoraCriacao, @identificadorSemana )  ; SELECT SCOPE_IDENTITY();";
                statement = "INSERT INTO TSDBAGDA_SIMU ( COD_PARM_AGDA_SIMU, COD_SIST_ORIG, DTHR_AGDA, DTHR_CRIA, COD_TIPO_SEMA_SIMU ) VALUES ( @codigoParametroAgenda, @codigoSistemaOrigem, @dataHoraAgendamento, @dataHoraCriacao, @identificadorSemana )  ; SELECT SCOPE_IDENTITY();";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoParametroAgenda == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoParametroAgenda", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoParametroAgenda", transferObject.CodigoParametroAgenda));
                            }

                            if (transferObject.CodigoSistemaOrigem == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", transferObject.CodigoSistemaOrigem));
                            }

                            if (transferObject.DataHoraAgendamento == DateTime.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@dataHoraAgendamento", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@dataHoraAgendamento", transferObject.DataHoraAgendamento));
                            }

                            if (transferObject.DataHoraCriacao == DateTime.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@dataHoraCriacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@dataHoraCriacao", transferObject.DataHoraCriacao));
                            }

                            if (transferObject.IdentificadorSemana == short.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@identificadorSemana", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@identificadorSemana", transferObject.IdentificadorSemana));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            entity.Codigo = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        protected override List<AgendaSimulacao> TranslateFromDTO(List<TOAgendaSimulacao> entityDTO)
        {
            var _lista = new List<AgendaSimulacao>();
            foreach (TOAgendaSimulacao et in entityDTO)
            {
                _lista.Add(TranslateFromDTO(et));
            }
            return _lista;
        }

        protected override AgendaSimulacao TranslateFromDTO(TOAgendaSimulacao entityDTO)
        {
            if (entityDTO == null) return null;

            var _agendaSimulacao = new AgendaSimulacao()
            {
                Codigo = entityDTO.CodigoAgendaSimulacao,
                CodigoOriginalLMS = entityDTO.CodigoSistemaOrigem,
                DataHoraAgendamento = entityDTO.DataHoraAgendamento,
                DataHoraCriacao = entityDTO.DataHoraCriacao,
                ParametrizacaoAgenda = new ParametrizacaoAgenda() { Codigo = entityDTO.CodigoParametroAgenda }
            };

            switch (entityDTO.IdentificadorSemana)
            {
                case 1:
                    _agendaSimulacao.TipoSemanaSimulacao = TipoSemanaSimulacao.PrimeiraSemana;
                    break;
                case 2:
                    _agendaSimulacao.TipoSemanaSimulacao = TipoSemanaSimulacao.SegundaSemana;
                    break;
                case 3:
                    _agendaSimulacao.TipoSemanaSimulacao = TipoSemanaSimulacao.TerceiraSemana;
                    break;
                case 4:
                    _agendaSimulacao.TipoSemanaSimulacao = TipoSemanaSimulacao.QuartaSemana;
                    break;
            }

            return _agendaSimulacao;
        }

        protected override List<TOAgendaSimulacao> TranslateToDTO(List<AgendaSimulacao> entity)
        {
            var _lista = new List<TOAgendaSimulacao>();
            foreach (AgendaSimulacao et in entity)
            {
                _lista.Add(TranslateToDTO(et));
            }
            return _lista;
        }

        protected override TOAgendaSimulacao TranslateToDTO(AgendaSimulacao entity)
        {
            var _toAgendaSimulacao = new TOAgendaSimulacao()
            {
                CodigoAgendaSimulacao = entity.Codigo,
                CodigoSistemaOrigem = entity.CodigoOriginalLMS,
                DataHoraAgendamento = entity.DataHoraAgendamento,
                DataHoraCriacao = entity.DataHoraCriacao,
                CodigoParametroAgenda = entity.ParametrizacaoAgenda.Codigo,
                IdentificadorSemana = (short)entity.TipoSemanaSimulacao
            };
            return _toAgendaSimulacao;
        }
    }
}
