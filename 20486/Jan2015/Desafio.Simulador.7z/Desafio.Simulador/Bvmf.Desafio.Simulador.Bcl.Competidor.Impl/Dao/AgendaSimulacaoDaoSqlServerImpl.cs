using System;
using System.Data;
using System.Data.SqlClient;
//using Framework.AcessoDados;

namespace Desafio.Simulador.Bcl.Agendamento.Simulacao.Impl.Dao
{
    
    /// <summary>
    /// Implementa��o de AgendaSimulacaoDAO - SqlServer
    /// </summary>
    public abstract class AgendaSimulacaoDAOSqlServerImpl : AgendaSimulacaoDAO
    {
        
    } //AgendaSimulacao
}
