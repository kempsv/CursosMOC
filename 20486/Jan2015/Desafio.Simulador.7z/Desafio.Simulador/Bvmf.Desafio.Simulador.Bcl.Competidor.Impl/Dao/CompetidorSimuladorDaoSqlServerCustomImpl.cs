﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Competidor.Entidade;
using System.Collections.Generic;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using System.Text;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Competidor.Impl.Dao
{
    public class CompetidorSimuladorDAOSqlServerCustomImpl : CompetidorSimuladorDAOSqlServerImpl
    {
        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "CompetidorSimuladorDAOSqlServerCustomImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<CompetidorSimulador> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOCompetidorSimulador> result = new List<TOCompetidorSimulador>();
            TOCompetidorSimulador transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBCOMPT_SIMD.COD_COMPT_SIMD, TSDBCOMPT_SIMD.COD_GRUP_ESCL, TSDBCOMPT_SIMD.COD_SIST_ORIG, TSDBCOMPT_SIMD.COD_TIPO_COMPT, TSDBCOMPT_SIMD.NOME_COMPT_SIMD, TSDBCOMPT_SIMD.NOME_EMAIL_CONT FROM TSDBCOMPT_SIMD TSDBCOMPT_SIMD WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open();
                            using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOCompetidorSimulador();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCompetidor = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.CodigoTipoCompetidor = dataReader.GetInt32(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.NomeCompetidor = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.EmailCompetidor = dataReader.GetString(5);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override CompetidorSimulador FindByKey(int codigoCompetidor)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOCompetidorSimulador transferObject = null;

            try
            {
                statement = "SELECT TSDBCOMPT_SIMD.COD_COMPT_SIMD, TSDBCOMPT_SIMD.COD_GRUP_ESCL, TSDBCOMPT_SIMD.COD_SIST_ORIG, TSDBCOMPT_SIMD.COD_TIPO_COMPT, TSDBCOMPT_SIMD.NOME_COMPT_SIMD, TSDBCOMPT_SIMD.NOME_EMAIL_CONT FROM TSDBCOMPT_SIMD TSDBCOMPT_SIMD WITH(NOLOCK) WHERE TSDBCOMPT_SIMD.COD_COMPT_SIMD = @codigoCompetidor";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoCompetidor", codigoCompetidor));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOCompetidorSimulador();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCompetidor = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.CodigoTipoCompetidor = dataReader.GetInt32(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.NomeCompetidor = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.EmailCompetidor = dataReader.GetString(5);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Buscar uma entidade pelo Codigo Origem da LMS
        /// </summary>
        /// <param name="codigoOrigemLMS"></param>
        /// <returns></returns>
        public override CompetidorSimulador ObterProfessorByCodigoOrigemLMS(int codigoOrigemLMS)
        {
            StringBuilder statement = new StringBuilder();
            IDataReader dataReader = null;
            TOCompetidorSimulador transferObject = null;
            IDbCommand command;

            try
            {
                statement.Append("SELECT  COD_COMPT_SIMD, ");
                statement.Append(" COD_GRUP_ESCL,  ");
                statement.Append(" COD_SIST_ORIG, ");
                statement.Append(" COD_TIPO_COMPT, ");
                statement.Append(" NOME_COMPT_SIMD, ");
                statement.Append(" NOME_EMAIL_CONT ");
                statement.Append(" FROM TSDBCOMPT_SIMD AS TSDBCOMPT_SIMD WITH (NOLOCK) ");
                statement.Append(" WHERE ");
                statement.Append(" (COD_TIPO_COMPT = 2) AND  ");
                statement.Append(" (COD_SIST_ORIG = @codigoOrigemLMS)  ");

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open();
                            using (command = new SqlCommand(statement.ToString(), (SqlConnection)connection))
                            {
                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoOrigemLMS", codigoOrigemLMS));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOCompetidorSimulador();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCompetidor = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.CodigoTipoCompetidor = dataReader.GetInt32(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.NomeCompetidor = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.EmailCompetidor = dataReader.GetString(5);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(transferObject);

        }


        /// <summary>
        /// Buscar uma entidade  pelo grupo escolar
        /// </summary>
        /// <param name="codigoGrupoEscolar">Codigo do grupo escolar</param>
        /// <returns>A entidade referenciada.</returns>
        public override CompetidorSimulador ObterProfessorGrupoEscolar(int codigoGrupoEscolar)
        {
            StringBuilder statement = new StringBuilder();
            IDataReader dataReader = null;
            TOCompetidorSimulador transferObject = null;
            IDbCommand command;
            try
            {
                statement.Append("SELECT  COD_COMPT_SIMD, ");
                statement.Append(" COD_GRUP_ESCL,  ");
                statement.Append(" COD_SIST_ORIG, ");
                statement.Append(" COD_TIPO_COMPT, ");
                statement.Append(" NOME_COMPT_SIMD, ");
                statement.Append(" NOME_EMAIL_CONT ");
                statement.Append(" FROM TSDBCOMPT_SIMD AS TSDBCOMPT_SIMD WITH (NOLOCK) ");
                statement.Append(" WHERE ");
                statement.Append(" (COD_TIPO_COMPT = 2) AND  ");
                statement.Append(" (COD_GRUP_ESCL = @codigoGrupoEscolar)  ");



                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open();
                            using (command = new SqlCommand(statement.ToString(), (SqlConnection)connection))
                            {
                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", codigoGrupoEscolar));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOCompetidorSimulador();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCompetidor = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.CodigoTipoCompetidor = dataReader.GetInt32(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.NomeCompetidor = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.EmailCompetidor = dataReader.GetString(5);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(transferObject);
        }


        /// <summary>
        /// Busca as entidades pelo Codigo do Grupos Escolar. 
        /// </summary>
        /// <param name="codigoGrupoEscolar">Codigo do Grupo Escolar</param>
        /// <returns>Lista com as entidades</returns>
        public override List<CompetidorSimulador> ListarAlunosGrupoEscolar(int codigoGrupoEscolar)
        {
            StringBuilder statement = new StringBuilder();
            IDataReader dataReader = null;
            List<TOCompetidorSimulador> result = new List<TOCompetidorSimulador>();
            TOCompetidorSimulador transferObject = null;
            IDbCommand command;
            try
            {
                statement.Append("SELECT COD_COMPT_SIMD, ");
                statement.Append(" COD_GRUP_ESCL,  ");
                statement.Append(" COD_SIST_ORIG, ");
                statement.Append(" COD_TIPO_COMPT, ");
                statement.Append(" NOME_COMPT_SIMD, ");
                statement.Append(" NOME_EMAIL_CONT ");
                statement.Append(" FROM TSDBCOMPT_SIMD AS TSDBCOMPT_SIMD WITH (NOLOCK) ");
                statement.Append(" WHERE ");
                statement.Append(" (COD_TIPO_COMPT = 1) AND  ");
                statement.Append(" (COD_GRUP_ESCL = @codigoGrupoEscolar)  ");



                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement.ToString(), (SqlConnection)connection))
                            {
                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", codigoGrupoEscolar));


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOCompetidorSimulador();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCompetidor = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.CodigoTipoCompetidor = dataReader.GetInt32(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.NomeCompetidor = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.EmailCompetidor = dataReader.GetString(5);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(result);
        }


        /// <summary>
        /// Remove uma entidade pela sua chave primária.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(CompetidorSimulador entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOCompetidorSimulador transferObject = TranslateToDTO(entity);

                statement = "DELETE FROM TSDBCOMPT_SIMD WHERE COD_COMPT_SIMD = @codigoCompetidor";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave primária
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoCompetidor", transferObject.CodigoCompetidor));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }
            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma instância em memória na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(CompetidorSimulador entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOCompetidorSimulador transferObject = TranslateToDTO(entity);

                statement = "UPDATE TSDBCOMPT_SIMD SET cOD_GRUP_ESCL = @codigoGrupoEscolar, cOD_SIST_ORIG = @codigoSistemaOrigem, cOD_TIPO_COMPT = @codigoTipoCompetidor, nOME_COMPT_SIMD = @nomeCompetidor, nOME_EMAIL_CONT = @emailCompetidor WHERE COD_COMPT_SIMD = @codigoCompetidor";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que não estão na chave
                            if (transferObject.CodigoGrupoEscolar == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", transferObject.CodigoGrupoEscolar));
                            }

                            if (transferObject.CodigoSistemaOrigem == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", transferObject.CodigoSistemaOrigem));
                            }

                            if (transferObject.CodigoTipoCompetidor == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoCompetidor", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoCompetidor", transferObject.CodigoTipoCompetidor));
                            }

                            if (transferObject.NomeCompetidor == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeCompetidor", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeCompetidor", transferObject.NomeCompetidor));
                            }

                            if (transferObject.EmailCompetidor == null)
                            {
                                command.Parameters.Add(new SqlParameter("@emailCompetidor", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@emailCompetidor", transferObject.EmailCompetidor));
                            }

                            // Chave primária
                            command.Parameters.Add(new SqlParameter("@codigoCompetidor", transferObject.CodigoCompetidor));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }
            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma instância em memória na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(CompetidorSimulador entity)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                TOCompetidorSimulador transferObject = TranslateToDTO(entity);

                statement = "INSERT INTO TSDBCOMPT_SIMD ( COD_GRUP_ESCL, COD_SIST_ORIG, COD_TIPO_COMPT, NOME_COMPT_SIMD, NOME_EMAIL_CONT ) VALUES ( @codigoGrupoEscolar, @codigoSistemaOrigem, @codigoTipoCompetidor, @nomeCompetidor, @emailCompetidor )  ; SELECT SCOPE_IDENTITY();";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); 
                        using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoGrupoEscolar == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", transferObject.CodigoGrupoEscolar));
                            }

                            if (transferObject.CodigoSistemaOrigem == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", transferObject.CodigoSistemaOrigem));
                            }

                            if (transferObject.CodigoTipoCompetidor == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoCompetidor", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoCompetidor", transferObject.CodigoTipoCompetidor));
                            }

                            if (transferObject.NomeCompetidor == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeCompetidor", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeCompetidor", transferObject.NomeCompetidor));
                            }

                            if (transferObject.EmailCompetidor == null)
                            {
                                command.Parameters.Add(new SqlParameter("@emailCompetidor", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@emailCompetidor", transferObject.EmailCompetidor));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            entity.Codigo = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }
            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        protected override List<CompetidorSimulador> TranslateFromDTO(List<TOCompetidorSimulador> entityDTO)
        {
            var _lista = new List<CompetidorSimulador>();
            foreach (TOCompetidorSimulador et in entityDTO)
            {
                _lista.Add(TranslateFromDTO(et));
            }
            return _lista;
        }

        protected override CompetidorSimulador TranslateFromDTO(TOCompetidorSimulador entityDTO)
        {
            if (entityDTO.CodigoTipoCompetidor == Convert.ToInt32(TipoCompetidor.Aluno))
            {
                return new Aluno()
                {
                    Codigo = entityDTO.CodigoCompetidor,
                    CodigoOriginalLMS = entityDTO.CodigoSistemaOrigem,
                    EmailContato = entityDTO.EmailCompetidor,
                    Nome = entityDTO.NomeCompetidor,
                    GrupoEscolar = new GrupoEscolar() { Codigo = entityDTO.CodigoGrupoEscolar }
                };
            }
            else if (entityDTO.CodigoTipoCompetidor == Convert.ToInt32(TipoCompetidor.Professor))
            {
                return new Professor()
                {
                    Codigo = entityDTO.CodigoCompetidor,
                    CodigoOriginalLMS = entityDTO.CodigoSistemaOrigem,
                    EmailContato = entityDTO.EmailCompetidor,
                    Nome = entityDTO.NomeCompetidor,
                    GrupoEscolar = new GrupoEscolar() { Codigo = entityDTO.CodigoGrupoEscolar }
                };
            }
            else return null;
        }

        protected override List<TOCompetidorSimulador> TranslateToDTO(List<CompetidorSimulador> entity)
        {
            var _lista = new List<TOCompetidorSimulador>();
            foreach (CompetidorSimulador et in entity)
            {
                _lista.Add(TranslateToDTO(et));
            }
            return _lista;
        }

        protected override TOCompetidorSimulador TranslateToDTO(CompetidorSimulador entity)
        {
            var _toRetorno = new TOCompetidorSimulador();

            if (typeof(Aluno) == entity.GetType())
                _toRetorno.CodigoTipoCompetidor = Convert.ToInt32(TipoCompetidor.Aluno);
            else if (typeof(Professor) == entity.GetType())
                _toRetorno.CodigoTipoCompetidor = Convert.ToInt32(TipoCompetidor.Professor);

            _toRetorno.CodigoCompetidor = entity.Codigo;
            _toRetorno.CodigoGrupoEscolar = entity.GrupoEscolar.Codigo;
            _toRetorno.CodigoSistemaOrigem = entity.CodigoOriginalLMS;
            _toRetorno.EmailCompetidor = entity.EmailContato;
            _toRetorno.NomeCompetidor = entity.Nome;

            return _toRetorno;
        }
    }
}
