using System;
//using Framework.AcessoDados;

namespace Desafio.Simulador.Bcl.Competidor.Impl.Dao
{
    
    /// <summary>
    /// Implementa��o de CompetidorSimuladorDAO - SqlServer
    /// </summary>
    public abstract class CompetidorSimuladorDAOSqlServerImpl : CompetidorSimuladorDAO
    {   
        
    } //CompetidorSimulador
}
