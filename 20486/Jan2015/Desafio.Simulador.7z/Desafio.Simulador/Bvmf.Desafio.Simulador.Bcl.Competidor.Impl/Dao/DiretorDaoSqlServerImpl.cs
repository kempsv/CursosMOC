using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Competidor.Entidade;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Competidor.Impl.Dao
{

    /// <summary>
    /// Implementa��o de DiretorDAO - SqlServer
    /// </summary>
    public class DiretorDAOSqlServerImpl : DiretorDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "DiretorDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TODiretor> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TODiretor> result = new List<TODiretor>();
            TODiretor transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBDIRE.COD_DIRE, TSDBDIRE.NOME_DIRE, TSDBDIRE.NOME_DTORIA_ENSI, TSDBDIRE.NOME_EMAIL_CONT FROM TSDBDIRE TSDBDIRE WITH(NOLOCK)";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TODiretor();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoDiretor = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.NomeDiretor = dataReader.GetString(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.NomeDiretoriaEnsino = dataReader.GetString(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.EmailContato = dataReader.GetString(3);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TODiretor FindByKey(int codigoDiretor)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TODiretor transferObject = null;

            try
            {
                statement = "SELECT TSDBDIRE.COD_DIRE, TSDBDIRE.NOME_DIRE, TSDBDIRE.NOME_DTORIA_ENSI, TSDBDIRE.NOME_EMAIL_CONT FROM TSDBDIRE TSDBDIRE WITH(NOLOCK) WHERE TSDBDIRE.COD_DIRE = @codigoDiretor";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoDiretor", codigoDiretor));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TODiretor();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoDiretor = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.NomeDiretor = dataReader.GetString(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.NomeDiretoriaEnsino = dataReader.GetString(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.EmailContato = dataReader.GetString(3);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Remove uma entidade pela sua chave prim�ria.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(TODiretor transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBDIRE WHERE COD_DIRE = @codigoDiretor";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave prim�ria
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoDiretor", transferObject.CodigoDiretor));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma inst�ncia em mem�ria na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(TODiretor transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "UPDATE TSDBDIRE SET nOME_DIRE = @nomeDiretor, nOME_DTORIA_ENSI = @nomeDiretoriaEnsino, nOME_EMAIL_CONT = @emailContato WHERE COD_DIRE = @codigoDiretor";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que n�o est�o na chave
                            if (transferObject.NomeDiretor == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeDiretor", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeDiretor", transferObject.NomeDiretor));
                            }

                            if (transferObject.NomeDiretoriaEnsino == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeDiretoriaEnsino", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeDiretoriaEnsino", transferObject.NomeDiretoriaEnsino));
                            }

                            if (transferObject.EmailContato == null)
                            {
                                command.Parameters.Add(new SqlParameter("@emailContato", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@emailContato", transferObject.EmailContato));
                            }

                            // Chave prim�ria
                            command.Parameters.Add(new SqlParameter("@codigoDiretor", transferObject.CodigoDiretor));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TODiretor transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBDIRE ( NOME_DIRE, NOME_DTORIA_ENSI, NOME_EMAIL_CONT ) VALUES ( @nomeDiretor, @nomeDiretoriaEnsino, @emailContato )  ; SELECT SCOPE_IDENTITY();";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.NomeDiretor == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeDiretor", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeDiretor", transferObject.NomeDiretor));
                            }

                            if (transferObject.NomeDiretoriaEnsino == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeDiretoriaEnsino", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeDiretoriaEnsino", transferObject.NomeDiretoriaEnsino));
                            }

                            if (transferObject.EmailContato == null)
                            {
                                command.Parameters.Add(new SqlParameter("@emailContato", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@emailContato", transferObject.EmailContato));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            transferObject.CodigoDiretor = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }


    } //Diretor
}
