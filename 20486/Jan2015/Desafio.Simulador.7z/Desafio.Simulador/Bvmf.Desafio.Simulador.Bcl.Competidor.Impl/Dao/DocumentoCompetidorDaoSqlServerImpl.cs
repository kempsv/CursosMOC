using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Competidor.Entidade;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Competidor.Impl.Dao
{

    /// <summary>
    /// Implementa��o de DocumentoCompetidorDAO - SqlServer
    /// </summary>
    public class DocumentoCompetidorDAOSqlServerImpl : DocumentoCompetidorDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "DocumentoCompetidorDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TODocumentoCompetidor> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TODocumentoCompetidor> result = new List<TODocumentoCompetidor>();
            TODocumentoCompetidor transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBDOCM_COMPT_SIMD.COD_COMPT_SIMD, TSDBDOCM_COMPT_SIMD.COD_TIPO_DOCM, TSDBDOCM_COMPT_SIMD.NUM_DOCM_COMPT_SIMD FROM TSDBDOCM_COMPT_SIMD TSDBDOCM_COMPT_SIMD WITH(NOLOCK)";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TODocumentoCompetidor();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCompetidor = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoTipoDocumento = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.NumeroDocumento = dataReader.GetString(2);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Lista todos os documentos de um determinado competidor
        /// </summary>
        public override List<TODocumentoCompetidor> FindDocumentosByCompetidor(int codigoCompetidor)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TODocumentoCompetidor> result = new List<TODocumentoCompetidor>();
            TODocumentoCompetidor transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBDOCM_COMPT_SIMD.COD_COMPT_SIMD, TSDBDOCM_COMPT_SIMD.COD_TIPO_DOCM, TSDBDOCM_COMPT_SIMD.NUM_DOCM_COMPT_SIMD FROM TSDBDOCM_COMPT_SIMD TSDBDOCM_COMPT_SIMD WITH(NOLOCK)  WHERE COD_COMPT_SIMD = " + codigoCompetidor + "";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {



                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TODocumentoCompetidor();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCompetidor = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoTipoDocumento = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.NumeroDocumento = dataReader.GetString(2);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();

                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Deleta todos os documentos de um determinado competidos
        /// </summary>
        public override void DeleteByCompetidor(int codigoCompetidor)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBDOCM_COMPT_SIMD WHERE COD_COMPT_SIMD = " + codigoCompetidor + "";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TODocumentoCompetidor transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBDOCM_COMPT_SIMD ( COD_COMPT_SIMD, COD_TIPO_DOCM, NUM_DOCM_COMPT_SIMD ) VALUES ( @codigoCompetidor, @codigoTipoDocumento, @numeroDocumento ) ";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoCompetidor == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCompetidor", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCompetidor", transferObject.CodigoCompetidor));
                            }

                            if (transferObject.CodigoTipoDocumento == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoDocumento", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoDocumento", transferObject.CodigoTipoDocumento));
                            }

                            if (transferObject.NumeroDocumento == null)
                            {
                                command.Parameters.Add(new SqlParameter("@numeroDocumento", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@numeroDocumento", transferObject.NumeroDocumento));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

    } //DocumentoCompetidor
}
