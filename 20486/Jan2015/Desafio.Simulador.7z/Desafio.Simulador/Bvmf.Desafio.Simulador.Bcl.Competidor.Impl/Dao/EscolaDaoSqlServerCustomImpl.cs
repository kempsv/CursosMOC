﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Competidor.Entidade;
using System.Collections.Generic;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Core.Domain.Enum;
using System.Transactions;
using Desafio.Simulador.Util.Logger;
namespace Desafio.Simulador.Bcl.Competidor.Impl.Dao
{
    public class EscolaDAOSqlServerCustomImpl : EscolaDAOSqlServerImpl
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "EscolaDAOSqlServerCustomImpl";

        /// <summary>
        /// Lista todas as escolas sorteadas para o uma determinada semana de agendamento de simulação
        /// </summary>
        public override List<Escola> FindEscolasSorteadasSimulacao(int identificadorSemanaSimulacao)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOEscola> result = new List<TOEscola>();
            TOEscola transferObject = null;

            try
            {
                //statement = "SELECT DISTINCT Escola.COD_ESLA, Escola.COD_DIRE, Escola.COD_SIST_ORIG, Escola.IND_TIPO_ESLA, Escola.NOME_EMAIL, Escola.NOME_ESLA, Escola.NUM_CNPJ, Escola.IND_SORT_PEND FROM TSDBESLA Escola WITH(NOLOCK)  INNER JOIN TSDBGRUP_ESCL Grupo WITH(NOLOCK)  ON Escola.COD_ESLA = Grupo.COD_ESLA INNER JOIN TSDBVINC_AGDA_RDAD_GRUP_ESCL VinculoGrupo WITH(NOLOCK)  ON Grupo.COD_GRUP_ESCL = VinculoGrupo.COD_GRUP_ESCL INNER JOIN TSDBAGDA_SIMU Agenda WITH(NOLOCK)  ON Agenda.COD_AGDA_SIMU = VinculoGrupo.COD_AGDA_SIMU WHERE Agenda.NUM_IDT_SEMA = " + identificadorSemanaSimulacao + " GROUP BY Escola.COD_ESLA, Escola.NOME_ESLA, Escola.COD_DIRE, Escola.COD_SIST_ORIG, Escola.IND_TIPO_ESLA, Escola.NOME_EMAIL, Escola.NUM_CNPJ, Agenda.NUM_IDT_SEMA, Agenda.COD_AGDA_SIMU";
                statement = "SELECT DISTINCT Escola.COD_ESLA, Escola.COD_DIRE, Escola.COD_SIST_ORIG, Escola.IND_TIPO_ESLA, Escola.NOME_EMAIL, Escola.NOME_ESLA, Escola.NUM_CNPJ, Escola.IND_SORT_PEND FROM TSDBESLA Escola WITH(NOLOCK)  INNER JOIN TSDBGRUP_ESCL Grupo WITH(NOLOCK)  ON Escola.COD_ESLA = Grupo.COD_ESLA INNER JOIN TSDBVINC_AGDA_RDAD_GRUP_ESCL VinculoGrupo WITH(NOLOCK)  ON Grupo.COD_GRUP_ESCL = VinculoGrupo.COD_GRUP_ESCL INNER JOIN TSDBAGDA_SIMU Agenda WITH(NOLOCK)  ON Agenda.COD_AGDA_SIMU = VinculoGrupo.COD_AGDA_SIMU INNER JOIN TSDBTIPO_SEMA_SIMU TipoAgenda WITH(NOLOCK) ON TipoAgenda.COD_TIPO_SEMA_SIMU = Agenda.COD_TIPO_SEMA_SIMU WHERE Agenda.COD_TIPO_SEMA_SIMU = " + identificadorSemanaSimulacao + " GROUP BY Escola.COD_ESLA, Escola.NOME_ESLA, Escola.COD_DIRE, Escola.COD_SIST_ORIG, Escola.IND_TIPO_ESLA, Escola.NOME_EMAIL, Escola.NUM_CNPJ, Escola.IND_SORT_PEND, Agenda.COD_TIPO_SEMA_SIMU, Agenda.COD_AGDA_SIMU";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {



                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOEscola();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoEscola = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoDiretor = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.IndicadorEscolaPrivada = dataReader.GetBoolean(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.EmailEscola = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.NomeEscola = dataReader.GetString(5);
                                    }
                                    if (!dataReader.IsDBNull(6))
                                    {
                                        transferObject.NumeroCNPJ = dataReader.GetString(6);
                                    }
                                    if (!dataReader.IsDBNull(7))
                                    {
                                        transferObject.IndicadorSorteioPendente = dataReader.GetBoolean(7);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();

                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Obtêm a escola sorteada para o uma determinada semana de agendamento de simulação
        /// </summary>
        public override Escola FindEscolasSorteadasSimulacao(int identificadorSemanaSimulacao, int codigoEscola)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOEscola transferObject = null;

            try
            {
                //statement = "SELECT DISTINCT Escola.COD_ESLA, Escola.COD_DIRE, Escola.COD_SIST_ORIG, Escola.IND_TIPO_ESLA, Escola.NOME_EMAIL, Escola.NOME_ESLA, Escola.NUM_CNPJ, Escola.IND_SORT_PEND FROM TSDBESLA Escola WITH(NOLOCK)  INNER JOIN TSDBGRUP_ESCL Grupo WITH(NOLOCK)  ON Escola.COD_ESLA = Grupo.COD_ESLA INNER JOIN TSDBVINC_AGDA_RDAD_GRUP_ESCL VinculoGrupo WITH(NOLOCK)  ON Grupo.COD_GRUP_ESCL = VinculoGrupo.COD_GRUP_ESCL INNER JOIN TSDBAGDA_SIMU Agenda WITH(NOLOCK)  ON Agenda.COD_AGDA_SIMU = VinculoGrupo.COD_AGDA_SIMU WHERE Escola.Cod_Esla = " + codigoEscola + " and Agenda.NUM_IDT_SEMA = " + identificadorSemanaSimulacao + " GROUP BY Escola.COD_ESLA, Escola.NOME_ESLA, Escola.COD_DIRE, Escola.COD_SIST_ORIG, Escola.IND_TIPO_ESLA, Escola.NOME_EMAIL, Escola.NUM_CNPJ, Agenda.NUM_IDT_SEMA, Agenda.COD_AGDA_SIMU";
                statement = "SELECT DISTINCT Escola.COD_ESLA, Escola.COD_DIRE, Escola.COD_SIST_ORIG, Escola.IND_TIPO_ESLA, Escola.NOME_EMAIL, Escola.NOME_ESLA, Escola.NUM_CNPJ, Escola.IND_SORT_PEND FROM TSDBESLA Escola WITH(NOLOCK)  INNER JOIN TSDBGRUP_ESCL Grupo WITH(NOLOCK)  ON Escola.COD_ESLA = Grupo.COD_ESLA INNER JOIN TSDBVINC_AGDA_RDAD_GRUP_ESCL VinculoGrupo WITH(NOLOCK)  ON Grupo.COD_GRUP_ESCL = VinculoGrupo.COD_GRUP_ESCL INNER JOIN TSDBAGDA_SIMU Agenda WITH(NOLOCK)  ON Agenda.COD_AGDA_SIMU = VinculoGrupo.COD_AGDA_SIMU INNER JOIN TSDBTIPO_SEMA_SIMU TipoAgenda WITH(NOLOCK) ON TipoAgenda.COD_TIPO_SEMA_SIMU = Agenda.COD_TIPO_SEMA_SIMU WHERE Escola.Cod_Esla = " + codigoEscola + " and Agenda.COD_TIPO_SEMA_SIMU = " + identificadorSemanaSimulacao + " GROUP BY Escola.COD_ESLA, Escola.NOME_ESLA, Escola.COD_DIRE, Escola.COD_SIST_ORIG, Escola.IND_TIPO_ESLA, Escola.NOME_EMAIL, Escola.NUM_CNPJ, Escola.IND_SORT_PEND, Agenda.COD_TIPO_SEMA_SIMU, Agenda.COD_AGDA_SIMU";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {



                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOEscola();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoEscola = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoDiretor = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.IndicadorEscolaPrivada = dataReader.GetBoolean(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.EmailEscola = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.NomeEscola = dataReader.GetString(5);
                                    }
                                    if (!dataReader.IsDBNull(6))
                                    {
                                        transferObject.NumeroCNPJ = dataReader.GetString(6);
                                    }
                                    if (!dataReader.IsDBNull(7))
                                    {
                                        transferObject.IndicadorSorteioPendente = dataReader.GetBoolean(7);
                                    }
                                }
                                dataReader.Close();

                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Lista todas as escolas pendente de sorteio de cenários de simulação
        /// </summary>
        public override List<Escola> FindEscolasPendenteSorteio()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOEscola> result = new List<TOEscola>();
            TOEscola transferObject = null;

            try
            {
                statement = "SELECT Escola.COD_ESLA, Escola.COD_DIRE, Escola.COD_SIST_ORIG, Escola.IND_TIPO_ESLA, Escola.NOME_EMAIL, Escola.NOME_ESLA, Escola.NUM_CNPJ, Escola.IND_SORT_PEND FROM TSDBESLA Escola WITH(NOLOCK)  WHERE IND_SORT_PEND = 1";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {



                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOEscola();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoEscola = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoDiretor = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.IndicadorEscolaPrivada = dataReader.GetBoolean(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.EmailEscola = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.NomeEscola = dataReader.GetString(5);
                                    }
                                    if (!dataReader.IsDBNull(6))
                                    {
                                        transferObject.NumeroCNPJ = dataReader.GetString(6);
                                    }
                                    if (!dataReader.IsDBNull(7))
                                    {
                                        transferObject.IndicadorSorteioPendente = dataReader.GetBoolean(7);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();

                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }
            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<Escola> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOEscola> result = new List<TOEscola>();
            TOEscola transferObject = null;

            try
            {
                statement = "SELECT Escola.COD_ESLA, Escola.COD_DIRE, Escola.COD_SIST_ORIG, Escola.IND_TIPO_ESLA, Escola.NOME_EMAIL, Escola.NOME_ESLA, Escola.NUM_CNPJ, Escola.IND_SORT_PEND FROM TSDBESLA Escola WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOEscola();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoEscola = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoDiretor = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.IndicadorEscolaPrivada = dataReader.GetBoolean(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.EmailEscola = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.NomeEscola = dataReader.GetString(5);
                                    }
                                    if (!dataReader.IsDBNull(6))
                                    {
                                        transferObject.NumeroCNPJ = dataReader.GetString(6);
                                    }
                                    if (!dataReader.IsDBNull(7))
                                    {
                                        transferObject.IndicadorSorteioPendente = dataReader.GetBoolean(7);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override Escola FindByKey(int codigoEscola)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOEscola transferObject = null;

            try
            {
                statement = "SELECT Escola.COD_ESLA, Escola.COD_DIRE, Escola.COD_SIST_ORIG, Escola.IND_TIPO_ESLA, Escola.NOME_EMAIL, Escola.NOME_ESLA, Escola.NUM_CNPJ, Escola.IND_SORT_PEND FROM TSDBESLA Escola WITH(NOLOCK) WHERE Escola.COD_ESLA = @codigoEscola";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoEscola", codigoEscola));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOEscola();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoEscola = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoDiretor = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.IndicadorEscolaPrivada = dataReader.GetBoolean(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.EmailEscola = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.NomeEscola = dataReader.GetString(5);
                                    }
                                    if (!dataReader.IsDBNull(6))
                                    {
                                        transferObject.NumeroCNPJ = dataReader.GetString(6);
                                    }
                                    if (!dataReader.IsDBNull(7))
                                    {
                                        transferObject.IndicadorSorteioPendente = dataReader.GetBoolean(7);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Remove uma entidade pela sua chave primária.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(Escola entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOEscola transferObject = TranslateToDTO(entity);

                statement = "DELETE FROM TSDBESLA WHERE COD_ESLA = @codigoEscola";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave primária
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoEscola", transferObject.CodigoEscola));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma instância em memória na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(Escola entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOEscola transferObject = TranslateToDTO(entity);

                statement = "UPDATE TSDBESLA SET cOD_DIRE = @codigoDiretor, cOD_SIST_ORIG = @codigoSistemaOrigem, iND_TIPO_ESLA = @indicadorEscolaPrivada, nOME_EMAIL = @emailEscola, nOME_ESLA = @nomeEscola, nUM_CNPJ = @numeroCNPJ, iND_SORT_PEND = @indicadorSorteioPendente WHERE COD_ESLA = @codigoEscola";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que não estão na chave
                            if (transferObject.CodigoDiretor == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoDiretor", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoDiretor", transferObject.CodigoDiretor));
                            }

                            if (transferObject.CodigoSistemaOrigem == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", transferObject.CodigoSistemaOrigem));
                            }

                            command.Parameters.Add(new SqlParameter("@indicadorEscolaPrivada", transferObject.IndicadorEscolaPrivada));

                            if (transferObject.EmailEscola == null)
                            {
                                command.Parameters.Add(new SqlParameter("@emailEscola", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@emailEscola", transferObject.EmailEscola));
                            }

                            if (transferObject.NomeEscola == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeEscola", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeEscola", transferObject.NomeEscola));
                            }

                            if (transferObject.NumeroCNPJ == null)
                            {
                                command.Parameters.Add(new SqlParameter("@numeroCNPJ", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@numeroCNPJ", transferObject.NumeroCNPJ));
                            }

                            command.Parameters.Add(new SqlParameter("@indicadorSorteioPendente", transferObject.IndicadorSorteioPendente));

                            // Chave primária
                            command.Parameters.Add(new SqlParameter("@codigoEscola", transferObject.CodigoEscola));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma instância em memória na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(Escola entity)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                TOEscola transferObject = TranslateToDTO(entity);

                statement = "INSERT INTO TSDBESLA ( COD_DIRE, COD_SIST_ORIG, IND_TIPO_ESLA, NOME_EMAIL, NOME_ESLA, NUM_CNPJ, IND_SORT_PEND ) VALUES ( @codigoDiretor, @codigoSistemaOrigem, @indicadorEscolaPrivada, @emailEscola, @nomeEscola, @numeroCNPJ, @indicadorSorteioPendente )  ; SELECT SCOPE_IDENTITY();";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoDiretor == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoDiretor", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoDiretor", transferObject.CodigoDiretor));
                            }

                            if (transferObject.CodigoSistemaOrigem == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", transferObject.CodigoSistemaOrigem));
                            }

                            command.Parameters.Add(new SqlParameter("@indicadorEscolaPrivada", transferObject.IndicadorEscolaPrivada));

                            if (transferObject.EmailEscola == null)
                            {
                                command.Parameters.Add(new SqlParameter("@emailEscola", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@emailEscola", transferObject.EmailEscola));
                            }

                            if (transferObject.NomeEscola == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeEscola", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeEscola", transferObject.NomeEscola));
                            }

                            if (transferObject.NumeroCNPJ == null)
                            {
                                command.Parameters.Add(new SqlParameter("@numeroCNPJ", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@numeroCNPJ", transferObject.NumeroCNPJ));
                            }

                            command.Parameters.Add(new SqlParameter("@indicadorSorteioPendente", transferObject.IndicadorSorteioPendente));


                            long initTime = System.DateTime.Now.Ticks;

                            entity.Codigo = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        protected override List<Escola> TranslateFromDTO(List<TOEscola> entityDTO)
        {
            if (entityDTO == null) return null;

            var _lista = new List<Escola>();
            foreach (TOEscola et in entityDTO)
            {
                _lista.Add(TranslateFromDTO(et));
            }
            return _lista;
        }

        protected override Escola TranslateFromDTO(TOEscola entityDTO)
        {
            return entityDTO == null ? null : new Escola()
            {
                Codigo = entityDTO.CodigoEscola,
                CodigoOriginalLMS = entityDTO.CodigoSistemaOrigem,
                Diretor = new Diretor() { Codigo = entityDTO.CodigoDiretor },
                Email = entityDTO.EmailEscola,
                IndicadorEscolaPrivada = entityDTO.IndicadorEscolaPrivada,
                Nome = entityDTO.NomeEscola,
                NumeroCNPJ = entityDTO.NumeroCNPJ,
                TipoStatusSorteioCenarios = entityDTO.IndicadorSorteioPendente == true ? TipoStatusSorteioCenarios.Pendente : TipoStatusSorteioCenarios.OK
            };
        }

        protected override List<TOEscola> TranslateToDTO(List<Escola> entity)
        {
            if (entity == null) return null;

            var _lista = new List<TOEscola>();
            foreach (Escola et in entity)
            {
                _lista.Add(TranslateToDTO(et));
            }
            return _lista;
        }

        protected override TOEscola TranslateToDTO(Escola entity)
        {
            return entity == null ? null : new TOEscola()
            {
                CodigoEscola = entity.Codigo,
                CodigoDiretor = entity.Diretor.Codigo,
                CodigoSistemaOrigem = entity.CodigoOriginalLMS,
                EmailEscola = entity.Email,
                IndicadorEscolaPrivada = entity.IndicadorEscolaPrivada,
                NumeroCNPJ = entity.NumeroCNPJ,
                NomeEscola = entity.Nome,
                IndicadorSorteioPendente = (entity.TipoStatusSorteioCenarios == TipoStatusSorteioCenarios.Pendente)
            };
        }
    }
}
