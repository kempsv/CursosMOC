using System;
using System.Data;
//using Framework.AcessoDados;


namespace Desafio.Simulador.Bcl.Competidor.Impl.Dao
{
    
    /// <summary>
    /// Implementa��o de EscolaDAO - SqlServer
    /// </summary>
    public abstract class EscolaDAOSqlServerImpl : EscolaDAO
    {
        
    } //Escola
}
