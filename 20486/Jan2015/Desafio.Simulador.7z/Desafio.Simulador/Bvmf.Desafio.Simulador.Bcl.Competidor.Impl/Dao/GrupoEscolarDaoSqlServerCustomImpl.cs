﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Competidor.Entidade;
using System.Collections.Generic;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Competidor.Impl.Dao
{
    public class GrupoEscolarDAOSqlServerCustomImpl : GrupoEscolarDAOSqlServerImpl
    {
        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "GrupoEscolarDAOSqlServerCustomImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<GrupoEscolar> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOGrupoEscolar> result = new List<TOGrupoEscolar>();
            TOGrupoEscolar transferObject = null;

            try
            {
                statement = "SELECT Grupo.COD_GRUP_ESCL, Grupo.COD_ESLA, Grupo.COD_SIST_ORIG, Grupo.IND_GRUP_ESCL_DSCL, Grupo.NOME_GRUP_ESCL, Grupo.VAL_INVE_INIC FROM TSDBGRUP_ESCL Grupo WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Competidor.Entidade.TOGrupoEscolar();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoEscola = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.IndicadorDesclassificado = dataReader.GetBoolean(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.NomeGrupoEscolar = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.ValorInvestimentoInicial = dataReader.GetDecimal(5);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override GrupoEscolar FindByKey(int codigoGrupoEscolar)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOGrupoEscolar transferObject = null;

            try
            {
                statement = "SELECT Grupo.COD_GRUP_ESCL, Grupo.COD_ESLA, Grupo.COD_SIST_ORIG, Grupo.IND_GRUP_ESCL_DSCL, Grupo.NOME_GRUP_ESCL, Grupo.VAL_INVE_INIC FROM TSDBGRUP_ESCL Grupo WITH(NOLOCK) WHERE Grupo.COD_GRUP_ESCL = @codigoGrupoEscolar";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", codigoGrupoEscolar));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Competidor.Entidade.TOGrupoEscolar();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoEscola = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.IndicadorDesclassificado = dataReader.GetBoolean(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.NomeGrupoEscolar = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.ValorInvestimentoInicial = dataReader.GetDecimal(5);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Obtêm o grupo escolar pelo código origem do LMS
        /// </summary>
        public override GrupoEscolar FindGrupoEscolarSimulacaoByCodigoLMS(int codigoOrigemLMS)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            Desafio.Simulador.Bcl.Competidor.Entidade.TOGrupoEscolar transferObject = null;

            try
            {
                statement = "SELECT Grupo.COD_GRUP_ESCL, Grupo.COD_ESLA, Grupo.COD_SIST_ORIG, Grupo.IND_GRUP_ESCL_DSCL, Grupo.NOME_GRUP_ESCL, Grupo.VAL_INVE_INIC FROM TSDBGRUP_ESCL Grupo WITH(NOLOCK)  WHERE COD_SIST_ORIG = " + codigoOrigemLMS + "";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {



                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Competidor.Entidade.TOGrupoEscolar();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoEscola = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.IndicadorDesclassificado = dataReader.GetBoolean(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.NomeGrupoEscolar = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.ValorInvestimentoInicial = dataReader.GetDecimal(5);
                                    }
                                }
                                dataReader.Close();

                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Lista todos os grupos escolares de uma determinada agenda de simulação
        /// </summary>
        public override List<GrupoEscolar> FindGrupoEscolarByAgendaSimulacao(int agendaSimulacao)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOGrupoEscolar> result = new List<TOGrupoEscolar>();
            Desafio.Simulador.Bcl.Competidor.Entidade.TOGrupoEscolar transferObject = null;

            try
            {
                statement = "SELECT DISTINCT Grupo.COD_GRUP_ESCL, Grupo.COD_ESLA, Grupo.COD_SIST_ORIG, Grupo.IND_GRUP_ESCL_DSCL, Grupo.NOME_GRUP_ESCL, Grupo.VAL_INVE_INIC FROM TSDBGRUP_ESCL Grupo WITH(NOLOCK)  INNER JOIN TSDBVINC_AGDA_RDAD_GRUP_ESCL agenda WITH(NOLOCK)  ON Agenda.COD_GRUP_ESCL = Grupo.COD_GRUP_ESCL WHERE Agenda.COD_AGDA_SIMU = " + agendaSimulacao + "";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {



                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Competidor.Entidade.TOGrupoEscolar();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoEscola = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.IndicadorDesclassificado = dataReader.GetBoolean(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.NomeGrupoEscolar = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.ValorInvestimentoInicial = dataReader.GetDecimal(5);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();

                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }
            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Lista todos os grupos escolares pela código da Escola
        /// </summary>
        public override List<GrupoEscolar> FindGruposEcolaresByEscola(int codigoEscola)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOGrupoEscolar> result = new List<TOGrupoEscolar>();
            Desafio.Simulador.Bcl.Competidor.Entidade.TOGrupoEscolar transferObject = null;

            try
            {
                statement = "SELECT Grupo.COD_GRUP_ESCL, Grupo.COD_ESLA, Grupo.COD_SIST_ORIG, Grupo.IND_GRUP_ESCL_DSCL, Grupo.NOME_GRUP_ESCL, Grupo.VAL_INVE_INIC FROM TSDBGRUP_ESCL Grupo WITH(NOLOCK)  INNER JOIN TSDBESLA Escola WITH(NOLOCK)  ON Escola.COD_ESLA = Grupo.COD_ESLA WHERE Escola.Cod_Esla = " + codigoEscola + "";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {



                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Competidor.Entidade.TOGrupoEscolar();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoEscola = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoSistemaOrigem = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.IndicadorDesclassificado = dataReader.GetBoolean(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.NomeGrupoEscolar = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.ValorInvestimentoInicial = dataReader.GetDecimal(5);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();

                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Remove uma entidade pela sua chave primária.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(GrupoEscolar entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOGrupoEscolar transferObject = TranslateToDTO(entity);

                statement = "DELETE FROM TSDBGRUP_ESCL WHERE COD_GRUP_ESCL = @codigoGrupoEscolar";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave primária
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", transferObject.CodigoGrupoEscolar));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma instância em memória na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(GrupoEscolar entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOGrupoEscolar transferObject = TranslateToDTO(entity);

                statement = "UPDATE TSDBGRUP_ESCL SET cOD_ESLA = @codigoEscola, cOD_SIST_ORIG = @codigoSistemaOrigem, iND_GRUP_ESCL_DSCL = @indicadorDesclassificado, nOME_GRUP_ESCL = @nomeGrupoEscolar, vAL_INVE_INIC = @valorInvestimentoInicial WHERE COD_GRUP_ESCL = @codigoGrupoEscolar";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que não estão na chave
                            if (transferObject.CodigoEscola == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoEscola", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoEscola", transferObject.CodigoEscola));
                            }

                            if (transferObject.CodigoSistemaOrigem == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", transferObject.CodigoSistemaOrigem));
                            }

                            command.Parameters.Add(new SqlParameter("@indicadorDesclassificado", transferObject.IndicadorDesclassificado));

                            if (transferObject.NomeGrupoEscolar == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeGrupoEscolar", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeGrupoEscolar", transferObject.NomeGrupoEscolar));
                            }

                            if (transferObject.ValorInvestimentoInicial == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorInvestimentoInicial", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorInvestimentoInicial", transferObject.ValorInvestimentoInicial));
                            }

                            // Chave primária
                            command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", transferObject.CodigoGrupoEscolar));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma instância em memória na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(GrupoEscolar entity)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                TOGrupoEscolar transferObject = TranslateToDTO(entity);

                statement = "INSERT INTO TSDBGRUP_ESCL ( COD_ESLA, COD_SIST_ORIG, IND_GRUP_ESCL_DSCL, NOME_GRUP_ESCL, VAL_INVE_INIC ) VALUES ( @codigoEscola, @codigoSistemaOrigem, @indicadorDesclassificado, @nomeGrupoEscolar, @valorInvestimentoInicial )  ; SELECT SCOPE_IDENTITY();";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoEscola == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoEscola", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoEscola", transferObject.CodigoEscola));
                            }

                            if (transferObject.CodigoSistemaOrigem == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoSistemaOrigem", transferObject.CodigoSistemaOrigem));
                            }

                            command.Parameters.Add(new SqlParameter("@indicadorDesclassificado", transferObject.IndicadorDesclassificado));

                            if (transferObject.NomeGrupoEscolar == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeGrupoEscolar", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeGrupoEscolar", transferObject.NomeGrupoEscolar));
                            }

                            if (transferObject.ValorInvestimentoInicial == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorInvestimentoInicial", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorInvestimentoInicial", transferObject.ValorInvestimentoInicial));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            entity.Codigo = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        protected override List<GrupoEscolar> TranslateFromDTO(List<TOGrupoEscolar> entityDTO)
        {
            var _lista = new List<GrupoEscolar>();
            foreach (TOGrupoEscolar et in entityDTO)
            {
                _lista.Add(TranslateFromDTO(et));
            }
            return _lista;
        }

        protected override GrupoEscolar TranslateFromDTO(TOGrupoEscolar entityDTO)
        {
            return new GrupoEscolar()
            {
                Codigo = entityDTO.CodigoGrupoEscolar,
                NomeGrupo = entityDTO.NomeGrupoEscolar,
                CodigoOriginalLMS = entityDTO.CodigoSistemaOrigem,
                IndicadorGrupoDesclassificado = entityDTO.IndicadorDesclassificado,
                ValorInvestimentoInicial = entityDTO.ValorInvestimentoInicial,
                Escola = new Escola() { Codigo = entityDTO.CodigoEscola }
            };
        }

        protected override List<TOGrupoEscolar> TranslateToDTO(List<GrupoEscolar> entity)
        {
            var _lista = new List<TOGrupoEscolar>();
            foreach (GrupoEscolar et in entity)
            {
                _lista.Add(TranslateToDTO(et));
            }
            return _lista;
        }

        protected override TOGrupoEscolar TranslateToDTO(GrupoEscolar entity)
        {
            return new TOGrupoEscolar()
            {
                CodigoEscola = entity.Escola.Codigo,
                CodigoGrupoEscolar = entity.Codigo,
                CodigoSistemaOrigem = entity.CodigoOriginalLMS,
                IndicadorDesclassificado = entity.IndicadorGrupoDesclassificado,
                NomeGrupoEscolar = entity.NomeGrupo,
                ValorInvestimentoInicial = entity.ValorInvestimentoInicial
            };
        }

    }
}
