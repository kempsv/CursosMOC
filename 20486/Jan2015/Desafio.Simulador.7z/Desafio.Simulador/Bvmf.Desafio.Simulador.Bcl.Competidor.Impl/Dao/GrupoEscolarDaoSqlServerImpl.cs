using System;
using System.Data;
//using Framework.AcessoDados;


namespace Desafio.Simulador.Bcl.Competidor.Impl.Dao
{
    
    /// <summary>
    /// Implementa��o de GrupoEscolarDAO - SqlServer
    /// </summary>
    public abstract class GrupoEscolarDAOSqlServerImpl : GrupoEscolarDAO
    {
        
    } //GrupoEscolar
}
