using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Entidade;
using System.Collections.Generic;
using Desafio.Simulador.Util.Logger;
using System.Transactions;

namespace Desafio.Simulador.Bcl.Agendamento.Simulacao.Impl.Dao
{

    /// <summary>
    /// Implementa��o de PrecoPapelAgendamentoDAO - SqlServer
    /// </summary>
    public class PrecoPapelAgendamentoDAOSqlServerImpl : PrecoPapelAgendamentoDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "PrecoPapelAgendamentoDAOSqlServerImpl";

        /// <summary>
        /// Lista os papeis cadastradas com pre�os inicial da simula��o pela identificador da semana de simula��o
        /// </summary>
        public override List<TOPrecoPapelAgendamento> FindPapeisBySemanaSimulacao(int identificadorSemanaSimulacao)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOPrecoPapelAgendamento> result = new List<TOPrecoPapelAgendamento>();
            TOPrecoPapelAgendamento transferObject = null;

            try
            {
                statement = "SELECT PRECOPAPEL.COD_TIPO_SEMA_SIMU, PRECOPAPEL.COD_PAP, PRECOPAPEL.VAL_PREC_PAP_AGDA_SIMU FROM TSDBPREC_PAP_AGDA_SIMU PRECOPAPEL WITH(NOLOCK)  INNER JOIN TSDBTIPO_SEMA_SIMU TIPOSEMANA WITH(NOLOCK)  ON PRECOPAPEL.COD_TIPO_SEMA_SIMU = TIPOSEMANA.COD_TIPO_SEMA_SIMU WHERE TIPOSEMANA.COD_TIPO_SEMA_SIMU = " + identificadorSemanaSimulacao + "";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {



                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOPrecoPapelAgendamento();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoTipoSemana = dataReader.GetInt16(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoPapel = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.ValorPrecoPapel = dataReader.GetDecimal(2);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();

                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Remove uma entidade pela sua chave prim�ria.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(TOPrecoPapelAgendamento transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                //statement = "DELETE FROM TSDBPREC_PAP_AGDA_SIMU WHERE COD_AGDA_SIMU = @codigoAgenda AND COD_PAP = @codigoPapel";
                statement = "DELETE FROM TSDBPREC_PAP_AGDA_SIMU WHERE COD_TIPO_SEMA_SIMU = @codigoTipoSemana AND COD_PAP = @codigoPapel";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave prim�ria
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoTipoSemana", transferObject.CodigoTipoSemana));
                            command.Parameters.Add(new SqlParameter("@codigoPapel", transferObject.CodigoPapel));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TOPrecoPapelAgendamento transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                //statement = "INSERT INTO TSDBPREC_PAP_AGDA_SIMU ( COD_AGDA_SIMU,      COD_PAP, VAL_PREC_PAP_AGDA_SIMU ) VALUES ( @codigoAgenda, @codigoPapel, @valorPrecoPapel ) ";
                statement = "INSERT INTO TSDBPREC_PAP_AGDA_SIMU ( COD_TIPO_SEMA_SIMU, COD_PAP, VAL_PREC_PAP_AGDA_SIMU ) VALUES ( @codigoTipoSemana, @codigoPapel, @valorPrecoPapel ) ";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoTipoSemana == short.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoSemana", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoSemana", transferObject.CodigoTipoSemana));
                            }

                            if (transferObject.CodigoPapel == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoPapel", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoPapel", transferObject.CodigoPapel));
                            }

                            if (transferObject.ValorPrecoPapel == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorPrecoPapel", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorPrecoPapel", transferObject.ValorPrecoPapel));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }


    } //PrecoPapelAgendamento
}
