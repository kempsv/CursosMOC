using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Competidor.Entidade;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Competidor.Impl.Dao
{

    /// <summary>
    /// Implementa��o de TelefoneDAO - SqlServer
    /// </summary>
    public class TelefoneDAOSqlServerImpl : TelefoneDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "TelefoneDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOTelefone> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOTelefone> result = new List<TOTelefone>();
            TOTelefone transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBTEL.COD_TEL, TSDBTEL.COD_TIPO_TEL, TSDBTEL.NOME_CONT, TSDBTEL.NUM_TEL FROM TSDBTEL TSDBTEL WITH(NOLOCK)";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOTelefone();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoTelefone = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoTipoTelefone = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.NomeContato = dataReader.GetString(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.NumeroTelefone = dataReader.GetString(3);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TOTelefone FindByKey(int codigoTelefone)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOTelefone transferObject = null;

            try
            {
                statement = "SELECT TSDBTEL.COD_TEL, TSDBTEL.COD_TIPO_TEL, TSDBTEL.NOME_CONT, TSDBTEL.NUM_TEL FROM TSDBTEL TSDBTEL WITH(NOLOCK) WHERE TSDBTEL.COD_TEL = @codigoTelefone";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoTelefone", codigoTelefone));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOTelefone();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoTelefone = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoTipoTelefone = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.NomeContato = dataReader.GetString(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.NumeroTelefone = dataReader.GetString(3);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Remove uma entidade pela sua chave prim�ria.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(TOTelefone transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBTEL WHERE COD_TEL = @codigoTelefone";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave prim�ria
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoTelefone", transferObject.CodigoTelefone));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma inst�ncia em mem�ria na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(TOTelefone transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "UPDATE TSDBTEL SET cOD_TIPO_TEL = @codigoTipoTelefone, nOME_CONT = @nomeContato, nUM_TEL = @numeroTelefone WHERE COD_TEL = @codigoTelefone";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que n�o est�o na chave
                            if (transferObject.CodigoTipoTelefone == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoTelefone", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoTelefone", transferObject.CodigoTipoTelefone));
                            }

                            if (transferObject.NomeContato == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeContato", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeContato", transferObject.NomeContato));
                            }

                            if (transferObject.NumeroTelefone == null)
                            {
                                command.Parameters.Add(new SqlParameter("@numeroTelefone", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@numeroTelefone", transferObject.NumeroTelefone));
                            }

                            // Chave prim�ria
                            command.Parameters.Add(new SqlParameter("@codigoTelefone", transferObject.CodigoTelefone));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TOTelefone transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBTEL ( COD_TIPO_TEL, NOME_CONT, NUM_TEL ) VALUES ( @codigoTipoTelefone, @nomeContato, @numeroTelefone )  ; SELECT SCOPE_IDENTITY();";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoTipoTelefone == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoTelefone", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoTelefone", transferObject.CodigoTipoTelefone));
                            }

                            if (transferObject.NomeContato == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeContato", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeContato", transferObject.NomeContato));
                            }

                            if (transferObject.NumeroTelefone == null)
                            {
                                command.Parameters.Add(new SqlParameter("@numeroTelefone", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@numeroTelefone", transferObject.NumeroTelefone));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            transferObject.CodigoTelefone = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }


    } //Telefone
}
