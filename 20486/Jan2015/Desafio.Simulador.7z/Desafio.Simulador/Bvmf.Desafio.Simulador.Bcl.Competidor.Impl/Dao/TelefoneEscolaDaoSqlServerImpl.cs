using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Competidor.Entidade;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Competidor.Impl.Dao
{

    /// <summary>
    /// Implementa��o de TelefoneEscolaDAO - SqlServer
    /// </summary>
    public class TelefoneEscolaDAOSqlServerImpl : TelefoneEscolaDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "TelefoneEscolaDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOTelefoneEscola> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOTelefoneEscola> result = new List<TOTelefoneEscola>();
            TOTelefoneEscola transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBTEL_ESLA.COD_ESLA, TSDBTEL_ESLA.COD_TEL FROM TSDBTEL_ESLA TSDBTEL_ESLA WITH(NOLOCK)";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOTelefoneEscola();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoEscola = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoTelefone = dataReader.GetInt32(1);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Obt�m os telefones de uma determinada Escola
        /// </summary>
        public override List<TOTelefoneEscola> FindTelefonesByEscola(int codigoEscola)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOTelefoneEscola> result = new List<TOTelefoneEscola>();
            TOTelefoneEscola transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBTEL_ESLA.COD_ESLA, TSDBTEL_ESLA.COD_TEL FROM TSDBTEL_ESLA TSDBTEL_ESLA WITH(NOLOCK)  WHERE COD_ESLA = " + codigoEscola + "";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {



                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOTelefoneEscola();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoEscola = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoTelefone = dataReader.GetInt32(1);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();

                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Exclui todos os telefones de uma determinada Escola
        /// </summary>
        public override void DeleteByEscola(int codigoEscola)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBTEL_ESLA WHERE COD_ESLA = " + codigoEscola + "";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TOTelefoneEscola transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBTEL_ESLA ( COD_ESLA, COD_TEL ) VALUES ( @codigoEscola, @codigoTelefone ) ";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoEscola == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoEscola", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoEscola", transferObject.CodigoEscola));
                            }

                            if (transferObject.CodigoTelefone == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTelefone", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTelefone", transferObject.CodigoTelefone));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }


    } //TelefoneEscola
}
