using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Competidor.Entidade;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Competidor.Impl.Dao
{

    /// <summary>
    /// Implementa��o de TipoCompetidorDAO - SqlServer
    /// </summary>
    public class TipoCompetidorDAOSqlServerImpl : TipoCompetidorDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "TipoCompetidorDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOTipoCompetidor> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOTipoCompetidor> result = new List<TOTipoCompetidor>();
            TOTipoCompetidor transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBTIPO_COMPT.COD_TIPO_COMPT, TSDBTIPO_COMPT.NOME_TIPO_COMPT FROM TSDBTIPO_COMPT TSDBTIPO_COMPT WITH(NOLOCK)";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOTipoCompetidor();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoTipoCompetidor = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.NomeTipoCompetidor = dataReader.GetString(1);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TOTipoCompetidor FindByKey(int codigoTipoCompetidor)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOTipoCompetidor transferObject = null;

            try
            {
                statement = "SELECT TSDBTIPO_COMPT.COD_TIPO_COMPT, TSDBTIPO_COMPT.NOME_TIPO_COMPT FROM TSDBTIPO_COMPT TSDBTIPO_COMPT WITH(NOLOCK) WHERE TSDBTIPO_COMPT.COD_TIPO_COMPT = @codigoTipoCompetidor";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoTipoCompetidor", codigoTipoCompetidor));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOTipoCompetidor();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoTipoCompetidor = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.NomeTipoCompetidor = dataReader.GetString(1);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Remove uma entidade pela sua chave prim�ria.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(TOTipoCompetidor transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBTIPO_COMPT WHERE COD_TIPO_COMPT = @codigoTipoCompetidor";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave prim�ria
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoTipoCompetidor", transferObject.CodigoTipoCompetidor));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma inst�ncia em mem�ria na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(TOTipoCompetidor transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "UPDATE TSDBTIPO_COMPT SET nOME_TIPO_COMPT = @nomeTipoCompetidor WHERE COD_TIPO_COMPT = @codigoTipoCompetidor";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que n�o est�o na chave
                            if (transferObject.NomeTipoCompetidor == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeTipoCompetidor", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeTipoCompetidor", transferObject.NomeTipoCompetidor));
                            }

                            // Chave prim�ria
                            command.Parameters.Add(new SqlParameter("@codigoTipoCompetidor", transferObject.CodigoTipoCompetidor));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TOTipoCompetidor transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBTIPO_COMPT ( COD_TIPO_COMPT, NOME_TIPO_COMPT ) VALUES ( @codigoTipoCompetidor, @nomeTipoCompetidor ) ";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoTipoCompetidor == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoCompetidor", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoCompetidor", transferObject.CodigoTipoCompetidor));
                            }

                            if (transferObject.NomeTipoCompetidor == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeTipoCompetidor", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeTipoCompetidor", transferObject.NomeTipoCompetidor));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }


    } //TipoCompetidor
}
