using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Competidor.Entidade;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Competidor.Impl.Dao
{

    /// <summary>
    /// Implementa��o de TipoTelefoneDAO - SqlServer
    /// </summary>
    public class TipoTelefoneDAOSqlServerImpl : TipoTelefoneDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "TipoTelefoneDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOTipoTelefone> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOTipoTelefone> result = new List<TOTipoTelefone>();
            TOTipoTelefone transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBTIPO_TEL.COD_TIPO_TEL, TSDBTIPO_TEL.NOME_TIPO_TEL FROM TSDBTIPO_TEL TSDBTIPO_TEL WITH(NOLOCK)";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOTipoTelefone();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoTipoTelefone = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.NomeTipoTelefone = dataReader.GetString(1);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TOTipoTelefone FindByKey(int codigoTipoTelefone)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOTipoTelefone transferObject = null;

            try
            {
                statement = "SELECT TSDBTIPO_TEL.COD_TIPO_TEL, TSDBTIPO_TEL.NOME_TIPO_TEL FROM TSDBTIPO_TEL TSDBTIPO_TEL WITH(NOLOCK) WHERE TSDBTIPO_TEL.COD_TIPO_TEL = @codigoTipoTelefone";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoTipoTelefone", codigoTipoTelefone));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOTipoTelefone();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoTipoTelefone = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.NomeTipoTelefone = dataReader.GetString(1);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Remove uma entidade pela sua chave prim�ria.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(TOTipoTelefone transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBTIPO_TEL WHERE COD_TIPO_TEL = @codigoTipoTelefone";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave prim�ria
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoTipoTelefone", transferObject.CodigoTipoTelefone));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma inst�ncia em mem�ria na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(TOTipoTelefone transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "UPDATE TSDBTIPO_TEL SET nOME_TIPO_TEL = @nomeTipoTelefone WHERE COD_TIPO_TEL = @codigoTipoTelefone";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que n�o est�o na chave
                            if (transferObject.NomeTipoTelefone == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeTipoTelefone", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeTipoTelefone", transferObject.NomeTipoTelefone));
                            }

                            // Chave prim�ria
                            command.Parameters.Add(new SqlParameter("@codigoTipoTelefone", transferObject.CodigoTipoTelefone));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TOTipoTelefone transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBTIPO_TEL ( COD_TIPO_TEL, NOME_TIPO_TEL ) VALUES ( @codigoTipoTelefone, @nomeTipoTelefone ) ";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoTipoTelefone == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoTelefone", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTipoTelefone", transferObject.CodigoTipoTelefone));
                            }

                            if (transferObject.NomeTipoTelefone == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeTipoTelefone", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeTipoTelefone", transferObject.NomeTipoTelefone));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

    } //TipoTelefone
}
