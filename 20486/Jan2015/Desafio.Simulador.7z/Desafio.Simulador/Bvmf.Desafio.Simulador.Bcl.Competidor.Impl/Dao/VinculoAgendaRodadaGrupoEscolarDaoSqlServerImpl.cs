using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Entidade;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Agendamento.Simulacao.Impl.Dao
{

    /// <summary>
    /// Implementa��o de VinculoAgendaRodadaGrupoEscolarDAO - SqlServer
    /// </summary>
    public class VinculoAgendaRodadaGrupoEscolarDAOSqlServerImpl : VinculoAgendaRodadaGrupoEscolarDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "VinculoAgendaRodadaGrupoEscolarDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOVinculoAgendaRodadaGrupoEscolar> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOVinculoAgendaRodadaGrupoEscolar> result = new List<TOVinculoAgendaRodadaGrupoEscolar>();
            TOVinculoAgendaRodadaGrupoEscolar transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBVINC_AGDA_RDAD_GRUP_ESCL.COD_GRUP_ESCL, TSDBVINC_AGDA_RDAD_GRUP_ESCL.COD_AGDA_SIMU, TSDBVINC_AGDA_RDAD_GRUP_ESCL.COD_RDAD, TSDBVINC_AGDA_RDAD_GRUP_ESCL.QTE_RDAD_CONG, TSDBVINC_AGDA_RDAD_GRUP_ESCL.IND_SIMU_CONC FROM TSDBVINC_AGDA_RDAD_GRUP_ESCL TSDBVINC_AGDA_RDAD_GRUP_ESCL WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOVinculoAgendaRodadaGrupoEscolar();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoAgendaSimulacao = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoRodada = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.ContadorRodadaContingencia = dataReader.GetInt16(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.IndicadorSimulacaoConcluida = dataReader.GetBoolean(4);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca todas os vinculos de um Grupo/Agenda
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOVinculoAgendaRodadaGrupoEscolar> FindVinculosAgendaGrupoEscolar(int codigoGrupo, int codigoAgendaSimulacao)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOVinculoAgendaRodadaGrupoEscolar> result = new List<TOVinculoAgendaRodadaGrupoEscolar>();
            TOVinculoAgendaRodadaGrupoEscolar transferObject = null;

            try
            {
                statement = "SELECT TSDBVINC_AGDA_RDAD_GRUP_ESCL.COD_GRUP_ESCL, TSDBVINC_AGDA_RDAD_GRUP_ESCL.COD_AGDA_SIMU, TSDBVINC_AGDA_RDAD_GRUP_ESCL.COD_RDAD, TSDBVINC_AGDA_RDAD_GRUP_ESCL.QTE_RDAD_CONG, TSDBVINC_AGDA_RDAD_GRUP_ESCL.IND_SIMU_CONC FROM TSDBVINC_AGDA_RDAD_GRUP_ESCL TSDBVINC_AGDA_RDAD_GRUP_ESCL WITH(NOLOCK) WHERE TSDBVINC_AGDA_RDAD_GRUP_ESCL.COD_GRUP_ESCL = " + codigoGrupo + " and TSDBVINC_AGDA_RDAD_GRUP_ESCL.COD_AGDA_SIMU = " + codigoAgendaSimulacao + "";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOVinculoAgendaRodadaGrupoEscolar();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoAgendaSimulacao = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoRodada = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.ContadorRodadaContingencia = dataReader.GetInt16(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.IndicadorSimulacaoConcluida = dataReader.GetBoolean(4);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TOVinculoAgendaRodadaGrupoEscolar FindByKey(int codigoGrupoEscolar, int codigoAgendaSimulacao, int codigoRodada)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOVinculoAgendaRodadaGrupoEscolar transferObject = null;

            try
            {
                statement = "SELECT TSDBVINC_AGDA_RDAD_GRUP_ESCL.COD_GRUP_ESCL, TSDBVINC_AGDA_RDAD_GRUP_ESCL.COD_AGDA_SIMU, TSDBVINC_AGDA_RDAD_GRUP_ESCL.COD_RDAD, TSDBVINC_AGDA_RDAD_GRUP_ESCL.QTE_RDAD_CONG, TSDBVINC_AGDA_RDAD_GRUP_ESCL.IND_SIMU_CONC FROM TSDBVINC_AGDA_RDAD_GRUP_ESCL TSDBVINC_AGDA_RDAD_GRUP_ESCL WITH(NOLOCK) WHERE TSDBVINC_AGDA_RDAD_GRUP_ESCL.COD_GRUP_ESCL = @codigoGrupoEscolar AND TSDBVINC_AGDA_RDAD_GRUP_ESCL.COD_AGDA_SIMU = @codigoAgendaSimulacao AND TSDBVINC_AGDA_RDAD_GRUP_ESCL.COD_RDAD = @codigoRodada";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", codigoGrupoEscolar));

                                command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", codigoAgendaSimulacao));

                                command.Parameters.Add(new SqlParameter("@codigoRodada", codigoRodada));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOVinculoAgendaRodadaGrupoEscolar();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoAgendaSimulacao = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoRodada = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.ContadorRodadaContingencia = dataReader.GetInt16(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.IndicadorSimulacaoConcluida = dataReader.GetBoolean(4);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Remove uma entidade pela sua chave prim�ria.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(TOVinculoAgendaRodadaGrupoEscolar transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBVINC_AGDA_RDAD_GRUP_ESCL WHERE COD_GRUP_ESCL = @codigoGrupoEscolar AND COD_AGDA_SIMU = @codigoAgendaSimulacao AND COD_RDAD = @codigoRodada";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave prim�ria
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", transferObject.CodigoGrupoEscolar));
                            command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", transferObject.CodigoAgendaSimulacao));
                            command.Parameters.Add(new SqlParameter("@codigoRodada", transferObject.CodigoRodada));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TOVinculoAgendaRodadaGrupoEscolar transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBVINC_AGDA_RDAD_GRUP_ESCL ( COD_GRUP_ESCL, COD_AGDA_SIMU, COD_RDAD, QTE_RDAD_CONG, IND_SIMU_CONC ) VALUES ( @codigoGrupoEscolar, @codigoAgendaSimulacao, @codigoRodada, @contadorRodadaContingencia, @indicadorSimulacaoConcluida ) ";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoGrupoEscolar == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", transferObject.CodigoGrupoEscolar));
                            }

                            if (transferObject.CodigoAgendaSimulacao == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", transferObject.CodigoAgendaSimulacao));
                            }

                            if (transferObject.CodigoRodada == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoRodada", transferObject.CodigoRodada));
                            }

                            if (transferObject.ContadorRodadaContingencia == short.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@contadorRodadaContingencia", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@contadorRodadaContingencia", transferObject.ContadorRodadaContingencia));
                            }

                            command.Parameters.Add(new SqlParameter("@indicadorSimulacaoConcluida", transferObject.IndicadorSimulacaoConcluida));


                            long initTime = System.DateTime.Now.Ticks;

                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza campo IndicadorSimulacaoConcluida na fonte de dados.
        /// </summary>
        /// <param name="transferObject">Entidade a ser persistida</param>
        public override void Update(TOVinculoAgendaRodadaGrupoEscolar transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "UPDATE TSDBVINC_AGDA_RDAD_GRUP_ESCL SET qTE_RDAD_CONG = @contadorRodadaContingencia, iND_SIMU_CONC = @indicadorSimulacaoConcluida WHERE COD_GRUP_ESCL = @codigoGrupoEscolar AND COD_AGDA_SIMU = @codigoAgendaSimulacao AND COD_RDAD = @codigoRodada";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que n�o est�o na chave
                            if (transferObject.ContadorRodadaContingencia == short.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@contadorRodadaContingencia", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@contadorRodadaContingencia", transferObject.ContadorRodadaContingencia));
                            }

                            command.Parameters.Add(new SqlParameter("@indicadorSimulacaoConcluida", transferObject.IndicadorSimulacaoConcluida));

                            // Chave prim�ria
                            command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", transferObject.CodigoGrupoEscolar));
                            command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", transferObject.CodigoAgendaSimulacao));
                            command.Parameters.Add(new SqlParameter("@codigoRodada", transferObject.CodigoRodada));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza o contador de contingencia de rodadas de simula��o
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void UpdateContadorContingencia(TOVinculoAgendaRodadaGrupoEscolar transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "UPDATE TSDBVINC_AGDA_RDAD_GRUP_ESCL SET qTE_RDAD_CONG = @contadorRodadaContingencia WHERE COD_GRUP_ESCL = @codigoGrupoEscolar AND COD_AGDA_SIMU = @codigoAgendaSimulacao AND COD_RDAD = @codigoRodada";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que n�o est�o na chave
                            if (transferObject.ContadorRodadaContingencia == short.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@contadorRodadaContingencia", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@contadorRodadaContingencia", transferObject.ContadorRodadaContingencia));
                            }
                            // Chave prim�ria
                            command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", transferObject.CodigoGrupoEscolar));
                            command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", transferObject.CodigoAgendaSimulacao));
                            command.Parameters.Add(new SqlParameter("@codigoRodada", transferObject.CodigoRodada));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }
        }


    } //VinculoAgendaRodadaGrupoEscolar
}
