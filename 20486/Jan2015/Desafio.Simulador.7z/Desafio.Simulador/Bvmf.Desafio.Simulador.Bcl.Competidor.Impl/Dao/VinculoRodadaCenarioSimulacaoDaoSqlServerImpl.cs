using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Entidade;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Agendamento.Simulacao.Impl.Dao
{

    /// <summary>
    /// Implementa��o de VinculoRodadaCenarioSimulacaoDAO - SqlServer
    /// </summary>
    public class VinculoRodadaCenarioSimulacaoDAOSqlServerImpl : VinculoRodadaCenarioSimulacaoDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "VinculoRodadaCenarioSimulacaoDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOVinculoRodadaCenarioSimulacao> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOVinculoRodadaCenarioSimulacao> result = new List<TOVinculoRodadaCenarioSimulacao>();
            TOVinculoRodadaCenarioSimulacao transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBVINC_RDAD_CENA_SIMU.COD_RDAD, TSDBVINC_RDAD_CENA_SIMU.COD_CENA, TSDBVINC_RDAD_CENA_SIMU.COD_AGDA_SIMU, TSDBVINC_RDAD_CENA_SIMU.COD_GRUP_ESCL, TSDBVINC_RDAD_CENA_SIMU.IND_CENA_CONG FROM TSDBVINC_RDAD_CENA_SIMU TSDBVINC_RDAD_CENA_SIMU WITH(NOLOCK)";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); 
                            using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {
                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOVinculoRodadaCenarioSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoRodada = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoCenario = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoAgendaSimulacao = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.IndicadorCenarioContingencia = dataReader.GetBoolean(4);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca todas os vinculos de um Grupo/Agenda/Rodada
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOVinculoRodadaCenarioSimulacao> FindVinculosAgendaGrupoRodada(int codigoGrupoEscolar, int codigoAgendaSimulacao, int codigoRodadaSimulacao)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOVinculoRodadaCenarioSimulacao> result = new List<TOVinculoRodadaCenarioSimulacao>();
            TOVinculoRodadaCenarioSimulacao transferObject = null;

            try
            {
                statement = "SELECT TSDBVINC_RDAD_CENA_SIMU.COD_RDAD, TSDBVINC_RDAD_CENA_SIMU.COD_CENA, TSDBVINC_RDAD_CENA_SIMU.COD_AGDA_SIMU, TSDBVINC_RDAD_CENA_SIMU.COD_GRUP_ESCL, TSDBVINC_RDAD_CENA_SIMU.IND_CENA_CONG FROM TSDBVINC_RDAD_CENA_SIMU TSDBVINC_RDAD_CENA_SIMU WITH(NOLOCK) WHERE TSDBVINC_RDAD_CENA_SIMU.COD_RDAD = " + codigoRodadaSimulacao + " and  TSDBVINC_RDAD_CENA_SIMU.COD_AGDA_SIMU = " + codigoAgendaSimulacao + " and TSDBVINC_RDAD_CENA_SIMU.COD_GRUP_ESCL = " + codigoGrupoEscolar + "";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOVinculoRodadaCenarioSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoRodada = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoCenario = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoAgendaSimulacao = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.IndicadorCenarioContingencia = dataReader.GetBoolean(4);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TOVinculoRodadaCenarioSimulacao FindByKey(int codigoRodada, int codigoCenario, int codigoAgendaSimulacao, int codigoGrupoEscolar)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOVinculoRodadaCenarioSimulacao transferObject = null;

            try
            {
                statement = "SELECT TSDBVINC_RDAD_CENA_SIMU.COD_RDAD, TSDBVINC_RDAD_CENA_SIMU.COD_CENA, TSDBVINC_RDAD_CENA_SIMU.COD_AGDA_SIMU, TSDBVINC_RDAD_CENA_SIMU.COD_GRUP_ESCL, TSDBVINC_RDAD_CENA_SIMU.IND_CENA_CONG FROM TSDBVINC_RDAD_CENA_SIMU TSDBVINC_RDAD_CENA_SIMU WITH(NOLOCK) WHERE TSDBVINC_RDAD_CENA_SIMU.COD_RDAD = @codigoRodada AND TSDBVINC_RDAD_CENA_SIMU.COD_CENA = @codigoCenario AND TSDBVINC_RDAD_CENA_SIMU.COD_AGDA_SIMU = @codigoAgendaSimulacao AND TSDBVINC_RDAD_CENA_SIMU.COD_GRUP_ESCL = @codigoGrupoEscolar";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoRodada", codigoRodada));

                                command.Parameters.Add(new SqlParameter("@codigoCenario", codigoCenario));

                                command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", codigoAgendaSimulacao));

                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", codigoGrupoEscolar));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOVinculoRodadaCenarioSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoRodada = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoCenario = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoAgendaSimulacao = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.IndicadorCenarioContingencia = dataReader.GetBoolean(4);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Remove uma entidade pela sua chave prim�ria.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(TOVinculoRodadaCenarioSimulacao transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBVINC_RDAD_CENA_SIMU WHERE COD_RDAD = @codigoRodada AND COD_AGDA_SIMU = @codigoAgendaSimulacao AND COD_GRUP_ESCL = @codigoGrupoEscolar";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoRodada", transferObject.CodigoRodada));
                            command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", transferObject.CodigoAgendaSimulacao));
                            command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", transferObject.CodigoGrupoEscolar));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma inst�ncia em mem�ria na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(TOVinculoRodadaCenarioSimulacao transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "UPDATE TSDBVINC_RDAD_CENA_SIMU SET iND_CENA_CONG = @indicadorCenarioContingencia WHERE COD_RDAD = @codigoRodada AND COD_CENA = @codigoCenario AND COD_AGDA_SIMU = @codigoAgendaSimulacao AND COD_GRUP_ESCL = @codigoGrupoEscolar";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que n�o est�o na chave
                            command.Parameters.Add(new SqlParameter("@indicadorCenarioContingencia", transferObject.IndicadorCenarioContingencia));

                            // Chave prim�ria
                            command.Parameters.Add(new SqlParameter("@codigoRodada", transferObject.CodigoRodada));
                            command.Parameters.Add(new SqlParameter("@codigoCenario", transferObject.CodigoCenario));
                            command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", transferObject.CodigoAgendaSimulacao));
                            command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", transferObject.CodigoGrupoEscolar));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TOVinculoRodadaCenarioSimulacao transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBVINC_RDAD_CENA_SIMU ( COD_RDAD, COD_CENA, COD_AGDA_SIMU, COD_GRUP_ESCL, IND_CENA_CONG ) VALUES ( @codigoRodada, @codigoCenario, @codigoAgendaSimulacao, @codigoGrupoEscolar, @indicadorCenarioContingencia ) ";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoRodada == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoRodada", transferObject.CodigoRodada));
                            }

                            if (transferObject.CodigoCenario == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCenario", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCenario", transferObject.CodigoCenario));
                            }

                            if (transferObject.CodigoAgendaSimulacao == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", transferObject.CodigoAgendaSimulacao));
                            }

                            if (transferObject.CodigoGrupoEscolar == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", transferObject.CodigoGrupoEscolar));
                            }

                            command.Parameters.Add(new SqlParameter("@indicadorCenarioContingencia", transferObject.IndicadorCenarioContingencia));


                            long initTime = System.DateTime.Now.Ticks;

                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }



    } //VinculoRodadaCenarioSimulacao
}
