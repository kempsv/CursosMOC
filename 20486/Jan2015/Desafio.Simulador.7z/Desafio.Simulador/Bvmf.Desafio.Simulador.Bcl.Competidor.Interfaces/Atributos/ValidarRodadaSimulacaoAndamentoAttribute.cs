﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity.InterceptionExtension;
using Microsoft.Practices.Unity;
using Desafio.Simulador.Bsl.UnityContainerCustom;

namespace Desafio.Simulador.Bcl.Agendamento.Simulacao.Interfaces
{
    public class ValidarRodadaSimulacaoAndamentoAttribute: HandlerAttribute
    {
        //[Dependency]
        //public BCAgendaSimulacao BCAgendaSimulacao { get; set; }

        public override ICallHandler CreateHandler(IUnityContainer container)
        {
            BCAgendaSimulacao _service = SimuladorContainerProvider<BCAgendaSimulacao>.GetInstance();
            return new ValidarRodadaSimulacaoAndamentoHandler(_service);
        }
    }
}
