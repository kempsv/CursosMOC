﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity.InterceptionExtension;
using System.Reflection;
using Desafio.Simulador.Util.Excecao;
using Microsoft.Practices.Unity;

namespace Desafio.Simulador.Bcl.Agendamento.Simulacao.Interfaces
{
    public class ValidarRodadaSimulacaoAndamentoHandler : ICallHandler
    {
        private DateTime _dataHoraSistema = DateTime.Now;
        BCAgendaSimulacao _bcAgendaSimulacao = null;

        public ValidarRodadaSimulacaoAndamentoHandler(BCAgendaSimulacao bcAgendaSimulacao)
        {
            _bcAgendaSimulacao = bcAgendaSimulacao;
        }
        
        #region ICallHandler Members

        public IMethodReturn Invoke(IMethodInvocation input, GetNextHandlerDelegate getNext)
        {
            //TODO: Chamar método para consultar na base de dados a Agenda de Simulação.
            bool _periodoVedacao = this._bcAgendaSimulacao.VerificarPeriodoSimulacao(_dataHoraSistema);
            if (_periodoVedacao)
            {
              RodadasSimulacaoAndamentoException ex = new RodadasSimulacaoAndamentoException();
              return input.CreateExceptionMethodReturn(ex);
            }
            return getNext()(input, getNext);
        }
        public int Order
        {
            get;
            set;
        }

        #endregion
    }
}
