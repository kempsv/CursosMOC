﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Entidade;
using Desafio.Simulador.Bcl.Core.Domain.Enum;

namespace Desafio.Simulador.Bcl.Agendamento.Simulacao.Interfaces
{
    public abstract class BCAgendaSimulacao : BCEntityPersistence<AgendaSimulacao, TOAgendaSimulacao>
    {
        public abstract bool VerificarPeriodoSimulacao(DateTime dataSimulacao);

        public abstract AgendaSimulacao ObterAgendaSimulacaoGrupoEscolar(DateTime dataHoraAgendamento, int codigoGrupoEscolar);

        public abstract List<AgendaSimulacao> ListarAgendaSimulacao(TipoSemanaSimulacao tipoSemanaSimulacao);

        public abstract List<AgendaSimulacao> ListarAgendaSimulacaoGrupoEscolar(int codigoGrupoEscolar);

        public abstract void VincularAgendaSimulacaoRodadas(AgendaSimulacao agendaSimulacao);

        public abstract void ReagendarSimuladoGrupoEscolar(AgendaSimulacao agendaSimulacao);

        //public abstract void DesvincularAgendaSimulacaoRodadas(AgendaSimulacao agendaSimualacao);

        //public abstract void VincularAgendaRodadasCenarioSimulacao(AgendaSimulacao agendaSimulacao);

        //public abstract void DesvincularAgendaRodadasCenarioSimulacao(AgendaSimulacao agendaSimualacao);

        public abstract void RealizarSorteioCenarios(ref List<Escola> escolas);

        public abstract void RealizarSorteioCenarios(ref List<Escola> escolas, TipoSemanaSimulacao tipoSemanaSimulacao, bool indicadorGruposNaoSorteados, bool indicadorSorteioManual);

        public abstract void FinalizarRodada(AgendaSimulacaoRodadas agendaSimulacaoRodada);

        public abstract void IncrementarContadorContingencia(AgendaSimulacaoRodadas agendaSimulacaoRodada);

        public abstract void AtualizarPrecoInicialSimulacao(PapelCarteira papelCarteira);

        public abstract List<PapelCarteira> ListarPrecosIniciaisSimulacao(TipoSemanaSimulacao tipoSemanaSimulacao);

        //public abstract List<RodadaCenario> ListarDetalhesRodada(int codigoRodada);
    }
}
