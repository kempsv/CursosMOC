﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Competidor.Entidade;

namespace Desafio.Simulador.Bcl.Competidor.Interfaces
{
    public abstract class BCCompetidorSimulador : BCEntityPersistence<CompetidorSimulador, TOCompetidorSimulador>
    {
        public abstract List<CompetidorSimulador> ListarAlunosGrupoEscolar(int codigoGrupoEscolar);

        public abstract CompetidorSimulador ObterProfessorGrupoEscolar(int codigoGrupoEscolar);
        
        public abstract CompetidorSimulador ObterProfessorByCodigoOrigemLMS(int codigoOrigemLMS);
    }
}
