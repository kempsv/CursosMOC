﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Competidor.Entidade;
using Desafio.Simulador.Bcl.Core.Domain.Enum;

namespace Desafio.Simulador.Bcl.Competidor.Interfaces
{
    public abstract class BCEscolasSimulador : BCEntityPersistence<Escola, TOEscola>
    {
        /// <summary>
        /// Adiciona as escolas classificadas no fase de avaliações.
        /// </summary>
        /// <param name="escolas"></param>
        public abstract void AdicionarEscolasClassificadas(List<Escola> escolas);

        /// <summary>
        /// Lista todas as escolas sorteadas para o uma determinada semana de agendamento de simulação
        /// </summary>
        /// <param name="tipoSemanaSimulacao"></param>
        /// <returns></returns>
        public abstract List<Escola> ListarEscolasSorteadas(TipoSemanaSimulacao tipoSemanaSimulacao);

        /// <summary>
        /// Obtêm a escola sorteada para o uma determinada semana de agendamento de simulação
        /// </summary>
        /// <param name="codigoEscola"></param>
        /// <param name="tipoSemanaSimulacao"></param>
        /// <returns></returns>
        public abstract Escola ObterEscolaSorteada(int codigoEscola, TipoSemanaSimulacao? tipoSemanaSimulacao);

        /// <summary>
        /// Lista todas as escolas que ainda estão pendentes de sorteio de cenários de simulação
        /// </summary>
        /// <returns></returns>
        public abstract List<Escola> ListarEscolasPendenteSorteioCenarios();

        /// <summary>
        /// Atualiza o campo Indicador de Sorteio de Cenários de Simulação de Investimento 
        /// das Escolas Pendentes de Sorteio
        /// </summary>
        /// <param name="escolas"></param>
        public abstract void AtualizarIndicadorSorteioCenarios(List<Escola> escolasPendentesSorteio);

        /// <summary>
        /// Indicador de LazyLoad
        /// </summary>
        /// example:
        /// TRUE = Não preenche as agregações das Escolas
        /// FASLE = Preenche as agregações das Escolas
        public bool LazyLoad { get; set; }
    }
}
