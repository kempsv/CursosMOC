﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Competidor.Entidade;

namespace Desafio.Simulador.Bcl.Competidor.Interfaces
{
    public abstract class BCGrupoEscolarSimulador: BCEntityPersistence<GrupoEscolar, TOGrupoEscolar>
    {
        /// <summary>
        /// Desclassifica o grupo escolar da simulação de investimento
        /// </summary>
        /// <param name="grupoEscolar"></param>
        public abstract void DesclassificarGrupoEscolar(GrupoEscolar grupoEscolar);

        /// <summary>
        /// Obtêm o Grupo Escolar pelo código origem do sistema LMS
        /// </summary>
        /// <param name="codigoOrigemLMS"></param>
        /// <returns></returns>
        public abstract GrupoEscolar ObterGrupoEscolarSimulacao(int codigoOrigemLMS);

        /// <summary>
        /// Lista todos os grupos escolares vinculados à uma determinada escola
        /// </summary>
        /// <param name="codigoEscola"></param>
        /// <returns></returns>
        public abstract List<GrupoEscolar> ListarGruposEscolaresByEscola(int codigoEscola);

        
        /// <summary>
        /// Lista todos os grupos escolares pertencentes a uma determinada agenda de simulação
        /// </summary>
        /// <param name="codigoAgendaSimulacao"></param>
        /// <returns></returns>
        public abstract List<GrupoEscolar> ListarGruposEscolaresByAgendaSimulacao(int codigoAgendaSimulacao);
    }
}
