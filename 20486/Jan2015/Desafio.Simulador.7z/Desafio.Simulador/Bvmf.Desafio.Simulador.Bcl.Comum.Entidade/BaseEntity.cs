﻿using System;
using System.Collections.Generic;

namespace Desafio.Simulador.Bcl.Comum.Entidade
{
    [Serializable]
    public abstract class BaseEntity : EntityWithTypedId<int> { }
}


