﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;

namespace Desafio.Simulador.Bcl.Comum.Entidade
{
    [Serializable]
    public abstract class EntityWithTypedId<IdT> : IEntityWithTypedId<IdT>
    {
        #region IBaseEntity<IdT> Members

        public IdT Codigo { get; set; }

        #endregion
    }
}
