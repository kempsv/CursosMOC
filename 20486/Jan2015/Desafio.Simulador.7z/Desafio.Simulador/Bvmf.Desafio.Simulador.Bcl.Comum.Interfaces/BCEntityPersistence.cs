﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using Desafio.Simulador.Util.Excecao;
//using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Comum.Interfaces
{
    public abstract class BCEntityPersistence<TEntity, TEntityDTO> : PersistenceBaseRepository<TEntity, TEntityDTO>
    {
        protected PersistenceBaseRepository<TEntity, TEntityDTO> _persistence = null;

        public override void Create(TEntity entity)
        {
            //LogManager.Trace("Adicionar", "Antes da chamada do DAO");
            _persistence.Create(entity);
            //LogManager.Trace("Adicionar", "Depois da chamada do DAO");
        }

        public override void Delete(TEntity entity)
        {
            _persistence.Delete(entity);
        }

        public override TEntity FindByKey(int key)
        {
            return _persistence.FindByKey(key);
        }

        public override List<TEntity> FindAll()
        {
            return _persistence.FindAll();
        }

        public override void Update(TEntity entity)
        {
            _persistence.Update(entity);
        }
    }
}
