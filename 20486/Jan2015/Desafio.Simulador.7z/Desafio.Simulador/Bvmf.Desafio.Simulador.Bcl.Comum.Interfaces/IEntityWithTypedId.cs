﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Desafio.Simulador.Bcl.Comum.Interfaces
{
    public interface IEntityWithTypedId<IdT>
    {
        IdT Codigo { get; set; }
    }
}

