﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Desafio.Simulador.Bcl.Comum.Interfaces
{
    public interface ITranslatorDTO<TEntity, TEntityDTO>
    {
        TEntityDTO TranslateToDTO(TEntity entity);

        TEntity TranslateFromDTO(TEntityDTO entityDTO);

        List<TEntityDTO> TranslateToDTO(List<TEntity> entity);

        List<TEntity> TranslateFromDTO(List<TEntityDTO> entityDTO);
    }
}
