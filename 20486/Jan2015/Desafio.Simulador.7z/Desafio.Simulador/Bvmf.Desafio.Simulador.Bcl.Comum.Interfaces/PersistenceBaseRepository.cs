﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Transactions;
using System.Data;

namespace Desafio.Simulador.Bcl.Comum.Interfaces
{
    public abstract class PersistenceBase
    {
        protected virtual System.Data.IDbConnection GetConnection()
        {
            string connectionSring = System.Configuration.ConfigurationManager.ConnectionStrings["Desafio.Simulador"].ConnectionString;

            System.Data.SqlClient.SqlConnection _connection = new System.Data.SqlClient.SqlConnection(connectionSring);

            return _connection;
        }

        protected virtual TransactionOptions GetTransactionOptions()
        {
            TransactionOptions options = new TransactionOptions();
            options.IsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted;
            options.Timeout = new TimeSpan(0, 2, 0);
            return options;
        }
    }

    public abstract class PersistenceBaseRepository<TEntity,TEntityDTO>: PersistenceBase
    {
        public abstract List<TEntity> FindAll();

        public abstract TEntity FindByKey(int key);

        public abstract void Delete(TEntity entity);

        public abstract void Create(TEntity entity);

        public abstract void Update(TEntity entity);

        protected virtual TEntityDTO TranslateToDTO(TEntity entity) { return default(TEntityDTO); }

        protected virtual TEntity TranslateFromDTO(TEntityDTO entityDTO) { return default(TEntity); }

        protected virtual List<TEntityDTO> TranslateToDTO(List<TEntity> entity) { return default(List<TEntityDTO>); }

        protected virtual List<TEntity> TranslateFromDTO(List<TEntityDTO> entityDTO) { return default(List<TEntity>); }
    }
}
