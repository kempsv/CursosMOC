using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Configuracao.Cenario.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOCenarioSimulacao
    {
        // Declara��o de atributos
        private int _codigoCenario;
        private short _numeracaoCenario;
        private int _anoReferencia;
        private int _mesReferencia;
        private DateTime _dataCriacao;
        private decimal _valorRentabilidadeMedia;
        
        public int CodigoCenario
        {
            get
            {
                return _codigoCenario;
            }
            set
            {
                _codigoCenario = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public short NumeracaoCenario
        {
            get
            {
                return _numeracaoCenario;
            }
            set
            {
                _numeracaoCenario = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int AnoReferencia
        {
            get
            {
                return _anoReferencia;
            }
            set
            {
                _anoReferencia = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int MesReferencia
        {
            get
            {
                return _mesReferencia;
            }
            set
            {
                _mesReferencia = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public DateTime DataCriacao
        {
            get
            {
                return _dataCriacao;
            }
            set
            {
                _dataCriacao = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal ValorRentabilidadeMedia
        {
            get
            {
                return _valorRentabilidadeMedia;
            }
            set
            {
                _valorRentabilidadeMedia = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOCenarioSimulacao()
        {
            _codigoCenario = int.MinValue;
            _numeracaoCenario = short.MinValue;
            _anoReferencia = int.MinValue;
            _mesReferencia = int.MinValue;
            _dataCriacao = DateTime.MinValue;
            _valorRentabilidadeMedia = decimal.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOCenarioSimulacao" );
            sb.Append( "\n\tCodigoCenario = " );
            sb.Append( _codigoCenario );
            sb.Append( "\n\tNumeracaoCenario = " );
            sb.Append( _numeracaoCenario );
            sb.Append( "\n\tAnoReferencia = " );
            sb.Append( _anoReferencia );
            sb.Append( "\n\tMesReferencia = " );
            sb.Append( _mesReferencia );
            sb.Append( "\n\tDataCriacao = " );
            sb.Append( _dataCriacao );
            sb.Append( "\n\tValorRentabilidadeMedia = " );
            sb.Append( _valorRentabilidadeMedia );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOCenarioSimulacao) )
            {
                return false;
            }
            
            TOCenarioSimulacao convertedParam = (TOCenarioSimulacao) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoCenario
            if( !CodigoCenario.Equals( convertedParam.CodigoCenario ) )
            {
                return false;
            }
            
            // Compara o atributo NumeracaoCenario
            if( !NumeracaoCenario.Equals( convertedParam.NumeracaoCenario ) )
            {
                return false;
            }
            
            // Compara o atributo AnoReferencia
            if( !AnoReferencia.Equals( convertedParam.AnoReferencia ) )
            {
                return false;
            }
            
            // Compara o atributo MesReferencia
            if( !MesReferencia.Equals( convertedParam.MesReferencia ) )
            {
                return false;
            }
            
            // Compara o atributo DataCriacao
            if( !DataCriacao.Equals( convertedParam.DataCriacao ) )
            {
                return false;
            }
            
            // Compara o atributo ValorRentabilidadeMedia
            if( !ValorRentabilidadeMedia.Equals( convertedParam.ValorRentabilidadeMedia ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //CenarioSimulacao
}
