using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Configuracao.Cenario.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOMacroCenarioEconomico
    {
        // Declara��o de atributos
        private int _codigoMacroCenario;
        private string _descricaoMacroCenario;
        private string _nomeMacroCenario;
        private int _codigoCenario;
        
        public int CodigoMacroCenario
        {
            get
            {
                return _codigoMacroCenario;
            }
            set
            {
                _codigoMacroCenario = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string DescricaoMacroCenario
        {
            get
            {
                return _descricaoMacroCenario;
            }
            set
            {
                _descricaoMacroCenario = value;
            }
        }
        
        public string NomeMacroCenario
        {
            get
            {
                return _nomeMacroCenario;
            }
            set
            {
                _nomeMacroCenario = value;
            }
        }
        
        public int CodigoCenario
        {
            get
            {
                return _codigoCenario;
            }
            set
            {
                _codigoCenario = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOMacroCenarioEconomico()
        {
            _codigoMacroCenario = int.MinValue;
            _descricaoMacroCenario = null;
            _nomeMacroCenario = null;
            _codigoCenario = int.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOMacroCenarioEconomico" );
            sb.Append( "\n\tCodigoMacroCenario = " );
            sb.Append( _codigoMacroCenario );
            sb.Append( "\n\tDescricaoMacroCenario = " );
            sb.Append( _descricaoMacroCenario );
            sb.Append( "\n\tNomeMacroCenario = " );
            sb.Append( _nomeMacroCenario );
            sb.Append( "\n\tCodigoCenario = " );
            sb.Append( _codigoCenario );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOMacroCenarioEconomico) )
            {
                return false;
            }
            
            TOMacroCenarioEconomico convertedParam = (TOMacroCenarioEconomico) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoMacroCenario
            if( !CodigoMacroCenario.Equals( convertedParam.CodigoMacroCenario ) )
            {
                return false;
            }
            
            // Compara o atributo DescricaoMacroCenario
            if( !DescricaoMacroCenario.Equals( convertedParam.DescricaoMacroCenario ) )
            {
                return false;
            }
            
            // Compara o atributo NomeMacroCenario
            if( !NomeMacroCenario.Equals( convertedParam.NomeMacroCenario ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoCenario
            if( !CodigoCenario.Equals( convertedParam.CodigoCenario ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //MacroCenarioEconomico
}
