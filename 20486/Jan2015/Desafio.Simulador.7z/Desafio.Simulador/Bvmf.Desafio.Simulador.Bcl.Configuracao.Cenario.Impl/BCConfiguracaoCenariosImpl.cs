﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Configuracao.Cenario.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Cenario.Impl.Dao;
using Desafio.Simulador.Bcl.Configuracao.Cenario.Entidade;
using Microsoft.Practices.Unity;
using Desafio.Simulador.Bcl.Configuracao.Fatos.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Grafico.Interfaces;
using System.Configuration;

namespace Desafio.Simulador.Bcl.Configuracao.Cenario.Impl
{
    public class BCConfiguracaoCenariosImpl : BCConfiguracaoCenarios
    {
        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCConfiguracaoFatos BCConfiguracaoFatos { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCConfiguracaoGraficos BCConfiguracaoGraficos { get; set; }

        public BCConfiguracaoCenariosImpl(CenarioSimulacaoDAO persistence)
        {
            _persistence = persistence;
        }

        public override void ZerarRentabilidadeMedia(CenarioSimulacao cenarioSimulacao)
        {
            AtualizarRentabilidadeMedia(cenarioSimulacao);
        }

        private void AtualizarRentabilidadeMedia(CenarioSimulacao cenarioSimulacao)
        {
            ((CenarioSimulacaoDAO)_persistence).UpdateValorRentabilidade(cenarioSimulacao);
        }

        public override void DefinirRentabilidadeMedia(IEnumerable<TaxaLucratividadeCenario> taxasCenarios)
        {
            decimal _valorRentabilidadeCenario = 0;
            int _contador = 0;

            foreach (TaxaLucratividadeCenario taxa in taxasCenarios)
            {
                _contador++;
                _valorRentabilidadeCenario += taxa.ValorPercentualLucratividade;
            }

            if (_valorRentabilidadeCenario != 0 && _contador != 0)
            {
                this.AtualizarRentabilidadeMedia(new CenarioSimulacao()
                {
                    Codigo = taxasCenarios.First<TaxaLucratividadeCenario>().CenarioSimulacao.Codigo,
                    ValorRentabilidadeMedia = (_valorRentabilidadeCenario / _contador)
                });
            }
        }

        public override CenarioSimulacao FindByKey(int key)
        {
            var _cenarioSimulacao = base.FindByKey(key);

            this.PreencherAgregacao(_cenarioSimulacao);

            return _cenarioSimulacao;
        }

        public override List<CenarioSimulacao> FindAll()
        {
            var _cenariosSimulacao = base.FindAll();

            this.PreencherAgregacao(_cenariosSimulacao);
            
            return _cenariosSimulacao;
        }

        public override void Create(CenarioSimulacao entity)
        {
            base.Create(entity);

            MacroCenarioEconomicoDAO.GetInstance().Create(new TOMacroCenarioEconomico()
            {
                CodigoCenario = entity.Codigo,
                DescricaoMacroCenario = entity.MacroCenario.Descricao,
                NomeMacroCenario = entity.MacroCenario.Nome
            });
        }

        public override void Update(CenarioSimulacao entity)
        {
            base.Update(entity);

            MacroCenarioEconomicoDAO.GetInstance().Update(new TOMacroCenarioEconomico()
            {
                CodigoMacroCenario = entity.MacroCenario.Codigo,
                CodigoCenario = entity.Codigo,
                DescricaoMacroCenario = entity.MacroCenario.Descricao,
                NomeMacroCenario = entity.MacroCenario.Nome
            });
        }

        private void PreencherAgregacao(List<CenarioSimulacao> cenariosSimulacao)
        {
            foreach (CenarioSimulacao cenario in cenariosSimulacao)
            {
                PreencherAgregacao(cenario);
            }
        }

        private void PreencherAgregacao(CenarioSimulacao cenarioSimulacao)
        {
            if (!this.LazyData)
            {
                cenarioSimulacao.FatosRelavantes = this.BCConfiguracaoFatos.ListarFatosByCenario(cenarioSimulacao.Codigo);
                cenarioSimulacao.GraficosCenario = this.BCConfiguracaoGraficos.ListarGraficosByCenario(cenarioSimulacao.Codigo);
                cenarioSimulacao.MacroCenario = PreencherAgregacaoMacroCenario(cenarioSimulacao.Codigo);
            }
        }

        private MacroCenarioEconomico PreencherAgregacaoMacroCenario(int codigoCenario)
        {
            var _macroCenarios = MacroCenarioEconomicoDAO.GetInstance().FindAll();

            var _toMacroCenario = (from m in _macroCenarios
                                   where m.CodigoCenario.Equals(codigoCenario)
                                   select m).Single<TOMacroCenarioEconomico>();

            return new MacroCenarioEconomico()
            {
                Codigo = _toMacroCenario.CodigoMacroCenario,
                Nome = _toMacroCenario.NomeMacroCenario,
                Descricao = _toMacroCenario.DescricaoMacroCenario
            };
        }
    }
}
