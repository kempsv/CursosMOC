﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

using Desafio.Simulador.Bcl.Configuracao.Cenario.Entidade;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Util.Logger;
using System.Transactions;
//using Framework.Log;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;

namespace Desafio.Simulador.Bcl.Configuracao.Cenario.Impl.Dao
{
    public class CenarioSimulacaoDAOSqlServerCustomImpl : CenarioSimulacaoDAOSqlServerImpl
    {
        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "CenarioSimulacaoDAOSqlServerCustomImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<CenarioSimulacao> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOCenarioSimulacao> result = new List<TOCenarioSimulacao>();
            TOCenarioSimulacao transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBCENA_SIMU.COD_CENA, TSDBCENA_SIMU.NUM_CTRL_CENA, TSDBCENA_SIMU.NUM_ANO_REF, TSDBCENA_SIMU.NUM_MES_REF, TSDBCENA_SIMU.TMST_CRIA_CENA, TSDBCENA_SIMU.VAL_RENT_MED FROM TSDBCENA_SIMU TSDBCENA_SIMU WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open();
                            using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {
                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Configuracao.Cenario.Entidade.TOCenarioSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCenario = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.NumeracaoCenario = dataReader.GetInt16(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.AnoReferencia = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.MesReferencia = dataReader.GetInt32(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.DataCriacao = dataReader.GetDateTime(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.ValorRentabilidadeMedia = dataReader.GetDecimal(5);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override CenarioSimulacao FindByKey(int codigoCenario)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOCenarioSimulacao transferObject = null;

            try
            {
                statement = "SELECT TSDBCENA_SIMU.COD_CENA, TSDBCENA_SIMU.NUM_CTRL_CENA, TSDBCENA_SIMU.NUM_ANO_REF, TSDBCENA_SIMU.NUM_MES_REF, TSDBCENA_SIMU.TMST_CRIA_CENA, TSDBCENA_SIMU.VAL_RENT_MED FROM TSDBCENA_SIMU TSDBCENA_SIMU WITH(NOLOCK) WHERE TSDBCENA_SIMU.COD_CENA = @codigoCenario";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open();
                            using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {
                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoCenario", codigoCenario));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Configuracao.Cenario.Entidade.TOCenarioSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCenario = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.NumeracaoCenario = dataReader.GetInt16(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.AnoReferencia = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.MesReferencia = dataReader.GetInt32(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.DataCriacao = dataReader.GetDateTime(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.ValorRentabilidadeMedia = dataReader.GetDecimal(5);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Remove uma entidade pela sua chave primária.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(CenarioSimulacao entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOCenarioSimulacao transferObject = TranslateToDTO(entity);

                statement = "DELETE FROM TSDBCENA_SIMU WHERE COD_CENA = @codigoCenario";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open();
                        using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {
                            // Chave primária
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoCenario", transferObject.CodigoCenario));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }
            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma instância em memória na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(CenarioSimulacao entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOCenarioSimulacao transferObject = TranslateToDTO(entity);

                statement = "UPDATE TSDBCENA_SIMU SET nUM_CTRL_CENA = @numeracaoCenario, nUM_ANO_REF = @anoReferencia, nUM_MES_REF = @mesReferencia, tMST_CRIA_CENA = @dataCriacao, vAL_RENT_MED = @valorRentabilidadeMedia WHERE COD_CENA = @codigoCenario";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open();
                        using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {

                            // Parametros que não estão na chave
                            if (transferObject.NumeracaoCenario == short.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@numeracaoCenario", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@numeracaoCenario", transferObject.NumeracaoCenario));
                            }

                            if (transferObject.AnoReferencia == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@anoReferencia", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@anoReferencia", transferObject.AnoReferencia));
                            }

                            if (transferObject.MesReferencia == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@mesReferencia", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@mesReferencia", transferObject.MesReferencia));
                            }

                            if (transferObject.DataCriacao == DateTime.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@dataCriacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@dataCriacao", transferObject.DataCriacao));
                            }

                            if (transferObject.ValorRentabilidadeMedia == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorRentabilidadeMedia", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorRentabilidadeMedia", transferObject.ValorRentabilidadeMedia));
                            }

                            // Chave primária
                            command.Parameters.Add(new SqlParameter("@codigoCenario", transferObject.CodigoCenario));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }
            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma instância em memória na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(CenarioSimulacao entity)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                TOCenarioSimulacao transferObject = TranslateToDTO(entity);

                statement = "INSERT INTO TSDBCENA_SIMU ( NUM_CTRL_CENA, NUM_ANO_REF, NUM_MES_REF, TMST_CRIA_CENA, VAL_RENT_MED ) VALUES ( @numeracaoCenario, @anoReferencia, @mesReferencia, @dataCriacao, @valorRentabilidadeMedia )  ; SELECT SCOPE_IDENTITY();";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open();
                        using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {

                            if (transferObject.NumeracaoCenario == short.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@numeracaoCenario", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@numeracaoCenario", transferObject.NumeracaoCenario));
                            }

                            if (transferObject.AnoReferencia == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@anoReferencia", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@anoReferencia", transferObject.AnoReferencia));
                            }

                            if (transferObject.MesReferencia == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@mesReferencia", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@mesReferencia", transferObject.MesReferencia));
                            }

                            if (transferObject.DataCriacao == DateTime.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@dataCriacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@dataCriacao", transferObject.DataCriacao));
                            }

                            if (transferObject.ValorRentabilidadeMedia == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorRentabilidadeMedia", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorRentabilidadeMedia", transferObject.ValorRentabilidadeMedia));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            entity.Codigo = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }
        }

        public override void UpdateValorRentabilidade(CenarioSimulacao entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOCenarioSimulacao transferObject = TranslateToDTO(entity);

                statement = "UPDATE TSDBCENA_SIMU SET vAL_RENT_MED = @valorRentabilidadeMedia WHERE COD_CENA = @codigoCenario";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open();
                        using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {

                            if (transferObject.ValorRentabilidadeMedia == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorRentabilidadeMedia", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorRentabilidadeMedia", transferObject.ValorRentabilidadeMedia));
                            }

                            // Chave primária
                            command.Parameters.Add(new SqlParameter("@codigoCenario", transferObject.CodigoCenario));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }
            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }
        }

        protected override List<CenarioSimulacao> TranslateFromDTO(List<TOCenarioSimulacao> entityDTO)
        {
            var _returnEntities = new List<CenarioSimulacao>();

            foreach (TOCenarioSimulacao entity in entityDTO)
            {
                var _returnEntity = new CenarioSimulacao
                {
                    Codigo = entity.CodigoCenario,
                    NumeracaoCenario = entity.NumeracaoCenario,
                    ValorRentabilidadeMedia = entity.ValorRentabilidadeMedia,
                    AnoReferencia = entity.AnoReferencia,
                    MesReferencia = entity.MesReferencia,
                    DataHoraCriacao = entity.DataCriacao,
                };
                _returnEntities.Add(_returnEntity);
            }

            return _returnEntities;
        }

        protected override CenarioSimulacao TranslateFromDTO(TOCenarioSimulacao entityDTO)
        {
            var _returnEntity = new CenarioSimulacao
            {
                Codigo = entityDTO.CodigoCenario,
                NumeracaoCenario = entityDTO.NumeracaoCenario,
                ValorRentabilidadeMedia = entityDTO.ValorRentabilidadeMedia,
                AnoReferencia = entityDTO.AnoReferencia,
                MesReferencia = entityDTO.MesReferencia,
                DataHoraCriacao = entityDTO.DataCriacao,
            };
            return _returnEntity;
        }

        protected override List<TOCenarioSimulacao> TranslateToDTO(List<CenarioSimulacao> entity)
        {
            var _returnEntities = new List<TOCenarioSimulacao>();

            foreach (CenarioSimulacao et in entity)
            {
                var _returnEntity = new TOCenarioSimulacao
                {
                    CodigoCenario = et.Codigo,
                    AnoReferencia = et.AnoReferencia,
                    MesReferencia = et.MesReferencia,
                    ValorRentabilidadeMedia = et.ValorRentabilidadeMedia,
                    DataCriacao = et.DataHoraCriacao,
                    NumeracaoCenario = et.NumeracaoCenario
                };

                _returnEntities.Add(_returnEntity);
            }
            return _returnEntities;
        }

        protected override TOCenarioSimulacao TranslateToDTO(CenarioSimulacao entity)
        {
            var _returnEntity = new TOCenarioSimulacao
            {
                CodigoCenario = entity.Codigo,
                AnoReferencia = entity.AnoReferencia,
                MesReferencia = entity.MesReferencia,
                ValorRentabilidadeMedia = entity.ValorRentabilidadeMedia,
                DataCriacao = entity.DataHoraCriacao,
                NumeracaoCenario = entity.NumeracaoCenario
            };
            return _returnEntity;
        }
    }
}
