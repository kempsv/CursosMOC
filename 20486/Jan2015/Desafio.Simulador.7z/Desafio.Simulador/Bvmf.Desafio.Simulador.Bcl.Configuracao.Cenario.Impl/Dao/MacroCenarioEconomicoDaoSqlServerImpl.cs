using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Configuracao.Cenario.Entidade;
using System.Collections.Generic;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Util.Logger;
using System.Transactions;

namespace Desafio.Simulador.Bcl.Configuracao.Cenario.Impl.Dao
{

    /// <summary>
    /// Implementa��o de MacroCenarioEconomicoDaoSqlServerImpl - SqlServer
    /// </summary>
    public class MacroCenarioEconomicoDAOSqlServerImpl : MacroCenarioEconomicoDAO
    {
        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "MacroCenarioEconomicoDAOSqlServerImpl";


        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOMacroCenarioEconomico> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOMacroCenarioEconomico> result = new List<TOMacroCenarioEconomico>();
            TOMacroCenarioEconomico transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBMACRO_CENA_ECON.COD_MACRO_CENA, TSDBMACRO_CENA_ECON.DESC_MACRO_CENA, TSDBMACRO_CENA_ECON.NOME_MACRO_CENA, TSDBMACRO_CENA_ECON.COD_CENA FROM TSDBMACRO_CENA_ECON TSDBMACRO_CENA_ECON WITH(NOLOCK)";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open();
                            using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOMacroCenarioEconomico();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoMacroCenario = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.DescricaoMacroCenario = dataReader.GetString(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.NomeMacroCenario = dataReader.GetString(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.CodigoCenario = dataReader.GetInt32(3);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TOMacroCenarioEconomico FindByKey(int codigoMacroCenario)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOMacroCenarioEconomico transferObject = null;

            try
            {
                statement = "SELECT TSDBMACRO_CENA_ECON.COD_MACRO_CENA, TSDBMACRO_CENA_ECON.DESC_MACRO_CENA, TSDBMACRO_CENA_ECON.NOME_MACRO_CENA, TSDBMACRO_CENA_ECON.COD_CENA FROM TSDBMACRO_CENA_ECON TSDBMACRO_CENA_ECON WITH(NOLOCK) WHERE TSDBMACRO_CENA_ECON.COD_MACRO_CENA = @codigoMacroCenario";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open();
                            using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {

                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoMacroCenario", codigoMacroCenario));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOMacroCenarioEconomico();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoMacroCenario = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.DescricaoMacroCenario = dataReader.GetString(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.NomeMacroCenario = dataReader.GetString(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.CodigoCenario = dataReader.GetInt32(3);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Remove uma entidade pela sua chave prim�ria.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(TOMacroCenarioEconomico transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBMACRO_CENA_ECON WHERE COD_MACRO_CENA = @codigoMacroCenario";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open();
                        using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {

                            // Chave prim�ria
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoMacroCenario", transferObject.CodigoMacroCenario));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }
            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma inst�ncia em mem�ria na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(TOMacroCenarioEconomico transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "UPDATE TSDBMACRO_CENA_ECON SET dESC_MACRO_CENA = @descricaoMacroCenario, nOME_MACRO_CENA = @nomeMacroCenario, cOD_CENA = @codigoCenario WHERE COD_MACRO_CENA = @codigoMacroCenario";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open();
                        using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {

                            // Parametros que n�o est�o na chave
                            if (transferObject.DescricaoMacroCenario == null)
                            {
                                command.Parameters.Add(new SqlParameter("@descricaoMacroCenario", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@descricaoMacroCenario", transferObject.DescricaoMacroCenario));
                            }

                            if (transferObject.NomeMacroCenario == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeMacroCenario", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeMacroCenario", transferObject.NomeMacroCenario));
                            }

                            if (transferObject.CodigoCenario == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCenario", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCenario", transferObject.CodigoCenario));
                            }

                            // Chave prim�ria
                            command.Parameters.Add(new SqlParameter("@codigoMacroCenario", transferObject.CodigoMacroCenario));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }
            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TOMacroCenarioEconomico transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBMACRO_CENA_ECON ( DESC_MACRO_CENA, NOME_MACRO_CENA, COD_CENA ) VALUES ( @descricaoMacroCenario, @nomeMacroCenario, @codigoCenario )  ; SELECT SCOPE_IDENTITY();";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open();
                        using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {

                            if (transferObject.DescricaoMacroCenario == null)
                            {
                                command.Parameters.Add(new SqlParameter("@descricaoMacroCenario", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@descricaoMacroCenario", transferObject.DescricaoMacroCenario));
                            }

                            if (transferObject.NomeMacroCenario == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeMacroCenario", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeMacroCenario", transferObject.NomeMacroCenario));
                            }

                            if (transferObject.CodigoCenario == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCenario", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCenario", transferObject.CodigoCenario));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            transferObject.CodigoMacroCenario = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }
            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

    } //MacroCenarioEconomico
}
