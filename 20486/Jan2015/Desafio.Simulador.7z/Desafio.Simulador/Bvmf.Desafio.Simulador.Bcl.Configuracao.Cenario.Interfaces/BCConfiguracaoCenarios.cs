﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Configuracao.Cenario.Entidade;

namespace Desafio.Simulador.Bcl.Configuracao.Cenario.Interfaces
{
    public abstract class BCConfiguracaoCenarios : BCEntityPersistence<CenarioSimulacao, TOCenarioSimulacao>
    {
        public abstract void DefinirRentabilidadeMedia(IEnumerable<TaxaLucratividadeCenario> taxasCenarios);

        public abstract void ZerarRentabilidadeMedia(CenarioSimulacao cenarioSimulacao);

        public virtual bool LazyData { get; set; }
    }
}
