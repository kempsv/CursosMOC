using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Configuracao.Fatos.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOFatoRelevante
    {
        // Declara��o de atributos
        private int _codigoFato;
        private int _codigoPapel;
        private string _descricaoFato;
        
        public int CodigoFato
        {
            get
            {
                return _codigoFato;
            }
            set
            {
                _codigoFato = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoPapel
        {
            get
            {
                return _codigoPapel;
            }
            set
            {
                _codigoPapel = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string DescricaoFato
        {
            get
            {
                return _descricaoFato;
            }
            set
            {
                _descricaoFato = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOFatoRelevante()
        {
            _codigoFato = int.MinValue;
            _codigoPapel = int.MinValue;
            _descricaoFato = null;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOFatoRelevante" );
            sb.Append( "\n\tCodigoFato = " );
            sb.Append( _codigoFato );
            sb.Append( "\n\tCodigoPapel = " );
            sb.Append( _codigoPapel );
            sb.Append( "\n\tDescricaoFato = " );
            sb.Append( _descricaoFato );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOFatoRelevante) )
            {
                return false;
            }
            
            TOFatoRelevante convertedParam = (TOFatoRelevante) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoFato
            if( !CodigoFato.Equals( convertedParam.CodigoFato ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoPapel
            if( !CodigoPapel.Equals( convertedParam.CodigoPapel ) )
            {
                return false;
            }
            
            // Compara o atributo DescricaoFato
            if( !DescricaoFato.Equals( convertedParam.DescricaoFato ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //FatoRelevante
}
