using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Configuracao.Fatos.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOVinculoFatoRelevanteCenario
    {
        // Declara��o de atributos
        private int _codigoCenario;
        private int _codigoFato;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoCenario
        {
            get
            {
                return _codigoCenario;
            }
            set
            {
                _codigoCenario = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoFato
        {
            get
            {
                return _codigoFato;
            }
            set
            {
                _codigoFato = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOVinculoFatoRelevanteCenario()
        {
            _codigoCenario = int.MinValue;
            _codigoFato = int.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOVinculoFatoRelevanteCenario" );
            sb.Append( "\n\tCodigoCenario = " );
            sb.Append( _codigoCenario );
            sb.Append( "\n\tCodigoFato = " );
            sb.Append( _codigoFato );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOVinculoFatoRelevanteCenario) )
            {
                return false;
            }
            
            TOVinculoFatoRelevanteCenario convertedParam = (TOVinculoFatoRelevanteCenario) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoCenario
            if( !CodigoCenario.Equals( convertedParam.CodigoCenario ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoFato
            if( !CodigoFato.Equals( convertedParam.CodigoFato ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //VinculoFatoRelevanteCenario
}
