﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Configuracao.Fatos.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Fatos.Impl.Dao;
using Desafio.Simulador.Bcl.Configuracao.Fatos.Entidade;
using Desafio.Simulador.Bcl.Configuracao.Papel.Interfaces;
using Microsoft.Practices.Unity;

namespace Desafio.Simulador.Bcl.Configuracao.Fatos.Impl
{
    public class BCConfiguracaoFatosImpl : BCConfiguracaoFatos
    {
        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCConfiguracaoPapel BCConfiguracaoPapel { get; set; }

        public BCConfiguracaoFatosImpl(FatoRelevanteDAO persistence)
        {
            _persistence = persistence;
        }

        private void VincularFatoCenario(FatoRelevante entity)
        {
            this.DesvincularFatoCenario(entity);

            //Faz o vínculo do Fato Relevante com o Cenário de Simulação de Investimento
            VinculoFatoRelevanteCenarioDAO.GetInstance().Create(new TOVinculoFatoRelevanteCenario()
                                                                {
                                                                    CodigoCenario = entity.CenarioSimulacao.Codigo,
                                                                    CodigoFato = entity.Codigo
                                                                }
                                                                );
        }

        private void DesvincularFatoCenario(FatoRelevante entity)
        {
            VinculoFatoRelevanteCenarioDAO.GetInstance().Delete(entity.Codigo);
        }

        public override List<FatoRelevante>  ListarFatosByCenario(int codigoCenario)
        {
            var _listaFatos = ((FatoRelevanteDAO)_persistence).FindFatosByCenario(codigoCenario);

            this.PreencherAgregacao(_listaFatos);

            return _listaFatos;
        }

        public override void Create(FatoRelevante entity)
        {
            base.Create(entity);
            
            this.VincularFatoCenario(entity);
        }

        public override void Update(FatoRelevante entity)
        {
            base.Update(entity);

            this.VincularFatoCenario(entity);
        }

        public override void Delete(FatoRelevante entity)
        {
            this.DesvincularFatoCenario(entity);

            base.Delete(entity);
        }

        public override FatoRelevante FindByKey(int key)
        {
            var _fatoRelevante = base.FindByKey(key);

            this.PreencherAgregacao(_fatoRelevante);
            
            return _fatoRelevante;
        }

        public override List<FatoRelevante> FindAll()
        {
            var _listaFatos = base.FindAll();

            this.PreencherAgregacao(_listaFatos);

            return _listaFatos;
        }

        private void PreencherAgregacao(List<FatoRelevante> fatos) 
        {
            foreach (FatoRelevante fato in fatos) 
            {
                PreencherAgregacao(fato);
            }
        }

        private void PreencherAgregacao(FatoRelevante fatoRelevante) 
        {
            var _vinculoFatoCenario = VinculoFatoRelevanteCenarioDAO.GetInstance().FindByKey(fatoRelevante.Codigo);

            //var _vinculoFatoCenario = _vinculos.Where(v => v.CodigoFato == fatoRelevante.Codigo).First<TOVinculoFatoRelevanteCenario>();

            //
            //Busca os dados do Papel, pois o objeto só possui o atributo Codigo preenchido
            //
            fatoRelevante.Papel = this.BCConfiguracaoPapel.FindByKey(fatoRelevante.Papel.Codigo);
            fatoRelevante.CenarioSimulacao = new CenarioSimulacao() { Codigo = _vinculoFatoCenario.CodigoCenario };
        }
    }
}
