﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

//using Framework.AcessoDados.Impl;

using Desafio.Simulador.Bcl.Configuracao.Fatos.Entidade;
using Desafio.Simulador.Bcl.Configuracao.Papel.Entidade;
using Desafio.Simulador.Bcl.Core.Domain;
using System.Transactions;
using Desafio.Simulador.Util.Logger;
//using Framework.Log;

namespace Desafio.Simulador.Bcl.Configuracao.Fatos.Impl.Dao
{
    public class FatoRelevanteDaoSqlServerCustomImpl : FatoRelevanteDAOSqlServerImpl
    {
        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "FatoRelevanteDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<FatoRelevante> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOFatoRelevante> result = new List<TOFatoRelevante>();
            TOFatoRelevante transferObject = null;

            try
            {
                statement = "SELECT FatoRelevante.COD_FATO_RLEV, FatoRelevante.COD_PAP, FatoRelevante.DESC_FATO_RLEV FROM TSDBFATO_ECON_RLEV FatoRelevante WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Configuracao.Fatos.Entidade.TOFatoRelevante();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoFato = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoPapel = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.DescricaoFato = dataReader.GetString(2);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override FatoRelevante FindByKey(int codigoFato)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOFatoRelevante transferObject = null;

            try
            {
                statement = "SELECT FatoRelevante.COD_FATO_RLEV, FatoRelevante.COD_PAP, FatoRelevante.DESC_FATO_RLEV FROM TSDBFATO_ECON_RLEV FatoRelevante WITH(NOLOCK) WHERE FatoRelevante.COD_FATO_RLEV = @codigoFato";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoFato", codigoFato));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Configuracao.Fatos.Entidade.TOFatoRelevante();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoFato = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoPapel = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.DescricaoFato = dataReader.GetString(2);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Lista todos os fatos relevantes de um Cenário
        /// </summary>
        public override List<FatoRelevante> FindFatosByCenario(int codigoCenario)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOFatoRelevante> result = new List<TOFatoRelevante>();
            TOFatoRelevante transferObject = null;

            try
            {
                statement = "SELECT FatoRelevante.COD_FATO_RLEV, FatoRelevante.COD_PAP, FatoRelevante.DESC_FATO_RLEV FROM TSDBFATO_ECON_RLEV FatoRelevante WITH(NOLOCK)  INNER JOIN TSDBVINC_FATO_ECON_CENA_SIMU vinculo WITH(NOLOCK)  ON FatoRelevante.COD_FATO_RLEV = vinculo.COD_FATO_RLEV WHERE vinculo.COD_CENA = " + codigoCenario + "";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {
                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Configuracao.Fatos.Entidade.TOFatoRelevante();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoFato = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoPapel = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.DescricaoFato = dataReader.GetString(2);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();

                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Remove uma entidade pela sua chave primária.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(FatoRelevante entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOFatoRelevante transferObject = TranslateToDTO(entity);

                statement = "DELETE FROM TSDBFATO_ECON_RLEV WHERE COD_FATO_RLEV = @codigoFato";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave primária
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoFato", transferObject.CodigoFato));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma instância em memória na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(FatoRelevante entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOFatoRelevante transferObject = TranslateToDTO(entity);

                statement = "UPDATE TSDBFATO_ECON_RLEV SET cOD_PAP = @codigoPapel, dESC_FATO_RLEV = @descricaoFato WHERE COD_FATO_RLEV = @codigoFato";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que não estão na chave
                            if (transferObject.CodigoPapel == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoPapel", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoPapel", transferObject.CodigoPapel));
                            }

                            if (transferObject.DescricaoFato == null)
                            {
                                command.Parameters.Add(new SqlParameter("@descricaoFato", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@descricaoFato", transferObject.DescricaoFato));
                            }

                            // Chave primária
                            command.Parameters.Add(new SqlParameter("@codigoFato", transferObject.CodigoFato));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma instância em memória na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(FatoRelevante entity)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                TOFatoRelevante transferObject = TranslateToDTO(entity);

                statement = "INSERT INTO TSDBFATO_ECON_RLEV ( COD_PAP, DESC_FATO_RLEV ) VALUES ( @codigoPapel, @descricaoFato )  ; SELECT SCOPE_IDENTITY();";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoPapel == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoPapel", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoPapel", transferObject.CodigoPapel));
                            }

                            if (transferObject.DescricaoFato == null)
                            {
                                command.Parameters.Add(new SqlParameter("@descricaoFato", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@descricaoFato", transferObject.DescricaoFato));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            entity.Codigo = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        protected override List<FatoRelevante> TranslateFromDTO(List<TOFatoRelevante> entityDTO)
        {
            var _returnEntities = new List<FatoRelevante>();

            foreach (TOFatoRelevante entity in entityDTO)
            {
                _returnEntities.Add(TranslateFromDTO(entity));
            }

            return _returnEntities;
        }

        protected override FatoRelevante TranslateFromDTO(TOFatoRelevante entityDTO)
        {
            var _returnEntity = new FatoRelevante
            {
                Codigo = entityDTO.CodigoFato,
                Descricao = entityDTO.DescricaoFato,
                Papel = new PapelCarteira() { Codigo = entityDTO.CodigoPapel }
            };
            return _returnEntity;
        }

        protected override List<TOFatoRelevante> TranslateToDTO(List<FatoRelevante> entity)
        {
            var _returnEntities = new List<TOFatoRelevante>();

            foreach (FatoRelevante et in entity)
            {
                _returnEntities.Add(TranslateToDTO(et));
            }

            return _returnEntities;
        }

        protected override TOFatoRelevante TranslateToDTO(FatoRelevante entity)
        {
            var _returnEntity = new TOFatoRelevante
            {
                CodigoFato = entity.Codigo,
                DescricaoFato = entity.Descricao,
            };

            if (entity.Papel != null)
            {
                _returnEntity.CodigoPapel = entity.Papel.Codigo;
            }
            return _returnEntity;
        }
    }
}
