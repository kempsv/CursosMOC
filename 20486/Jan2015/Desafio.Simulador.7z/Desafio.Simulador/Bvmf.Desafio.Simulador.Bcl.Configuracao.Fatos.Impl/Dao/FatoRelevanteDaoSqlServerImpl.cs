using System;
using System.Data;
using System.Data.SqlClient;
//using Framework.AcessoDados;


namespace Desafio.Simulador.Bcl.Configuracao.Fatos.Impl.Dao
{
    
    /// <summary>
    /// Implementa��o de FatoRelevanteDAO - SqlServer
    /// </summary>
    public abstract class FatoRelevanteDAOSqlServerImpl : FatoRelevanteDAO
    {
        
    } //FatoRelevante
}
