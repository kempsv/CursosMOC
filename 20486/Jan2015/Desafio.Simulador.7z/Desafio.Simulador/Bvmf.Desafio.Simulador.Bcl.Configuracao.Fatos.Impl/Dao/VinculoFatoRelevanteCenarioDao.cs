using System;
using System.Collections;
using Desafio.Simulador.Bcl.Configuracao.Fatos.Entidade;
using System.Collections.Generic;
using Desafio.Simulador.Bcl.Comum.Interfaces;

namespace Desafio.Simulador.Bcl.Configuracao.Fatos.Impl.Dao
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    public abstract class VinculoFatoRelevanteCenarioDAO : PersistenceBase
    {
        
        // Propriedade que identifica o datasource.
        public int DataSourceId
        {
            get{ return _datasourceId; }
            set{ _datasourceId = value; }
        }
        
        // Hashtable contendo as implementa��es
        private static Hashtable hashTable = new Hashtable();
        private static string _defaultImpl = "sqlserver";
        private int _datasourceId;
        
        /// <summmary>
        /// Construtor.
        /// </summmary>
        static VinculoFatoRelevanteCenarioDAO()
        {
            hashTable.Add( "sqlserver", "Desafio.Simulador.Bcl.Configuracao.Fatos.Impl.Dao.VinculoFatoRelevanteCenarioDAOSqlServerImpl" );
        }
        
        /// <summary>
        /// Redefine a implementa��o do DAO default.
        /// <param name="key">Chave que identifica a implementa��o.</param>
        /// </summary>
        public static void RegisterDefaultInstance( string key )
        {
            key = key.ToLower();
            if( hashTable[key]==null )
            {
                throw new Exception("Nao existe classe registrada com uma chave '" + key + "'");
            }
            _defaultImpl = key;
        }
        
        /// <summary>
        /// Registra uma nova implementa��o do DAO.
        /// <param name="key">Chave para classe.</param>
        /// <param name="className">Nome da classe.</param>
        /// </summary>
        public static void RegisterNewImplementation( string key, string className )
        {
            key = key.ToLower();
            hashTable.Add( key, className );
        }
        
        /// <summary>
        /// Retorna uma inst�ncia deste DAO. 
        /// A inst�ncia retornada � do tipo passado como par�metro
        /// <param name="key">Chave da classe que deve ser retornada. (oracle, db2, sqlserver, cache, mysql, etc...)</param>
        /// <param name="datasourceId">Identificador da fonte de dados a ser utilizada.</param>
        /// <returns>Inst�ncia do DAO.</returns>
        /// </summary>
        public static VinculoFatoRelevanteCenarioDAO GetInstance( string key, int datasourceId )
        {
            key = key.ToLower();
            VinculoFatoRelevanteCenarioDAO instance = null;
            string className = (string)hashTable[key];
            if( className=="" || className==null )
            {
                throw new Exception( "Nao existe classe registrada com uma chave '" + key + "'");
            }
            try
            {
                Type type = Type.GetType( className, true );
                instance = (VinculoFatoRelevanteCenarioDAO) Activator.CreateInstance( type );
                instance.DataSourceId = datasourceId;
            }
            catch( Exception exc )
            {
                throw new Exception( "Erro ao tentar instanciar a classe " + className + "."  + exc.Message );
            }
            return instance;
        }
        
        /// <summary>
        /// Retorna a inst�ncia default deste DAO. 
        /// <returns>Inst�ncia default do DAO.</returns>
        /// </summary>
        public static VinculoFatoRelevanteCenarioDAO GetInstance()
        {
            return GetInstance( _defaultImpl, 0 );
        }
        
        /// <summary>
        /// Retorna a implementa��o conforme a chave passada. 
        /// <returns>Implementa��o do DAO.</returns>
        /// </summary>
        public static VinculoFatoRelevanteCenarioDAO GetInstance( string key )
        {
            return GetInstance( key, 0 );
        }
        
        /// <summary>
        /// Retorna a inst�ncia default deste DAO. 
        /// <param name="datasourceId">Identificador da fonte de dados a ser utilizada</param>
        /// <returns>@return Inst�ncia default do DAO.</returns>
        /// </summary>
        public static VinculoFatoRelevanteCenarioDAO GetInstance( int datasourceId )
        {
            VinculoFatoRelevanteCenarioDAO dao = GetInstance( _defaultImpl, datasourceId );
            return dao;
        }
        
        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public abstract List<TOVinculoFatoRelevanteCenario> FindAll();
        
        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public abstract TOVinculoFatoRelevanteCenario FindByKey( int codigoCenario, int codigoFato );

        /// <summary>
        /// Busca uma entidade pela sua chave do Fato Relevante.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public abstract TOVinculoFatoRelevanteCenario FindByKey(int codigoFato);
        
        /// <summary>
        /// Remove uma entidade pela sua chave prim�ria.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public abstract void Delete( int codigoFato ) ;
        
        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public abstract void Create( TOVinculoFatoRelevanteCenario transferObject );
        
    } //VinculoFatoRelevanteCenario
}
