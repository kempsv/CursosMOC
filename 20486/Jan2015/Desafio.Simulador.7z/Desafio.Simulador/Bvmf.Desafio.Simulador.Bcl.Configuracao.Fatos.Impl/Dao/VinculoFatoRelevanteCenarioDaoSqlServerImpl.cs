using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Configuracao.Fatos.Entidade;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Configuracao.Fatos.Impl.Dao
{

    /// <summary>
    /// Implementa��o de VinculoFatoRelevanteCenarioDAO - SqlServer
    /// </summary>
    public class VinculoFatoRelevanteCenarioDAOSqlServerImpl : VinculoFatoRelevanteCenarioDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "VinculoFatoRelevanteCenarioDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOVinculoFatoRelevanteCenario> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOVinculoFatoRelevanteCenario> result = new List<TOVinculoFatoRelevanteCenario>();
            TOVinculoFatoRelevanteCenario transferObject = null;

            try
            {
                statement = "SELECT TSDBVINC_FATO_ECON_CENA_SIMU.COD_CENA, TSDBVINC_FATO_ECON_CENA_SIMU.COD_FATO_RLEV FROM TSDBVINC_FATO_ECON_CENA_SIMU TSDBVINC_FATO_ECON_CENA_SIMU WITH(NOLOCK)";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOVinculoFatoRelevanteCenario();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCenario = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoFato = dataReader.GetInt32(1);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave do Fato Relevante.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TOVinculoFatoRelevanteCenario FindByKey(int codigoFato)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOVinculoFatoRelevanteCenario transferObject = null;

            try
            {
                statement = "SELECT TSDBVINC_FATO_ECON_CENA_SIMU.COD_CENA, TSDBVINC_FATO_ECON_CENA_SIMU.COD_FATO_RLEV FROM TSDBVINC_FATO_ECON_CENA_SIMU TSDBVINC_FATO_ECON_CENA_SIMU WITH(NOLOCK) WHERE TSDBVINC_FATO_ECON_CENA_SIMU.COD_FATO_RLEV = @codigoFato ";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                command.Parameters.Add(new SqlParameter("@codigoFato", codigoFato));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOVinculoFatoRelevanteCenario();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCenario = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoFato = dataReader.GetInt32(1);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TOVinculoFatoRelevanteCenario FindByKey(int codigoCenario, int codigoFato)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOVinculoFatoRelevanteCenario transferObject = null;

            try
            {
                statement = "SELECT TSDBVINC_FATO_ECON_CENA_SIMU.COD_CENA, TSDBVINC_FATO_ECON_CENA_SIMU.COD_FATO_RLEV FROM TSDBVINC_FATO_ECON_CENA_SIMU TSDBVINC_FATO_ECON_CENA_SIMU WITH(NOLOCK) WHERE TSDBVINC_FATO_ECON_CENA_SIMU.COD_CENA = @codigoCenario AND TSDBVINC_FATO_ECON_CENA_SIMU.COD_FATO_RLEV = @codigoFato";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoCenario", codigoCenario));

                                command.Parameters.Add(new SqlParameter("@codigoFato", codigoFato));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOVinculoFatoRelevanteCenario();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCenario = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoFato = dataReader.GetInt32(1);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Remove uma entidade pela sua chave prim�ria.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(int codigoFato)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBVINC_FATO_ECON_CENA_SIMU WHERE COD_FATO_RLEV = @codigoFato";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {
                            // Chave prim�ria
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoFato", codigoFato));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TOVinculoFatoRelevanteCenario transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBVINC_FATO_ECON_CENA_SIMU ( COD_CENA, COD_FATO_RLEV ) VALUES ( @codigoCenario, @codigoFato ) ";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoCenario == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCenario", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCenario", transferObject.CodigoCenario));
                            }

                            if (transferObject.CodigoFato == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoFato", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoFato", transferObject.CodigoFato));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

    } //VinculoFatoRelevanteCenario
}
