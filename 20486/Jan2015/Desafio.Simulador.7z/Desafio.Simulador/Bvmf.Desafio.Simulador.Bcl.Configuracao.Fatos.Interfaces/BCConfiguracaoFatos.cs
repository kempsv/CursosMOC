﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Configuracao.Fatos.Entidade;

namespace Desafio.Simulador.Bcl.Configuracao.Fatos.Interfaces
{
    public abstract class BCConfiguracaoFatos : BCEntityPersistence<FatoRelevante,TOFatoRelevante>
    {
        public abstract List<FatoRelevante> ListarFatosByCenario(int codigoCenario);
    }

}
