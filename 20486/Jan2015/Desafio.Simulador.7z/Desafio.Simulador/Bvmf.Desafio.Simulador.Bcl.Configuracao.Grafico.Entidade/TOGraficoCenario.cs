using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Configuracao.Grafico.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOGraficoCenario
    {
        // Declara��o de atributos
        private int _codigoGrafico;
        private string _descricaoGrafico;
        private DateTime _dataCriacao;
        private byte[] _imagemGrafico;
        private string _nomeGrafico;
        private string _caminhoFisicoGrafico;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoGrafico
        {
            get
            {
                return _codigoGrafico;
            }
            set
            {
                _codigoGrafico = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string DescricaoGrafico
        {
            get
            {
                return _descricaoGrafico;
            }
            set
            {
                _descricaoGrafico = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public DateTime DataCriacao
        {
            get
            {
                return _dataCriacao;
            }
            set
            {
                _dataCriacao = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public byte[] ImagemGrafico
        {
            get
            {
                return _imagemGrafico;
            }
            set
            {
                _imagemGrafico = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NomeGrafico
        {
            get
            {
                return _nomeGrafico;
            }
            set
            {
                _nomeGrafico = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string CaminhoFisicoGrafico
        {
            get
            {
                return _caminhoFisicoGrafico;
            }
            set
            {
                _caminhoFisicoGrafico = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOGraficoCenario()
        {
            _codigoGrafico = int.MinValue;
            _descricaoGrafico = null;
            _dataCriacao = DateTime.MinValue;
            _imagemGrafico = null;
            _nomeGrafico = null;
            _caminhoFisicoGrafico = null;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOGraficoCenario" );
            sb.Append( "\n\tCodigoGrafico = " );
            sb.Append( _codigoGrafico );
            sb.Append( "\n\tDescricaoGrafico = " );
            sb.Append( _descricaoGrafico );
            sb.Append( "\n\tDataCriacao = " );
            sb.Append( _dataCriacao );
            sb.Append( "\n\tImagemGrafico = " );
            sb.Append( _imagemGrafico );
            sb.Append( "\n\tNomeGrafico = " );
            sb.Append( _nomeGrafico );
            sb.Append( "\n\tCaminhoFisicoGrafico = " );
            sb.Append( _caminhoFisicoGrafico );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOGraficoCenario) )
            {
                return false;
            }
            
            TOGraficoCenario convertedParam = (TOGraficoCenario) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoGrafico
            if( !CodigoGrafico.Equals( convertedParam.CodigoGrafico ) )
            {
                return false;
            }
            
            // Compara o atributo DescricaoGrafico
            if( !DescricaoGrafico.Equals( convertedParam.DescricaoGrafico ) )
            {
                return false;
            }
            
            // Compara o atributo DataCriacao
            if( !DataCriacao.Equals( convertedParam.DataCriacao ) )
            {
                return false;
            }
            
            // Compara o atributo ImagemGrafico
            if( !ImagemGrafico.Equals( convertedParam.ImagemGrafico ) )
            {
                return false;
            }
            
            // Compara o atributo NomeGrafico
            if( !NomeGrafico.Equals( convertedParam.NomeGrafico ) )
            {
                return false;
            }
            
            // Compara o atributo CaminhoFisicoGrafico
            if( !CaminhoFisicoGrafico.Equals( convertedParam.CaminhoFisicoGrafico ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //GraficoCenario
}
