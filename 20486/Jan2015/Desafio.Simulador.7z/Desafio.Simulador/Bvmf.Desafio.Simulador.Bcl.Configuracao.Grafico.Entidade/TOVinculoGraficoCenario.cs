using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Configuracao.Grafico.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOVinculoGraficoCenario
    {
        // Declara��o de atributos
        private int _codigoGrafico;
        private int _codigoCenario;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoGrafico
        {
            get
            {
                return _codigoGrafico;
            }
            set
            {
                _codigoGrafico = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoCenario
        {
            get
            {
                return _codigoCenario;
            }
            set
            {
                _codigoCenario = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOVinculoGraficoCenario()
        {
            _codigoGrafico = int.MinValue;
            _codigoCenario = int.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOVinculoGraficoCenario" );
            sb.Append( "\n\tCodigoGrafico = " );
            sb.Append( _codigoGrafico );
            sb.Append( "\n\tCodigoCenario = " );
            sb.Append( _codigoCenario );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOVinculoGraficoCenario) )
            {
                return false;
            }
            
            TOVinculoGraficoCenario convertedParam = (TOVinculoGraficoCenario) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoGrafico
            if( !CodigoGrafico.Equals( convertedParam.CodigoGrafico ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoCenario
            if( !CodigoCenario.Equals( convertedParam.CodigoCenario ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //VinculoGraficoCenario
}
