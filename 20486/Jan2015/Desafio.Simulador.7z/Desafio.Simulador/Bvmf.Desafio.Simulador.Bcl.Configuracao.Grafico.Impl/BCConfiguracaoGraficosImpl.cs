﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Configuracao.Grafico.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Grafico.Impl.Dao;
using Desafio.Simulador.Bcl.Configuracao.Grafico.Entidade;
using Desafio.Simulador.Bcl.Configuracao.Cenario.Interfaces;
using Microsoft.Practices.Unity;

namespace Desafio.Simulador.Bcl.Configuracao.Grafico.Impl
{
    public class BCConfiguracaoGraficosImpl : BCConfiguracaoGraficos
    {
        public BCConfiguracaoGraficosImpl(GraficoCenarioDAO persistence)
        {
            _persistence = persistence;
        }

        private void VincularFatoCenario(GraficoCenario entity)
        {
            this.DesvincularFatoCenario(entity);

            //Faz o vínculo do Fato Relevante com o Cenário de Simulação de Investimento
            VinculoGraficoCenarioDAO.GetInstance().Create(new TOVinculoGraficoCenario()
            {
                CodigoCenario = entity.CenarioSimulacao.Codigo,
                CodigoGrafico = entity.Codigo
            }
            );
        }

        private void PreencherAgregacao(List<GraficoCenario> graficos)
        {
            graficos.ForEach(delegate(GraficoCenario graficoCenario)
            {
                var _vinculosGrafico = VinculoGraficoCenarioDAO.GetInstance().FindByKey(graficoCenario.Codigo);
                graficoCenario.CenarioSimulacao = new CenarioSimulacao() { Codigo = _vinculosGrafico.CodigoCenario };
            });
        }

        private void PreencherAgregacao(GraficoCenario grafico)
        {
            this.PreencherAgregacao(new List<GraficoCenario>() { grafico });
        }

        private void DesvincularFatoCenario(GraficoCenario entity)
        {
            VinculoGraficoCenarioDAO.GetInstance().Delete(entity.Codigo);
        }

        public override void Create(GraficoCenario entity)
        {
            base.Create(entity);

            this.VincularFatoCenario(entity);
       }

        public override void Update(GraficoCenario entity)
        {
            base.Update(entity);

            this.VincularFatoCenario(entity);
        }

        public override void Delete(GraficoCenario entity)
        {
            this.DesvincularFatoCenario(entity);

            base.Delete(entity);
        }

        public override List<GraficoCenario> FindAll()
        {
            var _graficos = base.FindAll();

            this.PreencherAgregacao(_graficos);

            return _graficos;
        }


        public override GraficoCenario FindByKey(int key)
        {
            var _grafico = base.FindByKey(key);

            this.PreencherAgregacao(_grafico);

            return _grafico;
        }

        public override List<GraficoCenario> ListarGraficosByCenario(int codigoCenario)
        {
            var _graficosCenario = ((GraficoCenarioDAO)_persistence).FindGraficosByCenarios(codigoCenario);

            _graficosCenario.ForEach(delegate(GraficoCenario graficoCenario)
            {
                graficoCenario.CenarioSimulacao = new CenarioSimulacao() { Codigo = codigoCenario };
            });
            return _graficosCenario;
        }
    }
}
