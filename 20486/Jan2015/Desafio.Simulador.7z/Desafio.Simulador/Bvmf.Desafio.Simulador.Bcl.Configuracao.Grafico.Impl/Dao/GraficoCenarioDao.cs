using System;
using System.Collections;
using Desafio.Simulador.Bcl.Configuracao.Grafico.Entidade;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using System.Collections.Generic;

namespace Desafio.Simulador.Bcl.Configuracao.Grafico.Impl.Dao
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    public abstract class GraficoCenarioDAO : PersistenceBaseRepository<GraficoCenario,TOGraficoCenario>
    {
        
        // Propriedade que identifica o datasource.
        public int DataSourceId
        {
            get{ return _datasourceId; }
            set{ _datasourceId = value; }
        }
        
        // Hashtable contendo as implementa��es
        private static Hashtable hashTable = new Hashtable();
        private static string _defaultImpl = "default";
        private int _datasourceId;
        
        /// <summmary>
        /// Construtor.
        /// </summmary>
        static GraficoCenarioDAO()
        {
            hashTable.Add( "sqlserver", "Desafio.Simulador.Bcl.Configuracao.Grafico.Impl.Dao.GraficoCenarioDAOSqlServerImpl" );
            hashTable.Add( "default", "Desafio.Simulador.Bcl.Configuracao.Grafico.Impl.Dao.GraficoCenarioDaoSqlServerCustomImpl" );
        }
        
        /// <summary>
        /// Redefine a implementa��o do DAO default.
        /// <param name="key">Chave que identifica a implementa��o.</param>
        /// </summary>
        public static void RegisterDefaultInstance( string key )
        {
            key = key.ToLower();
            if( hashTable[key]==null )
            {
                throw new Exception("Nao existe classe registrada com uma chave '" + key + "'");
            }
            _defaultImpl = key;
        }
        
        /// <summary>
        /// Registra uma nova implementa��o do DAO.
        /// <param name="key">Chave para classe.</param>
        /// <param name="className">Nome da classe.</param>
        /// </summary>
        public static void RegisterNewImplementation( string key, string className )
        {
            key = key.ToLower();
            hashTable.Add( key, className );
        }
        
        /// <summary>
        /// Retorna uma inst�ncia deste DAO. 
        /// A inst�ncia retornada � do tipo passado como par�metro
        /// <param name="key">Chave da classe que deve ser retornada. (oracle, db2, sqlserver, cache, mysql, etc...)</param>
        /// <param name="datasourceId">Identificador da fonte de dados a ser utilizada.</param>
        /// <returns>Inst�ncia do DAO.</returns>
        /// </summary>
        public static GraficoCenarioDAO GetInstance( string key, int datasourceId )
        {
            key = key.ToLower();
            GraficoCenarioDAO instance = null;
            string className = (string)hashTable[key];
            if( className=="" || className==null )
            {
                throw new Exception( "Nao existe classe registrada com uma chave '" + key + "'");
            }
            try
            {
                Type type = Type.GetType( className, true );
                instance = (GraficoCenarioDAO) Activator.CreateInstance( type );
                instance.DataSourceId = datasourceId;
            }
            catch( Exception exc )
            {
                throw new Exception( "Erro ao tentar instanciar a classe " + className + "."  + exc.Message );
            }
            return instance;
        }
        
        /// <summary>
        /// Retorna a inst�ncia default deste DAO. 
        /// <returns>Inst�ncia default do DAO.</returns>
        /// </summary>
        public static GraficoCenarioDAO GetInstance()
        {
            return GetInstance( _defaultImpl, 0 );
        }
        
        /// <summary>
        /// Retorna a implementa��o conforme a chave passada. 
        /// <returns>Implementa��o do DAO.</returns>
        /// </summary>
        public static GraficoCenarioDAO GetInstance( string key )
        {
            return GetInstance( key, 0 );
        }
        
        /// <summary>
        /// Retorna a inst�ncia default deste DAO. 
        /// <param name="datasourceId">Identificador da fonte de dados a ser utilizada</param>
        /// <returns>@return Inst�ncia default do DAO.</returns>
        /// </summary>
        public static GraficoCenarioDAO GetInstance( int datasourceId )
        {
            GraficoCenarioDAO dao = GetInstance( _defaultImpl, datasourceId );
            return dao;
        }

        /// <summary>
        /// Busca todas as entidades pelo c�digo do cen�rio
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public abstract List<GraficoCenario> FindGraficosByCenarios(int codigoCenario);
        
    } //GraficoCenario
}
