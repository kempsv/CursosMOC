﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Configuracao.Grafico.Entidade;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Configuracao.Grafico.Impl.Dao
{
    public class GraficoCenarioDaoSqlServerCustomImpl : GraficoCenarioDAOSqlServerImpl
    {
        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "GraficoCenarioDaoSqlServerCustomImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<GraficoCenario> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOGraficoCenario> result = new List<TOGraficoCenario>();
            TOGraficoCenario transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBGRAF_CENA.COD_GRAF, TSDBGRAF_CENA.DESC_GRAF, TSDBGRAF_CENA.DTHR_CRIA, TSDBGRAF_CENA.IMAG_GRAF, TSDBGRAF_CENA.NOME_GRAF, TSDBGRAF_CENA.TXT_CAM_FISI_GRAF FROM TSDBGRAF_CENA TSDBGRAF_CENA WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOGraficoCenario();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrafico = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.DescricaoGrafico = dataReader.GetString(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.DataCriacao = dataReader.GetDateTime(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.ImagemGrafico = ((SqlDataReader)dataReader).GetSqlBytes(3).Buffer;
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.NomeGrafico = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.CaminhoFisicoGrafico = dataReader.GetString(5);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca todas as entidades pelo código do cenário
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<GraficoCenario> FindGraficosByCenarios(int codigoCenario)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOGraficoCenario> result = new List<TOGraficoCenario>();
            TOGraficoCenario transferObject = null;

            try
            {
                statement = "SELECT TSDBGRAF_CENA.COD_GRAF, TSDBGRAF_CENA.DESC_GRAF, TSDBGRAF_CENA.DTHR_CRIA, TSDBGRAF_CENA.IMAG_GRAF, TSDBGRAF_CENA.NOME_GRAF, TSDBGRAF_CENA.TXT_CAM_FISI_GRAF FROM TSDBGRAF_CENA TSDBGRAF_CENA WITH(NOLOCK) INNER JOIN TSDBVINC_GRAF_CENA_SIMU VINCULO WITH(NOLOCK)	ON VINCULO.COD_GRAF = TSDBGRAF_CENA.COD_GRAF WHERE VINCULO.COD_CENA = " + codigoCenario + "";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOGraficoCenario();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrafico = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.DescricaoGrafico = dataReader.GetString(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.DataCriacao = dataReader.GetDateTime(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.ImagemGrafico = ((SqlDataReader)dataReader).GetSqlBytes(3).Buffer;
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.NomeGrafico = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.CaminhoFisicoGrafico = dataReader.GetString(5);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override GraficoCenario FindByKey(int codigoGrafico)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOGraficoCenario transferObject = null;

            try
            {
                statement = "SELECT TSDBGRAF_CENA.COD_GRAF, TSDBGRAF_CENA.DESC_GRAF, TSDBGRAF_CENA.DTHR_CRIA, TSDBGRAF_CENA.IMAG_GRAF, TSDBGRAF_CENA.NOME_GRAF, TSDBGRAF_CENA.TXT_CAM_FISI_GRAF FROM TSDBGRAF_CENA TSDBGRAF_CENA WITH(NOLOCK) WHERE TSDBGRAF_CENA.COD_GRAF = @codigoGrafico";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoGrafico", codigoGrafico));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOGraficoCenario();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrafico = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.DescricaoGrafico = dataReader.GetString(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.DataCriacao = dataReader.GetDateTime(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.ImagemGrafico = ((SqlDataReader)dataReader).GetSqlBytes(3).Buffer;
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.NomeGrafico = dataReader.GetString(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.CaminhoFisicoGrafico = dataReader.GetString(5);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Remove uma entidade pela sua chave primária.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(GraficoCenario entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOGraficoCenario transferObject = TranslateToDTO(entity);

                statement = "DELETE FROM TSDBGRAF_CENA WHERE COD_GRAF = @codigoGrafico";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave primária
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoGrafico", transferObject.CodigoGrafico));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma instância em memória na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(GraficoCenario entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOGraficoCenario transferObject = TranslateToDTO(entity);

                statement = "UPDATE TSDBGRAF_CENA SET dESC_GRAF = @descricaoGrafico, dTHR_CRIA = @dataCriacao, iMAG_GRAF = @imagemGrafico, nOME_GRAF = @nomeGrafico, tXT_CAM_FISI_GRAF = @caminhoFisicoGrafico WHERE COD_GRAF = @codigoGrafico";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que não estão na chave
                            if (transferObject.DescricaoGrafico == null)
                            {
                                command.Parameters.Add(new SqlParameter("@descricaoGrafico", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@descricaoGrafico", transferObject.DescricaoGrafico));
                            }

                            if (transferObject.DataCriacao == DateTime.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@dataCriacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@dataCriacao", transferObject.DataCriacao));
                            }

                            if (transferObject.ImagemGrafico == null)
                            {
                                command.Parameters.Add(new SqlParameter("@imagemGrafico", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@imagemGrafico", transferObject.ImagemGrafico));
                            }

                            if (transferObject.NomeGrafico == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeGrafico", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeGrafico", transferObject.NomeGrafico));
                            }

                            if (transferObject.CaminhoFisicoGrafico == null)
                            {
                                command.Parameters.Add(new SqlParameter("@caminhoFisicoGrafico", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@caminhoFisicoGrafico", transferObject.CaminhoFisicoGrafico));
                            }

                            // Chave primária
                            command.Parameters.Add(new SqlParameter("@codigoGrafico", transferObject.CodigoGrafico));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma instância em memória na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(GraficoCenario entity)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                TOGraficoCenario transferObject = TranslateToDTO(entity);

                statement = "INSERT INTO TSDBGRAF_CENA ( DESC_GRAF, DTHR_CRIA, IMAG_GRAF, NOME_GRAF, TXT_CAM_FISI_GRAF ) VALUES ( @descricaoGrafico, @dataCriacao, @imagemGrafico, @nomeGrafico, @caminhoFisicoGrafico )  ; SELECT SCOPE_IDENTITY();";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.DescricaoGrafico == null)
                            {
                                command.Parameters.Add(new SqlParameter("@descricaoGrafico", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@descricaoGrafico", transferObject.DescricaoGrafico));
                            }

                            if (transferObject.DataCriacao == DateTime.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@dataCriacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@dataCriacao", transferObject.DataCriacao));
                            }

                            if (transferObject.ImagemGrafico == null)
                            {
                                command.Parameters.Add(new SqlParameter("@imagemGrafico", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@imagemGrafico", transferObject.ImagemGrafico));
                            }

                            if (transferObject.NomeGrafico == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeGrafico", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeGrafico", transferObject.NomeGrafico));
                            }

                            if (transferObject.CaminhoFisicoGrafico == null)
                            {
                                command.Parameters.Add(new SqlParameter("@caminhoFisicoGrafico", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@caminhoFisicoGrafico", transferObject.CaminhoFisicoGrafico));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            entity.Codigo = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        protected override List<GraficoCenario> TranslateFromDTO(List<TOGraficoCenario> entityDTO)
        {
            var _returnEntities = new List<GraficoCenario>();

            foreach (TOGraficoCenario entity in entityDTO)
            {
                _returnEntities.Add(TranslateFromDTO(entity));
            }

            return _returnEntities;
        }

        protected override GraficoCenario TranslateFromDTO(TOGraficoCenario entityDTO)
        {
            var _returnEntity = new GraficoCenario
            {
                Codigo = entityDTO.CodigoGrafico,
                BufferImagem = entityDTO.ImagemGrafico,
                CaminhoFisico = entityDTO.CaminhoFisicoGrafico,
                Descricao = entityDTO.DescricaoGrafico,
                Nome = entityDTO.NomeGrafico,
                DataCriacao = entityDTO.DataCriacao
            };

            return _returnEntity;
        }

        protected override TOGraficoCenario TranslateToDTO(GraficoCenario entity)
        {
            var _returnEntity = new TOGraficoCenario
            {
                CodigoGrafico = entity.Codigo,
                NomeGrafico = entity.Nome,
                CaminhoFisicoGrafico = entity.CaminhoFisico,
                DataCriacao = entity.DataCriacao,
                DescricaoGrafico = entity.Descricao,
                ImagemGrafico = entity.BufferImagem,
            };
            return _returnEntity;
        }

        protected override List<TOGraficoCenario> TranslateToDTO(List<GraficoCenario> entity)
        {
            var _returnEntities = new List<TOGraficoCenario>();

            foreach (GraficoCenario et in entity)
            {
                _returnEntities.Add(TranslateToDTO(et));
            }
            return _returnEntities;
        }
    }
}
