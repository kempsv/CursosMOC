using System;
using System.Data;
using System.Data.SqlClient;
//using Framework.AcessoDados;

namespace Desafio.Simulador.Bcl.Configuracao.Grafico.Impl.Dao
{
    
    /// <summary>
    /// Implementa��o de GraficoCenarioDAO - SqlServer
    /// </summary>
    public abstract class GraficoCenarioDAOSqlServerImpl : GraficoCenarioDAO
    {
      
    } //GraficoCenario
}
