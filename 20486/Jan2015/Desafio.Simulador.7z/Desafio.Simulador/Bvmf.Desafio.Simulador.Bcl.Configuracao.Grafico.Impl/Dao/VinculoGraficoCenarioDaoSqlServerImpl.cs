using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Configuracao.Grafico.Entidade;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Configuracao.Grafico.Impl.Dao
{

    /// <summary>
    /// Implementa��o de VinculoGraficoCenarioDAO - SqlServer
    /// </summary>
    public class VinculoGraficoCenarioDAOSqlServerImpl : VinculoGraficoCenarioDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "VinculoGraficoCenarioDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOVinculoGraficoCenario> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOVinculoGraficoCenario> result = new List<TOVinculoGraficoCenario>();
            TOVinculoGraficoCenario transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBVINC_GRAF_CENA_SIMU.COD_GRAF, TSDBVINC_GRAF_CENA_SIMU.COD_CENA FROM TSDBVINC_GRAF_CENA_SIMU TSDBVINC_GRAF_CENA_SIMU WITH(NOLOCK)";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOVinculoGraficoCenario();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrafico = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoCenario = dataReader.GetInt32(1);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TOVinculoGraficoCenario FindByKey(int codigoGrafico, int codigoCenario)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOVinculoGraficoCenario transferObject = null;

            try
            {
                statement = "SELECT TSDBVINC_GRAF_CENA_SIMU.COD_GRAF, TSDBVINC_GRAF_CENA_SIMU.COD_CENA FROM TSDBVINC_GRAF_CENA_SIMU TSDBVINC_GRAF_CENA_SIMU WITH(NOLOCK) WHERE TSDBVINC_GRAF_CENA_SIMU.COD_GRAF = @codigoGrafico AND TSDBVINC_GRAF_CENA_SIMU.COD_CENA = @codigoCenario";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoGrafico", codigoGrafico));

                                command.Parameters.Add(new SqlParameter("@codigoCenario", codigoCenario));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOVinculoGraficoCenario();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrafico = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoCenario = dataReader.GetInt32(1);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave do Gr�fico.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TOVinculoGraficoCenario FindByKey(int codigoGrafico)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOVinculoGraficoCenario transferObject = null;

            try
            {
                statement = "SELECT TSDBVINC_GRAF_CENA_SIMU.COD_GRAF, TSDBVINC_GRAF_CENA_SIMU.COD_CENA FROM TSDBVINC_GRAF_CENA_SIMU TSDBVINC_GRAF_CENA_SIMU WITH(NOLOCK) WHERE TSDBVINC_GRAF_CENA_SIMU.COD_GRAF = @codigoGrafico ";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoGrafico", codigoGrafico));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOVinculoGraficoCenario();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrafico = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoCenario = dataReader.GetInt32(1);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Remove uma entidade pela sua chave prim�ria.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(int codigoGrafico)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBVINC_GRAF_CENA_SIMU WHERE COD_GRAF = @codigoGrafico ";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave prim�ria
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoGrafico", codigoGrafico));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TOVinculoGraficoCenario transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBVINC_GRAF_CENA_SIMU ( COD_GRAF, COD_CENA ) VALUES ( @codigoGrafico, @codigoCenario ) ";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoGrafico == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoGrafico", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoGrafico", transferObject.CodigoGrafico));
                            }

                            if (transferObject.CodigoCenario == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCenario", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCenario", transferObject.CodigoCenario));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

    } //VinculoGraficoCenario
}
