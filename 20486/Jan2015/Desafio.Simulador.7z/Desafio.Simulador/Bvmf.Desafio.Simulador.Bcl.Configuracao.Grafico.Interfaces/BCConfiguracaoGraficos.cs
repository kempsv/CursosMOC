﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Configuracao.Grafico.Entidade;

namespace Desafio.Simulador.Bcl.Configuracao.Grafico.Interfaces
{
    public abstract class BCConfiguracaoGraficos : BCEntityPersistence<GraficoCenario, TOGraficoCenario>
    {
        public abstract List<GraficoCenario> ListarGraficosByCenario(int codigoCenario);
    }
}
