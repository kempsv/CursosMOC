using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Configuracao.Papel.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOPapel
    {
        // Declara��o de atributos
        private int _codigoPapel;
        private string _nomeAbreviado;
        private string _nomeCompleto;
        private decimal _valorPrecoInicial;
        
        public int CodigoPapel
        {
            get
            {
                return _codigoPapel;
            }
            set
            {
                _codigoPapel = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NomeAbreviado
        {
            get
            {
                return _nomeAbreviado;
            }
            set
            {
                _nomeAbreviado = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NomeCompleto
        {
            get
            {
                return _nomeCompleto;
            }
            set
            {
                _nomeCompleto = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal ValorPrecoInicial
        {
            get
            {
                return _valorPrecoInicial;
            }
            set
            {
                _valorPrecoInicial = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOPapel()
        {
            _codigoPapel = int.MinValue;
            _nomeAbreviado = null;
            _nomeCompleto = null;
            _valorPrecoInicial = decimal.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOPapel" );
            sb.Append( "\n\tCodigoPapel = " );
            sb.Append( _codigoPapel );
            sb.Append( "\n\tNomeAbreviado = " );
            sb.Append( _nomeAbreviado );
            sb.Append( "\n\tNomeCompleto = " );
            sb.Append( _nomeCompleto );
            sb.Append( "\n\tValorPrecoInicial = " );
            sb.Append( _valorPrecoInicial );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOPapel) )
            {
                return false;
            }
            
            TOPapel convertedParam = (TOPapel) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoPapel
            if( !CodigoPapel.Equals( convertedParam.CodigoPapel ) )
            {
                return false;
            }
            
            // Compara o atributo NomeAbreviado
            if( !NomeAbreviado.Equals( convertedParam.NomeAbreviado ) )
            {
                return false;
            }
            
            // Compara o atributo NomeCompleto
            if( !NomeCompleto.Equals( convertedParam.NomeCompleto ) )
            {
                return false;
            }
            
            // Compara o atributo ValorPrecoInicial
            if( !ValorPrecoInicial.Equals( convertedParam.ValorPrecoInicial ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //Papel
}
