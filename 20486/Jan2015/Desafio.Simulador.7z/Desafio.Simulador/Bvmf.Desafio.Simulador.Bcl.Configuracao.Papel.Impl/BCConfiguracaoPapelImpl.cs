﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Papel.Entidade;
using Desafio.Simulador.Bcl.Configuracao.Papel.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Papel.Impl.Dao;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bcl.Core.Domain;

namespace Desafio.Simulador.Bcl.Configuracao.Papel.Impl
{
    public class BCConfiguracaoPapelImpl : BCConfiguracaoPapel
    {
        public BCConfiguracaoPapelImpl(PapelDAO persistence)
        {
            _persistence = persistence;
        }

        public override void Delete(PapelCarteira entity)
        {
            base.Delete(entity);
        }
        public override List<PapelCarteira> ListarPapeisByCarteira(int codigoCarteira)
        {
            /*try
            {
                //var _papeisDTO = ((PapelCarteiraDao)_persistence).FindPapeisByCarteira(codigoCarteira);

                return ((PapelDAO)_persistence).FindPapeisByCarteira(codigoCarteira);
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }*/
            return null;
        }
    }
}
