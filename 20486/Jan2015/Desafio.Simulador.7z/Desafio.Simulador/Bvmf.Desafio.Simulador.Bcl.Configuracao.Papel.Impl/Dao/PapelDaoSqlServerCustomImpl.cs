﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

//using Framework.AcessoDados.Impl;
//using Framework.Log;

using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Configuracao.Papel.Entidade;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Configuracao.Papel.Impl.Dao
{
    public class PapelDaoSqlServerCustomImpl : PapelDAOSqlServerImpl
    {
        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "PapelDaoSqlServerCustomImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<PapelCarteira> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOPapel> result = new List<TOPapel>();
            TOPapel transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 Papel.COD_PAP, Papel.NOME_ABRE_PAP, Papel.NOME_CMPL_PAP, Papel.VAL_PREC_INIC_PAP FROM TSDBPAP Papel WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOPapel();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoPapel = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.NomeAbreviado = dataReader.GetString(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.NomeCompleto = dataReader.GetString(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.ValorPrecoInicial = dataReader.GetDecimal(3);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override PapelCarteira FindByKey(int codigoPapel)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOPapel transferObject = null;

            try
            {
                statement = "SELECT Papel.COD_PAP, Papel.NOME_ABRE_PAP, Papel.NOME_CMPL_PAP, Papel.VAL_PREC_INIC_PAP FROM TSDBPAP Papel WITH(NOLOCK) WHERE Papel.COD_PAP = @codigoPapel";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoPapel", codigoPapel));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOPapel();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoPapel = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.NomeAbreviado = dataReader.GetString(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.NomeCompleto = dataReader.GetString(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.ValorPrecoInicial = dataReader.GetDecimal(3);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Remove uma entidade pela sua chave primária.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(PapelCarteira entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOPapel transferObject = TranslateToDTO(entity);

                statement = "DELETE FROM TSDBPAP WHERE COD_PAP = @codigoPapel";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {

                            // Chave primária
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoPapel", transferObject.CodigoPapel));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma instância em memória na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(PapelCarteira entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOPapel transferObject = TranslateToDTO(entity);

                statement = "UPDATE TSDBPAP SET nOME_ABRE_PAP = @nomeAbreviado, nOME_CMPL_PAP = @nomeCompleto, vAL_PREC_INIC_PAP = @valorPrecoInicial WHERE COD_PAP = @codigoPapel";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que não estão na chave
                            if (transferObject.NomeAbreviado == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeAbreviado", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeAbreviado", transferObject.NomeAbreviado));
                            }

                            if (transferObject.NomeCompleto == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeCompleto", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeCompleto", transferObject.NomeCompleto));
                            }

                            if (transferObject.ValorPrecoInicial == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorPrecoInicial", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorPrecoInicial", transferObject.ValorPrecoInicial));
                            }

                            // Chave primária
                            command.Parameters.Add(new SqlParameter("@codigoPapel", transferObject.CodigoPapel));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma instância em memória na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(PapelCarteira entity)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                TOPapel transferObject = TranslateToDTO(entity);

                statement = "INSERT INTO TSDBPAP ( NOME_ABRE_PAP, NOME_CMPL_PAP, VAL_PREC_INIC_PAP ) VALUES ( @nomeAbreviado, @nomeCompleto, @valorPrecoInicial )  ; SELECT SCOPE_IDENTITY();";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.NomeAbreviado == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeAbreviado", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeAbreviado", transferObject.NomeAbreviado));
                            }

                            if (transferObject.NomeCompleto == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeCompleto", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeCompleto", transferObject.NomeCompleto));
                            }

                            if (transferObject.ValorPrecoInicial == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorPrecoInicial", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorPrecoInicial", transferObject.ValorPrecoInicial));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            entity.Codigo = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }
        }

        protected override PapelCarteira TranslateFromDTO(TOPapel entityDTO)
        {
            var papelEntity = new PapelCarteira
            {
                Codigo = entityDTO.CodigoPapel,
                NomeAbreviado = entityDTO.NomeAbreviado,
                NomeCompleto = entityDTO.NomeCompleto,
                PrecoCompraInicial = entityDTO.ValorPrecoInicial
            };

            return papelEntity;
        }

        protected override List<PapelCarteira> TranslateFromDTO(List<TOPapel> entityDTO)
        {
            var _papeis = new List<PapelCarteira>();

            foreach (TOPapel papel in entityDTO)
            {
                var papelEntity = new PapelCarteira
                {
                    Codigo = papel.CodigoPapel,
                    NomeAbreviado = papel.NomeAbreviado,
                    NomeCompleto = papel.NomeCompleto,
                    PrecoCompraInicial = papel.ValorPrecoInicial
                };
                _papeis.Add(papelEntity);
            }

            return _papeis;
        }

        protected override List<TOPapel> TranslateToDTO(List<PapelCarteira> entity)
        {
            var _papeis = new List<TOPapel>();

            foreach (PapelCarteira papel in entity)
            {
                var papelEntity = new TOPapel
                {
                    CodigoPapel = papel.Codigo,
                    NomeAbreviado = papel.NomeAbreviado,
                    NomeCompleto = papel.NomeCompleto,
                    ValorPrecoInicial = papel.PrecoCompraInicial,
                };
                _papeis.Add(papelEntity);
            }

            return _papeis;
        }

        protected override TOPapel TranslateToDTO(PapelCarteira entity)
        {
            var papelEntity = new TOPapel
            {
                CodigoPapel = entity.Codigo,
                NomeAbreviado = entity.NomeAbreviado,
                NomeCompleto = entity.NomeCompleto,
                ValorPrecoInicial = entity.PrecoCompraInicial,
            };

            return papelEntity;
        }
    }
}
