﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Papel.Entidade;
using Desafio.Simulador.Bcl.Core.Domain;

namespace Desafio.Simulador.Bcl.Configuracao.Papel.Interfaces
{
    public abstract class BCConfiguracaoPapel : BCEntityPersistence<PapelCarteira,TOPapel>
    {
        public abstract List<PapelCarteira> ListarPapeisByCarteira(int codigoCarteira);
    }
}
