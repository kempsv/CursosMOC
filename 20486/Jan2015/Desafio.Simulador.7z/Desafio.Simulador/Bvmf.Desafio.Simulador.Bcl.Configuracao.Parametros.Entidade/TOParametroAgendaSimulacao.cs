using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Configuracao.Parametros.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOParametroAgendaSimulacao
    {
        // Declara��o de atributos
        private int _codigoParametro;
        private int _tipoModoSimulacao;
        private int _quantidadeRodadas;
        private short _variacaoMaximaSimulacao;
        private short _mediaInicialSimulacao;
        private int _maximaTentativaContingencia;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoParametro
        {
            get
            {
                return _codigoParametro;
            }
            set
            {
                _codigoParametro = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int TipoModoSimulacao
        {
            get
            {
                return _tipoModoSimulacao;
            }
            set
            {
                _tipoModoSimulacao = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int QuantidadeRodadas
        {
            get
            {
                return _quantidadeRodadas;
            }
            set
            {
                _quantidadeRodadas = value;
            }
        }
        
        public short VariacaoMaximaSimulacao
        {
            get
            {
                return _variacaoMaximaSimulacao;
            }
            set
            {
                _variacaoMaximaSimulacao = value;
            }
        }
        
        public short MediaInicialSimulacao
        {
            get
            {
                return _mediaInicialSimulacao;
            }
            set
            {
                _mediaInicialSimulacao = value;
            }
        }
        
        public int MaximaTentativaContingencia
        {
            get
            {
                return _maximaTentativaContingencia;
            }
            set
            {
                _maximaTentativaContingencia = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOParametroAgendaSimulacao()
        {
            _codigoParametro = int.MinValue;
            _tipoModoSimulacao = int.MinValue;
            _quantidadeRodadas = int.MinValue;
            _variacaoMaximaSimulacao = short.MinValue;
            _mediaInicialSimulacao = short.MinValue;
            _maximaTentativaContingencia = int.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOParametroAgendaSimulacao" );
            sb.Append( "\n\tCodigoParametro = " );
            sb.Append( _codigoParametro );
            sb.Append( "\n\tTipoModoSimulacao = " );
            sb.Append( _tipoModoSimulacao );
            sb.Append( "\n\tQuantidadeRodadas = " );
            sb.Append( _quantidadeRodadas );
            sb.Append( "\n\tVariacaoMaximaSimulacao = " );
            sb.Append( _variacaoMaximaSimulacao );
            sb.Append( "\n\tMediaInicialSimulacao = " );
            sb.Append( _mediaInicialSimulacao );
            sb.Append( "\n\tMaximaTentativaContingencia = " );
            sb.Append( _maximaTentativaContingencia );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOParametroAgendaSimulacao) )
            {
                return false;
            }
            
            TOParametroAgendaSimulacao convertedParam = (TOParametroAgendaSimulacao) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoParametro
            if( !CodigoParametro.Equals( convertedParam.CodigoParametro ) )
            {
                return false;
            }
            
            // Compara o atributo TipoModoSimulacao
            if( !TipoModoSimulacao.Equals( convertedParam.TipoModoSimulacao ) )
            {
                return false;
            }
            
            // Compara o atributo QuantidadeRodadas
            if( !QuantidadeRodadas.Equals( convertedParam.QuantidadeRodadas ) )
            {
                return false;
            }
            
            // Compara o atributo VariacaoMaximaSimulacao
            if( !VariacaoMaximaSimulacao.Equals( convertedParam.VariacaoMaximaSimulacao ) )
            {
                return false;
            }
            
            // Compara o atributo MediaInicialSimulacao
            if( !MediaInicialSimulacao.Equals( convertedParam.MediaInicialSimulacao ) )
            {
                return false;
            }
            
            // Compara o atributo MaximaTentativaContingencia
            if( !MaximaTentativaContingencia.Equals( convertedParam.MaximaTentativaContingencia ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //ParametroAgendaSimulacao
}
