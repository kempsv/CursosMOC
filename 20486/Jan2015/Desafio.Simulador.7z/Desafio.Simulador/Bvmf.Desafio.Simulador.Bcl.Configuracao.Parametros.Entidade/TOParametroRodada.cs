using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Configuracao.Parametros.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOParametroRodada
    {
        // Declara��o de atributos
        private int _codigoParametro;
        private int _tipoModoSimulacao;
        private bool _indicadorCenarioRandomico;
        private bool _indicadorAtivo;
        private decimal _percentualAcao;
        private decimal _percentualOutros;
        private int _quantidadeCenariosContingencia;
        private string _tempoRodadaNaoHabilitada;
        private int _tempoRodada;
        private int _tempoIntervaloRodada;
        private decimal _percentualPenalidade;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoParametro
        {
            get
            {
                return _codigoParametro;
            }
            set
            {
                _codigoParametro = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int TipoModoSimulacao
        {
            get
            {
                return _tipoModoSimulacao;
            }
            set
            {
                _tipoModoSimulacao = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public bool IndicadorCenarioRandomico
        {
            get
            {
                return _indicadorCenarioRandomico;
            }
            set
            {
                _indicadorCenarioRandomico = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public bool IndicadorAtivo
        {
            get
            {
                return _indicadorAtivo;
            }
            set
            {
                _indicadorAtivo = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal PercentualAcao
        {
            get
            {
                return _percentualAcao;
            }
            set
            {
                _percentualAcao = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal PercentualOutros
        {
            get
            {
                return _percentualOutros;
            }
            set
            {
                _percentualOutros = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int QuantidadeCenariosContingencia
        {
            get
            {
                return _quantidadeCenariosContingencia;
            }
            set
            {
                _quantidadeCenariosContingencia = value;
            }
        }
        
        public string TempoRodadaNaoHabilitada
        {
            get
            {
                return _tempoRodadaNaoHabilitada;
            }
            set
            {
                _tempoRodadaNaoHabilitada = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int TempoRodada
        {
            get
            {
                return _tempoRodada;
            }
            set
            {
                _tempoRodada = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int TempoIntervaloRodada
        {
            get
            {
                return _tempoIntervaloRodada;
            }
            set
            {
                _tempoIntervaloRodada = value;
            }
        }
        
        public decimal PercentualPenalidade
        {
            get
            {
                return _percentualPenalidade;
            }
            set
            {
                _percentualPenalidade = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOParametroRodada()
        {
            _codigoParametro = int.MinValue;
            _tipoModoSimulacao = int.MinValue;
            _indicadorCenarioRandomico = false;
            _indicadorAtivo = false;
            _percentualAcao = decimal.MinValue;
            _percentualOutros = decimal.MinValue;
            _quantidadeCenariosContingencia = int.MinValue;
            _tempoRodadaNaoHabilitada = null;
            _tempoRodada = int.MinValue;
            _tempoIntervaloRodada = int.MinValue;
            _percentualPenalidade = decimal.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOParametroRodada" );
            sb.Append( "\n\tCodigoParametro = " );
            sb.Append( _codigoParametro );
            sb.Append( "\n\tTipoModoSimulacao = " );
            sb.Append( _tipoModoSimulacao );
            sb.Append( "\n\tIndicadorCenarioRandomico = " );
            sb.Append( _indicadorCenarioRandomico );
            sb.Append( "\n\tIndicadorAtivo = " );
            sb.Append( _indicadorAtivo );
            sb.Append( "\n\tPercentualAcao = " );
            sb.Append( _percentualAcao );
            sb.Append( "\n\tPercentualOutros = " );
            sb.Append( _percentualOutros );
            sb.Append( "\n\tQuantidadeCenariosContingencia = " );
            sb.Append( _quantidadeCenariosContingencia );
            sb.Append( "\n\tTempoRodadaNaoHabilitada = " );
            sb.Append( _tempoRodadaNaoHabilitada );
            sb.Append( "\n\tTempoRodada = " );
            sb.Append( _tempoRodada );
            sb.Append( "\n\tTempoIntervaloRodada = " );
            sb.Append( _tempoIntervaloRodada );
            sb.Append( "\n\tPercentualPenalidade = " );
            sb.Append( _percentualPenalidade );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOParametroRodada) )
            {
                return false;
            }
            
            TOParametroRodada convertedParam = (TOParametroRodada) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoParametro
            if( !CodigoParametro.Equals( convertedParam.CodigoParametro ) )
            {
                return false;
            }
            
            // Compara o atributo TipoModoSimulacao
            if( !TipoModoSimulacao.Equals( convertedParam.TipoModoSimulacao ) )
            {
                return false;
            }
            
            // Compara o atributo IndicadorCenarioRandomico
            if( !IndicadorCenarioRandomico.Equals( convertedParam.IndicadorCenarioRandomico ) )
            {
                return false;
            }
            
            // Compara o atributo IndicadorAtivo
            if( !IndicadorAtivo.Equals( convertedParam.IndicadorAtivo ) )
            {
                return false;
            }
            
            // Compara o atributo PercentualAcao
            if( !PercentualAcao.Equals( convertedParam.PercentualAcao ) )
            {
                return false;
            }
            
            // Compara o atributo PercentualOutros
            if( !PercentualOutros.Equals( convertedParam.PercentualOutros ) )
            {
                return false;
            }
            
            // Compara o atributo QuantidadeCenariosContingencia
            if( !QuantidadeCenariosContingencia.Equals( convertedParam.QuantidadeCenariosContingencia ) )
            {
                return false;
            }
            
            // Compara o atributo TempoRodadaNaoHabilitada
            if( !TempoRodadaNaoHabilitada.Equals( convertedParam.TempoRodadaNaoHabilitada ) )
            {
                return false;
            }
            
            // Compara o atributo TempoRodada
            if( !TempoRodada.Equals( convertedParam.TempoRodada ) )
            {
                return false;
            }
            
            // Compara o atributo TempoIntervaloRodada
            if( !TempoIntervaloRodada.Equals( convertedParam.TempoIntervaloRodada ) )
            {
                return false;
            }
            
            // Compara o atributo PercentualPenalidade
            if( !PercentualPenalidade.Equals( convertedParam.PercentualPenalidade ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //ParametroRodada
}
