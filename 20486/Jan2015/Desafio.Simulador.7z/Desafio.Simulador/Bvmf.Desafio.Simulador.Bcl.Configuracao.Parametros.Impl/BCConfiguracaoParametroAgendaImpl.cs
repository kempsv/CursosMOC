﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Configuracao.Parametros.Entidade;
using Desafio.Simulador.Bcl.Configuracao.Parametros.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Parametros.Impl.Dao;

namespace Desafio.Simulador.Bcl.Configuracao.Parametros.Impl
{
    public class BCConfiguracaoParametroAgendaImpl : BCConfiguracaoParametroAgenda
    {
        public BCConfiguracaoParametroAgendaImpl(ParametroAgendaSimulacaoDAO persistence)
        {
            _persistence = persistence;
        }
    }
}
