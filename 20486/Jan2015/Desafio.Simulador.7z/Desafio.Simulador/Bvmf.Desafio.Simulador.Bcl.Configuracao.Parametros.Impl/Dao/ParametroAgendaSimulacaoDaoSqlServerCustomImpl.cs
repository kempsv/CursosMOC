﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Configuracao.Parametros.Entidade;
using Desafio.Simulador.Bcl.Core.Domain;
using System.Collections.Generic;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain.Enum;
using Desafio.Simulador.Util.Logger;
using System.Transactions;

namespace Desafio.Simulador.Bcl.Configuracao.Parametros.Impl.Dao
{
    public class ParametroAgendaSimulacaoDAOSqlServerCustomImpl : ParametroAgendaSimulacaoDAOSqlServerImpl
    {
        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "ParametroAgendaSimulacaoDAOSqlServerCustomImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<ParametrizacaoAgenda> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOParametroAgendaSimulacao> result = new List<TOParametroAgendaSimulacao>();
            TOParametroAgendaSimulacao transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBPARM_AGDA_SIMU.COD_PARM_AGDA_SIMU, TSDBPARM_AGDA_SIMU.COD_TIPO_MODO_SIMU, TSDBPARM_AGDA_SIMU.QTE_RDAD_SIMU, TSDBPARM_AGDA_SIMU.VAL_VARI_MAX_SIMU, TSDBPARM_AGDA_SIMU.VAL_MED_INIC_SIMU, TSDBPARM_AGDA_SIMU.QTE_MAX_TENT_CONG FROM TSDBPARM_AGDA_SIMU TSDBPARM_AGDA_SIMU WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {
                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOParametroAgendaSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoParametro = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.TipoModoSimulacao = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.QuantidadeRodadas = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.VariacaoMaximaSimulacao = dataReader.GetInt16(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.MediaInicialSimulacao = dataReader.GetInt16(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.MaximaTentativaContingencia = dataReader.GetInt32(5);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }
            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override ParametrizacaoAgenda FindByKey(int codigoParametro)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOParametroAgendaSimulacao transferObject = null;

            try
            {
                statement = "SELECT TSDBPARM_AGDA_SIMU.COD_PARM_AGDA_SIMU, TSDBPARM_AGDA_SIMU.COD_TIPO_MODO_SIMU, TSDBPARM_AGDA_SIMU.QTE_RDAD_SIMU, TSDBPARM_AGDA_SIMU.VAL_VARI_MAX_SIMU, TSDBPARM_AGDA_SIMU.VAL_MED_INIC_SIMU, TSDBPARM_AGDA_SIMU.QTE_MAX_TENT_CONG FROM TSDBPARM_AGDA_SIMU TSDBPARM_AGDA_SIMU WITH(NOLOCK) WHERE TSDBPARM_AGDA_SIMU.COD_PARM_AGDA_SIMU = @codigoParametro";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {

                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoParametro", codigoParametro));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOParametroAgendaSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoParametro = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.TipoModoSimulacao = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.QuantidadeRodadas = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.VariacaoMaximaSimulacao = dataReader.GetInt16(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.MediaInicialSimulacao = dataReader.GetInt16(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.MaximaTentativaContingencia = dataReader.GetInt32(5);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Remove uma entidade pela sua chave primária.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(ParametrizacaoAgenda entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOParametroAgendaSimulacao transferObject = TranslateToDTO(entity);

                statement = "DELETE FROM TSDBPARM_AGDA_SIMU WHERE COD_PARM_AGDA_SIMU = @codigoParametro";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave primária
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoParametro", transferObject.CodigoParametro));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma instância em memória na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(ParametrizacaoAgenda entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOParametroAgendaSimulacao transferObject = TranslateToDTO(entity);

                statement = "UPDATE TSDBPARM_AGDA_SIMU SET cOD_TIPO_MODO_SIMU = @tipoModoSimulacao, qTE_RDAD_SIMU = @quantidadeRodadas, vAL_VARI_MAX_SIMU = @variacaoMaximaSimulacao, vAL_MED_INIC_SIMU = @mediaInicialSimulacao, qTE_MAX_TENT_CONG = @maximaTentativaContingencia WHERE COD_PARM_AGDA_SIMU = @codigoParametro";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que não estão na chave
                            if (transferObject.TipoModoSimulacao == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@tipoModoSimulacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@tipoModoSimulacao", transferObject.TipoModoSimulacao));
                            }

                            if (transferObject.QuantidadeRodadas == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@quantidadeRodadas", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@quantidadeRodadas", transferObject.QuantidadeRodadas));
                            }

                            if (transferObject.VariacaoMaximaSimulacao == short.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@variacaoMaximaSimulacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@variacaoMaximaSimulacao", transferObject.VariacaoMaximaSimulacao));
                            }

                            if (transferObject.MediaInicialSimulacao == short.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@mediaInicialSimulacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@mediaInicialSimulacao", transferObject.MediaInicialSimulacao));
                            }

                            if (transferObject.MaximaTentativaContingencia == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@maximaTentativaContingencia", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@maximaTentativaContingencia", transferObject.MaximaTentativaContingencia));
                            }

                            // Chave primária
                            command.Parameters.Add(new SqlParameter("@codigoParametro", transferObject.CodigoParametro));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma instância em memória na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(ParametrizacaoAgenda entity)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                TOParametroAgendaSimulacao transferObject = TranslateToDTO(entity);

                statement = "INSERT INTO TSDBPARM_AGDA_SIMU ( COD_TIPO_MODO_SIMU, QTE_RDAD_SIMU, VAL_VARI_MAX_SIMU, VAL_MED_INIC_SIMU, QTE_MAX_TENT_CONG ) VALUES ( @tipoModoSimulacao, @quantidadeRodadas, @variacaoMaximaSimulacao, @mediaInicialSimulacao, @maximaTentativaContingencia )  ; SELECT SCOPE_IDENTITY();";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.TipoModoSimulacao == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@tipoModoSimulacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@tipoModoSimulacao", transferObject.TipoModoSimulacao));
                            }

                            if (transferObject.QuantidadeRodadas == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@quantidadeRodadas", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@quantidadeRodadas", transferObject.QuantidadeRodadas));
                            }

                            if (transferObject.VariacaoMaximaSimulacao == short.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@variacaoMaximaSimulacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@variacaoMaximaSimulacao", transferObject.VariacaoMaximaSimulacao));
                            }

                            if (transferObject.MediaInicialSimulacao == short.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@mediaInicialSimulacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@mediaInicialSimulacao", transferObject.MediaInicialSimulacao));
                            }

                            if (transferObject.MaximaTentativaContingencia == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@maximaTentativaContingencia", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@maximaTentativaContingencia", transferObject.MaximaTentativaContingencia));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            entity.Codigo = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        protected override List<ParametrizacaoAgenda> TranslateFromDTO(List<TOParametroAgendaSimulacao> entityDTO)
        {
            List<ParametrizacaoAgenda> _listaRetorno = new List<ParametrizacaoAgenda>();

            entityDTO.ForEach(delegate(TOParametroAgendaSimulacao item)
            {
                _listaRetorno.Add(this.TranslateFromDTO(item));
            });

            return _listaRetorno;
        }

        protected override ParametrizacaoAgenda TranslateFromDTO(TOParametroAgendaSimulacao entityDTO)
        {
            return new ParametrizacaoAgenda()
            {
                Codigo = entityDTO.CodigoParametro,
                QuantidadeRodadas = entityDTO.QuantidadeRodadas,
                TipoModoSimulacao = entityDTO.TipoModoSimulacao == 1 ? TipoModoSimulacao.Web : TipoModoSimulacao.Presencial,
                MediaInicialSimulacao = entityDTO.MediaInicialSimulacao,
                VariacaoMaximaSimulacao = entityDTO.VariacaoMaximaSimulacao,
                MaximaTentativaContigencia = entityDTO.MaximaTentativaContingencia
            };
        }

        protected override List<TOParametroAgendaSimulacao> TranslateToDTO(List<ParametrizacaoAgenda> entity)
        {
            List<TOParametroAgendaSimulacao> _listaRetorno = new List<TOParametroAgendaSimulacao>();

            entity.ForEach(delegate(ParametrizacaoAgenda item)
            {
                _listaRetorno.Add(this.TranslateToDTO(item));
            });

            return _listaRetorno;
        }

        protected override TOParametroAgendaSimulacao TranslateToDTO(ParametrizacaoAgenda entity)
        {
            return new TOParametroAgendaSimulacao()
            {
                CodigoParametro = entity.Codigo,
                QuantidadeRodadas = entity.QuantidadeRodadas,
                TipoModoSimulacao = entity.TipoModoSimulacao == TipoModoSimulacao.Web ? 1 : 2,
                MediaInicialSimulacao = entity.MediaInicialSimulacao,
                VariacaoMaximaSimulacao = entity.VariacaoMaximaSimulacao,
                MaximaTentativaContingencia = entity.MaximaTentativaContigencia
            };
        }
    }
}
