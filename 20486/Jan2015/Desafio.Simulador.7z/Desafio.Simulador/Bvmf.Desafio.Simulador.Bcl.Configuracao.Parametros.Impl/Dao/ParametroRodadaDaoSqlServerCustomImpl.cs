﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Configuracao.Parametros.Entidade;
using Desafio.Simulador.Bcl.Core.Domain;
using System.Collections.Generic;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain.Enum;
using System.Transactions;
using Desafio.Simulador.Util.Logger;


namespace Desafio.Simulador.Bcl.Configuracao.Parametros.Impl.Dao
{
    public class ParametroRodadaDAOSqlServerCustomImpl : ParametroRodadaDAOSqlServerImpl
    {
        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "ParametroRodadaDAOSqlServerCustomImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<ParametrizacaoRodada> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOParametroRodada> result = new List<TOParametroRodada>();
            TOParametroRodada transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBPARM_RDAD.COD_PARM_RDAD, TSDBPARM_RDAD.COD_TIPO_MODO_SIMU, TSDBPARM_RDAD.IND_CENA_RDOM, TSDBPARM_RDAD.IND_PARM_ATIV, TSDBPARM_RDAD.PERC_MINI_ACAO, TSDBPARM_RDAD.PERC_MINI_OUTR_INVE, TSDBPARM_RDAD.QTE_CENA_CONG, TSDBPARM_RDAD.TEM_RDAD_NAO_HAB, TSDBPARM_RDAD.TEM_RDAD, TSDBPARM_RDAD.TEM_INTV_RDAD, TSDBPARM_RDAD.PERC_PENA FROM TSDBPARM_RDAD TSDBPARM_RDAD WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Configuracao.Parametros.Entidade.TOParametroRodada();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoParametro = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.TipoModoSimulacao = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.IndicadorCenarioRandomico = dataReader.GetBoolean(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.IndicadorAtivo = dataReader.GetBoolean(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.PercentualAcao = dataReader.GetDecimal(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.PercentualOutros = dataReader.GetDecimal(5);
                                    }
                                    if (!dataReader.IsDBNull(6))
                                    {
                                        transferObject.QuantidadeCenariosContingencia = dataReader.GetInt32(6);
                                    }
                                    if (!dataReader.IsDBNull(7))
                                    {
                                        transferObject.TempoRodadaNaoHabilitada = dataReader.GetString(7);
                                    }
                                    if (!dataReader.IsDBNull(8))
                                    {
                                        transferObject.TempoRodada = dataReader.GetInt32(8);
                                    }
                                    if (!dataReader.IsDBNull(9))
                                    {
                                        transferObject.TempoIntervaloRodada = dataReader.GetInt32(9);
                                    }
                                    if (!dataReader.IsDBNull(10))
                                    {
                                        transferObject.PercentualPenalidade = dataReader.GetDecimal(10);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override ParametrizacaoRodada FindByKey(int codigoParametro)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOParametroRodada transferObject = null;

            try
            {
                statement = "SELECT TSDBPARM_RDAD.COD_PARM_RDAD, TSDBPARM_RDAD.COD_TIPO_MODO_SIMU, TSDBPARM_RDAD.IND_CENA_RDOM, TSDBPARM_RDAD.IND_PARM_ATIV, TSDBPARM_RDAD.PERC_MINI_ACAO, TSDBPARM_RDAD.PERC_MINI_OUTR_INVE, TSDBPARM_RDAD.QTE_CENA_CONG, TSDBPARM_RDAD.TEM_RDAD_NAO_HAB, TSDBPARM_RDAD.TEM_RDAD, TSDBPARM_RDAD.TEM_INTV_RDAD, TSDBPARM_RDAD.PERC_PENA FROM TSDBPARM_RDAD TSDBPARM_RDAD WITH(NOLOCK) WHERE TSDBPARM_RDAD.COD_PARM_RDAD = @codigoParametro";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoParametro", codigoParametro));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Configuracao.Parametros.Entidade.TOParametroRodada();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoParametro = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.TipoModoSimulacao = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.IndicadorCenarioRandomico = dataReader.GetBoolean(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.IndicadorAtivo = dataReader.GetBoolean(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.PercentualAcao = dataReader.GetDecimal(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.PercentualOutros = dataReader.GetDecimal(5);
                                    }
                                    if (!dataReader.IsDBNull(6))
                                    {
                                        transferObject.QuantidadeCenariosContingencia = dataReader.GetInt32(6);
                                    }
                                    if (!dataReader.IsDBNull(7))
                                    {
                                        transferObject.TempoRodadaNaoHabilitada = dataReader.GetString(7);
                                    }
                                    if (!dataReader.IsDBNull(8))
                                    {
                                        transferObject.TempoRodada = dataReader.GetInt32(8);
                                    }
                                    if (!dataReader.IsDBNull(9))
                                    {
                                        transferObject.TempoIntervaloRodada = dataReader.GetInt32(9);
                                    }
                                    if (!dataReader.IsDBNull(10))
                                    {
                                        transferObject.PercentualPenalidade = dataReader.GetDecimal(10);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Remove uma entidade pela sua chave primária.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(ParametrizacaoRodada entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOParametroRodada transferObject = TranslateToDTO(entity);

                statement = "DELETE FROM TSDBPARM_RDAD WHERE COD_PARM_RDAD = @codigoParametro";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave primária
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoParametro", transferObject.CodigoParametro));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma instância em memória na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(ParametrizacaoRodada entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOParametroRodada transferObject = TranslateToDTO(entity);

                statement = "UPDATE TSDBPARM_RDAD SET cOD_TIPO_MODO_SIMU = @tipoModoSimulacao, iND_CENA_RDOM = @indicadorCenarioRandomico, iND_PARM_ATIV = @indicadorAtivo, pERC_MINI_ACAO = @percentualAcao, pERC_MINI_OUTR_INVE = @percentualOutros, qTE_CENA_CONG = @quantidadeCenariosContingencia, tEM_RDAD_NAO_HAB = @tempoRodadaNaoHabilitada, tEM_RDAD = @tempoRodada, tEM_INTV_RDAD = @tempoIntervaloRodada, pERC_PENA = @percentualPenalidade WHERE COD_PARM_RDAD = @codigoParametro";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que não estão na chave
                            if (transferObject.TipoModoSimulacao == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@tipoModoSimulacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@tipoModoSimulacao", transferObject.TipoModoSimulacao));
                            }

                            command.Parameters.Add(new SqlParameter("@indicadorCenarioRandomico", transferObject.IndicadorCenarioRandomico));

                            command.Parameters.Add(new SqlParameter("@indicadorAtivo", transferObject.IndicadorAtivo));

                            if (transferObject.PercentualAcao == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@percentualAcao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@percentualAcao", transferObject.PercentualAcao));
                            }

                            if (transferObject.PercentualOutros == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@percentualOutros", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@percentualOutros", transferObject.PercentualOutros));
                            }

                            if (transferObject.QuantidadeCenariosContingencia == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@quantidadeCenariosContingencia", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@quantidadeCenariosContingencia", transferObject.QuantidadeCenariosContingencia));
                            }

                            if (transferObject.TempoRodadaNaoHabilitada == null)
                            {
                                command.Parameters.Add(new SqlParameter("@tempoRodadaNaoHabilitada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@tempoRodadaNaoHabilitada", transferObject.TempoRodadaNaoHabilitada));
                            }

                            if (transferObject.TempoRodada == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@tempoRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@tempoRodada", transferObject.TempoRodada));
                            }

                            if (transferObject.TempoIntervaloRodada == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@tempoIntervaloRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@tempoIntervaloRodada", transferObject.TempoIntervaloRodada));
                            }

                            if (transferObject.PercentualPenalidade == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@percentualPenalidade", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@percentualPenalidade", transferObject.PercentualPenalidade));
                            }

                            // Chave primária
                            command.Parameters.Add(new SqlParameter("@codigoParametro", transferObject.CodigoParametro));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma instância em memória na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(ParametrizacaoRodada entity)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                TOParametroRodada transferObject = TranslateToDTO(entity);

                statement = "INSERT INTO TSDBPARM_RDAD ( COD_TIPO_MODO_SIMU, IND_CENA_RDOM, IND_PARM_ATIV, PERC_MINI_ACAO, PERC_MINI_OUTR_INVE, QTE_CENA_CONG, TEM_RDAD_NAO_HAB, TEM_RDAD, TEM_INTV_RDAD, PERC_PENA ) VALUES ( @tipoModoSimulacao, @indicadorCenarioRandomico, @indicadorAtivo, @percentualAcao, @percentualOutros, @quantidadeCenariosContingencia, @tempoRodadaNaoHabilitada, @tempoRodada, @tempoIntervaloRodada, @percentualPenalidade )  ; SELECT SCOPE_IDENTITY();";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.TipoModoSimulacao == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@tipoModoSimulacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@tipoModoSimulacao", transferObject.TipoModoSimulacao));
                            }

                            command.Parameters.Add(new SqlParameter("@indicadorCenarioRandomico", transferObject.IndicadorCenarioRandomico));

                            command.Parameters.Add(new SqlParameter("@indicadorAtivo", transferObject.IndicadorAtivo));

                            if (transferObject.PercentualAcao == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@percentualAcao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@percentualAcao", transferObject.PercentualAcao));
                            }

                            if (transferObject.PercentualOutros == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@percentualOutros", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@percentualOutros", transferObject.PercentualOutros));
                            }

                            if (transferObject.QuantidadeCenariosContingencia == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@quantidadeCenariosContingencia", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@quantidadeCenariosContingencia", transferObject.QuantidadeCenariosContingencia));
                            }

                            if (transferObject.TempoRodadaNaoHabilitada == null)
                            {
                                command.Parameters.Add(new SqlParameter("@tempoRodadaNaoHabilitada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@tempoRodadaNaoHabilitada", transferObject.TempoRodadaNaoHabilitada));
                            }

                            if (transferObject.TempoRodada == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@tempoRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@tempoRodada", transferObject.TempoRodada));
                            }

                            if (transferObject.TempoIntervaloRodada == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@tempoIntervaloRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@tempoIntervaloRodada", transferObject.TempoIntervaloRodada));
                            }

                            if (transferObject.PercentualPenalidade == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@percentualPenalidade", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@percentualPenalidade", transferObject.PercentualPenalidade));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            entity.Codigo = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        protected override List<ParametrizacaoRodada> TranslateFromDTO(List<TOParametroRodada> entityDTO)
        {
            List<ParametrizacaoRodada> _listaRetorno = new List<ParametrizacaoRodada>();

            entityDTO.ForEach(delegate(TOParametroRodada item)
            {
                _listaRetorno.Add(this.TranslateFromDTO(item));
            });

            return _listaRetorno;
        }

        protected override ParametrizacaoRodada TranslateFromDTO(TOParametroRodada entityDTO)
        {
            return new ParametrizacaoRodada()
            {
                Codigo = entityDTO.CodigoParametro,
                DataCriacao = DateTime.Now,
                IndicadorCenarioRandomico = entityDTO.IndicadorCenarioRandomico,
                IndicadorParametroAtivo = entityDTO.IndicadorAtivo,
                QuantidadeCenariosContingencia = entityDTO.QuantidadeCenariosContingencia,
                TempoRodada = entityDTO.TempoRodada,
                TempoIntervaloRodadas = entityDTO.TempoIntervaloRodada,
                TempoTelaInicialRodada = Convert.ToInt32(entityDTO.TempoRodadaNaoHabilitada),
                TipoModoSimulacao = entityDTO.TipoModoSimulacao == 1 ? TipoModoSimulacao.Web : TipoModoSimulacao.Presencial,
                ValorPercentualMinimoAcoes = entityDTO.PercentualAcao,
                ValorPercentualMinimoOutros = entityDTO.PercentualOutros,
                ValorPercentualOscilacao = 0M,
                ValorPercentualPenalidadeRodada = entityDTO.PercentualPenalidade
            };
        }

        protected override List<TOParametroRodada> TranslateToDTO(List<ParametrizacaoRodada> entity)
        {
            List<TOParametroRodada> _listaRetorno = new List<TOParametroRodada>();

            entity.ForEach(delegate(ParametrizacaoRodada item)
            {
                _listaRetorno.Add(this.TranslateToDTO(item));
            });

            return _listaRetorno;
        }

        protected override TOParametroRodada TranslateToDTO(ParametrizacaoRodada entity)
        {
            return new TOParametroRodada()
            {
                CodigoParametro = entity.Codigo,
                IndicadorAtivo = entity.IndicadorParametroAtivo,
                IndicadorCenarioRandomico = entity.IndicadorCenarioRandomico,
                PercentualAcao = entity.ValorPercentualMinimoAcoes,
                PercentualOutros = entity.ValorPercentualMinimoOutros,
                QuantidadeCenariosContingencia = entity.QuantidadeCenariosContingencia,
                TempoRodada = entity.TempoRodada,
                TipoModoSimulacao = entity.TipoModoSimulacao == TipoModoSimulacao.Web ? 1 : 2,
                PercentualPenalidade = entity.ValorPercentualPenalidadeRodada,
                TempoIntervaloRodada = entity.TempoIntervaloRodadas,
                TempoRodadaNaoHabilitada = entity.TempoTelaInicialRodada.ToString()
            };
        }
    }
}
