using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Configuracao.Rodada.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TORodadaSimulacao
    {
        // Declara��o de atributos
        private int _codigoRodada;
        private int _codigoParametroRodada;
        private string _nomeRodada;
        private DateTime _dataCriacaoRodada;
        private short _identificadorRodada;
        
        public int CodigoRodada
        {
            get
            {
                return _codigoRodada;
            }
            set
            {
                _codigoRodada = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoParametroRodada
        {
            get
            {
                return _codigoParametroRodada;
            }
            set
            {
                _codigoParametroRodada = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NomeRodada
        {
            get
            {
                return _nomeRodada;
            }
            set
            {
                _nomeRodada = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public DateTime DataCriacaoRodada
        {
            get
            {
                return _dataCriacaoRodada;
            }
            set
            {
                _dataCriacaoRodada = value;
            }
        }
        
        public short IdentificadorRodada
        {
            get
            {
                return _identificadorRodada;
            }
            set
            {
                _identificadorRodada = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TORodadaSimulacao()
        {
            _codigoRodada = int.MinValue;
            _codigoParametroRodada = int.MinValue;
            _nomeRodada = null;
            _dataCriacaoRodada = DateTime.MinValue;
            _identificadorRodada = short.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TORodadaSimulacao" );
            sb.Append( "\n\tCodigoRodada = " );
            sb.Append( _codigoRodada );
            sb.Append( "\n\tCodigoParametroRodada = " );
            sb.Append( _codigoParametroRodada );
            sb.Append( "\n\tNomeRodada = " );
            sb.Append( _nomeRodada );
            sb.Append( "\n\tDataCriacaoRodada = " );
            sb.Append( _dataCriacaoRodada );
            sb.Append( "\n\tIdentificadorRodada = " );
            sb.Append( _identificadorRodada );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TORodadaSimulacao) )
            {
                return false;
            }
            
            TORodadaSimulacao convertedParam = (TORodadaSimulacao) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoRodada
            if( !CodigoRodada.Equals( convertedParam.CodigoRodada ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoParametroRodada
            if( !CodigoParametroRodada.Equals( convertedParam.CodigoParametroRodada ) )
            {
                return false;
            }
            
            // Compara o atributo NomeRodada
            if( !NomeRodada.Equals( convertedParam.NomeRodada ) )
            {
                return false;
            }
            
            // Compara o atributo DataCriacaoRodada
            if( !DataCriacaoRodada.Equals( convertedParam.DataCriacaoRodada ) )
            {
                return false;
            }
            
            // Compara o atributo IdentificadorRodada
            if( !IdentificadorRodada.Equals( convertedParam.IdentificadorRodada ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //RodadaSimulacao
}
