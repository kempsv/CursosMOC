﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Configuracao.Rodada.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Microsoft.Practices.Unity;
using Desafio.Simulador.Bcl.Configuracao.Parametros.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Cenario.Interfaces;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bcl.Configuracao.Rodada.Impl.Dao;
using Desafio.Simulador.Bcl.Configuracao.Rodada.Entidade;
using Desafio.Simulador.Bcl.Core.Domain.Enum;

namespace Desafio.Simulador.Bcl.Configuracao.Rodada.Impl
{
    public class BCConfiguracaoRodadaImpl : BCConfiguracaoRodada
    {
        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCConfiguracaoParametroRodada BCConfiguracaoParametroRodada { get; set; }

        public BCConfiguracaoRodadaImpl(RodadaSimulacaoDAO persistence)
        {
            _persistence = persistence;
        }

        public override void GerarRodadasSimulacao(int quantidadeRodadas, out List<RodadaSimulacao> rodadasSimulacaoGeradas)
        {
            
            //
            //Variável de retorno do método
            //
            rodadasSimulacaoGeradas = new List<RodadaSimulacao>();

            //
            //Obtêm o parâmetro para as Rodadas
            //
            var _paramRodada = this.BCConfiguracaoParametroRodada.FindAll().Where(pr => pr.TipoModoSimulacao == TipoModoSimulacao.Web).First<ParametrizacaoRodada>();

            //
            //Gera as Rodadas de Simulação
            //
            for (int count = 0; count < quantidadeRodadas; count++)
            {
                var _rodada = new RodadaSimulacao()
                {
                    DataHoraCriacao = DateTime.Now,
                    IdentificadorRodada = Convert.ToInt16(count + 1),
                    Nome = "Rodada " + Convert.ToInt16(count + 1).ToString(),
                    ParametrizacaoRodada = _paramRodada
                };
                Create(_rodada);
                rodadasSimulacaoGeradas.Add(_rodada);
            }
        }

        public override RodadaSimulacao FindByKey(int key)
        {
            var _rodadaSimulacao = base.FindByKey(key);

            _rodadaSimulacao.ParametrizacaoRodada = this.BCConfiguracaoParametroRodada.FindByKey(_rodadaSimulacao.ParametrizacaoRodada.Codigo);

            return _rodadaSimulacao;
        }
    }
}
