using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Configuracao.Rodada.Entidade;
using System.Collections.Generic;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Configuracao.Rodada.Impl.Dao
{

    /// <summary>
    /// Implementa��o de RodadaSimulacaoDAO - SqlServer
    /// </summary>
    public class RodadaSimulacaoDAOSqlServerCustomImpl : RodadaSimulacaoDAOSqlServerImpl
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "RodadaSimulacaoDAOSqlServerCustomImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<RodadaSimulacao> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TORodadaSimulacao> result = new List<TORodadaSimulacao>();
            TORodadaSimulacao transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBRDAD.COD_RDAD, TSDBRDAD.COD_PARM_RDAD, TSDBRDAD.NOME_RDAD, TSDBRDAD.TMST_CRIA_RDAD, TSDBRDAD.NUM_ORDE_RDAD FROM TSDBRDAD TSDBRDAD WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Configuracao.Rodada.Entidade.TORodadaSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoRodada = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoParametroRodada = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.NomeRodada = dataReader.GetString(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.DataCriacaoRodada = dataReader.GetDateTime(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.IdentificadorRodada = dataReader.GetInt16(4);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override RodadaSimulacao FindByKey(int codigoRodada)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TORodadaSimulacao transferObject = null;

            try
            {
                statement = "SELECT TSDBRDAD.COD_RDAD, TSDBRDAD.COD_PARM_RDAD, TSDBRDAD.NOME_RDAD, TSDBRDAD.TMST_CRIA_RDAD, TSDBRDAD.NUM_ORDE_RDAD FROM TSDBRDAD TSDBRDAD WITH(NOLOCK) WHERE TSDBRDAD.COD_RDAD = @codigoRodada";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoRodada", codigoRodada));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Configuracao.Rodada.Entidade.TORodadaSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoRodada = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoParametroRodada = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.NomeRodada = dataReader.GetString(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.DataCriacaoRodada = dataReader.GetDateTime(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.IdentificadorRodada = dataReader.GetInt16(4);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Remove uma entidade pela sua chave prim�ria.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(RodadaSimulacao entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TORodadaSimulacao transferObject = TranslateToDTO(entity);

                statement = "DELETE FROM TSDBRDAD WHERE COD_RDAD = @codigoRodada";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave prim�ria
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoRodada", transferObject.CodigoRodada));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma inst�ncia em mem�ria na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(RodadaSimulacao entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TORodadaSimulacao transferObject = TranslateToDTO(entity);

                statement = "UPDATE TSDBRDAD SET cOD_PARM_RDAD = @codigoParametroRodada, nOME_RDAD = @nomeRodada, tMST_CRIA_RDAD = @dataCriacaoRodada, nUM_ORDE_RDAD = @identificadorRodada WHERE COD_RDAD = @codigoRodada";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que n�o est�o na chave
                            if (transferObject.CodigoParametroRodada == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoParametroRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoParametroRodada", transferObject.CodigoParametroRodada));
                            }

                            if (transferObject.NomeRodada == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeRodada", transferObject.NomeRodada));
                            }

                            if (transferObject.DataCriacaoRodada == DateTime.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@dataCriacaoRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@dataCriacaoRodada", transferObject.DataCriacaoRodada));
                            }

                            if (transferObject.IdentificadorRodada == short.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@identificadorRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@identificadorRodada", transferObject.IdentificadorRodada));
                            }

                            // Chave prim�ria
                            command.Parameters.Add(new SqlParameter("@codigoRodada", transferObject.CodigoRodada));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(RodadaSimulacao entity)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                TORodadaSimulacao transferObject = TranslateToDTO(entity);

                statement = "INSERT INTO TSDBRDAD ( COD_PARM_RDAD, NOME_RDAD, TMST_CRIA_RDAD, NUM_ORDE_RDAD ) VALUES ( @codigoParametroRodada, @nomeRodada, @dataCriacaoRodada, @identificadorRodada )  ; SELECT SCOPE_IDENTITY();";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoParametroRodada == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoParametroRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoParametroRodada", transferObject.CodigoParametroRodada));
                            }

                            if (transferObject.NomeRodada == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeRodada", transferObject.NomeRodada));
                            }

                            if (transferObject.DataCriacaoRodada == DateTime.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@dataCriacaoRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@dataCriacaoRodada", transferObject.DataCriacaoRodada));
                            }

                            if (transferObject.IdentificadorRodada == short.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@identificadorRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@identificadorRodada", transferObject.IdentificadorRodada));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            entity.Codigo = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        protected override List<RodadaSimulacao> TranslateFromDTO(List<TORodadaSimulacao> entityDTO)
        {
            var _lista = new List<RodadaSimulacao>();
            foreach (TORodadaSimulacao et in entityDTO)
            {
                _lista.Add(TranslateFromDTO(et));
            }
            return _lista;
        }

        protected override RodadaSimulacao TranslateFromDTO(TORodadaSimulacao entityDTO)
        {
            return new RodadaSimulacao()
            {
                Codigo = entityDTO.CodigoRodada,
                Nome = entityDTO.NomeRodada,
                DataHoraCriacao = entityDTO.DataCriacaoRodada,
                IdentificadorRodada = entityDTO.IdentificadorRodada,
                ParametrizacaoRodada = new ParametrizacaoRodada() { Codigo = entityDTO.CodigoParametroRodada }
            };
        }

        protected override List<TORodadaSimulacao> TranslateToDTO(List<RodadaSimulacao> entity)
        {
            var _lista = new List<TORodadaSimulacao>();
            foreach (RodadaSimulacao et in entity)
            {
                _lista.Add(TranslateToDTO(et));
            }
            return _lista;
        }

        protected override TORodadaSimulacao TranslateToDTO(RodadaSimulacao entity)
        {
            return new TORodadaSimulacao()
            {
                IdentificadorRodada = entity.IdentificadorRodada,
                CodigoParametroRodada = entity.ParametrizacaoRodada.Codigo,
                CodigoRodada = entity.Codigo,
                DataCriacaoRodada = entity.DataHoraCriacao,
                NomeRodada = entity.Nome
            };
        }

    } //RodadaSimulacao
}
