using System;
using System.Configuration;
//using Framework.AcessoDados;

namespace Desafio.Simulador.Bcl.Configuracao.Rodada.Impl.Dao
{
    
    /// <summary>
    /// Implementa��o de RodadaSimulacaoDAO - SqlServer
    /// </summary>
    public abstract class RodadaSimulacaoDAOSqlServerImpl : RodadaSimulacaoDAO
    {
       
        
    } //RodadaSimulacao
}
