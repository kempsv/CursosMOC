﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Core.Domain.Enum;
using Desafio.Simulador.Bcl.Configuracao.Rodada.Entidade;

namespace Desafio.Simulador.Bcl.Configuracao.Rodada.Interfaces
{
    public abstract class BCConfiguracaoRodada : BCEntityPersistence<RodadaSimulacao, TORodadaSimulacao>
    {
        public abstract void GerarRodadasSimulacao(int quantidadeRodadas, out List<RodadaSimulacao> rodadasSimulacaoGeradas);
    }
}
