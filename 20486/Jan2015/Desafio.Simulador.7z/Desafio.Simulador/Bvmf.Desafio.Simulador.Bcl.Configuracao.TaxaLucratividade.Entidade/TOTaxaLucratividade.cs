using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Configuracao.TaxaLucratividade.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOTaxaLucratividade
    {
        // Declara��o de atributos
        private int _codigoCenario;
        private int _codigoPapel;
        private decimal _valorPercentualLucratividade;
        private decimal _percentualOscilacao;
        
        public int CodigoCenario
        {
            get
            {
                return _codigoCenario;
            }
            set
            {
                _codigoCenario = value;
            }
        }
        
        public int CodigoPapel
        {
            get
            {
                return _codigoPapel;
            }
            set
            {
                _codigoPapel = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal ValorPercentualLucratividade
        {
            get
            {
                return _valorPercentualLucratividade;
            }
            set
            {
                _valorPercentualLucratividade = value;
            }
        }
        
        public decimal PercentualOscilacao
        {
            get
            {
                return _percentualOscilacao;
            }
            set
            {
                _percentualOscilacao = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOTaxaLucratividade()
        {
            _codigoCenario = int.MinValue;
            _codigoPapel = int.MinValue;
            _valorPercentualLucratividade = decimal.MinValue;
            _percentualOscilacao = decimal.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOTaxaLucratividade" );
            sb.Append( "\n\tCodigoCenario = " );
            sb.Append( _codigoCenario );
            sb.Append( "\n\tCodigoPapel = " );
            sb.Append( _codigoPapel );
            sb.Append( "\n\tValorPercentualLucratividade = " );
            sb.Append( _valorPercentualLucratividade );
            sb.Append( "\n\tPercentualOscilacao = " );
            sb.Append( _percentualOscilacao );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOTaxaLucratividade) )
            {
                return false;
            }
            
            TOTaxaLucratividade convertedParam = (TOTaxaLucratividade) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoCenario
            if( !CodigoCenario.Equals( convertedParam.CodigoCenario ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoPapel
            if( !CodigoPapel.Equals( convertedParam.CodigoPapel ) )
            {
                return false;
            }
            
            // Compara o atributo ValorPercentualLucratividade
            if( !ValorPercentualLucratividade.Equals( convertedParam.ValorPercentualLucratividade ) )
            {
                return false;
            }
            
            // Compara o atributo PercentualOscilacao
            if( !PercentualOscilacao.Equals( convertedParam.PercentualOscilacao ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //TaxaLucratividade
}
