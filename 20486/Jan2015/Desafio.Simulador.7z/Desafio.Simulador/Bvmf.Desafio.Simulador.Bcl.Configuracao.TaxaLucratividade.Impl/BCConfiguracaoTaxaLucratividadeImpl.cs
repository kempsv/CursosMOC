﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Configuracao.TaxaLucratividade.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.TaxaLucratividade.Impl.Dao;
using Desafio.Simulador.Bcl.Configuracao.TaxaLucratividade.Entidade;
using Desafio.Simulador.Bcl.Configuracao.Cenario.Interfaces;
using Microsoft.Practices.Unity;
using Desafio.Simulador.Bcl.Configuracao.Papel.Interfaces;

namespace Desafio.Simulador.Bcl.Configuracao.TaxaLucratividade.Impl
{
    public class BCConfiguracaoTaxaLucratividadeImpl : BCConfiguracaoTaxaLucratividade
    {
        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCConfiguracaoCenarios BCConfiguracaoCenarios { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCConfiguracaoPapel BCConfiguracaoPapel { get; set; }

        public BCConfiguracaoTaxaLucratividadeImpl(TaxaLucratividadeDAO persistence)
        {
            _persistence = persistence;
        }

        private void AtualizarRentabilidadeMediaCenario(TaxaLucratividadeCenario entity)
        {
            var _listaTaxas = ((TaxaLucratividadeDAO)_persistence).FindAll();

            var _taxasCenario = _listaTaxas.Where(tx => tx.CenarioSimulacao.Codigo == entity.CenarioSimulacao.Codigo);
            
            if (_taxasCenario.Count<TaxaLucratividadeCenario>() == 0)
            {
                this.BCConfiguracaoCenarios.ZerarRentabilidadeMedia(entity.CenarioSimulacao);
            }
            else
                this.BCConfiguracaoCenarios.DefinirRentabilidadeMedia(_taxasCenario);
        }

        public override void Create(TaxaLucratividadeCenario entity)
        {
            base.Create(entity);

            this.AtualizarRentabilidadeMediaCenario(entity);
        }


        public override void Update(TaxaLucratividadeCenario entity)
        {
            base.Update(entity);

            this.AtualizarRentabilidadeMediaCenario(entity);
        }

        public override void Delete(TaxaLucratividadeCenario entity)
        {
            base.Delete(entity);

            this.AtualizarRentabilidadeMediaCenario(entity);
        }

        public override List<TaxaLucratividadeCenario> ListarTaxasByCenario(int codigoCenario)
        {
            var _taxasCadastradas = this.FindAll();
            
            var _taxasCenarios = _taxasCadastradas.Where(tx => tx.CenarioSimulacao.Codigo == codigoCenario).ToList<TaxaLucratividadeCenario>();

            return _taxasCenarios;
        }

        public override List<TaxaLucratividadeCenario> FindAll()
        {
            var _taxas = base.FindAll();

            BCConfiguracaoCenarios.LazyData = true;
            foreach (TaxaLucratividadeCenario taxa in _taxas) 
            {
                taxa.CenarioSimulacao = BCConfiguracaoCenarios.FindByKey(taxa.CenarioSimulacao.Codigo);
                taxa.PapelCarteira = BCConfiguracaoPapel.FindByKey(taxa.PapelCarteira.Codigo);
            }

            return _taxas;
        }
    }
}
