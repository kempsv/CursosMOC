﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;

using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Configuracao.TaxaLucratividade.Entidade;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Configuracao.TaxaLucratividade.Impl.Dao
{
    public class TaxaLucratividadeDAOSqlServerCustomImpl : TaxaLucratividadeDAOSqlServerImpl
    {
        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "TaxaLucratividadeDaoSqlServerCustomImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TaxaLucratividadeCenario> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOTaxaLucratividade> result = new List<TOTaxaLucratividade>();
            TOTaxaLucratividade transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBTAXA_LUCT.COD_CENA, TSDBTAXA_LUCT.COD_PAP, TSDBTAXA_LUCT.PERC_TAXA_LUCT_PAP, TSDBTAXA_LUCT.PERC_OSCI FROM TSDBTAXA_LUCT TSDBTAXA_LUCT WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Configuracao.TaxaLucratividade.Entidade.TOTaxaLucratividade();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCenario = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoPapel = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.ValorPercentualLucratividade = dataReader.GetDecimal(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.PercentualOscilacao = dataReader.GetDecimal(3);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TaxaLucratividadeCenario FindByKey(int codigoCenario, int codigoPapel)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOTaxaLucratividade transferObject = null;

            try
            {
                statement = "SELECT TSDBTAXA_LUCT.COD_CENA, TSDBTAXA_LUCT.COD_PAP, TSDBTAXA_LUCT.PERC_TAXA_LUCT_PAP, TSDBTAXA_LUCT.PERC_OSCI FROM TSDBTAXA_LUCT TSDBTAXA_LUCT WITH(NOLOCK) WHERE TSDBTAXA_LUCT.COD_CENA = @codigoCenario AND TSDBTAXA_LUCT.COD_PAP = @codigoPapel";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoCenario", codigoCenario));

                                command.Parameters.Add(new SqlParameter("@codigoPapel", codigoPapel));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new Desafio.Simulador.Bcl.Configuracao.TaxaLucratividade.Entidade.TOTaxaLucratividade();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCenario = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoPapel = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.ValorPercentualLucratividade = dataReader.GetDecimal(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.PercentualOscilacao = dataReader.GetDecimal(3);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(transferObject);
        }

        public override TaxaLucratividadeCenario FindByKey(int key)
        {
            throw new NotImplementedException("Não há implementação desse método");
        }

        /// <summary>
        /// Remove uma entidade pela sua chave primária.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(TaxaLucratividadeCenario entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOTaxaLucratividade transferObject = TranslateToDTO(entity);

                statement = "DELETE FROM TSDBTAXA_LUCT WHERE COD_CENA = @codigoCenario AND COD_PAP = @codigoPapel";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave primária
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoCenario", transferObject.CodigoCenario));
                            command.Parameters.Add(new SqlParameter("@codigoPapel", transferObject.CodigoPapel));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma instância em memória na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(TaxaLucratividadeCenario entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOTaxaLucratividade transferObject = TranslateToDTO(entity);

                statement = "UPDATE TSDBTAXA_LUCT SET pERC_TAXA_LUCT_PAP = @valorPercentualLucratividade, pERC_OSCI = @percentualOscilacao WHERE COD_CENA = @codigoCenario AND COD_PAP = @codigoPapel";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que não estão na chave
                            if (transferObject.ValorPercentualLucratividade == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorPercentualLucratividade", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorPercentualLucratividade", transferObject.ValorPercentualLucratividade));
                            }

                            if (transferObject.PercentualOscilacao == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@percentualOscilacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@percentualOscilacao", transferObject.PercentualOscilacao));
                            }

                            // Chave primária
                            command.Parameters.Add(new SqlParameter("@codigoCenario", transferObject.CodigoCenario));
                            command.Parameters.Add(new SqlParameter("@codigoPapel", transferObject.CodigoPapel));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma instância em memória na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TaxaLucratividadeCenario entity)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                TOTaxaLucratividade transferObject = TranslateToDTO(entity);

                statement = "INSERT INTO TSDBTAXA_LUCT ( COD_CENA, COD_PAP, PERC_TAXA_LUCT_PAP, PERC_OSCI ) VALUES ( @codigoCenario, @codigoPapel, @valorPercentualLucratividade, @percentualOscilacao ) ";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoCenario == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCenario", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCenario", transferObject.CodigoCenario));
                            }

                            if (transferObject.CodigoPapel == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoPapel", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoPapel", transferObject.CodigoPapel));
                            }

                            if (transferObject.ValorPercentualLucratividade == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorPercentualLucratividade", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorPercentualLucratividade", transferObject.ValorPercentualLucratividade));
                            }

                            if (transferObject.PercentualOscilacao == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@percentualOscilacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@percentualOscilacao", transferObject.PercentualOscilacao));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        protected override List<TaxaLucratividadeCenario> TranslateFromDTO(List<TOTaxaLucratividade> entityDTO)
        {
            var _returnEntities = new List<TaxaLucratividadeCenario>();

            foreach (TOTaxaLucratividade entity in entityDTO)
            {
                _returnEntities.Add(this.TranslateFromDTO(entity));
            }

            return _returnEntities;
        }

        protected override TaxaLucratividadeCenario TranslateFromDTO(TOTaxaLucratividade entityDTO)
        {
            var _returnEntity = new TaxaLucratividadeCenario
            {
                CenarioSimulacao = new CenarioSimulacao() { Codigo = entityDTO.CodigoCenario },
                PapelCarteira = new PapelCarteira() { Codigo = entityDTO.CodigoPapel },
                ValorPercentualLucratividade = entityDTO.ValorPercentualLucratividade,
                ValorPercentualOscilacao = entityDTO.PercentualOscilacao
            };
            return _returnEntity;
        }

        protected override List<TOTaxaLucratividade> TranslateToDTO(List<TaxaLucratividadeCenario> entity)
        {
            var _returnEntities = new List<TOTaxaLucratividade>();

            foreach (TaxaLucratividadeCenario et in entity)
            {
                _returnEntities.Add(this.TranslateToDTO(et));
            }
            return _returnEntities;
        }

        protected override TOTaxaLucratividade TranslateToDTO(TaxaLucratividadeCenario entity)
        {
            var _returnEntity = new TOTaxaLucratividade
            {
                CodigoCenario = entity.CenarioSimulacao.Codigo,
                CodigoPapel = entity.PapelCarteira.Codigo,
                ValorPercentualLucratividade = entity.ValorPercentualLucratividade,
                PercentualOscilacao = entity.ValorPercentualOscilacao
            };

            return _returnEntity;
        }
    }
}
