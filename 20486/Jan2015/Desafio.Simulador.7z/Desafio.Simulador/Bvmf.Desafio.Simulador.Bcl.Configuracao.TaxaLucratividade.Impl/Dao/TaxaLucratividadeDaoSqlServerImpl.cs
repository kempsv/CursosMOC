using System;
using System.Data;
using System.Data.SqlClient;
//using Framework.AcessoDados;

namespace Desafio.Simulador.Bcl.Configuracao.TaxaLucratividade.Impl.Dao
{
    
    /// <summary>
    /// Implementa��o de TaxaLucratividadeDAO - SqlServer
    /// </summary>
    public abstract class TaxaLucratividadeDAOSqlServerImpl : TaxaLucratividadeDAO
    {   
        
    } //TaxaLucratividade
}
