﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Configuracao.TaxaLucratividade.Entidade;

namespace Desafio.Simulador.Bcl.Configuracao.TaxaLucratividade.Interfaces
{
    public abstract class BCConfiguracaoTaxaLucratividade : BCEntityPersistence<TaxaLucratividadeCenario, TOTaxaLucratividade>
    {
        public abstract List<TaxaLucratividadeCenario> ListarTaxasByCenario(int codigoCenario);
    }
}
