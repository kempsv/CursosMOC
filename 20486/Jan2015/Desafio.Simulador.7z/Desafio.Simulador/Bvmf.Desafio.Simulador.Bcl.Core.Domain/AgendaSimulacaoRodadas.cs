﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Desafio.Simulador.Bcl.Core.Domain
{
    public class AgendaSimulacaoRodadas
    {
        /// <summary>
        /// Indicador de Simulação concluída por cada grupo
        /// </summary>
        public bool IndicadorSimulacaoConcluida { get; set; }

        public short ContadorRodadaContingencia { get; set; }

        public RodadaSimulacao Rodada { get; set; }

        public GrupoEscolar GrupoEscolar { get; set; }

        public List<RodadaCenario> RodadaCenario { get; set; }

        public AgendaSimulacao AgendaSimulacao { get; set; }
    }
}
