﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Entidade;

namespace Desafio.Simulador.Bcl.Core.Domain
{
    public class CondicoesTermoAceite: BaseEntity
    {
        public string Descricao { get; set; }
        public List<TermoAceiteSimulacao> TermoAceiteSimulacao { get; set; }
    }
}
