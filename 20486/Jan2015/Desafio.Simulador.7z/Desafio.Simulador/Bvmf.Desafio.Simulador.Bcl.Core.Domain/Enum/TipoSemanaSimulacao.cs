﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Desafio.Simulador.Bcl.Core.Domain.Enum
{
    public enum TipoSemanaSimulacao
    {
        PrimeiraSemana = 1,
        SegundaSemana = 2,
        TerceiraSemana = 3,
        QuartaSemana = 4
    }
}
