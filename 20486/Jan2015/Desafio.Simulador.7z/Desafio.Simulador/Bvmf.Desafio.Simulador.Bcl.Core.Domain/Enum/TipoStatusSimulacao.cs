﻿using System;

namespace Desafio.Simulador.Bcl.Core.Domain.Enum
{
    public enum TipoStatusSimulacao
    {
        EmAndamento,
        Encerrado
    }
}
