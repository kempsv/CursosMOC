﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Entidade;
using Desafio.Simulador.Bcl.Core.Domain.Enum;

namespace Desafio.Simulador.Bcl.Core.Domain
{
    public class TermoAceiteSimulacao : BaseEntity
    {
        public string Descricao { get; set; }

        public bool IndicadorTermoAceito { get; set; }

        public TipoModoSimulacao TipoModoSimulacao { get; set; }

        public AgendaSimulacao AgendaSimulacao { get; set; }
    }
}
