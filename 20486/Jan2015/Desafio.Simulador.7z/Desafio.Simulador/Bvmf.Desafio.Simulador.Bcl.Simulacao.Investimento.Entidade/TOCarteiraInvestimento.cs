using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOCarteiraInvestimento
    {
        // Declara��o de atributos
        private int _codigoCarteira;
        private int _codigoRodada;
        private DateTime _dataHoraCriacao;
        private string _nomeCarteira;
        private decimal _percentualRentabilidadeAcumulada;
        private decimal _percentualRentabilidadePeriodo;
        private decimal _valorSaldoAtual;
        
        public int CodigoCarteira
        {
            get
            {
                return _codigoCarteira;
            }
            set
            {
                _codigoCarteira = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoRodada
        {
            get
            {
                return _codigoRodada;
            }
            set
            {
                _codigoRodada = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public DateTime DataHoraCriacao
        {
            get
            {
                return _dataHoraCriacao;
            }
            set
            {
                _dataHoraCriacao = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NomeCarteira
        {
            get
            {
                return _nomeCarteira;
            }
            set
            {
                _nomeCarteira = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal PercentualRentabilidadeAcumulada
        {
            get
            {
                return _percentualRentabilidadeAcumulada;
            }
            set
            {
                _percentualRentabilidadeAcumulada = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal PercentualRentabilidadePeriodo
        {
            get
            {
                return _percentualRentabilidadePeriodo;
            }
            set
            {
                _percentualRentabilidadePeriodo = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal ValorSaldoAtual
        {
            get
            {
                return _valorSaldoAtual;
            }
            set
            {
                _valorSaldoAtual = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOCarteiraInvestimento()
        {
            _codigoCarteira = int.MinValue;
            _codigoRodada = int.MinValue;
            _dataHoraCriacao = DateTime.MinValue;
            _nomeCarteira = null;
            _percentualRentabilidadeAcumulada = decimal.MinValue;
            _percentualRentabilidadePeriodo = decimal.MinValue;
            _valorSaldoAtual = decimal.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOCarteiraInvestimento" );
            sb.Append( "\n\tCodigoCarteira = " );
            sb.Append( _codigoCarteira );
            sb.Append( "\n\tCodigoRodada = " );
            sb.Append( _codigoRodada );
            sb.Append( "\n\tDataHoraCriacao = " );
            sb.Append( _dataHoraCriacao );
            sb.Append( "\n\tNomeCarteira = " );
            sb.Append( _nomeCarteira );
            sb.Append( "\n\tPercentualRentabilidadeAcumulada = " );
            sb.Append( _percentualRentabilidadeAcumulada );
            sb.Append( "\n\tPercentualRentabilidadePeriodo = " );
            sb.Append( _percentualRentabilidadePeriodo );
            sb.Append( "\n\tValorSaldoAtual = " );
            sb.Append( _valorSaldoAtual );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOCarteiraInvestimento) )
            {
                return false;
            }
            
            TOCarteiraInvestimento convertedParam = (TOCarteiraInvestimento) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoCarteira
            if( !CodigoCarteira.Equals( convertedParam.CodigoCarteira ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoRodada
            if( !CodigoRodada.Equals( convertedParam.CodigoRodada ) )
            {
                return false;
            }
            
            // Compara o atributo DataHoraCriacao
            if( !DataHoraCriacao.Equals( convertedParam.DataHoraCriacao ) )
            {
                return false;
            }
            
            // Compara o atributo NomeCarteira
            if( !NomeCarteira.Equals( convertedParam.NomeCarteira ) )
            {
                return false;
            }
            
            // Compara o atributo PercentualRentabilidadeAcumulada
            if( !PercentualRentabilidadeAcumulada.Equals( convertedParam.PercentualRentabilidadeAcumulada ) )
            {
                return false;
            }
            
            // Compara o atributo PercentualRentabilidadePeriodo
            if( !PercentualRentabilidadePeriodo.Equals( convertedParam.PercentualRentabilidadePeriodo ) )
            {
                return false;
            }
            
            // Compara o atributo ValorSaldoAtual
            if( !ValorSaldoAtual.Equals( convertedParam.ValorSaldoAtual ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //CarteiraInvestimento
}
