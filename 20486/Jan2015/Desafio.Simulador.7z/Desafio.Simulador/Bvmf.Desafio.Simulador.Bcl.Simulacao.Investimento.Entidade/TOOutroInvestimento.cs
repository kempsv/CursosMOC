using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOOutroInvestimento
    {
        // Declara��o de atributos
        private int _codigoOutroInvestimento;
        private string _nomeAtivoOutro;
        private decimal _percentualTaxaRentabilidade;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int CodigoOutroInvestimento
        {
            get
            {
                return _codigoOutroInvestimento;
            }
            set
            {
                _codigoOutroInvestimento = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string NomeAtivoOutro
        {
            get
            {
                return _nomeAtivoOutro;
            }
            set
            {
                _nomeAtivoOutro = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal PercentualTaxaRentabilidade
        {
            get
            {
                return _percentualTaxaRentabilidade;
            }
            set
            {
                _percentualTaxaRentabilidade = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOOutroInvestimento()
        {
            _codigoOutroInvestimento = int.MinValue;
            _nomeAtivoOutro = null;
            _percentualTaxaRentabilidade = decimal.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOOutroInvestimento" );
            sb.Append( "\n\tCodigoOutroInvestimento = " );
            sb.Append( _codigoOutroInvestimento );
            sb.Append( "\n\tNomeAtivoOutro = " );
            sb.Append( _nomeAtivoOutro );
            sb.Append( "\n\tPercentualTaxaRentabilidade = " );
            sb.Append( _percentualTaxaRentabilidade );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOOutroInvestimento) )
            {
                return false;
            }
            
            TOOutroInvestimento convertedParam = (TOOutroInvestimento) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoOutroInvestimento
            if( !CodigoOutroInvestimento.Equals( convertedParam.CodigoOutroInvestimento ) )
            {
                return false;
            }
            
            // Compara o atributo NomeAtivoOutro
            if( !NomeAtivoOutro.Equals( convertedParam.NomeAtivoOutro ) )
            {
                return false;
            }
            
            // Compara o atributo PercentualTaxaRentabilidade
            if( !PercentualTaxaRentabilidade.Equals( convertedParam.PercentualTaxaRentabilidade ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //OutroInvestimento
}
