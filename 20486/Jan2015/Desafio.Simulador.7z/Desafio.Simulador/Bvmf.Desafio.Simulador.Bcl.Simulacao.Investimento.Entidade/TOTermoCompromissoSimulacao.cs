using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOTermoCompromissoSimulacao
    {
        // Declara��o de atributos
        private int _codigo;
        private string _descricao;
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int Codigo
        {
            get
            {
                return _codigo;
            }
            set
            {
                _codigo = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public string Descricao
        {
            get
            {
                return _descricao;
            }
            set
            {
                _descricao = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOTermoCompromissoSimulacao()
        {
            _codigo = int.MinValue;
            _descricao = null;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOTermoCompromissoSimulacao" );
            sb.Append( "\n\tCodigo = " );
            sb.Append( _codigo );
            sb.Append( "\n\tDescricao = " );
            sb.Append( _descricao );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOTermoCompromissoSimulacao) )
            {
                return false;
            }
            
            TOTermoCompromissoSimulacao convertedParam = (TOTermoCompromissoSimulacao) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo Codigo
            if( !Codigo.Equals( convertedParam.Codigo ) )
            {
                return false;
            }
            
            // Compara o atributo Descricao
            if( !Descricao.Equals( convertedParam.Descricao ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //TermoCompromissoSimulacao
}
