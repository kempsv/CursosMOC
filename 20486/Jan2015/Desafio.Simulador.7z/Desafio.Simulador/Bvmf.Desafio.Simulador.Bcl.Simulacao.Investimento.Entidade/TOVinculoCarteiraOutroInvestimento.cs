using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOVinculoCarteiraOutroInvestimento
    {
        // Declara��o de atributos
        private int _codigoCarteira;
        private int _codigoOutroInvestimento;
        private decimal _valorFinalOutroInvestimento;
        private decimal _valorInvestidoOutroInvestimento;
        
        public int CodigoCarteira
        {
            get
            {
                return _codigoCarteira;
            }
            set
            {
                _codigoCarteira = value;
            }
        }
        
        public int CodigoOutroInvestimento
        {
            get
            {
                return _codigoOutroInvestimento;
            }
            set
            {
                _codigoOutroInvestimento = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal ValorFinalOutroInvestimento
        {
            get
            {
                return _valorFinalOutroInvestimento;
            }
            set
            {
                _valorFinalOutroInvestimento = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal ValorInvestidoOutroInvestimento
        {
            get
            {
                return _valorInvestidoOutroInvestimento;
            }
            set
            {
                _valorInvestidoOutroInvestimento = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOVinculoCarteiraOutroInvestimento()
        {
            _codigoCarteira = int.MinValue;
            _codigoOutroInvestimento = int.MinValue;
            _valorFinalOutroInvestimento = decimal.MinValue;
            _valorInvestidoOutroInvestimento = decimal.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOVinculoCarteiraOutroInvestimento" );
            sb.Append( "\n\tCodigoCarteira = " );
            sb.Append( _codigoCarteira );
            sb.Append( "\n\tCodigoOutroInvestimento = " );
            sb.Append( _codigoOutroInvestimento );
            sb.Append( "\n\tValorFinalOutroInvestimento = " );
            sb.Append( _valorFinalOutroInvestimento );
            sb.Append( "\n\tValorInvestidoOutroInvestimento = " );
            sb.Append( _valorInvestidoOutroInvestimento );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOVinculoCarteiraOutroInvestimento) )
            {
                return false;
            }
            
            TOVinculoCarteiraOutroInvestimento convertedParam = (TOVinculoCarteiraOutroInvestimento) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoCarteira
            if( !CodigoCarteira.Equals( convertedParam.CodigoCarteira ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoOutroInvestimento
            if( !CodigoOutroInvestimento.Equals( convertedParam.CodigoOutroInvestimento ) )
            {
                return false;
            }
            
            // Compara o atributo ValorFinalOutroInvestimento
            if( !ValorFinalOutroInvestimento.Equals( convertedParam.ValorFinalOutroInvestimento ) )
            {
                return false;
            }
            
            // Compara o atributo ValorInvestidoOutroInvestimento
            if( !ValorInvestidoOutroInvestimento.Equals( convertedParam.ValorInvestidoOutroInvestimento ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //VinculoCarteiraOutroInvestimento
}
