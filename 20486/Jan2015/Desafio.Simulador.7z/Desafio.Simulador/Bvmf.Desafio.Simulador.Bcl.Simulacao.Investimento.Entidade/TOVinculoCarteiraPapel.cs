using System;
using System.Collections;
using System.Text;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade
{
    
    /// <summary>
    /// Coloque os coment�rios aqui...
    /// </summary>
    [Serializable]
    public class TOVinculoCarteiraPapel
    {
        // Declara��o de atributos
        private int _codigoCarteira;
        private int _codigoPapel;
        private int _quantidadePapelNegociado;
        private decimal _valorFinalInvestido;
        private decimal _valorInvestido;
        private decimal _valorPrecoCompra;
        private decimal _valorPrecoFinal;
        private decimal _valorRentabilidade;
        
        public int CodigoCarteira
        {
            get
            {
                return _codigoCarteira;
            }
            set
            {
                _codigoCarteira = value;
            }
        }
        
        public int CodigoPapel
        {
            get
            {
                return _codigoPapel;
            }
            set
            {
                _codigoPapel = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public int QuantidadePapelNegociado
        {
            get
            {
                return _quantidadePapelNegociado;
            }
            set
            {
                _quantidadePapelNegociado = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal ValorFinalInvestido
        {
            get
            {
                return _valorFinalInvestido;
            }
            set
            {
                _valorFinalInvestido = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal ValorInvestido
        {
            get
            {
                return _valorInvestido;
            }
            set
            {
                _valorInvestido = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal ValorPrecoCompra
        {
            get
            {
                return _valorPrecoCompra;
            }
            set
            {
                _valorPrecoCompra = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal ValorPrecoFinal
        {
            get
            {
                return _valorPrecoFinal;
            }
            set
            {
                _valorPrecoFinal = value;
            }
        }
        
        /// <summary>
        /// Coloque os coment�rios aqui...
        /// </summary>
        public decimal ValorRentabilidade
        {
            get
            {
                return _valorRentabilidade;
            }
            set
            {
                _valorRentabilidade = value;
            }
        }
        
        /// <summary>
        /// Construtor default
        /// </summary>
        public TOVinculoCarteiraPapel()
        {
            _codigoCarteira = int.MinValue;
            _codigoPapel = int.MinValue;
            _quantidadePapelNegociado = int.MinValue;
            _valorFinalInvestido = decimal.MinValue;
            _valorInvestido = decimal.MinValue;
            _valorPrecoCompra = decimal.MinValue;
            _valorPrecoFinal = decimal.MinValue;
            _valorRentabilidade = decimal.MinValue;
        }
        
        /// <summary>
        /// Retorna a representa��o textual deste objeto
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append( "[ TOVinculoCarteiraPapel" );
            sb.Append( "\n\tCodigoCarteira = " );
            sb.Append( _codigoCarteira );
            sb.Append( "\n\tCodigoPapel = " );
            sb.Append( _codigoPapel );
            sb.Append( "\n\tQuantidadePapelNegociado = " );
            sb.Append( _quantidadePapelNegociado );
            sb.Append( "\n\tValorFinalInvestido = " );
            sb.Append( _valorFinalInvestido );
            sb.Append( "\n\tValorInvestido = " );
            sb.Append( _valorInvestido );
            sb.Append( "\n\tValorPrecoCompra = " );
            sb.Append( _valorPrecoCompra );
            sb.Append( "\n\tValorPrecoFinal = " );
            sb.Append( _valorPrecoFinal );
            sb.Append( "\n\tValorRentabilidade = " );
            sb.Append( _valorRentabilidade );
            sb.Append( "\n]\n" ); 
            return sb.ToString();
        }
        
        
        
        /// <summary>
        /// Compara este objeto com outra instancia da classe 
        /// </summary>
        /// <param name="param">Instancia a ser comparada</param>
        /// <returns>true caso os objetos possuam os mesmo atributos, false caso contrario</returns>
        public override bool Equals( Object param )
        {
            if ( !(param is TOVinculoCarteiraPapel) )
            {
                return false;
            }
            
            TOVinculoCarteiraPapel convertedParam = (TOVinculoCarteiraPapel) param;
            
            // mesmo objeto sendo comparado
            if( this == convertedParam )
            {
                return true;
            }
            
            // Compara o atributo CodigoCarteira
            if( !CodigoCarteira.Equals( convertedParam.CodigoCarteira ) )
            {
                return false;
            }
            
            // Compara o atributo CodigoPapel
            if( !CodigoPapel.Equals( convertedParam.CodigoPapel ) )
            {
                return false;
            }
            
            // Compara o atributo QuantidadePapelNegociado
            if( !QuantidadePapelNegociado.Equals( convertedParam.QuantidadePapelNegociado ) )
            {
                return false;
            }
            
            // Compara o atributo ValorFinalInvestido
            if( !ValorFinalInvestido.Equals( convertedParam.ValorFinalInvestido ) )
            {
                return false;
            }
            
            // Compara o atributo ValorInvestido
            if( !ValorInvestido.Equals( convertedParam.ValorInvestido ) )
            {
                return false;
            }
            
            // Compara o atributo ValorPrecoCompra
            if( !ValorPrecoCompra.Equals( convertedParam.ValorPrecoCompra ) )
            {
                return false;
            }
            
            // Compara o atributo ValorPrecoFinal
            if( !ValorPrecoFinal.Equals( convertedParam.ValorPrecoFinal ) )
            {
                return false;
            }
            
            // Compara o atributo ValorRentabilidade
            if( !ValorRentabilidade.Equals( convertedParam.ValorRentabilidade ) )
            {
                return false;
            }
            
            return true;
        }
        
        /// <summary>
        /// GetHashCode() default
        /// </summary>
        /// <returns>GetHashCode() default</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        
    } //VinculoCarteiraPapel
}
