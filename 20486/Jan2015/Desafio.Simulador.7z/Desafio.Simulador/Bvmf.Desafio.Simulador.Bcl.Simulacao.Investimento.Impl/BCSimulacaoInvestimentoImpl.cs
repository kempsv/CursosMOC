﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Impl.Dao;
using Microsoft.Practices.Unity;
using Desafio.Simulador.Bcl.Configuracao.Papel.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.TaxaLucratividade.Interfaces;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Impl
{
    public class BCSimulacaoInvestimentoImpl : BCSimulacaoInvestimento
    {
        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCConfiguracaoTaxaLucratividade BCConfiguracaoTaxaLucratividade { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCConfiguracaoPapel BCConfiguracaoPapel { get; set; }

        public BCSimulacaoInvestimentoImpl(CarteiraInvestimentoDAO carteiraInvestimentoDAO)
        {
            _persistence = carteiraInvestimentoDAO;
        }

        public override CarteiraInvestimento ObterCarteiraInvestimentoRodada(RodadaSimulacao rodadaSimulacao)
        {
            CarteiraInvestimento _carteira = null;
            _carteira = ((CarteiraInvestimentoDAO)_persistence).FindCarteiraByRodada(rodadaSimulacao.Codigo);

            if (null != _carteira)
            {
                List<TOVinculoCarteiraPapel> _papeis = VinculoCarteiraPapelDAO.GetInstance().FindPapeisByCarteira(_carteira.Codigo);
                _carteira.AtivosCarteiraPapeis = new List<AtivosCarteiraPapeis>();

                foreach (TOVinculoCarteiraPapel papel in _papeis)
                {
                    _carteira.AtivosCarteiraPapeis.Add(new AtivosCarteiraPapeis()
                    {
                        Codigo = papel.CodigoCarteira,
                        PapelCarteira = this.BCConfiguracaoPapel.FindByKey(papel.CodigoPapel),
                        Quantidade = papel.QuantidadePapelNegociado,
                        ValorInvestido = papel.ValorInvestido,
                        ValorInvestidoFinal = papel.ValorFinalInvestido,
                        ValorPrecoCompra = papel.ValorPrecoCompra,
                        ValorPrecoFinal = papel.ValorPrecoFinal,
                        ValorRentabilidade = papel.ValorRentabilidade
                    });
                }

                _carteira.AtivosCarteiraOutros = new List<AtivosCarteiraOutros>();
                List<TOVinculoCarteiraOutroInvestimento> _outrosInvestimentos = VinculoCarteiraOutroInvestimentoDAO.GetInstance().FindOutrosInvestimentosByCarteira(_carteira.Codigo);

                foreach (TOVinculoCarteiraOutroInvestimento outroInvestimento in _outrosInvestimentos)
                {
                    TOOutroInvestimento _outroInvData = OutroInvestimentoDAO.GetInstance().FindByKey(outroInvestimento.CodigoOutroInvestimento);

                    _carteira.AtivosCarteiraOutros.Add(new AtivosCarteiraOutros()
                    {
                        Codigo = outroInvestimento.CodigoCarteira,
                        NomeAtivo = _outroInvData.NomeAtivoOutro,
                        Quantidade = 0,
                        ValorInvestido = outroInvestimento.ValorInvestidoOutroInvestimento,
                        ValorInvestidoFinal = outroInvestimento.ValorFinalOutroInvestimento,
                        ValorPercentualRendimento = _outroInvData.PercentualTaxaRentabilidade
                    });
                }
            }
            return _carteira;
        }

        public override void SalvarCarteiraInvestimento(CarteiraInvestimento carteira)
        {
            CarteiraInvestimento carteiraRodadaAnterior = null;
            CarteiraInvestimento carteiraRodadaAtual = null;
            decimal saldoAnterior = 0;
            decimal saldoPapeis = 0;
            decimal saldoOutros = 0;
            decimal rentabilidadeAcumulada = 0;
            decimal valorPercAcoes = 0;
            decimal valorPercOutros = 0;
            //decimal valorPenalidade = 0;

            //	Valores parametrizados
            valorPercAcoes = carteira.RodadaSimulacao.ParametrizacaoRodada.ValorPercentualMinimoAcoes;
            valorPercOutros = carteira.RodadaSimulacao.ParametrizacaoRodada.ValorPercentualMinimoOutros;

            // Obter carteira da rodada anterior
            if (null != carteira.RodadaSimulacaoAnterior)
            {
                carteiraRodadaAnterior = this.ObterCarteiraInvestimentoRodada(carteira.RodadaSimulacaoAnterior);
                //	Recuperar rentabilidade da carteira da rodada anterior                  
                rentabilidadeAcumulada = carteiraRodadaAnterior.ValorRentabilidadeAcumulada;
            }

            #region Calcular saldos

            //saldoPapeis = ValorSaldoAtual(carteira.AtivosCarteiraPapeis);
            saldoPapeis = carteira.ObterValorSaldoAtual();
            if (null != carteira.AtivosCarteiraOutros)
                //saldoOutros = ValorSaldoAtualOutrosInvestimentos(carteira.AtivosCarteiraOutros);
                saldoOutros = carteira.ObterValorSaldoAtualOutrosInvestimentos();

            if (carteira.RodadaSimulacao.IdentificadorRodada == 1)	// Primeira rodada. 
                // Recupera o investimento inicial retirado de dados do grupo escolar				            
                saldoAnterior = carteira.RodadaSimulacao.GrupoEscolar.ValorInvestimentoInicial;
            else
                // Saldo atual da carteira da rodada anterior
                saldoAnterior = carteiraRodadaAnterior.ValorSaldoAtual;

            #endregion

            #region RN1 - Validar Outros Investimentos

            if ((saldoAnterior * (valorPercAcoes / 100)) > saldoPapeis)
            {
                //TODO: Trocar pelo objeto de Parametrizacao da Rodada
                //throw new OutrosInvestimentosException("10%");
                GerenciadorExcecao.TratarExcecao(new OutrosInvestimentosException("10%"));
            }

            #endregion

            #region RN2 - Validar Saldo Insuficiente

            //if ((saldoPapeis + saldoOutros) > saldoAnterior)
            if ((saldoPapeis) > saldoAnterior)
            {
                //throw new SaldoInsuficienteException();
                GerenciadorExcecao.TratarExcecao(new SaldoInsuficienteException());
            }

            #endregion

            #region Calcular dados da carteira
            //	Calcular dados da carteira
            var _taxas = BCConfiguracaoTaxaLucratividade.ListarTaxasByCenario(carteira.RodadaSimulacao.CenarioSimulacao.Codigo);
            //carteira = this.CalcularValoresCarteira(carteira);
            carteira.CalcularValores(_taxas);

            //	Calcular rentabilidade acumulada
            carteira.ValorRentabilidadeAcumulada = rentabilidadeAcumulada + carteira.ValorRentabilidadePeriodo;
            #endregion

            #region Excluir carteira já existente na rodada
            //	Obter carteira salva anteriormente durante a rodada
            carteiraRodadaAtual = this.ObterCarteiraInvestimentoRodada(carteira.RodadaSimulacao);

            if (carteiraRodadaAtual != null)
            {
                //	Apaga a carteira atual
                this.DesvincularCarteiraOutros(carteiraRodadaAtual.Codigo);
                this.DesvincularCarteiraPapeis(carteiraRodadaAtual.Codigo);
                _persistence.Delete(carteiraRodadaAtual);
            }
            #endregion

            #region Salvar carteira
            _persistence.Create(carteira);
            this.VincularCarteirasOutros(carteira);
            this.VincularCarteiraPapeis(carteira);
            #endregion
        }

        #region Métodos Vincular / Desvincular

        private void VincularCarteirasOutros(CarteiraInvestimento carteira)
        {
            //	Desvincular valores anteriores da mesma carteira
            this.DesvincularCarteiraOutros(carteira.Codigo);

            foreach (AtivosCarteiraOutros outros in carteira.AtivosCarteiraOutros)
            {
                VincularCarteiraOutros(outros, carteira.Codigo);
            }
        }

        private void VincularCarteiraOutros(AtivosCarteiraOutros entity, int codigo)
        {
            //	Recupera o código do campo outros investimentos para salvar na carteira
            int codOutros = 0;
            List<TOOutroInvestimento> outrosInvestimentos = null;
            outrosInvestimentos = OutroInvestimentoDAO.GetInstance().FindAll();

            if (outrosInvestimentos != null)
            {
                foreach (TOOutroInvestimento outro in outrosInvestimentos)
                {
                    codOutros = outro.CodigoOutroInvestimento;
                }
            }

            //Faz o vínculo de Outros Investimentos com a Carteira
            VinculoCarteiraOutroInvestimentoDAO.GetInstance().Create(new TOVinculoCarteiraOutroInvestimento()
            {
                CodigoCarteira = codigo,
                CodigoOutroInvestimento = codOutros,
                ValorInvestidoOutroInvestimento = entity.ValorInvestido,
                ValorFinalOutroInvestimento = entity.ValorInvestidoFinal
            });
        }

        private void DesvincularCarteiraOutros(int codigo)
        {
            VinculoCarteiraOutroInvestimentoDAO.GetInstance().DeleteByCarteira(codigo);
        }

        private void VincularCarteiraPapeis(CarteiraInvestimento carteira)
        {
            //	Desvincular valores anteriores da mesma carteira
            this.DesvincularCarteiraPapeis(carteira.Codigo);

            foreach (AtivosCarteiraPapeis papeis in carteira.AtivosCarteiraPapeis)
            {
                VincularCarteiraPapeis(papeis, carteira.Codigo);
            }
        }

        private void VincularCarteiraPapeis(AtivosCarteiraPapeis entity, int codigo)
        {
            //Faz o vínculo dos Papeis com a Carteira			
            VinculoCarteiraPapelDAO.GetInstance().Create(new TOVinculoCarteiraPapel()
            {
                CodigoCarteira = codigo,
                CodigoPapel = entity.PapelCarteira.Codigo,
                QuantidadePapelNegociado = entity.Quantidade,
                ValorFinalInvestido = entity.ValorInvestidoFinal,
                ValorInvestido = entity.ValorInvestido,
                ValorPrecoCompra = entity.ValorPrecoCompra,
                ValorPrecoFinal = entity.ValorPrecoFinal,
                ValorRentabilidade = entity.ValorRentabilidade
            });
        }

        private void DesvincularCarteiraPapeis(int codigo)
        {
            VinculoCarteiraPapelDAO.GetInstance().DeleteByCarteira(codigo);
        }

        #endregion
    }
}
