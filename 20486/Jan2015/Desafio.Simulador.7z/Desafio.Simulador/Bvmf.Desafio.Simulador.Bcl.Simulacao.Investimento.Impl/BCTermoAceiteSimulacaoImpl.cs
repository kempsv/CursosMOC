﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Impl.Dao;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade;
using Desafio.Simulador.Bcl.Core.Domain.Enum;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Impl
{
    public class BCTermoAceiteSimulacaoImpl : BCTermoAceiteSimulacao
    {
        public BCTermoAceiteSimulacaoImpl(CondicaoTermoCompromissoDAO condicaoTermoCompromissoDAO)
        {
            _persistence = condicaoTermoCompromissoDAO;
        }

        /// <summary>
        /// Método da classe base sobrescrito. não é necessário incluir os registros da tabela de Termos
        /// </summary>
        /// <param name="entity"></param>
        public override void Create(CondicoesTermoAceite entity)
        {
            base.Create(entity);

            this.VincularCondicaoTermoAceite(entity);
        }

        private void VincularCondicaoTermoAceite(CondicoesTermoAceite entity)
        {
            //
            //Faz o vinculo da condição do termo com os termo de aceite de simulação
            //
            this.DesvincularCondicaoTermoAceite(entity);

            var _termosAceiteCadastrados = TermoCompromissoSimulacaoDAO.GetInstance().FindAll();

            entity.TermoAceiteSimulacao.ForEach(delegate(TermoAceiteSimulacao termoAceite)
            {
                switch (termoAceite.TipoModoSimulacao) 
                {
                    case TipoModoSimulacao.Presencial:
                        termoAceite.Codigo = _termosAceiteCadastrados.Where(trm => trm.Descricao == "Presencial").First<TermoAceiteSimulacao>().Codigo;
                        break;
                    case TipoModoSimulacao.Web:
                    default:
                        termoAceite.Codigo = _termosAceiteCadastrados.Where(trm => trm.Descricao == "Web").First<TermoAceiteSimulacao>().Codigo;
                        break;
                    
                }
                VinculoCondicaoTermoCompromissoDAO.GetInstance().Create(new TOVinculoCondicaoTermoCompromisso()
                {
                    CodigoCondicaoTermoCompromisso = entity.Codigo,
                    CodigoTermoCompromisso = termoAceite.Codigo
                });
            });
        }

        private void DesvincularCondicaoTermoAceite(CondicoesTermoAceite entity)
        {
            //Exclui todas os vinculos da condição do termo de aceite
            VinculoCondicaoTermoCompromissoDAO.GetInstance().DeleteAllTermoAceite(entity.Codigo);
        }

        private void PreencherAgregacao(List<CondicoesTermoAceite> condicaoTermosAceite)
        {
            condicaoTermosAceite.ForEach(delegate(CondicoesTermoAceite condicaoTermoAceite)
            {
                PreencherAgregacao(condicaoTermoAceite);
            });
        }

        private void PreencherAgregacao(CondicoesTermoAceite condicaoTermoAceite)
        {
            //
            //Lista todos os vinculos cadastrados na base.
            //
            var _vinculosTermoAceite = VinculoCondicaoTermoCompromissoDAO.GetInstance().FindAll();

            //
            //Lista somente os vinculos do termo de aceite passado como parametro ao método
            //
            _vinculosTermoAceite = _vinculosTermoAceite.Where(vinc => vinc.CodigoCondicaoTermoCompromisso == condicaoTermoAceite.Codigo).ToList<TOVinculoCondicaoTermoCompromisso>();

            if (_vinculosTermoAceite != null)
            {
                condicaoTermoAceite.TermoAceiteSimulacao = new List<TermoAceiteSimulacao>();
                _vinculosTermoAceite.ForEach(delegate(TOVinculoCondicaoTermoCompromisso toVinculo)
                {
                    condicaoTermoAceite.TermoAceiteSimulacao.Add(TermoCompromissoSimulacaoDAO.GetInstance().FindByKey(toVinculo.CodigoTermoCompromisso));
                });
            }
        }

        public override void Update(CondicoesTermoAceite entity)
        {
            base.Update(entity);

            this.VincularCondicaoTermoAceite(entity);
        }

        public override void Delete(CondicoesTermoAceite entity)
        {
            this.DesvincularCondicaoTermoAceite(entity);
            
            base.Delete(entity);
        }

        public override List<CondicoesTermoAceite> FindAll()
        {
            var _condicoesTermos = base.FindAll();

            this.PreencherAgregacao(_condicoesTermos);

            return _condicoesTermos;
        }

        public override CondicoesTermoAceite FindByKey(int key)
        {
            var _condicaoTermoAceite = base.FindByKey(key);

            this.PreencherAgregacao(_condicaoTermoAceite);

            return _condicaoTermoAceite;
        }

        public override TermoAceiteSimulacao ObterTermoAceiteSimulacao(AgendaSimulacao agendaSimulacao, GrupoEscolar grupoEscolar)
        {
            var _toVinculosAceiteSimulacao = VinculoTermoCompromissoAgendamentoDAO.GetInstance().FindByKey(grupoEscolar.Codigo, agendaSimulacao.Codigo);

            if (_toVinculosAceiteSimulacao != null)
            {
                var _termoAceiteSimulacao = TermoCompromissoSimulacaoDAO.GetInstance().FindByKey(_toVinculosAceiteSimulacao.CodigoTermoCompromisso);
                _termoAceiteSimulacao.IndicadorTermoAceito = _toVinculosAceiteSimulacao.IndicadorTermoAceito;

                return _termoAceiteSimulacao;
            }
            else return null;
        }

        public override void AceitarTermoSimulacao(TermoAceiteSimulacao termoAceiteSimulacao)
        {
            termoAceiteSimulacao.AgendaSimulacao.GrupoEscolar.ForEach(delegate(GrupoEscolar grupoEscolar) 
            {
                VinculoTermoCompromissoAgendamentoDAO.GetInstance().Delete(new TOVinculoTermoCompromissoAgendamento()
                {
                    CodigoTermoCompromisso = termoAceiteSimulacao.Codigo,
                    CodigoAgendaSimulacao = termoAceiteSimulacao.AgendaSimulacao.Codigo,
                    CodigoGrupoEscolar = grupoEscolar.Codigo
                });

                VinculoTermoCompromissoAgendamentoDAO.GetInstance().Create(new TOVinculoTermoCompromissoAgendamento()
                {
                    CodigoTermoCompromisso = termoAceiteSimulacao.Codigo,
                    CodigoAgendaSimulacao = termoAceiteSimulacao.AgendaSimulacao.Codigo,
                    CodigoGrupoEscolar = grupoEscolar.Codigo,
                    IndicadorTermoAceito = termoAceiteSimulacao.IndicadorTermoAceito
                });
            });
            
            
        }
    }
}
