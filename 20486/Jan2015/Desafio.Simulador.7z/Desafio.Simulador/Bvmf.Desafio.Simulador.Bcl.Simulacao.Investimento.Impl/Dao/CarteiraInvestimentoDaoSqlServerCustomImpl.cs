﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade;
using System.Collections.Generic;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Impl.Dao
{
    public class CarteiraInvestimentoDAOSqlServerCustomImpl : CarteiraInvestimentoDAOSqlServerImpl
    {
        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "CarteiraInvestimentoDAOSqlServerCustomImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<CarteiraInvestimento> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOCarteiraInvestimento> result = new List<TOCarteiraInvestimento>();
            TOCarteiraInvestimento transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBCART.COD_CART, TSDBCART.COD_RDAD, TSDBCART.DTHR_CRIA, TSDBCART.NOME_CART, TSDBCART.PERC_RENT_ACUM, TSDBCART.PERC_RENT_PERI_INVE, TSDBCART.VAL_SALD_ATU_CART FROM TSDBCART TSDBCART WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOCarteiraInvestimento();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCarteira = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoRodada = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.DataHoraCriacao = dataReader.GetDateTime(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.NomeCarteira = dataReader.GetString(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.PercentualRentabilidadeAcumulada = dataReader.GetDecimal(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.PercentualRentabilidadePeriodo = dataReader.GetDecimal(5);
                                    }
                                    if (!dataReader.IsDBNull(6))
                                    {
                                        transferObject.ValorSaldoAtual = dataReader.GetDecimal(6);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override CarteiraInvestimento FindByKey(int codigoCarteira)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOCarteiraInvestimento transferObject = null;

            try
            {
                statement = "SELECT TSDBCART.COD_CART, TSDBCART.COD_RDAD, TSDBCART.DTHR_CRIA, TSDBCART.NOME_CART, TSDBCART.PERC_RENT_ACUM, TSDBCART.PERC_RENT_PERI_INVE, TSDBCART.VAL_SALD_ATU_CART FROM TSDBCART TSDBCART WITH(NOLOCK) WHERE TSDBCART.COD_CART = @codigoCarteira";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoCarteira", codigoCarteira));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOCarteiraInvestimento();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCarteira = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoRodada = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.DataHoraCriacao = dataReader.GetDateTime(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.NomeCarteira = dataReader.GetString(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.PercentualRentabilidadeAcumulada = dataReader.GetDecimal(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.PercentualRentabilidadePeriodo = dataReader.GetDecimal(5);
                                    }
                                    if (!dataReader.IsDBNull(6))
                                    {
                                        transferObject.ValorSaldoAtual = dataReader.GetDecimal(6);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override CarteiraInvestimento FindCarteiraByRodada(int codigoRodada)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOCarteiraInvestimento transferObject = null;

            try
            {
                statement = "SELECT TOP 1 TSDBCART.COD_CART, TSDBCART.COD_RDAD, TSDBCART.DTHR_CRIA, TSDBCART.NOME_CART, TSDBCART.PERC_RENT_ACUM, TSDBCART.PERC_RENT_PERI_INVE, TSDBCART.VAL_SALD_ATU_CART FROM TSDBCART TSDBCART WITH(NOLOCK) WHERE TSDBCART.COD_RDAD = @codigoRodada ORDER BY TSDBCART.COD_CART DESC";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoRodada", codigoRodada));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOCarteiraInvestimento();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCarteira = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoRodada = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.DataHoraCriacao = dataReader.GetDateTime(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.NomeCarteira = dataReader.GetString(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.PercentualRentabilidadeAcumulada = dataReader.GetDecimal(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.PercentualRentabilidadePeriodo = dataReader.GetDecimal(5);
                                    }
                                    if (!dataReader.IsDBNull(6))
                                    {
                                        transferObject.ValorSaldoAtual = dataReader.GetDecimal(6);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            if (null != transferObject)
                return TranslateFromDTO(transferObject);
            else
                return null;
        }

        /// <summary>
        /// Remove uma entidade pela sua chave primária.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(CarteiraInvestimento entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOCarteiraInvestimento transferObject = TranslateToDTO(entity);

                statement = "DELETE FROM TSDBCART WHERE COD_CART = @codigoCarteira";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave primária
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoCarteira", transferObject.CodigoCarteira));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma instância em memória na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(CarteiraInvestimento entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOCarteiraInvestimento transferObject = TranslateToDTO(entity);

                statement = "UPDATE TSDBCART SET cOD_RDAD = @codigoRodada, dTHR_CRIA = @dataHoraCriacao, nOME_CART = @nomeCarteira, pERC_RENT_ACUM = @percentualRentabilidadeAcumulada, pERC_RENT_PERI_INVE = @percentualRentabilidadePeriodo, vAL_SALD_ATU_CART = @valorSaldoAtual WHERE COD_CART = @codigoCarteira";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que não estão na chave
                            if (transferObject.CodigoRodada == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoRodada", transferObject.CodigoRodada));
                            }

                            if (transferObject.DataHoraCriacao == DateTime.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@dataHoraCriacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@dataHoraCriacao", transferObject.DataHoraCriacao));
                            }

                            if (transferObject.NomeCarteira == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeCarteira", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeCarteira", transferObject.NomeCarteira));
                            }

                            if (transferObject.PercentualRentabilidadeAcumulada == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@percentualRentabilidadeAcumulada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@percentualRentabilidadeAcumulada", transferObject.PercentualRentabilidadeAcumulada));
                            }

                            if (transferObject.PercentualRentabilidadePeriodo == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@percentualRentabilidadePeriodo", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@percentualRentabilidadePeriodo", transferObject.PercentualRentabilidadePeriodo));
                            }

                            if (transferObject.ValorSaldoAtual == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorSaldoAtual", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorSaldoAtual", transferObject.ValorSaldoAtual));
                            }

                            // Chave primária
                            command.Parameters.Add(new SqlParameter("@codigoCarteira", transferObject.CodigoCarteira));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma instância em memória na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(CarteiraInvestimento entity)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                TOCarteiraInvestimento transferObject = TranslateToDTO(entity);

                statement = "INSERT INTO TSDBCART ( COD_RDAD, DTHR_CRIA, NOME_CART, PERC_RENT_ACUM, PERC_RENT_PERI_INVE, VAL_SALD_ATU_CART ) VALUES ( @codigoRodada, @dataHoraCriacao, @nomeCarteira, @percentualRentabilidadeAcumulada, @percentualRentabilidadePeriodo, @valorSaldoAtual )  ; SELECT SCOPE_IDENTITY();";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoRodada == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoRodada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoRodada", transferObject.CodigoRodada));
                            }

                            if (transferObject.DataHoraCriacao == DateTime.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@dataHoraCriacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@dataHoraCriacao", transferObject.DataHoraCriacao));
                            }

                            if (transferObject.NomeCarteira == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeCarteira", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeCarteira", transferObject.NomeCarteira));
                            }

                            if (transferObject.PercentualRentabilidadeAcumulada == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@percentualRentabilidadeAcumulada", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@percentualRentabilidadeAcumulada", transferObject.PercentualRentabilidadeAcumulada));
                            }

                            if (transferObject.PercentualRentabilidadePeriodo == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@percentualRentabilidadePeriodo", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@percentualRentabilidadePeriodo", transferObject.PercentualRentabilidadePeriodo));
                            }

                            if (transferObject.ValorSaldoAtual == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorSaldoAtual", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorSaldoAtual", transferObject.ValorSaldoAtual));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            entity.Codigo = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        protected override List<CarteiraInvestimento> TranslateFromDTO(List<TOCarteiraInvestimento> entityDTO)
        {
            var _lista = new List<CarteiraInvestimento>();
            foreach (TOCarteiraInvestimento et in entityDTO)
            {
                _lista.Add(TranslateFromDTO(et));
            }
            return _lista;
        }

        protected override CarteiraInvestimento TranslateFromDTO(TOCarteiraInvestimento entityDTO)
        {
            return new CarteiraInvestimento()
            {
                Codigo = entityDTO.CodigoCarteira,
                DataHoraCriacao = entityDTO.DataHoraCriacao,
                RodadaSimulacao = new RodadaSimulacao() { Codigo = entityDTO.CodigoRodada },
                ValorRentabilidadeAcumulada = entityDTO.PercentualRentabilidadeAcumulada,
                ValorRentabilidadePeriodo = entityDTO.PercentualRentabilidadePeriodo,
                ValorSaldoAtual = entityDTO.ValorSaldoAtual
            };

        }

        protected override List<TOCarteiraInvestimento> TranslateToDTO(List<CarteiraInvestimento> entity)
        {
            var _lista = new List<TOCarteiraInvestimento>();
            foreach (CarteiraInvestimento et in entity)
            {
                _lista.Add(TranslateToDTO(et));
            }
            return _lista;
        }

        protected override TOCarteiraInvestimento TranslateToDTO(CarteiraInvestimento entity)
        {
            return new TOCarteiraInvestimento()
            {
                CodigoCarteira = entity.Codigo,
                CodigoRodada = entity.RodadaSimulacao.Codigo,
                DataHoraCriacao = entity.DataHoraCriacao,
                NomeCarteira = "Carteira Rodada " + entity.RodadaSimulacao.IdentificadorRodada.ToString(),
                PercentualRentabilidadeAcumulada = entity.ValorRentabilidadeAcumulada,
                PercentualRentabilidadePeriodo = entity.ValorRentabilidadePeriodo,
                ValorSaldoAtual = entity.ValorSaldoAtual
            };
        }
    }
}
