using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Impl.Dao
{
    
    /// <summary>
    /// Implementa��o de CarteiraInvestimentoDAO - SqlServer
    /// </summary>
    public abstract class CarteiraInvestimentoDAOSqlServerImpl : CarteiraInvestimentoDAO
    {
        
    } //CarteiraInvestimento
}
