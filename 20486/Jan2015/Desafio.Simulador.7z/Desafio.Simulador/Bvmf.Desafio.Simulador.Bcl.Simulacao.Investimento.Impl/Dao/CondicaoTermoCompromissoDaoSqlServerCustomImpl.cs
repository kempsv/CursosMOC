﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade;
using System.Collections.Generic;
using Desafio.Simulador.Bcl.Core.Domain;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Impl.Dao
{
    public class CondicaoTermoCompromissoDAOSqlServerCustomImpl : CondicaoTermoCompromissoDAOSqlServerImpl
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "CondicaoTermoCompromissoDAOSqlServerCustomImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<CondicoesTermoAceite> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOCondicaoTermoCompromisso> result = new List<TOCondicaoTermoCompromisso>();
            TOCondicaoTermoCompromisso transferObject = null;

            try
            {
                statement = "SELECT TSDBCOND_TRMO_COPS.COD_COND_TRMO_COPS, TSDBCOND_TRMO_COPS.DESC_COND_TRMO_COPS FROM TSDBCOND_TRMO_COPS TSDBCOND_TRMO_COPS WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOCondicaoTermoCompromisso();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.Codigo = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.Descricao = dataReader.GetString(1);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override CondicoesTermoAceite FindByKey(int codigo)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOCondicaoTermoCompromisso transferObject = null;

            try
            {
                statement = "SELECT TSDBCOND_TRMO_COPS.COD_COND_TRMO_COPS, TSDBCOND_TRMO_COPS.DESC_COND_TRMO_COPS FROM TSDBCOND_TRMO_COPS TSDBCOND_TRMO_COPS WITH(NOLOCK) WHERE TSDBCOND_TRMO_COPS.COD_COND_TRMO_COPS = @codigo";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigo", codigo));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOCondicaoTermoCompromisso();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.Codigo = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.Descricao = dataReader.GetString(1);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Remove uma entidade pela sua chave primária.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(CondicoesTermoAceite entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOCondicaoTermoCompromisso transferObject = TranslateToDTO(entity);

                statement = "DELETE FROM TSDBCOND_TRMO_COPS WHERE COD_COND_TRMO_COPS = @codigo";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave primária
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigo", transferObject.Codigo));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma instância em memória na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(CondicoesTermoAceite entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOCondicaoTermoCompromisso transferObject = TranslateToDTO(entity);

                statement = "UPDATE TSDBCOND_TRMO_COPS SET dESC_COND_TRMO_COPS = @descricao WHERE COD_COND_TRMO_COPS = @codigo";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que não estão na chave
                            if (transferObject.Descricao == null)
                            {
                                command.Parameters.Add(new SqlParameter("@descricao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@descricao", transferObject.Descricao));
                            }

                            // Chave primária
                            command.Parameters.Add(new SqlParameter("@codigo", transferObject.Codigo));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma instância em memória na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(CondicoesTermoAceite entity)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                TOCondicaoTermoCompromisso transferObject = TranslateToDTO(entity);

                statement = "INSERT INTO TSDBCOND_TRMO_COPS ( DESC_COND_TRMO_COPS ) VALUES ( @descricao )  ; SELECT SCOPE_IDENTITY();";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.Descricao == null)
                            {
                                command.Parameters.Add(new SqlParameter("@descricao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@descricao", transferObject.Descricao));
                            }

                            long initTime = System.DateTime.Now.Ticks;

                            entity.Codigo = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        protected override List<CondicoesTermoAceite> TranslateFromDTO(List<TOCondicaoTermoCompromisso> entityDTO)
        {
            var _lista = new List<CondicoesTermoAceite>();
            foreach (TOCondicaoTermoCompromisso et in entityDTO)
            {
                _lista.Add(TranslateFromDTO(et));
            }
            return _lista;
        }

        protected override CondicoesTermoAceite TranslateFromDTO(TOCondicaoTermoCompromisso entityDTO)
        {
            return new CondicoesTermoAceite()
            {
                Codigo = entityDTO.Codigo,
                Descricao = entityDTO.Descricao
            };
        }

        protected override List<TOCondicaoTermoCompromisso> TranslateToDTO(List<CondicoesTermoAceite> entity)
        {
            var _lista = new List<TOCondicaoTermoCompromisso>();
            foreach (CondicoesTermoAceite et in entity)
            {
                _lista.Add(TranslateToDTO(et));
            }
            return _lista;
        }

        protected override TOCondicaoTermoCompromisso TranslateToDTO(CondicoesTermoAceite entity)
        {
            return new TOCondicaoTermoCompromisso()
            {
                Codigo = entity.Codigo,
                Descricao = entity.Descricao
            };
        }
    }
}
