using System;
//using Framework.AcessoDados;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Impl.Dao
{
    /// <summary>
    /// Implementa��o de CondicaoTermoCompromissoDAO - SqlServer
    /// </summary>
    public abstract class CondicaoTermoCompromissoDAOSqlServerImpl : CondicaoTermoCompromissoDAO
    {
       
    } //CondicaoTermoCompromisso
}
