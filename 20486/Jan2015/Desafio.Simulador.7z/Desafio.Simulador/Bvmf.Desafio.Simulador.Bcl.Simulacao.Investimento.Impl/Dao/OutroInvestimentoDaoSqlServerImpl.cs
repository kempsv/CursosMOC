using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Impl.Dao
{

    /// <summary>
    /// Implementa��o de OutroInvestimentoDAO - SqlServer
    /// </summary>
    public class OutroInvestimentoDAOSqlServerImpl : OutroInvestimentoDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "OutroInvestimentoDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOOutroInvestimento> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOOutroInvestimento> result = new List<TOOutroInvestimento>();
            TOOutroInvestimento transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBOUTR_INVE.COD_OUTR_INVE, TSDBOUTR_INVE.NOME_ATIV_OUTR_INVE, TSDBOUTR_INVE.PERC_TAXA_RENT FROM TSDBOUTR_INVE TSDBOUTR_INVE WITH(NOLOCK)";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOOutroInvestimento();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoOutroInvestimento = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.NomeAtivoOutro = dataReader.GetString(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.PercentualTaxaRentabilidade = dataReader.GetDecimal(2);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TOOutroInvestimento FindByKey(int codigoOutroInvestimento)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOOutroInvestimento transferObject = null;

            try
            {
                statement = "SELECT TSDBOUTR_INVE.COD_OUTR_INVE, TSDBOUTR_INVE.NOME_ATIV_OUTR_INVE, TSDBOUTR_INVE.PERC_TAXA_RENT FROM TSDBOUTR_INVE TSDBOUTR_INVE WITH(NOLOCK) WHERE TSDBOUTR_INVE.COD_OUTR_INVE = @codigoOutroInvestimento";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoOutroInvestimento", codigoOutroInvestimento));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOOutroInvestimento();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoOutroInvestimento = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.NomeAtivoOutro = dataReader.GetString(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.PercentualTaxaRentabilidade = dataReader.GetDecimal(2);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Remove uma entidade pela sua chave prim�ria.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(TOOutroInvestimento transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBOUTR_INVE WHERE COD_OUTR_INVE = @codigoOutroInvestimento";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave prim�ria
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoOutroInvestimento", transferObject.CodigoOutroInvestimento));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma inst�ncia em mem�ria na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(TOOutroInvestimento transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "UPDATE TSDBOUTR_INVE SET nOME_ATIV_OUTR_INVE = @nomeAtivoOutro, pERC_TAXA_RENT = @percentualTaxaRentabilidade WHERE COD_OUTR_INVE = @codigoOutroInvestimento";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que n�o est�o na chave
                            if (transferObject.NomeAtivoOutro == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeAtivoOutro", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeAtivoOutro", transferObject.NomeAtivoOutro));
                            }

                            if (transferObject.PercentualTaxaRentabilidade == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@percentualTaxaRentabilidade", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@percentualTaxaRentabilidade", transferObject.PercentualTaxaRentabilidade));
                            }

                            // Chave prim�ria
                            command.Parameters.Add(new SqlParameter("@codigoOutroInvestimento", transferObject.CodigoOutroInvestimento));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TOOutroInvestimento transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBOUTR_INVE ( NOME_ATIV_OUTR_INVE, PERC_TAXA_RENT ) VALUES ( @nomeAtivoOutro, @percentualTaxaRentabilidade )  ; SELECT SCOPE_IDENTITY();";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.NomeAtivoOutro == null)
                            {
                                command.Parameters.Add(new SqlParameter("@nomeAtivoOutro", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@nomeAtivoOutro", transferObject.NomeAtivoOutro));
                            }

                            if (transferObject.PercentualTaxaRentabilidade == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@percentualTaxaRentabilidade", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@percentualTaxaRentabilidade", transferObject.PercentualTaxaRentabilidade));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            transferObject.CodigoOutroInvestimento = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }


    } //OutroInvestimento
}
