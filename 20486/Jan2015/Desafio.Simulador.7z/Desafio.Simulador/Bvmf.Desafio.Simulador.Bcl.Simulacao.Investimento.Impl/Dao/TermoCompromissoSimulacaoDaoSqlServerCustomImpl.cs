﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade;
using System.Collections.Generic;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Core.Domain.Enum;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Impl.Dao
{
    public class TermoCompromissoSimulacaoDAOSqlServerCustomImpl : TermoCompromissoSimulacaoDAOSqlServerImpl
    {
        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "TermoCompromissoSimulacaoDAOSqlServerCustomImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TermoAceiteSimulacao> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOTermoCompromissoSimulacao> result = new List<TOTermoCompromissoSimulacao>();
            TOTermoCompromissoSimulacao transferObject = null;

            try
            {
                statement = "SELECT TSDBTRMO_COPS_SIMU.COD_TRMO_COPS, TSDBTRMO_COPS_SIMU.DESC_TRMO_COPS FROM TSDBTRMO_COPS_SIMU TSDBTRMO_COPS_SIMU WITH(NOLOCK)";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOTermoCompromissoSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.Codigo = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.Descricao = dataReader.GetString(1);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return TranslateFromDTO(result);
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TermoAceiteSimulacao FindByKey(int codigo)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOTermoCompromissoSimulacao transferObject = null;

            try
            {
                statement = "SELECT TSDBTRMO_COPS_SIMU.COD_TRMO_COPS, TSDBTRMO_COPS_SIMU.DESC_TRMO_COPS FROM TSDBTRMO_COPS_SIMU TSDBTRMO_COPS_SIMU WITH(NOLOCK) WHERE TSDBTRMO_COPS_SIMU.COD_TRMO_COPS = @codigo";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigo", codigo));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOTermoCompromissoSimulacao();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.Codigo = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.Descricao = dataReader.GetString(1);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

            return TranslateFromDTO(transferObject);
        }

        /// <summary>
        /// Remove uma entidade pela sua chave primária.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(TermoAceiteSimulacao entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOTermoCompromissoSimulacao transferObject = TranslateToDTO(entity);

                statement = "DELETE FROM TSDBTRMO_COPS_SIMU WHERE COD_TRMO_COPS = @codigo";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave primária
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigo", transferObject.Codigo));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma instância em memória na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(TermoAceiteSimulacao entity)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                TOTermoCompromissoSimulacao transferObject = TranslateToDTO(entity);

                statement = "UPDATE TSDBTRMO_COPS_SIMU SET dESC_TRMO_COPS = @descricao WHERE COD_TRMO_COPS = @codigo";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que não estão na chave
                            if (transferObject.Descricao == null)
                            {
                                command.Parameters.Add(new SqlParameter("@descricao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@descricao", transferObject.Descricao));
                            }

                            // Chave primária
                            command.Parameters.Add(new SqlParameter("@codigo", transferObject.Codigo));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma instância em memória na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TermoAceiteSimulacao entity)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                TOTermoCompromissoSimulacao transferObject = TranslateToDTO(entity);

                statement = "INSERT INTO TSDBTRMO_COPS_SIMU ( DESC_TRMO_COPS ) VALUES ( @descricao )  ; SELECT SCOPE_IDENTITY();";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.Descricao == null)
                            {
                                command.Parameters.Add(new SqlParameter("@descricao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@descricao", transferObject.Descricao));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            entity.Codigo = Convert.ToInt32(command.ExecuteScalar());
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        protected override List<TermoAceiteSimulacao> TranslateFromDTO(List<TOTermoCompromissoSimulacao> entityDTO)
        {
            var _lista = new List<TermoAceiteSimulacao>();
            foreach (TOTermoCompromissoSimulacao et in entityDTO)
            {
                _lista.Add(TranslateFromDTO(et));
            }
            return _lista;
        }

        protected override TermoAceiteSimulacao TranslateFromDTO(TOTermoCompromissoSimulacao entityDTO)
        {
            return entityDTO == null ? null : new TermoAceiteSimulacao()
            {
                Codigo = entityDTO.Codigo,
                Descricao = entityDTO.Descricao,
                TipoModoSimulacao = entityDTO.Descricao == "Web" ? TipoModoSimulacao.Web : TipoModoSimulacao.Presencial
            };
        }

        protected override List<TOTermoCompromissoSimulacao> TranslateToDTO(List<TermoAceiteSimulacao> entity)
        {
            var _lista = new List<TOTermoCompromissoSimulacao>();
            foreach (TermoAceiteSimulacao et in entity)
            {
                _lista.Add(TranslateToDTO(et));
            }
            return _lista;
        }

        protected override TOTermoCompromissoSimulacao TranslateToDTO(TermoAceiteSimulacao entity)
        {
            return entity == null ? null : new TOTermoCompromissoSimulacao()
            {
                Codigo = entity.Codigo,
                Descricao = entity.Descricao
            };
        }
    }
}
