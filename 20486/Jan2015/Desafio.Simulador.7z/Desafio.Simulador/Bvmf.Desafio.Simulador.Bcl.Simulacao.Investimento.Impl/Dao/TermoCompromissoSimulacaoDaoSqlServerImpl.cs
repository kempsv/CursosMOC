using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade;
using System.Collections.Generic;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Impl.Dao
{
    
    /// <summary>
    /// Implementa��o de TermoCompromissoSimulacaoDAO - SqlServer
    /// </summary>
    public abstract class TermoCompromissoSimulacaoDAOSqlServerImpl : TermoCompromissoSimulacaoDAO
    {
       
    } //TermoCompromissoSimulacao
}
