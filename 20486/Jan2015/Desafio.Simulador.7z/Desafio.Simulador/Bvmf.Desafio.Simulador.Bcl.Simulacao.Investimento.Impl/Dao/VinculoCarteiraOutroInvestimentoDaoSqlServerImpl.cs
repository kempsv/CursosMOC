using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Impl.Dao
{

    /// <summary>
    /// Implementa��o de VinculoCarteiraOutroInvestimentoDAO - SqlServer
    /// </summary>
    public class VinculoCarteiraOutroInvestimentoDAOSqlServerImpl : VinculoCarteiraOutroInvestimentoDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "VinculoCarteiraOutroInvestimentoDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOVinculoCarteiraOutroInvestimento> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOVinculoCarteiraOutroInvestimento> result = new List<TOVinculoCarteiraOutroInvestimento>();
            TOVinculoCarteiraOutroInvestimento transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBVINC_CART_OUTR_INVE.COD_CART, TSDBVINC_CART_OUTR_INVE.COD_OUTR_INVE, TSDBVINC_CART_OUTR_INVE.VAL_FIM_INVE_OUTR_INVE, TSDBVINC_CART_OUTR_INVE.VAL_INVE_OUTR_INVE FROM TSDBVINC_CART_OUTR_INVE TSDBVINC_CART_OUTR_INVE WITH(NOLOCK)";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOVinculoCarteiraOutroInvestimento();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCarteira = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoOutroInvestimento = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.ValorFinalOutroInvestimento = dataReader.GetDecimal(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.ValorInvestidoOutroInvestimento = dataReader.GetDecimal(3);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TOVinculoCarteiraOutroInvestimento FindByKey(int codigoCarteira, int codigoOutroInvestimento)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOVinculoCarteiraOutroInvestimento transferObject = null;

            try
            {
                statement = "SELECT TSDBVINC_CART_OUTR_INVE.COD_CART, TSDBVINC_CART_OUTR_INVE.COD_OUTR_INVE, TSDBVINC_CART_OUTR_INVE.VAL_FIM_INVE_OUTR_INVE, TSDBVINC_CART_OUTR_INVE.VAL_INVE_OUTR_INVE FROM TSDBVINC_CART_OUTR_INVE TSDBVINC_CART_OUTR_INVE WITH(NOLOCK) WHERE TSDBVINC_CART_OUTR_INVE.COD_CART = @codigoCarteira AND TSDBVINC_CART_OUTR_INVE.COD_OUTR_INVE = @codigoOutroInvestimento";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoCarteira", codigoCarteira));

                                command.Parameters.Add(new SqlParameter("@codigoOutroInvestimento", codigoOutroInvestimento));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOVinculoCarteiraOutroInvestimento();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCarteira = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoOutroInvestimento = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.ValorFinalOutroInvestimento = dataReader.GetDecimal(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.ValorInvestidoOutroInvestimento = dataReader.GetDecimal(3);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Lista todos os OutrosInvestimentos de uma carteira
        /// </summary>
        /// <param name="codigoCarteira"></param>        
        /// <returns></returns>
        public override List<TOVinculoCarteiraOutroInvestimento> FindOutrosInvestimentosByCarteira(int codigoCarteira)
        {
            string statement = "";
            IDbCommand command;
            List<TOVinculoCarteiraOutroInvestimento> result = new List<TOVinculoCarteiraOutroInvestimento>();
            IDataReader dataReader = null;
            TOVinculoCarteiraOutroInvestimento transferObject = null;

            try
            {
                statement = "SELECT TSDBVINC_CART_OUTR_INVE.COD_CART, TSDBVINC_CART_OUTR_INVE.COD_OUTR_INVE, TSDBVINC_CART_OUTR_INVE.VAL_FIM_INVE_OUTR_INVE, TSDBVINC_CART_OUTR_INVE.VAL_INVE_OUTR_INVE FROM TSDBVINC_CART_OUTR_INVE TSDBVINC_CART_OUTR_INVE WITH(NOLOCK) WHERE TSDBVINC_CART_OUTR_INVE.COD_CART = @codigoCarteira";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoCarteira", codigoCarteira));


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOVinculoCarteiraOutroInvestimento();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCarteira = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoOutroInvestimento = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.ValorFinalOutroInvestimento = dataReader.GetDecimal(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.ValorInvestidoOutroInvestimento = dataReader.GetDecimal(3);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Exclui o v�nculo pelo c�digo da Carteira
        /// </summary>
        public override void DeleteByCarteira(int codigoCarteira)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBVINC_CART_OUTR_INVE WHERE COD_CART = " + codigoCarteira + "";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TOVinculoCarteiraOutroInvestimento transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBVINC_CART_OUTR_INVE ( COD_CART, COD_OUTR_INVE, VAL_FIM_INVE_OUTR_INVE, VAL_INVE_OUTR_INVE ) VALUES ( @codigoCarteira, @codigoOutroInvestimento, @valorFinalOutroInvestimento, @valorInvestidoOutroInvestimento ) ";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoCarteira == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCarteira", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCarteira", transferObject.CodigoCarteira));
                            }

                            if (transferObject.CodigoOutroInvestimento == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoOutroInvestimento", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoOutroInvestimento", transferObject.CodigoOutroInvestimento));
                            }

                            if (transferObject.ValorFinalOutroInvestimento == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorFinalOutroInvestimento", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorFinalOutroInvestimento", transferObject.ValorFinalOutroInvestimento));
                            }

                            if (transferObject.ValorInvestidoOutroInvestimento == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorInvestidoOutroInvestimento", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorInvestidoOutroInvestimento", transferObject.ValorInvestidoOutroInvestimento));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }


    } //VinculoCarteiraOutroInvestimento
}
