using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Impl.Dao
{

    /// <summary>
    /// Implementa��o de VinculoCarteiraPapelDAO - SqlServer
    /// </summary>
    public class VinculoCarteiraPapelDAOSqlServerImpl : VinculoCarteiraPapelDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "VinculoCarteiraPapelDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOVinculoCarteiraPapel> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOVinculoCarteiraPapel> result = new List<TOVinculoCarteiraPapel>();
            TOVinculoCarteiraPapel transferObject = null;

            try
            {
                statement = "SELECT TOP 1000 TSDBVINC_CART_PAP.COD_CART, TSDBVINC_CART_PAP.COD_PAP, TSDBVINC_CART_PAP.QTE_PAP_NEG, TSDBVINC_CART_PAP.VAL_FIM_INVE_PAP, TSDBVINC_CART_PAP.VAL_INVE_PAP, TSDBVINC_CART_PAP.VAL_PREC_CPA_PAP, TSDBVINC_CART_PAP.VAL_PREC_FIM_PAP, TSDBVINC_CART_PAP.VAL_RENT_PAP FROM TSDBVINC_CART_PAP TSDBVINC_CART_PAP WITH(NOLOCK)";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOVinculoCarteiraPapel();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCarteira = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoPapel = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.QuantidadePapelNegociado = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.ValorFinalInvestido = dataReader.GetDecimal(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.ValorInvestido = dataReader.GetDecimal(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.ValorPrecoCompra = dataReader.GetDecimal(5);
                                    }
                                    if (!dataReader.IsDBNull(6))
                                    {
                                        transferObject.ValorPrecoFinal = dataReader.GetDecimal(6);
                                    }
                                    if (!dataReader.IsDBNull(7))
                                    {
                                        transferObject.ValorRentabilidade = dataReader.GetDecimal(7);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TOVinculoCarteiraPapel FindByKey(int codigoCarteira, int codigoPapel)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOVinculoCarteiraPapel transferObject = null;

            try
            {
                statement = "SELECT TSDBVINC_CART_PAP.COD_CART, TSDBVINC_CART_PAP.COD_PAP, TSDBVINC_CART_PAP.QTE_PAP_NEG, TSDBVINC_CART_PAP.VAL_FIM_INVE_PAP, TSDBVINC_CART_PAP.VAL_INVE_PAP, TSDBVINC_CART_PAP.VAL_PREC_CPA_PAP, TSDBVINC_CART_PAP.VAL_PREC_FIM_PAP, TSDBVINC_CART_PAP.VAL_RENT_PAP FROM TSDBVINC_CART_PAP TSDBVINC_CART_PAP WITH(NOLOCK) WHERE TSDBVINC_CART_PAP.COD_CART = @codigoCarteira AND TSDBVINC_CART_PAP.COD_PAP = @codigoPapel";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoCarteira", codigoCarteira));

                                command.Parameters.Add(new SqlParameter("@codigoPapel", codigoPapel));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOVinculoCarteiraPapel();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCarteira = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoPapel = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.QuantidadePapelNegociado = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.ValorFinalInvestido = dataReader.GetDecimal(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.ValorInvestido = dataReader.GetDecimal(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.ValorPrecoCompra = dataReader.GetDecimal(5);
                                    }
                                    if (!dataReader.IsDBNull(6))
                                    {
                                        transferObject.ValorPrecoFinal = dataReader.GetDecimal(6);
                                    }
                                    if (!dataReader.IsDBNull(7))
                                    {
                                        transferObject.ValorRentabilidade = dataReader.GetDecimal(7);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>        
        public override List<TOVinculoCarteiraPapel> FindPapeisByCarteira(int codigoCarteira)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOVinculoCarteiraPapel> result = new List<TOVinculoCarteiraPapel>();
            TOVinculoCarteiraPapel transferObject = null;

            try
            {
                statement = "SELECT TSDBVINC_CART_PAP.COD_CART, TSDBVINC_CART_PAP.COD_PAP, TSDBVINC_CART_PAP.QTE_PAP_NEG, TSDBVINC_CART_PAP.VAL_FIM_INVE_PAP, TSDBVINC_CART_PAP.VAL_INVE_PAP, TSDBVINC_CART_PAP.VAL_PREC_CPA_PAP, TSDBVINC_CART_PAP.VAL_PREC_FIM_PAP, TSDBVINC_CART_PAP.VAL_RENT_PAP FROM TSDBVINC_CART_PAP TSDBVINC_CART_PAP WITH(NOLOCK) WHERE TSDBVINC_CART_PAP.COD_CART = @codigoCarteira";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoCarteira", codigoCarteira));


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOVinculoCarteiraPapel();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoCarteira = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoPapel = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.QuantidadePapelNegociado = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.ValorFinalInvestido = dataReader.GetDecimal(3);
                                    }
                                    if (!dataReader.IsDBNull(4))
                                    {
                                        transferObject.ValorInvestido = dataReader.GetDecimal(4);
                                    }
                                    if (!dataReader.IsDBNull(5))
                                    {
                                        transferObject.ValorPrecoCompra = dataReader.GetDecimal(5);
                                    }
                                    if (!dataReader.IsDBNull(6))
                                    {
                                        transferObject.ValorPrecoFinal = dataReader.GetDecimal(6);
                                    }
                                    if (!dataReader.IsDBNull(7))
                                    {
                                        transferObject.ValorRentabilidade = dataReader.GetDecimal(7);
                                    }

                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Exclui o Vinculo pelo c�digo da Carteira
        /// </summary>
        public override void DeleteByCarteira(int codigoCarteira)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBVINC_CART_PAP WHERE COD_CART = " + codigoCarteira + "";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TOVinculoCarteiraPapel transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBVINC_CART_PAP ( COD_CART, COD_PAP, QTE_PAP_NEG, VAL_FIM_INVE_PAP, VAL_INVE_PAP, VAL_PREC_CPA_PAP, VAL_PREC_FIM_PAP, VAL_RENT_PAP ) VALUES ( @codigoCarteira, @codigoPapel, @quantidadePapelNegociado, @valorFinalInvestido, @valorInvestido, @valorPrecoCompra, @valorPrecoFinal, @valorRentabilidade ) ";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoCarteira == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCarteira", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCarteira", transferObject.CodigoCarteira));
                            }

                            if (transferObject.CodigoPapel == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoPapel", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoPapel", transferObject.CodigoPapel));
                            }

                            if (transferObject.QuantidadePapelNegociado == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@quantidadePapelNegociado", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@quantidadePapelNegociado", transferObject.QuantidadePapelNegociado));
                            }

                            if (transferObject.ValorFinalInvestido == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorFinalInvestido", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorFinalInvestido", transferObject.ValorFinalInvestido));
                            }

                            if (transferObject.ValorInvestido == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorInvestido", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorInvestido", transferObject.ValorInvestido));
                            }

                            if (transferObject.ValorPrecoCompra == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorPrecoCompra", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorPrecoCompra", transferObject.ValorPrecoCompra));
                            }

                            if (transferObject.ValorPrecoFinal == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorPrecoFinal", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorPrecoFinal", transferObject.ValorPrecoFinal));
                            }

                            if (transferObject.ValorRentabilidade == decimal.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@valorRentabilidade", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@valorRentabilidade", transferObject.ValorRentabilidade));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }


    } //VinculoCarteiraPapel
}
