using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Impl.Dao
{

    /// <summary>
    /// Implementa��o de VinculoCondicaoTermoCompromissoDAO - SqlServer
    /// </summary>
    public class VinculoCondicaoTermoCompromissoDAOSqlServerImpl : VinculoCondicaoTermoCompromissoDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "VinculoCondicaoTermoCompromissoDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOVinculoCondicaoTermoCompromisso> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOVinculoCondicaoTermoCompromisso> result = new List<TOVinculoCondicaoTermoCompromisso>();
            TOVinculoCondicaoTermoCompromisso transferObject = null;

            try
            {
                statement = "SELECT TSDBCOND_TRMO_COPS_SIMU.COD_TRMO_COPS, TSDBCOND_TRMO_COPS_SIMU.COD_COND_TRMO_COPS FROM TSDBCOND_TRMO_COPS_SIMU TSDBCOND_TRMO_COPS_SIMU WITH(NOLOCK)";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOVinculoCondicaoTermoCompromisso();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoTermoCompromisso = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoCondicaoTermoCompromisso = dataReader.GetInt32(1);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TOVinculoCondicaoTermoCompromisso FindByKey(int codigoTermoCompromisso, int codigoCondicaoTermoCompromisso)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOVinculoCondicaoTermoCompromisso transferObject = null;

            try
            {
                statement = "SELECT TSDBCOND_TRMO_COPS_SIMU.COD_TRMO_COPS, TSDBCOND_TRMO_COPS_SIMU.COD_COND_TRMO_COPS FROM TSDBCOND_TRMO_COPS_SIMU TSDBCOND_TRMO_COPS_SIMU WITH(NOLOCK) WHERE TSDBCOND_TRMO_COPS_SIMU.COD_TRMO_COPS = @codigoTermoCompromisso AND TSDBCOND_TRMO_COPS_SIMU.COD_COND_TRMO_COPS = @codigoCondicaoTermoCompromisso";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoTermoCompromisso", codigoTermoCompromisso));

                                command.Parameters.Add(new SqlParameter("@codigoCondicaoTermoCompromisso", codigoCondicaoTermoCompromisso));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOVinculoCondicaoTermoCompromisso();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoTermoCompromisso = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoCondicaoTermoCompromisso = dataReader.GetInt32(1);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Remove uma entidade pela sua chave prim�ria.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(TOVinculoCondicaoTermoCompromisso transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBCOND_TRMO_COPS_SIMU WHERE COD_TRMO_COPS = @codigoTermoCompromisso AND COD_COND_TRMO_COPS = @codigoCondicaoTermoCompromisso";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave prim�ria
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoTermoCompromisso", transferObject.CodigoTermoCompromisso));
                            command.Parameters.Add(new SqlParameter("@codigoCondicaoTermoCompromisso", transferObject.CodigoCondicaoTermoCompromisso));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Remove todos os Termos de Aceite de uma determinada condi��o de termo de compromisso da simula��o
        /// </summary>
        /// <param>Codigo da Condi��o do Termo de Aceite</param>
        public override void DeleteAllTermoAceite(int codigoCondicaoTermoCompromisso)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBCOND_TRMO_COPS_SIMU WHERE COD_COND_TRMO_COPS = @codigoCondicaoTermoCompromisso";

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave prim�ria
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoCondicaoTermoCompromisso", codigoCondicaoTermoCompromisso));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }
        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TOVinculoCondicaoTermoCompromisso transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBCOND_TRMO_COPS_SIMU ( COD_TRMO_COPS, COD_COND_TRMO_COPS ) VALUES ( @codigoTermoCompromisso, @codigoCondicaoTermoCompromisso ) ";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoTermoCompromisso == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTermoCompromisso", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTermoCompromisso", transferObject.CodigoTermoCompromisso));
                            }

                            if (transferObject.CodigoCondicaoTermoCompromisso == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCondicaoTermoCompromisso", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoCondicaoTermoCompromisso", transferObject.CodigoCondicaoTermoCompromisso));
                            }


                            long initTime = System.DateTime.Now.Ticks;

                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

    } //VinculoCondicaoTermoCompromisso
}
