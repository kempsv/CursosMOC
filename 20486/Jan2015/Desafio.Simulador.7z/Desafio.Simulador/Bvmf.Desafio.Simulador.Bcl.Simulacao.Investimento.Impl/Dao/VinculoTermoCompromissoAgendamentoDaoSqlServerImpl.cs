using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
//using Framework.AcessoDados;
//using Framework.AcessoDados.Impl;
//using Framework.Log;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade;
using System.Collections.Generic;
using System.Transactions;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Impl.Dao
{

    /// <summary>
    /// Implementa��o de VinculoTermoCompromissoAgendamentoDAO - SqlServer
    /// </summary>
    public class VinculoTermoCompromissoAgendamentoDAOSqlServerImpl : VinculoTermoCompromissoAgendamentoDAO
    {

        // Nome da classe. Utilizado para log.
        private const string CLASS_NAME = "VinculoTermoCompromissoAgendamentoDAOSqlServerImpl";

        /// <summary>
        /// Busca todas as entidades
        /// </summary>
        /// <returns>Todas as entidades</returns>
        public override List<TOVinculoTermoCompromissoAgendamento> FindAll()
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            List<TOVinculoTermoCompromissoAgendamento> result = new List<TOVinculoTermoCompromissoAgendamento>();
            TOVinculoTermoCompromissoAgendamento transferObject = null;

            try
            {
                statement = "SELECT TSDBVINC_TRMO_COPS_AGDA.COD_GRUP_ESCL, TSDBVINC_TRMO_COPS_AGDA.COD_AGDA_SIMU, TSDBVINC_TRMO_COPS_AGDA.COD_TRMO_COPS, TSDBVINC_TRMO_COPS_AGDA.IND_ACEI_TRMO_COPS FROM TSDBVINC_TRMO_COPS_AGDA TSDBVINC_TRMO_COPS_AGDA WITH(NOLOCK)";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                while (dataReader.Read())
                                {
                                    transferObject = new TOVinculoTermoCompromissoAgendamento();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoAgendaSimulacao = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoTermoCompromisso = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.IndicadorTermoAceito = dataReader.GetBoolean(3);
                                    }
                                    result.Add(transferObject);
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return result;
        }

        /// <summary>
        /// Busca uma entidade pela sua chave.
        /// </summary>
        /// <param>Chave de busca</param>
        /// <returns>A entidade referenciada pela chave.</returns>
        public override TOVinculoTermoCompromissoAgendamento FindByKey(int codigoGrupoEscolar, int codigoAgendaSimulacao)
        {
            string statement = "";
            IDbCommand command;
            IDataReader dataReader = null;
            TOVinculoTermoCompromissoAgendamento transferObject = null;

            try
            {
                statement = "SELECT TSDBVINC_TRMO_COPS_AGDA.COD_GRUP_ESCL, TSDBVINC_TRMO_COPS_AGDA.COD_AGDA_SIMU, TSDBVINC_TRMO_COPS_AGDA.COD_TRMO_COPS, TSDBVINC_TRMO_COPS_AGDA.IND_ACEI_TRMO_COPS FROM TSDBVINC_TRMO_COPS_AGDA TSDBVINC_TRMO_COPS_AGDA WITH(NOLOCK) WHERE TSDBVINC_TRMO_COPS_AGDA.COD_GRUP_ESCL = @codigoGrupoEscolar AND TSDBVINC_TRMO_COPS_AGDA.COD_AGDA_SIMU = @codigoAgendaSimulacao";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    try
                    {
                        using (IDbConnection connection = base.GetConnection())
                        {
                            connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                            {


                                // Parametros
                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", codigoGrupoEscolar));

                                command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", codigoAgendaSimulacao));

                                long initTime = System.DateTime.Now.Ticks;
                                dataReader = command.ExecuteReader();
                                long endTime = System.DateTime.Now.Ticks;

                                if (dataReader.Read())
                                {
                                    transferObject = new TOVinculoTermoCompromissoAgendamento();
                                    if (!dataReader.IsDBNull(0))
                                    {
                                        transferObject.CodigoGrupoEscolar = dataReader.GetInt32(0);
                                    }
                                    if (!dataReader.IsDBNull(1))
                                    {
                                        transferObject.CodigoAgendaSimulacao = dataReader.GetInt32(1);
                                    }
                                    if (!dataReader.IsDBNull(2))
                                    {
                                        transferObject.CodigoTermoCompromisso = dataReader.GetInt32(2);
                                    }
                                    if (!dataReader.IsDBNull(3))
                                    {
                                        transferObject.IndicadorTermoAceito = dataReader.GetBoolean(3);
                                    }
                                }
                                dataReader.Close();
                                scope.Complete();
                            }
                        }
                    }
                    catch (Exception except)
                    {
                        if (dataReader != null) dataReader.Close();
                        throw except;
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }


            return transferObject;
        }

        /// <summary>
        /// Remove uma entidade pela sua chave prim�ria.
        /// </summary>
        /// <param>Entidade a ser deletada</param>
        public override void Delete(TOVinculoTermoCompromissoAgendamento transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "DELETE FROM TSDBVINC_TRMO_COPS_AGDA WHERE COD_GRUP_ESCL = @codigoGrupoEscolar AND COD_AGDA_SIMU = @codigoAgendaSimulacao AND COD_TRMO_COPS = @codigoTermoCompromisso";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Chave prim�ria
                            // Parametros
                            command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", transferObject.CodigoGrupoEscolar));
                            command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", transferObject.CodigoAgendaSimulacao));
                            command.Parameters.Add(new SqlParameter("@codigoTermoCompromisso", transferObject.CodigoTermoCompromisso));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Atualiza os valores de uma inst�ncia em mem�ria na fonte de dados
        /// </summary>
        /// <param>Entidade a ser alterada</param>
        public override void Update(TOVinculoTermoCompromissoAgendamento transferObject)
        {
            IDbCommand command;
            string statement = "";

            try
            {
                statement = "UPDATE TSDBVINC_TRMO_COPS_AGDA SET iND_ACEI_TRMO_COPS = @indicadorTermoAceito WHERE COD_GRUP_ESCL = @codigoGrupoEscolar AND COD_AGDA_SIMU = @codigoAgendaSimulacao AND COD_TRMO_COPS = @codigoTermoCompromisso";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            // Parametros que n�o est�o na chave
                            command.Parameters.Add(new SqlParameter("@indicadorTermoAceito", transferObject.IndicadorTermoAceito));

                            // Chave prim�ria
                            command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", transferObject.CodigoGrupoEscolar));
                            command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", transferObject.CodigoAgendaSimulacao));
                            command.Parameters.Add(new SqlParameter("@codigoTermoCompromisso", transferObject.CodigoTermoCompromisso));

                            long initTime = System.DateTime.Now.Ticks;
                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

        /// <summary>
        /// Persiste (cria) uma inst�ncia em mem�ria na fonte de dados.
        /// </summary>
        /// <param>Entidade a ser persistida</param>
        public override void Create(TOVinculoTermoCompromissoAgendamento transferObject)
        {
            string statement = "";
            IDbCommand command;

            try
            {
                statement = "INSERT INTO TSDBVINC_TRMO_COPS_AGDA ( COD_GRUP_ESCL, COD_AGDA_SIMU, COD_TRMO_COPS, IND_ACEI_TRMO_COPS ) VALUES ( @codigoGrupoEscolar, @codigoAgendaSimulacao, @codigoTermoCompromisso, @indicadorTermoAceito ) ";
                command = new SqlCommand(statement);
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, base.GetTransactionOptions()))
                {
                    using (IDbConnection connection = base.GetConnection())
                    {
                        connection.Open(); using (command = new SqlCommand(statement, (SqlConnection)connection))
                        {


                            if (transferObject.CodigoGrupoEscolar == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoGrupoEscolar", transferObject.CodigoGrupoEscolar));
                            }

                            if (transferObject.CodigoAgendaSimulacao == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoAgendaSimulacao", transferObject.CodigoAgendaSimulacao));
                            }

                            if (transferObject.CodigoTermoCompromisso == int.MinValue)
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTermoCompromisso", DBNull.Value));
                            }
                            else
                            {
                                command.Parameters.Add(new SqlParameter("@codigoTermoCompromisso", transferObject.CodigoTermoCompromisso));
                            }

                            command.Parameters.Add(new SqlParameter("@indicadorTermoAceito", transferObject.IndicadorTermoAceito));


                            long initTime = System.DateTime.Now.Ticks;

                            command.ExecuteNonQuery();
                            long endTime = System.DateTime.Now.Ticks;

                            scope.Complete();
                        }
                    }
                }

            }
            catch (Exception except)
            {
                LogManager.Error(except.Message + " - statement[" + statement + "]", except);
                throw except;
            }

        }

    } //VinculoTermoCompromissoAgendamento
}
