﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Entidade;

namespace Desafio.Simulador.Bcl.Simulacao.Investimento.Interfaces
{
    public abstract class BCTermoAceiteSimulacao : BCEntityPersistence<CondicoesTermoAceite, TOCondicaoTermoCompromisso>
    {
        public abstract TermoAceiteSimulacao ObterTermoAceiteSimulacao(AgendaSimulacao agendaSimulacao, GrupoEscolar grupoEscolar);

        public abstract void AceitarTermoSimulacao(TermoAceiteSimulacao termoAceiteSimulacao);
    }
}
