﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity.InterceptionExtension;
using Microsoft.Practices.Unity;

namespace Desafio.Simulador.Bsl.Competidor.Impl
{
    /// <summary>
    /// Faz a validação das Escolas Classificadas e enviadas pelo LMS antes de integrar no Simulador.
    /// Verifica se todas as agregações foram enviadas corretamente
    /// </summary>
    public class ValidarAgregacoesEscolasClassificadasAttribute: HandlerAttribute
    {
        public override ICallHandler CreateHandler(IUnityContainer container)
        {
            return new ValidarAgregacoesEscolasClassificadasHandler();
        }
    }
}
