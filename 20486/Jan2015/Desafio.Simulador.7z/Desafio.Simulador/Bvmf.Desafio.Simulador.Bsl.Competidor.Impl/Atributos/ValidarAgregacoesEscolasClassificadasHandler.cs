﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity.InterceptionExtension;
using System.Reflection;
using Desafio.Simulador.Util.Excecao;
//using Framework.Excecao;
using Desafio.Simulador.Util.Logger;
using Desafio.Simulador.Bsl.Comum.Dto;

namespace Desafio.Simulador.Bsl.Competidor.Impl
{
    public class ValidarAgregacoesEscolasClassificadasHandler : ICallHandler
    {
        #region ICallHandler Members

        public IMethodReturn Invoke(IMethodInvocation input, GetNextHandlerDelegate getNext)
        {
            for (int i = 0; i < input.Inputs.Count; i++)
            {
                object target = input.Inputs[i];
                if (target == null)
                {
                    ParameterInfo parameterInfo = input.Inputs.GetParameterInfo(i);
                    ArgumentNullException ex = new ArgumentNullException(parameterInfo.Name, "Parâmetro de entrada não pode ser Nulo");

                    LogManager.Error("Assembly [ " + ((System.Reflection.MemberInfo)input.MethodBase).ReflectedType.FullName + "." + input.MethodBase.Name + "() ] ", ex.Message.Replace("\r\n", ". "));

                    return input.CreateExceptionMethodReturn(ex);
                }
                else 
                {
                    List<EscolaDTO> _escolasDTO = (List<EscolaDTO>)target;
                    //
                    //Faz validação dos grupos escolares a serem integrados
                    //
                    foreach(EscolaDTO escolaDTO in _escolasDTO)
                    {
                        if (escolaDTO.GruposEscolares == null)
                            return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Lista de Grupos Escolares" }));
                        else if (escolaDTO.GruposEscolares.Count == 0)
                            return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Lista de Grupos Escolares" }));

                        if (escolaDTO.Telefones == null)
                            return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Lista de Telefones da Escola" }));
                        else if (escolaDTO.Telefones.Count == 0)
                            return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Lista de Telefones da Escola" }));

                        if (escolaDTO.Diretor == null)
                            return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Diretor da Escola" }));

                        foreach (GrupoEscolarDTO grupoEscolar in escolaDTO.GruposEscolares) 
                        {
                            if (grupoEscolar.AgendaSimulacao == null)
                                return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Agenda de Simulação do Grupo Escolar" }));
                            else if (grupoEscolar.AgendaSimulacao.Count == 0)
                                return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Agenda de Simulação do Grupo Escolar" }));

                            if (grupoEscolar.Professor == null)
                                return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Professor do Grupos Escolar" }));

                            if (grupoEscolar.Professor.Documentos == null)
                                return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Lista de Documentos Professor do Grupo Escolar" }));
                            else if (grupoEscolar.Professor.Documentos.Count == 0)
                                return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Lista de Documentos Professor do Grupo Escolar" }));

                            if (grupoEscolar.Professor.Telefones == null)
                                return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Lista de Tefefones Professor do Grupo Escolar" }));
                            else if (grupoEscolar.Professor.Telefones.Count == 0)
                                return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Lista de Tefefones Professor do Grupo Escolar" }));

                            if (grupoEscolar.Alunos == null)
                                return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Lista de Alunos do Grupo Escolar" }));
                            else if (grupoEscolar.Alunos.Count == 0)
                                return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Lista de Alunos do Grupo Escolar" }));

                            foreach (AlunoDTO aluno in grupoEscolar.Alunos) 
                            {
                                if (aluno.Documentos == null)
                                    return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Lista de Documentos do Auno" }));
                                else if (aluno.Documentos.Count == 0)
                                    return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Lista de Documentos do Auno" }));

                                if (aluno.Telefones == null)
                                    return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Lista de Telefones do Auno" }));
                                else if (aluno.Telefones.Count == 0)
                                    return input.CreateExceptionMethodReturn(new FxApplicationException("ERR_MSG0002", new object[] { "Lista de Telefones do Auno" }));
                            }
                        }
                    }
                }
            }
            return getNext()(input, getNext);
        }

        public int Order
        {
            get;
            set;
        }

        #endregion
    }
}
