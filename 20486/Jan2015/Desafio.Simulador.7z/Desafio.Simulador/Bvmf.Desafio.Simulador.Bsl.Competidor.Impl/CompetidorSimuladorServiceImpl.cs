﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Activation;
using System.ServiceModel;
using Microsoft.Practices.Unity;

using Desafio.Simulador.Bsl.Integrador.Interfaces;
using Desafio.Simulador.Bsl.Competidor.Interfaces;
using Desafio.Simulador.Bcl.Competidor.Interfaces;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Util.Logger;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Core.Domain.Enum;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bsl.Comum.Extensions;
using Desafio.Simulador.Bsl.Comum.Dto;
//using Framework.Excecao;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Interfaces;

namespace Desafio.Simulador.Bsl.Competidor.Impl
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(Namespace = "Desafio.Simulador.Bsl.Competidor.Impl.CompetidorSimuladorServiceImpl", 
        TransactionIsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted)]
    public class CompetidorSimuladorServiceImpl : ICompetidorSimuladorService, IIntegradorEscolasService
    {
        private BCEscolasSimulador _bcPersistence = null;
        private static List<EscolaDTO> _escolasCadastradas = null;

        #region Propriedade Injetadas
        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCGrupoEscolarSimulador BCGrupoEscolarSimulador { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCCompetidorSimulador BCCompetidorSimulador { get; set; }


        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCAgendaSimulacao BCAgendaSimulacao { get; set; }

        #endregion

        #region Construtores
        public CompetidorSimuladorServiceImpl(BCEscolasSimulador bcPersistence)
        {
            //Dependencia injetada pela mecanismo de Dependecy Injection do Unity
            _bcPersistence = bcPersistence;
        }
        #endregion

        #region IIntegradorEscolasService Members

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AdicionarEscolasClassificadas", "AdicionarEscolasClassificadas")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarAgregacoesEscolasClassificadas()]
        public void AdicionarEscolasClassificadas(List<EscolaDTO> escolasDTO)
        {
            try 
            {
                _bcPersistence.AdicionarEscolasClassificadas(escolasDTO.TranslateFromDTO());
            }
            catch (Exception ex) 
            {
                //TODO: disparar execption para LMS sem dependencia dos assemblies do framework
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        #endregion

        #region ICompetidorSimuladorService Members

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-DesclassificarGrupoEscolar", "DesclassificarGrupoEscolar")]
        [NotNullParam()]
        [LogSistema()]
        public void DesclassificarGrupoEscolar(GrupoEscolarDTO grupoEscolar)
        {
            try
            {
                this.BCGrupoEscolarSimulador.DesclassificarGrupoEscolar(grupoEscolar.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [LogSistema()]
        public GrupoEscolarDTO ObterGrupoEscolarSimulacao(int codigoOrigemLMS)
        {
            GrupoEscolarDTO _returnEntitie = null;
            try
            {
               return this.BCGrupoEscolarSimulador.ObterGrupoEscolarSimulacao(codigoOrigemLMS).TranslateToDTO();
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return _returnEntitie;
        }

        [LogSistema()]
        public List<EscolaDTO> ListarEscolasSorteadasSimulacao(int codigoEscola, TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO, TipoStatusSorteioCenariosDTO tipoStatusSorteioCenarios)
        {
            try
            {
                List<EscolaDTO> _listaRetorno = new List<EscolaDTO>();

                _bcPersistence.LazyLoad = true;
                if (codigoEscola == 0 || codigoEscola == int.MinValue)
                    _listaRetorno = _bcPersistence.ListarEscolasSorteadas(tipoSemanaSimulacaoDTO.ConvertToEnum()).TranslateToDTO();
                else
                    _listaRetorno.Add(_bcPersistence.ObterEscolaSorteada(codigoEscola, tipoSemanaSimulacaoDTO.ConvertToEnum()).TranslateToDTO());
                _bcPersistence.LazyLoad = false;

                if (tipoStatusSorteioCenarios == TipoStatusSorteioCenariosDTO.OK || 
                    tipoStatusSorteioCenarios == TipoStatusSorteioCenariosDTO.Pendente)
                    return _listaRetorno.Where(p => p.TipoStatusSorteioCenariosDTO == tipoStatusSorteioCenarios).ToList<EscolaDTO>();

                return _listaRetorno;
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }
        
        [LogSistema()]
        public List<GrupoEscolarDTO> ListarAgendamentoSimulacao(EscolaDTO escolaDTO, TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO)
        {
            try 
            {
                //Lista todos os grupo escolares de uma determinada escola
                var _grupoEscolares = this.BCGrupoEscolarSimulador.ListarGruposEscolaresByEscola(escolaDTO.Codigo).TranslateToDTO();
                _grupoEscolares.ForEach(delegate(GrupoEscolarDTO grupoEscolar)
                {
                    grupoEscolar.AgendaSimulacao = this.BCAgendaSimulacao.ListarAgendaSimulacaoGrupoEscolar(grupoEscolar.Codigo).TranslateToDTO();
                });
                return _grupoEscolares.ListarAgendaByPeriodoSemana(tipoSemanaSimulacaoDTO);
            }
            catch (Exception ex) 
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        [LogSistema()]
        public List<GrupoEscolarDTO> ListarAgendamentoSimulacao(TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO)
        {
            try 
            {
                var _escolasCadastrada = this.ListarTodasConfiguracoes();
                _escolasCadastrada.ForEach(delegate(EscolaDTO escola)
                {
                    escola.GruposEscolares = this.BCGrupoEscolarSimulador.ListarGruposEscolaresByEscola(escola.Codigo).TranslateToDTO();

                    escola.GruposEscolares.ForEach(delegate(GrupoEscolarDTO grupoEscolar)
                    {
                        grupoEscolar.AgendaSimulacao = this.BCAgendaSimulacao.ListarAgendaSimulacaoGrupoEscolar(grupoEscolar.Codigo).TranslateToDTO();
                    });
                });
                return _escolasCadastrada.ListarAgendaByPeriodoSemana(tipoSemanaSimulacaoDTO);
            }
            catch (Exception ex) 
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        [LogSistema()]
        public List<GrupoEscolarDTO> ListarAgendamentoSimulacao()
        {
            try
            {
                var _escolasCadastrada = this.ListarTodasConfiguracoes();
                _escolasCadastrada.ForEach(delegate(EscolaDTO escola) 
                {
                    escola.GruposEscolares = this.BCGrupoEscolarSimulador.ListarGruposEscolaresByEscola(escola.Codigo).TranslateToDTO();

                    escola.GruposEscolares.ForEach(delegate(GrupoEscolarDTO grupoEscolar) 
                    {
                        grupoEscolar.AgendaSimulacao = this.BCAgendaSimulacao.ListarAgendaSimulacaoGrupoEscolar(grupoEscolar.Codigo).TranslateToDTO();
                    });
                });

                return _escolasCadastrada.ListarGruposEscolares();
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        [LogSistema()]
        public List<AlunoDTO> ListarAlunosByEscola(EscolaDTO escolaDTO)
        {
            try
            {
                var _gruposEscolares = this.ObterConfiguracao(escolaDTO.Codigo).ListarGruposEscolares();

                List<AlunoDTO> _listaAlunos = new List<AlunoDTO>();
                _gruposEscolares.ForEach(delegate(GrupoEscolarDTO grupoEscolar)
                {
                    var _alunos = this.BCCompetidorSimulador.ListarAlunosGrupoEscolar(grupoEscolar.Codigo);
                    _alunos.ForEach(delegate(CompetidorSimulador competidor) 
                    {
                        _listaAlunos.Add(((Aluno)competidor).TranslateToDTO());
                    });
                });

                return _listaAlunos;
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        [LogSistema()]
        public List<DocumentoDTO> ListarDocumentos(AlunoDTO alunoDTO)
        {
            try
            {
                var _aluno = ((Aluno)this.BCCompetidorSimulador.FindByKey(alunoDTO.Codigo)).TranslateToDTO();
                return _aluno.Documentos;
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        [LogSistema()]
        public List<DocumentoDTO> ListarDocumentos(ProfessorDTO professorDTO)
        {
            try
            {
                var _professor = ((Professor)this.BCCompetidorSimulador.FindByKey(professorDTO.Codigo)).TranslateToDTO();
                return _professor.Documentos;
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        [LogSistema()]
        public List<GrupoEscolarDTO> ListarGruposByEscola(EscolaDTO escolaDTO)
        {
            try
            {
                return this.BCGrupoEscolarSimulador.ListarGruposEscolaresByEscola(escolaDTO.Codigo).TranslateToDTO();
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        [LogSistema()]
        public List<ProfessorDTO> ListarProfessoresByEscola(EscolaDTO escolaDTO)
        {
            try
            {
                var _gruposEscolares = this.ObterConfiguracao(escolaDTO.Codigo).ListarGruposEscolares();

                List<ProfessorDTO> _listaProfessor = new List<ProfessorDTO>();
                _gruposEscolares.ForEach(delegate(GrupoEscolarDTO grupoEscolar) 
                {
                    var _professor = this.BCCompetidorSimulador.ObterProfessorGrupoEscolar(grupoEscolar.Codigo);
                    _listaProfessor.Add(((Professor)_professor).TranslateToDTO());
                });

                return _listaProfessor;
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        [LogSistema()]
        public List<TelefoneDTO> ListarTelefones(AlunoDTO alunoDTO)
        {
            try
            {
                var _aluno = ((Aluno)this.BCCompetidorSimulador.FindByKey(alunoDTO.Codigo)).TranslateToDTO();
                return _aluno.Telefones;
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        [LogSistema()]
        public List<TelefoneDTO> ListarTelefones(ProfessorDTO professorDTO)
        {
            try
            {
                var _professor = ((Professor)this.BCCompetidorSimulador.FindByKey(professorDTO.Codigo)).TranslateToDTO();
                return _professor.Telefones;
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        [LogSistema()]
        public List<TelefoneDTO> ListarTelefones(EscolaDTO escolaDTO)
        {
            try
            {
                var _escolasCadastrada = this.ObterConfiguracao(escolaDTO.Codigo);
                return _escolasCadastrada.Telefones;
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        [LogSistema()]
        public List<TipoSemanaSimulacaoDTO> ListarSemanasSimulacao()
        {
            return new List<TipoSemanaSimulacaoDTO> { TipoSemanaSimulacaoDTO.PrimeiraSemana, TipoSemanaSimulacaoDTO.SegundaSemana, TipoSemanaSimulacaoDTO.TerceiraSemana, TipoSemanaSimulacaoDTO.QuartaSemana };
        }

        [LogSistema()]
        public List<TipoStatusSorteioCenariosDTO> ListarStatusSorteioCenarios()
        {
            return new List<TipoStatusSorteioCenariosDTO> { TipoStatusSorteioCenariosDTO.OK, TipoStatusSorteioCenariosDTO.Pendente };
        }

        #endregion

        #region IConfiguradorService<EscolaDTO> Members

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AdicionarConfiguracao", "AdicionarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        public void AdicionarConfiguracao(EscolaDTO entity)
        {
            try
            {
                _bcPersistence.Create(entity.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AtualizarConfiguracao", "AtualizarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        public void AtualizarConfiguracao(EscolaDTO entity)
        {
            try 
            {
                _bcPersistence.Update(entity.TranslateFromDTO());
            }
            catch (Exception ex) 
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-ExcluirConfiguracao", "ExcluirConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        public void ExcluirConfiguracao(EscolaDTO entity)
        {
            try
            {
                _bcPersistence.Delete(entity.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [LogSistema()]
        public List<EscolaDTO> ListarTodasConfiguracoes()
        {
            if (_escolasCadastradas == null)
                _escolasCadastradas = _bcPersistence.FindAll().TranslateToDTO();
            return _escolasCadastradas;
        }

        [LogSistema()]
        public EscolaDTO ObterConfiguracao(int codigo)
        {
            return _bcPersistence.FindByKey(codigo).TranslateToDTO();
        }

        #endregion
    }
}
