﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Activation;
using Desafio.Simulador.Bsl.Simulacao.Agenda.Interfaces;
using Desafio.Simulador.Bsl.Integrador.Interfaces;
using Desafio.Simulador.Util.Excecao;
using System.ServiceModel;
using Desafio.Simulador.Util.Logger;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Interfaces;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Core.Domain.Enum;
using Microsoft.Practices.Unity;
using Desafio.Simulador.Bcl.Competidor.Interfaces;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Bsl.Comum.Extensions;

namespace Desafio.Simulador.Bsl.Simulacao.Agenda.Impl
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(Namespace = "Desafio.Simulador.Bsl.Simulacao.Agenda.Impl.SimuladorAgendamentoServiceImpl", TransactionIsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted)]
    public class SimuladorAgendamentoServiceImpl : ISimuladorAgendamentoService, IIntegradorAgendaSimuladoService
    {
        private BCAgendaSimulacao _bcPersistence;

        public SimuladorAgendamentoServiceImpl(BCAgendaSimulacao bcPersistence) 
        {
            _bcPersistence = bcPersistence;
        }

        #region Propriedade Injetadas
        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCEscolasSimulador BCEscolasSimulador { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCGrupoEscolarSimulador BCGrupoEscolarSimulador { get; set; }

        #endregion

        #region ISimuladorAgendamentoService Members

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-DispararSorteioManualCenarios", "DispararSorteioManualCenarios")]
        [LogSistema()]
        public void DispararSorteioManualCenarios(TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO, bool indicadorGruposNaoSorteados)
        {
            try
            {
                this.DispararSorteioManualCenarios(int.MinValue, tipoSemanaSimulacaoDTO, indicadorGruposNaoSorteados);
            }
            catch (Exception ex) 
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-DispararSorteioManualCenarios", "DispararSorteioManualCenarios")]
        [LogSistema()]
        public void DispararSorteioManualCenarios(int codigoEscola, TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO, bool indicadorGruposNaoSorteados)
        {
            //try
            //{
            //    List<Escola> _escolasPendentes = null;
            //    if (codigoEscola == int.MinValue)
            //        _escolasPendentes = this.BCEscolasSimulador.ListarEscolasPendenteSorteioCenarios();
            //    else
            //    {
            //        var _escolaSeleciona = this.BCEscolasSimulador.FindByKey(codigoEscola);
            //        _escolasPendentes = new List<Escola>() { _escolaSeleciona };
            //    }

            //    //Dispara o sorteio automático para a lista de escolas selecionadas
            //    _bcPersistence.RealizarSorteioCenarios(ref _escolasPendentes, tipoSemanaSimulacaoDTO.ConvertToEnum(), indicadorGruposNaoSorteados);

            //    //Atualiza indicador das Escolas Sorteadas
            //    this.BCEscolasSimulador.AtualizarIndicadorSorteioCenarios(_escolasPendentes);
            //}
            //catch (Exception ex)
            //{
            //    //TODO: disparar execption para LMS sem dependencia dos assemblies do framework
            //    GerenciadorExcecao.TratarExcecao(ex);
            //}
            string nomeMetodoLog = "SimuladorAgendamentoServiceImpl.DispararSorteioManualCenarios";
            LogManager.InicioMetodo(nomeMetodoLog);

            try
            {
                LogManager.Trace(nomeMetodoLog, "Selecionando Escolas Pendentes");
                List<Escola> _escolasPendentes = null;
                if (codigoEscola == int.MinValue)
                    _escolasPendentes = this.BCEscolasSimulador.ListarEscolasPendenteSorteioCenarios();
                else
                {
                    var _escolaSeleciona = this.BCEscolasSimulador.FindByKey(codigoEscola);
                    _escolasPendentes = new List<Escola>() { _escolaSeleciona };
                }
                LogManager.Trace(nomeMetodoLog, "Escolas Pendentes Selecionadas! [{0}] Escolas Selecionadas.", (_escolasPendentes != null ? _escolasPendentes.Count : 0));

                if (_escolasPendentes != null &&
                    _escolasPendentes.Count > 0)
                {
                    //Dispara o sorteio automático para a lista de escolas selecionadas
                    LogManager.Trace(nomeMetodoLog, "Realizando Sorteio de Cenários para Escolas Pendentes");
                    //Dispara o sorteio automático para a lista de escolas selecionadas
                    _bcPersistence.RealizarSorteioCenarios(ref _escolasPendentes, tipoSemanaSimulacaoDTO.ConvertToEnum(), indicadorGruposNaoSorteados, true);
                    LogManager.Trace(nomeMetodoLog, "Sorteio de Cenários para Escolas Pendentes Realizado!");

                    //Atualiza indicador das Escolas Sorteadas
                    LogManager.Trace(nomeMetodoLog, "Atualizando Indicador de Escolas");
                    this.BCEscolasSimulador.AtualizarIndicadorSorteioCenarios(_escolasPendentes);
                    LogManager.Trace(nomeMetodoLog, "Indicador de Escolas Atualizado!");
                }
                else
                {
                    LogManager.Trace(nomeMetodoLog, "Não existem Escolas Pendentes para Sorteio!");
                }
            }
            catch (Exception ex)
            {
                //TODO: disparar execption para LMS sem dependencia dos assemblies do framework
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [LogSistema()]
        public AgendaSimulacaoDTO ObterAgendaSimulacaoGrupoEscolar(DateTime dataHoraAgendamento, int codigoGrupoEscolar)
        {
            try
            {
                var _agendaSimulacao = _bcPersistence.ObterAgendaSimulacaoGrupoEscolar(dataHoraAgendamento, codigoGrupoEscolar);

                if (null != _agendaSimulacao)
                    return _agendaSimulacao.TranslateToDTO();
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;  
        }
        
        [LogSistema()]
        public List<AgendaSimulacaoDTO> ListarAgendaSimulacaoGrupoEscolar(int codigoGrupoEscolar)
        {
            try
            {
                var _agendaSimulacao = _bcPersistence.ListarAgendaSimulacaoGrupoEscolar(codigoGrupoEscolar);
                if (null != _agendaSimulacao)
                    return _agendaSimulacao.TranslateToDTO();

            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-FinalizarRodada", "FinalizarRodada")]
        [LogSistema()]
        public void FinalizarRodada(AgendaSimulacaoRodadasDTO rodada)
        {
            try
            {
                _bcPersistence.FinalizarRodada(rodada.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-IncrementarContadorContingencia", "IncrementarContadorContingencia")]
        [LogSistema()]
        public void IncrementarContadorContingencia(AgendaSimulacaoRodadasDTO rodada)
        {
            try
            {
                _bcPersistence.IncrementarContadorContingencia(rodada.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        #endregion

        #region IIntegradorAgendaSimuladoService Members
        
        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-ReagendarSimuladoGrupoEscolar", "ReagendarSimuladoGrupoEscolar")]
        [LogSistema()]
        public void ReagendarSimuladoGrupoEscolar(GrupoEscolarDTO grupoEscolarDTO)
        {
            try
            {
                //Obtêm o Grupo Escolar no Simulador
                var _grupoEscolarSimulacao = this.BCGrupoEscolarSimulador.ObterGrupoEscolarSimulacao(grupoEscolarDTO.CodigoOriginalLMS);

                //Lista a agenda atual do Grupo Escolar
                _grupoEscolarSimulacao.AgendaSimulacao = _bcPersistence.ListarAgendaSimulacaoGrupoEscolar(_grupoEscolarSimulacao.Codigo);

                //Atualiza a Data e Hora de agendamento enviada pelo LMS
                grupoEscolarDTO.AgendaSimulacao.ForEach(delegate(AgendaSimulacaoDTO novaAgendaGrupoEscolar) 
                {
                    //Obtêm a nova agenda enviada pelo LMS
                    var _agendaAtual = _grupoEscolarSimulacao.AgendaSimulacao.Where(ag => ag.CodigoOriginalLMS == novaAgendaGrupoEscolar.CodigoOriginalLMS).FirstOrDefault<AgendaSimulacao>();
                    if (_agendaAtual != null)
                    {
                        _agendaAtual.GrupoEscolar = this.BCGrupoEscolarSimulador.ListarGruposEscolaresByAgendaSimulacao(_agendaAtual.Codigo);
                        _agendaAtual.DataHoraAgendamento = novaAgendaGrupoEscolar.DataHoraAgendamento;
                        _bcPersistence.ReagendarSimuladoGrupoEscolar(_agendaAtual);
                    }
                });
            }
            catch (Exception ex)
            {
                //TODO: disparar execption para LMS sem dependencia dos assemblies do framework
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-DispararSorteioAutmaticoCenarios", "DispararSorteioAutmaticoCenarios")]
        [LogSistema()]
        public void DispararSorteioAutomaticoCenarios()
        {
            try
            {
                string nomeMetodoLog = "SimuladorAgendamentoServiceImpl.DispararSorteioAutmaticoCenarios";
                LogManager.InicioMetodo(nomeMetodoLog);

                LogManager.Trace(nomeMetodoLog, "Selecionando Escolas Pendentes");
                var _escolasPendentes = this.BCEscolasSimulador.ListarEscolasPendenteSorteioCenarios();
                LogManager.Trace(nomeMetodoLog, "Escolas Pendentes Selecionadas! [{0}] Escolas Selecionadas.", (_escolasPendentes != null ? _escolasPendentes.Count : 0));

                if (_escolasPendentes != null &&
                    _escolasPendentes.Count > 0)
                {
                    //Dispara o sorteio automático para a lista de escolas selecionadas
                    LogManager.Trace(nomeMetodoLog, "Realizando Sorteio de Cenários para Escolas Pendentes");
                    _bcPersistence.RealizarSorteioCenarios(ref _escolasPendentes);
                    LogManager.Trace(nomeMetodoLog, "Sorteio de Cenários para Escolas Pendentes Realizado!");

                    //Atualiza indicador das Escolas Sorteadas
                    LogManager.Trace(nomeMetodoLog, "Atualizando Indicador de Escolas");
                    this.BCEscolasSimulador.AtualizarIndicadorSorteioCenarios(_escolasPendentes);
                    LogManager.Trace(nomeMetodoLog, "Indicador de Escolas Atualizado!");
                }
                else
                {
                    LogManager.Trace(nomeMetodoLog, "Não existem Escolas Pendentes para Sorteio!");
                }
                LogManager.FimMetodo(nomeMetodoLog);
            }
            catch (Exception ex)
            {
                //TODO: disparar execption para LMS sem dependencia dos assemblies do framework
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        #endregion
    }
}
