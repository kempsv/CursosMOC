﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Bsl.Comum.Interfaces;

namespace Desafio.Simulador.Bsl.Competidor.Interfaces
{
    [ServiceContract]
    public interface ICompetidorSimuladorService : IConfiguradorService<EscolaDTO>
    {
        /// <summary>
        /// Obtêm o grupo escolar pelo código origem do Grupo no sistema LMS
        /// </summary>
        /// <param name="codigoLMS"></param>
        /// <returns></returns>
        [OperationContract]
        GrupoEscolarDTO ObterGrupoEscolarSimulacao(int codigoOrigemLMS);

        /// <summary>
        /// Lista todos os alunos de uma determinada Escola
        /// </summary>
        /// <param name="codigoGrupoEscolar"></param>
        /// <returns></returns>
        [OperationContract]
        List<AlunoDTO> ListarAlunosByEscola(EscolaDTO escolaDTO);

        /// <summary>
        /// Lista todos os professores de uma determinada Escola
        /// </summary>
        /// <param name="codigoGrupoEscolar"></param>
        /// <returns></returns>
        [OperationContract]
        List<ProfessorDTO> ListarProfessoresByEscola(EscolaDTO escolaDTO);

        /// <summary>
        /// Lista todos os telefones de uma determinada escola
        /// </summary>
        /// <param name="escolaDTO"></param>
        /// <returns></returns>
        [OperationContract(Name="TelefonesEscola")]
        List<TelefoneDTO> ListarTelefones(EscolaDTO escolaDTO);

        /// <summary>
        /// Lista todos os telefones de um Professor
        /// </summary>
        /// <param name="escolaDTO"></param>
        /// <returns></returns>
        [OperationContract(Name = "TelefonesProfessor")]
        List<TelefoneDTO> ListarTelefones(ProfessorDTO professorDTO);

        /// <summary>
        /// Lista todos os telefones de um Aluno
        /// </summary>
        /// <param name="escolaDTO"></param>
        /// <returns></returns>
        [OperationContract(Name = "TelefonesAluno")]
        List<TelefoneDTO> ListarTelefones(AlunoDTO alunoDTO);

        /// <summary>
        /// Lista todos os documentos de um Professor
        /// </summary>
        /// <param name="escolaDTO"></param>
        /// <returns></returns>
        [OperationContract(Name = "DocumentosProfessor")]
        List<DocumentoDTO> ListarDocumentos(ProfessorDTO professorDTO);

        /// <summary>
        /// Lista todos os documentos de um Aluno
        /// </summary>
        /// <param name="escolaDTO"></param>
        /// <returns></returns>
        [OperationContract(Name = "DocumentosAluno")]
        List<DocumentoDTO> ListarDocumentos(AlunoDTO alunoDTO);

        /// <summary>
        /// Desclassifica o grupo escolar da Simulação de investimento
        /// </summary>
        /// <param name="codigoGrupoEscolar"></param>
        [OperationContract]
        void DesclassificarGrupoEscolar(GrupoEscolarDTO grupoEscolar);

        /// <summary>
        /// Obtêm a escola sorteada para o uma determinada semana de agendamento de simulação
        /// </summary>
        /// <param name="codigoEscola"></param>
        /// <param name="tipoSemanaSimulacaoDTO"></param>
        /// <returns></returns>
        [OperationContract(Name = "ListarEscolasSorteadasSimulacao1")]
        List<EscolaDTO> ListarEscolasSorteadasSimulacao(int codigoEscola, TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO, TipoStatusSorteioCenariosDTO tipoStatusSorteioCenarios);

        /// <summary>
        /// /// Lista todos os agendamentos de simulações de investimento
        /// </summary>
        /// <returns>Lista de AgendaSimulacaoDTO</returns>
        [OperationContract(Name = "ListarTodosAgendamentoSimulacao")]
        List<GrupoEscolarDTO> ListarAgendamentoSimulacao();

        /// <summary>
        /// Lista todos os agendamentos de uma determinada semana de simulação
        /// </summary>
        /// <param name="tipoSemanaSimulacaoDTO"></param>
        /// <returns>Lista de AgendaSimulacaoDTO</returns>
        [OperationContract(Name = "ListarAgendamentoSimulacaoPorSemana")]
        List<GrupoEscolarDTO> ListarAgendamentoSimulacao(TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO);

        /// <summary>
        /// Lista os Grupos Escolares com agendamento de simulação
        /// </summary>
        /// <param name="escolaDTO"></param>
        /// <param name="tipoSemanaSimulacaoDTO"></param>
        /// <returns>Lista de Grupos Escolares</returns>
        [OperationContract(Name = "ListarAgendamentoSimulacaoPorSemanaEscola")]
        List<GrupoEscolarDTO> ListarAgendamentoSimulacao(EscolaDTO escolaDTO, TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO);

        /// <summary>
        /// Lista as semanas de simulação (primeira, segunda, terceira, quarta)
        /// </summary>
        /// <returns>Lista das Semanas</returns>
        [OperationContract(Name = "ListarSemanasSimulacao")]
        List<TipoSemanaSimulacaoDTO> ListarSemanasSimulacao();

        /// <summary>
        /// Lista os tipos dos status dos cenários (Pendente ou OK)
        /// </summary>
        /// <returns>Lista de status</returns>
        [OperationContract(Name = "ListarStatusSorteioCenarios")]
        List<TipoStatusSorteioCenariosDTO> ListarStatusSorteioCenarios();

        ///// <summary>
        ///// Lista os grupos escolares pelo código descola.
        ///// </summary>
        ///// <param name="codigoEscola"></param>
        ///// <returns></returns>
        //[OperationContract(Name = "ListarGruposEscolaresByEscola")]
        //List<GrupoEscolarDTO> ListarGruposEscolaresByEscola(int codigoEscola);

        /// <summary>
        /// Lista todos os grupos escolares de uma determinada Escola
        /// </summary>
        /// <param name="escolaDTO"></param>
        /// <returns></returns>
        [OperationContract]
        List<GrupoEscolarDTO> ListarGruposByEscola(EscolaDTO escolaDTO);
    }
}
