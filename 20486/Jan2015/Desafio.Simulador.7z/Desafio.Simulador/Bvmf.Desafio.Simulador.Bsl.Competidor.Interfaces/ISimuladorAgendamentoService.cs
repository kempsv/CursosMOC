﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Desafio.Simulador.Bsl.Comum.Dto;


namespace Desafio.Simulador.Bsl.Simulacao.Agenda.Interfaces
{
    [ServiceContract()]
    public interface ISimuladorAgendamentoService
    {
        /// <summary>
        /// Obtêm a Agenda de Simulação do Grupo Escolar através da data e hora do agendamento
        /// Caso não exista simulação para a data e hora de agendamento, NULL reference é retornado.
        /// </summary>
        /// <param name="dataHoraAgendamento"></param>
        /// <param name="grupoEscolar"></param>
        /// <returns>Retorna a Agenda de Simulação do Grupo para a data e hora informada</returns>
        [OperationContract]
        AgendaSimulacaoDTO ObterAgendaSimulacaoGrupoEscolar(DateTime dataHoraAgendamento, int codigoGrupoEscolar);

        /// <summary>
        /// Obtêm a Agenda de Simulação do Grupo Escolar do código do Grupo Escolar
        /// Caso não exista simulação para o grupo escolar informado, NULL reference é retornado.
        /// </summary>
        /// <param name="codigoGrupoEscolar"></param>
        /// <returns>Retorna a lista de Agenda de Simulacao do grupo escolar</returns>
        [OperationContract]
        List<AgendaSimulacaoDTO> ListarAgendaSimulacaoGrupoEscolar(int codigoGrupoEscolar);

        /// <summary>
        /// Atualiza o campo IndicadorSimulacaoConcluida para true
        /// </summary>
        /// <param name="rodada"></param>
        /// <param name="codigoAgenda"></param>
        [OperationContract]
        void FinalizarRodada(AgendaSimulacaoRodadasDTO rodada);

        /// <summary>
        /// Atualiza o Contador de Rodadas de Simulacao
        /// </summary>
        /// <param name="rodada"></param>
        [OperationContract]
        void IncrementarContadorContingencia(AgendaSimulacaoRodadasDTO rodada);
        
        /// <summary>
        /// Dispara o sorteio manual de cenários e faz o sorteio para a escola especificada
        /// </summary>
        /// <param name="codigoEscola"></param>
        /// <param name="tipoSemanaSimulacaoDTO"></param>
        /// <param name="indicadorGruposSorteados"></param>
        [OperationContract(Name = "DispararSorteioManualCenarios")]
        void DispararSorteioManualCenarios(int codigoEscola, TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO, bool indicadorGruposNaoSorteados);

        /// <summary>
        /// Dispara o sorteio manual de cenários e faz o sorteio para todas as escolas
        /// </summary>
        /// <param name="tipoSemanaSimulacaoDTO"></param>
        /// <param name="indicadorGruposSorteados"></param>
        [OperationContract(Name = "DispararSorteioManualCenarios1")]
        void DispararSorteioManualCenarios(TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO, bool indicadorGruposNaoSorteados);

        ///// <summary>
        ///// Obtêm detalhes da Rodada
        ///// </summary>
        ///// <param name="codigoRodada"></param>
        ///// <returns></returns>
        //[OperationContract(Name = "ObterDetalhesRodada")]
        //List<RodadaCenarioDTO> ObterDetalhesRodada(int codigoRodada);
    }
}
