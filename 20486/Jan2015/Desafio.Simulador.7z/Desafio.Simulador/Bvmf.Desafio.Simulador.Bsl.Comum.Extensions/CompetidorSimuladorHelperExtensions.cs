﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Core.Domain.Enum;
using Desafio.Simulador.Bsl.Comum.Dto;

namespace Desafio.Simulador.Bsl.Comum.Extensions
{
    /// <summary>
    /// Extension class for the types List Of EscolaDTO and GrupoEscolarDTO
    /// </summary>
    public static partial class CompetidorSimuladorHelperExtensions
    {
        public static List<GrupoEscolar> ListarAgendaByPeriodoSemana(this List<GrupoEscolar> gruposEscolares, TipoSemanaSimulacao tipoSemanaSimulacao)
        {
            gruposEscolares.ForEach(delegate(GrupoEscolar grupoEscolar)
            {
                //Seleciona somente as agendas que satisfaçam ao Where do Linq
                grupoEscolar.AgendaSimulacao = grupoEscolar.AgendaSimulacao.Where(ag => ag.TipoSemanaSimulacao == tipoSemanaSimulacao).ToList<AgendaSimulacao>();

                //Se não existir agenda, remove o grupo da lista
                if (grupoEscolar.AgendaSimulacao == null)
                    gruposEscolares.Remove(grupoEscolar);
            });

            return gruposEscolares;
        }

        public static List<GrupoEscolarDTO> ListarAgendaByPeriodoSemana(this List<GrupoEscolarDTO> gruposEscolares, TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO)
        {
            gruposEscolares.ForEach(delegate(GrupoEscolarDTO grupoEscolar)
            {
                //Seleciona somente as agendas que satisfaçam ao Where do Linq
                grupoEscolar.AgendaSimulacao = grupoEscolar.AgendaSimulacao.Where(ag => ag.TipoSemanaSimulacao == tipoSemanaSimulacaoDTO).ToList<AgendaSimulacaoDTO>();

                //Se não existir agenda, remove o grupo da lista
                if (grupoEscolar.AgendaSimulacao == null)
                    gruposEscolares.Remove(grupoEscolar);
            });

            return gruposEscolares;
        }

        public static List<GrupoEscolarDTO> ListarAgendaByPeriodoSemana(this List<EscolaDTO> escolasDTO, TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO)
        {
            escolasDTO.ForEach(delegate(EscolaDTO escola)
            {
                escola.GruposEscolares = escola.GruposEscolares.ListarAgendaByPeriodoSemana(tipoSemanaSimulacaoDTO);
            });

            return escolasDTO.ListarGruposEscolares();
        }

        public static List<GrupoEscolarDTO> ListarGruposEscolares(this List<EscolaDTO> escolasDTO)
        {
            List<GrupoEscolarDTO> _grupoEscolaresRetorno = new List<GrupoEscolarDTO>();

            escolasDTO.ForEach(delegate(EscolaDTO escola)
            {
                _grupoEscolaresRetorno.AddRange(escola.ListarGruposEscolares());
            });

            return _grupoEscolaresRetorno;
        }

        public static List<GrupoEscolarDTO> ListarGruposEscolares(this EscolaDTO escolasDTO)
        {
            List<GrupoEscolarDTO> _grupoEscolaresRetorno = new List<GrupoEscolarDTO>();

            escolasDTO.GruposEscolares.ForEach(delegate(GrupoEscolarDTO grupoEscolar)
            {
                _grupoEscolaresRetorno.Add(grupoEscolar);
            });

            return _grupoEscolaresRetorno;
        }

    }
}
