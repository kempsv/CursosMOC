﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Bcl.Core.Domain;

namespace Desafio.Simulador.Bsl.Comum.Extensions
{
    /// <summary>
    /// Extension class for the types List Of EscolaDTO and GrupoEscolarDTO
    /// </summary>
    public static class RankingSimulacaoServiceImplHelperExtensions
    {
        public static void GerarRanking(this List<RankingSimulacaoGrupoEscolarDTO> rankingGruposEscolares, GrupoEscolar grupoEscolar, CarteiraInvestimento carteiraInvestimento)
        {
            if (carteiraInvestimento == null) return;
            
            if (rankingGruposEscolares == null)
                rankingGruposEscolares = new List<RankingSimulacaoGrupoEscolarDTO>();

            rankingGruposEscolares.Add(new RankingSimulacaoGrupoEscolarDTO()
            {
                Codigo = grupoEscolar.Codigo,
                Nome = grupoEscolar.NomeGrupo,
                ValorInvestimentoInicial = grupoEscolar.ValorInvestimentoInicial, // String.Format("{0:C2}", grupoEscolar.ValorInvestimentoInicial),
                RentabilidadeAcumulada = carteiraInvestimento.ValorRentabilidadeAcumulada // String.Format("{0:N2}", carteiraInvestimento.ValorRentabilidadeAcumulada) + "%"
            });
        }

        public static void GerarRanking(this List<RankingSimulacaoEscolaDTO> rankingEscolas, Escola escola, List<RankingSimulacaoGrupoEscolarDTO> rankingGruposEscolares)
        {
            if (rankingGruposEscolares.Count == 0) return;

            if (rankingEscolas == null)
                rankingEscolas = new List<RankingSimulacaoEscolaDTO>();

            //var _grupoClassificados = rankingGruposEscolares.Where(rk => rk.RentabilidadeAcumulada != 0).FirstOrDefault<RankingSimulacaoGrupoEscolarDTO>();
            var _grupoClassificados = rankingGruposEscolares.OrderByDescending(tr => tr.RentabilidadeAcumulada).FirstOrDefault<RankingSimulacaoGrupoEscolarDTO>();

            rankingEscolas.Add(new RankingSimulacaoEscolaDTO()
            {
                Codigo = escola.Codigo,
                Nome = escola.Nome,
                TipoEscola = escola.IndicadorEscolaPrivada == true ? "Privada" : "Pública",
                RankingSimulacaoGrupoEscolar = rankingGruposEscolares,
                RentabilidadeAcumulada = _grupoClassificados != null ? _grupoClassificados.RentabilidadeAcumulada : 0
            });
        }

        //public static List<RankingSimulacaoGrupoEscolarDTO> ClassificarRanking(this List<RankingSimulacaoGrupoEscolarDTO> ranking)
        //{
        //    var _resultadoRanking = ranking.OrderByDescending(tr => tr.RentabilidadeAcumulada).ToList<RankingSimulacaoGrupoEscolarDTO>();

        //    _resultadoRanking.ForEach(delegate(RankingSimulacaoGrupoEscolarDTO rankingGrupo)
        //    {
        //        rankingGrupo.Classificacao += 1;
        //    });

        //    return _resultadoRanking;
        //}

        public static List<RankingSimulacaoEscolaDTO> ClassificarRanking(this List<RankingSimulacaoEscolaDTO> ranking)
        {
            if (ranking.Count == 0) return null;

            var _rankingGruposEscolares = new List<RankingSimulacaoGrupoEscolarDTO>();

            //Ordena de forma descendente o ranking das escolas
            var _resultadoRankingEscolas =  ranking.OrderByDescending(tr => tr.RentabilidadeAcumulada).ToList<RankingSimulacaoEscolaDTO>();
            //Classifica as escolas
            _resultadoRankingEscolas.ForEach(delegate(RankingSimulacaoEscolaDTO rankingEscola) 
            {
                rankingEscola.Classificacao += 1;
                
                //Adiciona a lista de grupos para classificação
                _rankingGruposEscolares.AddRange(rankingEscola.RankingSimulacaoGrupoEscolar);
            });

            //Ordena de forma descendente o ranking do Grupos Escolares
            var _resultadoRankingGrupos = _rankingGruposEscolares.OrderByDescending(tr => tr.RentabilidadeAcumulada).ToList<RankingSimulacaoGrupoEscolarDTO>();
            //Classifica os Grupos Escolares
            _resultadoRankingGrupos.ForEach(delegate(RankingSimulacaoGrupoEscolarDTO rankingGrupoEscolar)
            {
                rankingGrupoEscolar.Classificacao += 1;
            });

            _resultadoRankingEscolas.ForEach(delegate(RankingSimulacaoEscolaDTO rankingEscola) 
            {
                rankingEscola.RankingSimulacaoGrupoEscolar.ForEach(delegate(RankingSimulacaoGrupoEscolarDTO rankingGrupoEscolar) 
                {
                    //Atualiza a classificação atual do grupos Escolar
                    rankingGrupoEscolar.Classificacao = _resultadoRankingGrupos.Where(
                                                                                rs => 
                                                                                rs.Codigo == rankingGrupoEscolar.Codigo)
                                                                                .First<RankingSimulacaoGrupoEscolarDTO>().Classificacao;
                });    
            });
            return _resultadoRankingEscolas;
        }
    }
}
