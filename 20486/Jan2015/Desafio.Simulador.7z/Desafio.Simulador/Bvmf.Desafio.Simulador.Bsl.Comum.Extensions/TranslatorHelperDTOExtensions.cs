﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Core.Domain.Enum;

namespace Desafio.Simulador.Bsl.Comum.Extensions
{
    public static class TranslatorHelperDTOExtensions
    {
        #region TranslatorDTO<RodadaSimulacao,RodadaSimulacaoDTO> Members

        public static List<RodadaSimulacao> TranslateFromDTO(this List<RodadaSimulacaoDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<RodadaSimulacao>();
            foreach (RodadaSimulacaoDTO entity in entityDTO)
            {
                _returnEntities.Add(entity.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static RodadaSimulacao TranslateFromDTO(this RodadaSimulacaoDTO entityDTO)
        {
            return entityDTO == null ? null : new RodadaSimulacao()
            {
                Codigo = entityDTO.Codigo,
                DataHoraCriacao = DateTime.Now,
                Nome = string.Empty,
                IdentificadorRodada = entityDTO.IdentificadorRodada,
                CarteiraInvestimento = entityDTO.CarteiraInvestimento.TranslateFromDTO(),
                ParametrizacaoRodada = entityDTO.ParametrizacaoRodada == null ? null : new ParametrizacaoRodada()
                {
                    Codigo = entityDTO.ParametrizacaoRodada.Codigo,
                    ValorPercentualMinimoAcoes = entityDTO.ParametrizacaoRodada.ValorPercentualMinimoAcoes,
                    ValorPercentualMinimoOutros = entityDTO.ParametrizacaoRodada.ValorPercentualMinimoOutros,
                    ValorPercentualPenalidadeRodada = entityDTO.ParametrizacaoRodada.ValorPercentualPenalidadeRodada
                },
                GrupoEscolar = entityDTO.GrupoEscolar == null ? null : new GrupoEscolar()
                {
                    Codigo = entityDTO.GrupoEscolar.Codigo,
                    CodigoOriginalLMS = entityDTO.GrupoEscolar.CodigoOriginalLMS,
                    NomeGrupo = entityDTO.GrupoEscolar.NomeGrupo,
                    ValorInvestimentoInicial = entityDTO.GrupoEscolar.ValorInvestimentoInicial
                },
                CenarioSimulacao = entityDTO.CenarioSimulacao == null ? null : new CenarioSimulacao()
                {
                    Codigo = entityDTO.CenarioSimulacao.Codigo
                }
            };
        }

        public static List<RodadaSimulacaoDTO> TranslateToDTO(this List<RodadaSimulacao> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<RodadaSimulacaoDTO>();
            foreach (RodadaSimulacao et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static RodadaSimulacaoDTO TranslateToDTO(this RodadaSimulacao entity)
        {
            return entity == null ? null : new RodadaSimulacaoDTO()
            {
                Codigo = entity.Codigo,
                IdentificadorRodada = entity.IdentificadorRodada,
                GrupoEscolar = entity.GrupoEscolar == null ? null : new GrupoEscolarDTO()
                {
                    Codigo = entity.GrupoEscolar.Codigo
                },
                ParametrizacaoRodada = entity.ParametrizacaoRodada == null ? null : new ParametrizacaoRodadaDTO()
                {
                    Codigo = entity.ParametrizacaoRodada.Codigo,
                    TempoIntervaloRodadas = entity.ParametrizacaoRodada.TempoIntervaloRodadas,
                    TempoRodada = entity.ParametrizacaoRodada.TempoRodada,
                    TempoTelaInicialRodada = entity.ParametrizacaoRodada.TempoTelaInicialRodada,
                    ValorPercentualMinimoAcoes = entity.ParametrizacaoRodada.ValorPercentualMinimoAcoes,
                    ValorPercentualMinimoOutros = entity.ParametrizacaoRodada.ValorPercentualMinimoOutros,
                    ValorPercentualOscilacao = entity.ParametrizacaoRodada.ValorPercentualOscilacao,
                    ValorPercentualPenalidadeRodada = entity.ParametrizacaoRodada.ValorPercentualPenalidadeRodada,
                    QuantidadeCenariosContingencia = entity.ParametrizacaoRodada.QuantidadeCenariosContingencia,
                    DataCriacao = entity.ParametrizacaoRodada.DataCriacao,
                    IndicadorCenarioRandomico = entity.ParametrizacaoRodada.IndicadorCenarioRandomico,
                    IndicadorParametroAtivo = entity.ParametrizacaoRodada.IndicadorParametroAtivo,
                    IndicadorSimulacaoWEB = entity.ParametrizacaoRodada.TipoModoSimulacao == TipoModoSimulacao.Web ? true : false
                }
            };
        }

        #endregion
     
        #region TranslatorDTO<CarteiraInvestimento,CarteiraInvestimentoDTO> Members

        public static List<CarteiraInvestimento> TranslateFromDTO(this List<CarteiraInvestimentoDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<CarteiraInvestimento>();
            foreach (CarteiraInvestimentoDTO et in entityDTO)
            {
                _returnEntities.Add(et.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static CarteiraInvestimento TranslateFromDTO(this CarteiraInvestimentoDTO entityDTO)
        {
            if (entityDTO == null) return null;

            #region Ativos Carteira Outros
            List<AtivosCarteiraOutros> _ativosCarteirasOutros = null;
            if (null != entityDTO.AtivosCarteiraOutros)
            {
                _ativosCarteirasOutros = new List<AtivosCarteiraOutros>();
                entityDTO.AtivosCarteiraOutros.ForEach(delegate(AtivosCarteiraOutrosDTO ativosOutrosDTO)
                {
                    _ativosCarteirasOutros.Add(new AtivosCarteiraOutros()
                    {
                        Codigo = ativosOutrosDTO.Codigo,
                        NomeAtivo = ativosOutrosDTO.NomeAtivo,
                        Quantidade = ativosOutrosDTO.Quantidade,
                        ValorInvestido = ativosOutrosDTO.ValorInvestido,
                        ValorInvestidoFinal = ativosOutrosDTO.ValorInvestidoFinal,
                        ValorPercentualRendimento = ativosOutrosDTO.ValorPercentualRendimento
                    });
                });
            }

            #endregion

            #region Ativos Carteira Papeis
            List<AtivosCarteiraPapeis> _ativosCarteirasPapeis = null;

            if (null != entityDTO.AtivosCarteiraPapeis)
            {
                _ativosCarteirasPapeis = new List<AtivosCarteiraPapeis>();
                entityDTO.AtivosCarteiraPapeis.ForEach(delegate(AtivosCarteiraPapeisDTO ativosPapeisDTO)
                {
                    _ativosCarteirasPapeis.Add(new AtivosCarteiraPapeis()
                    {
                        Codigo = ativosPapeisDTO.Codigo,
                        PapelCarteira = new PapelCarteira()
                        {
                            Codigo = ativosPapeisDTO.PapelCarteira.Codigo,
                            NomeAbreviado = ativosPapeisDTO.PapelCarteira.NomeAbreviado,
                            NomeCompleto = ativosPapeisDTO.PapelCarteira.NomeCompleto,
                            PrecoCompraInicial = ativosPapeisDTO.ValorPrecoCompra
                        },
                        Quantidade = ativosPapeisDTO.Quantidade,
                        ValorInvestido = ativosPapeisDTO.ValorInvestido,
                        ValorInvestidoFinal = ativosPapeisDTO.ValorInvestidoFinal,
                        ValorPrecoCompra = ativosPapeisDTO.ValorPrecoCompra,
                        ValorPrecoFinal = ativosPapeisDTO.ValorPrecoFinal,
                        ValorRentabilidade = ativosPapeisDTO.ValorRentabilidade
                    });
                });
            }

            #endregion

            #region Carteira Investimento
            return new CarteiraInvestimento()
            {
                AtivosCarteiraOutros = _ativosCarteirasOutros,
                AtivosCarteiraPapeis = _ativosCarteirasPapeis,
                Codigo = entityDTO.Codigo,
                DataHoraCriacao = DateTime.Now,
                RodadaSimulacao = entityDTO.RodadaSimulacao.TranslateFromDTO(),
                RodadaSimulacaoAnterior = entityDTO.RodadaSimulacaoAnterior.TranslateFromDTO(),
                ValorRentabilidadeAcumulada = entityDTO.ValorRentabilidadeAcumulada,
                ValorRentabilidadePeriodo = entityDTO.ValorRentabilidadePeriodo,
                ValorSaldoAtual = entityDTO.ValorSaldoAtual
            };
            #endregion
        }

        public static List<CarteiraInvestimentoDTO> TranslateToDTO(this List<CarteiraInvestimento> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<CarteiraInvestimentoDTO>();
            foreach (CarteiraInvestimento et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static CarteiraInvestimentoDTO TranslateToDTO(this CarteiraInvestimento entity)
        {
            if (entity == null) return null;

            #region Ativos Carteira Outros
            List<AtivosCarteiraOutrosDTO> _ativosCarteirasOutrosDTO = null;
            if (null != entity.AtivosCarteiraOutros)
            {
                _ativosCarteirasOutrosDTO = new List<AtivosCarteiraOutrosDTO>();
                entity.AtivosCarteiraOutros.ForEach(delegate(AtivosCarteiraOutros ativosOutros)
                {
                    _ativosCarteirasOutrosDTO.Add(new AtivosCarteiraOutrosDTO()
                    {
                        Codigo = ativosOutros.Codigo,
                        NomeAtivo = ativosOutros.NomeAtivo,
                        Quantidade = ativosOutros.Quantidade,
                        ValorInvestido = ativosOutros.ValorInvestido,
                        ValorInvestidoFinal = ativosOutros.ValorInvestidoFinal,
                        ValorPercentualRendimento = ativosOutros.ValorPercentualRendimento
                    });
                });
            }
            #endregion

            #region Ativos Carteira Papeis
            List<AtivosCarteiraPapeisDTO> _ativosCarteirasPapeisDTO= null;
            if (null != entity.AtivosCarteiraOutros)
            {
                _ativosCarteirasPapeisDTO = new List<AtivosCarteiraPapeisDTO>();
                entity.AtivosCarteiraPapeis.ForEach(delegate(AtivosCarteiraPapeis ativosPapeis)
                {
                    _ativosCarteirasPapeisDTO.Add(new AtivosCarteiraPapeisDTO()
                    {
                        Codigo = ativosPapeis.Codigo,
                        PapelCarteira = new PapelCarteiraDTO()
                        {
                            Codigo = ativosPapeis.PapelCarteira.Codigo,
                            NomeAbreviado = ativosPapeis.PapelCarteira.NomeAbreviado,
                            NomeCompleto = ativosPapeis.PapelCarteira.NomeCompleto,
                            PrecoCompraInicial = ativosPapeis.PapelCarteira.PrecoCompraInicial
                        },
                        Quantidade = ativosPapeis.Quantidade,
                        ValorInvestido = ativosPapeis.ValorInvestido,
                        ValorInvestidoFinal = ativosPapeis.ValorInvestidoFinal,
                        ValorPrecoCompra = ativosPapeis.ValorPrecoCompra,
                        ValorPrecoFinal = ativosPapeis.ValorPrecoFinal,
                        ValorRentabilidade = ativosPapeis.ValorRentabilidade
                    });
                });
            }
            #endregion

            #region Carteira Investimento
            return new CarteiraInvestimentoDTO()
            {
                AtivosCarteiraOutros = _ativosCarteirasOutrosDTO,
                AtivosCarteiraPapeis = _ativosCarteirasPapeisDTO,
                Codigo = entity.Codigo,
                RodadaSimulacao = entity.RodadaSimulacao.TranslateToDTO(),
                RodadaSimulacaoAnterior = entity.RodadaSimulacaoAnterior.TranslateToDTO(),
                ValorRentabilidadeAcumulada = entity.ValorRentabilidadeAcumulada,
                ValorRentabilidadePeriodo = entity.ValorRentabilidadePeriodo,
                ValorSaldoAtual = entity.ValorSaldoAtual
            };

            #endregion
        }

        #endregion

        #region TranslatorDTO<RodadaCenario,RodadaCenarioDTO> Members

        public static List<RodadaCenario> TranslateFromDTO(this List<RodadaCenarioDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<RodadaCenario>();
            foreach (RodadaCenarioDTO et in entityDTO)
            {
                _returnEntities.Add(et.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static RodadaCenario TranslateFromDTO(this RodadaCenarioDTO entityDTO)
        {
            return entityDTO == null ? null : new RodadaCenario()
            {
                CenarioSimulacao = new CenarioSimulacao()
                {
                    Codigo = entityDTO.CenarioSimulacao.Codigo,
                },
                IndicadorCenarioContingencia = entityDTO.IndicadorCenarioContingencia
            };
        }

        public static List<RodadaCenarioDTO> TranslateToDTO(this List<RodadaCenario> entity, RodadaSimulacaoDTO rodadaSimulacao)
        {
            if (entity == null) return null;

            var _returnEntities = new List<RodadaCenarioDTO>();
            foreach (RodadaCenario et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO(rodadaSimulacao));
            }
            return _returnEntities;
        }

        public static RodadaCenarioDTO TranslateToDTO(this RodadaCenario entity, RodadaSimulacaoDTO rodadaSimulacao) 
        {
            var _entityReturn = entity.TranslateToDTO();
            _entityReturn.RodadaSimulacao = rodadaSimulacao;
            return _entityReturn;
        }
        public static RodadaCenarioDTO TranslateToDTO(this RodadaCenario entity)
        {
            return entity == null ? null : new RodadaCenarioDTO()
            {
                CenarioSimulacao = entity.CenarioSimulacao.TranslateToDTO(),
                IndicadorCenarioContingencia = entity.IndicadorCenarioContingencia,
                FatosRelevante = entity.CenarioSimulacao == null ? null : entity.CenarioSimulacao.FatosRelavantes.TranslateToDTO(),
                GraficosCenario = entity.CenarioSimulacao == null ? null : entity.CenarioSimulacao.GraficosCenario.TranslateToDTO()
            };
        }

        #endregion

        #region TranslatorDTO<AgendaSimulacao,AgendaSimulacaoDTO> Members

        public static List<AgendaSimulacao> TranslateFromDTO(this List<AgendaSimulacaoDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<AgendaSimulacao>();
            foreach (AgendaSimulacaoDTO entity in entityDTO)
            {
                _returnEntities.Add(entity.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static AgendaSimulacao TranslateFromDTO(this AgendaSimulacaoDTO entityDTO)
        {
            var _agendaSimulacao = entityDTO == null ? null : new AgendaSimulacao()
            {
                Codigo = entityDTO.Codigo,
                CodigoOriginalLMS = entityDTO.CodigoOriginalLMS,
                DataHoraAgendamento = entityDTO.DataHoraAgendamento,
                DataHoraCriacao = DateTime.Now,
                ParametrizacaoAgenda = entityDTO.ParametrizacaoAgenda.TranslateFromDTO(),
                AgendaSimulacaoRodadas = entityDTO.AgendaSimulacaoRodadas.TranslateFromDTO(),
                TipoSemanaSimulacao = entityDTO.TipoSemanaSimulacao.ConvertToEnum()
            };
            return _agendaSimulacao;
        }

        public static List<AgendaSimulacaoDTO> TranslateToDTO(this List<AgendaSimulacao> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<AgendaSimulacaoDTO>();
            foreach (AgendaSimulacao et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static AgendaSimulacaoDTO TranslateToDTO(this AgendaSimulacao entity)
        {
            var _agendaDTO = entity == null ? null : new AgendaSimulacaoDTO()
            {
                Codigo = entity.Codigo,
                CodigoOriginalLMS = entity.CodigoOriginalLMS,
                DataHoraAgendamento = entity.DataHoraAgendamento,
                ParametrizacaoAgenda = entity.ParametrizacaoAgenda.TranslateToDTO(),
                AgendaSimulacaoRodadas = entity.AgendaSimulacaoRodadas.TranslateToDTO(),
                TipoSemanaSimulacao = entity.TipoSemanaSimulacao.ConvertToEnum(),
                TermoAceiteSimulacao = entity.TermoAceiteSimulacao.TranslateToDTO()
            };

            if (_agendaDTO.AgendaSimulacaoRodadas != null)
            {
                var _agendaNaoConcluida = (_agendaDTO.AgendaSimulacaoRodadas.Where(ag => ag.IndicadorSimulacaoConcluida == false).FirstOrDefault<AgendaSimulacaoRodadasDTO>());
                if (_agendaNaoConcluida == null)//Se for null, siginifica que todas as rodadas de simulação foram concluídadas
                    _agendaDTO.IndicadorSimulacaoConcluida = true;
            }
            return _agendaDTO;
        }

        #endregion

        #region TranslatorDTO<AgendaSimulacaoRodadas,AgendaSimulacaoRodadasDTO> Members

        public static List<AgendaSimulacaoRodadas> TranslateFromDTO(this List<AgendaSimulacaoRodadasDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<AgendaSimulacaoRodadas>();
            foreach (AgendaSimulacaoRodadasDTO entity in entityDTO)
            {
                _returnEntities.Add(entity.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static AgendaSimulacaoRodadas TranslateFromDTO(this AgendaSimulacaoRodadasDTO entityDTO)
        {
            return entityDTO == null ? null : new AgendaSimulacaoRodadas()
            {
                Rodada = entityDTO.Rodada.TranslateFromDTO(),
                GrupoEscolar = entityDTO.GrupoEscolar == null ? null : new GrupoEscolar()
                {
                    Codigo = entityDTO.GrupoEscolar.Codigo
                },
                ContadorRodadaContingencia = entityDTO.ContadorRodadaContingencia,
                IndicadorSimulacaoConcluida = entityDTO.IndicadorSimulacaoConcluida,
                AgendaSimulacao = entityDTO.AgendaSimulacao == null ? null : new AgendaSimulacao()
                {
                    Codigo = entityDTO.AgendaSimulacao.Codigo,
                    DataHoraAgendamento = entityDTO.AgendaSimulacao.DataHoraAgendamento,
                    TipoSemanaSimulacao = entityDTO.AgendaSimulacao.TipoSemanaSimulacao.ConvertToEnum(),
                    ParametrizacaoAgenda = entityDTO.AgendaSimulacao.ParametrizacaoAgenda.TranslateFromDTO()
                }
            };
        }

        public static List<AgendaSimulacaoRodadasDTO> TranslateToDTO(this List<AgendaSimulacaoRodadas> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<AgendaSimulacaoRodadasDTO>();
            foreach (AgendaSimulacaoRodadas et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static AgendaSimulacaoRodadasDTO TranslateToDTO(this AgendaSimulacaoRodadas entity)
        {
            return entity == null ? null : new AgendaSimulacaoRodadasDTO()
            {
                ContadorRodadaContingencia = entity.ContadorRodadaContingencia,
                IndicadorSimulacaoConcluida = entity.IndicadorSimulacaoConcluida,
                GrupoEscolar = entity.GrupoEscolar == null ? null : new GrupoEscolarDTO()
                {
                    Codigo = entity.GrupoEscolar.Codigo
                },
                Rodada = entity.Rodada.TranslateToDTO(),
                AgendaSimulacao = entity.AgendaSimulacao == null ? null : new AgendaSimulacaoDTO()
                {
                    Codigo = entity.AgendaSimulacao.Codigo,
                    DataHoraAgendamento = entity.AgendaSimulacao.DataHoraAgendamento,
                    TipoSemanaSimulacao = entity.AgendaSimulacao.TipoSemanaSimulacao.ConvertToEnum(),
                    ParametrizacaoAgenda = entity.AgendaSimulacao.ParametrizacaoAgenda.TranslateToDTO()
                },
                RodadaCenario = entity.RodadaCenario.TranslateToDTO(entity.Rodada.TranslateToDTO())
            };
        }

        #endregion

        #region TranslatorDTO<Escola,EscolaDTO> Members

        public static List<Escola> TranslateFromDTO(this List<EscolaDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<Escola>();
            foreach (EscolaDTO entity in entityDTO)
            {
                _returnEntities.Add(entity.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static Escola TranslateFromDTO(this EscolaDTO entityDTO)
        {
            return entityDTO == null ? null : new Escola()
            {
                Codigo = entityDTO.Codigo,
                CodigoOriginalLMS = entityDTO.CodigoOriginalLMS,
                Diretor = new Diretor()
                {
                    Nome = entityDTO.Diretor.Nome,
                    Codigo = entityDTO.Diretor.Codigo,
                    DiretoriaEnsino = entityDTO.Diretor.DiretoriaEnsino,
                    EmailContato = entityDTO.Diretor.EmailContato
                },
                Email = entityDTO.Email,
                IndicadorEscolaPrivada = entityDTO.IndicadorEscolaPrivada,
                Nome = entityDTO.Nome,
                NumeroCNPJ = entityDTO.CNPJ,
                GruposEscolares = entityDTO.GruposEscolares.TranslateFromDTO(),
                Telefones = entityDTO.Telefones.TranslateFromDTO(),
                TipoStatusSorteioCenarios = entityDTO.TipoStatusSorteioCenariosDTO == TipoStatusSorteioCenariosDTO.OK ? TipoStatusSorteioCenarios.OK : TipoStatusSorteioCenarios.Pendente
            };
        }

        public static List<EscolaDTO> TranslateToDTO(this List<Escola> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<EscolaDTO>();
            foreach (Escola et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static EscolaDTO TranslateToDTO(this Escola entity)
        {
            return entity == null ? null : new EscolaDTO()
            {
                Codigo = entity.Codigo,
                CodigoOriginalLMS = entity.CodigoOriginalLMS,
                Diretor = new DiretorDTO()
                {
                    Nome = entity.Diretor.Nome,
                    Codigo = entity.Diretor.Codigo,
                    DiretoriaEnsino = entity.Diretor.DiretoriaEnsino,
                    EmailContato = entity.Diretor.EmailContato
                },
                Email = entity.Email,
                IndicadorEscolaPrivada = entity.IndicadorEscolaPrivada,
                Nome = entity.Nome,
                CNPJ = entity.NumeroCNPJ,
                GruposEscolares = entity.GruposEscolares.TranslateToDTO(),
                Telefones = entity.Telefones.TranslateToDTO(),
                TipoStatusSorteioCenariosDTO = entity.TipoStatusSorteioCenarios == TipoStatusSorteioCenarios.OK ? TipoStatusSorteioCenariosDTO.OK : TipoStatusSorteioCenariosDTO.Pendente
            };
        }

        #endregion

        #region TranslatorDTO<GrupoEscolar,GrupoEscolarDTO> Members

        public static List<GrupoEscolar> TranslateFromDTO(this List<GrupoEscolarDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<GrupoEscolar>();
            foreach (GrupoEscolarDTO entity in entityDTO)
            {
                _returnEntities.Add(entity.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static GrupoEscolar TranslateFromDTO(this GrupoEscolarDTO entityDTO)
        {
            #region Agenda Simulacao Grupo Escolar
            List<AgendaSimulacao> _agendamentosGrupoEscolar = null;
            if (entityDTO.AgendaSimulacao != null)
            {
                 _agendamentosGrupoEscolar = new List<AgendaSimulacao>();
                foreach (AgendaSimulacaoDTO agenda in entityDTO.AgendaSimulacao)
                {
                    AgendaSimulacao _agendaGrupoEscolar = new AgendaSimulacao()
                    {
                        Codigo = agenda.Codigo,
                        CodigoOriginalLMS = agenda.CodigoOriginalLMS,
                        DataHoraAgendamento = agenda.DataHoraAgendamento,
                        DataHoraCriacao = DateTime.Now,
                        TipoSemanaSimulacao = agenda.TipoSemanaSimulacao.ConvertToEnum()
                    };
                    _agendamentosGrupoEscolar.Add(_agendaGrupoEscolar);
                }
            }
            #endregion

            #region Grupos Escolares
            return entityDTO == null ? null : new GrupoEscolar()
            {
                CodigoOriginalLMS = entityDTO.CodigoOriginalLMS,
                NomeGrupo = entityDTO.NomeGrupo,
                ValorInvestimentoInicial = entityDTO.ValorInvestimentoInicial,
                Alunos = entityDTO.Alunos.TranslateFromDTO(),
                Professor = entityDTO.Professor.TranslateFromDTO(),
                AgendaSimulacao = _agendamentosGrupoEscolar
            };
            #endregion
        }

        public static List<GrupoEscolarDTO> TranslateToDTO(this List<GrupoEscolar> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<GrupoEscolarDTO>();
            foreach (GrupoEscolar et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static GrupoEscolarDTO TranslateToDTO(this GrupoEscolar entity)
        {
            /*#region Agenda Simulacao Grupo Escolar
            List<AgendaSimulacaoDTO> _agendamentosGrupoEscolar = null;
            if (null != entity.AgendaSimulacao)
            {
                _agendamentosGrupoEscolar = new List<AgendaSimulacaoDTO>();

                foreach (AgendaSimulacao agenda in entity.AgendaSimulacao)
                {
                    AgendaSimulacaoDTO _agendaGrupoEscolar = new AgendaSimulacaoDTO()
                    {
                        Codigo = agenda.Codigo,
                        CodigoOriginalLMS = agenda.CodigoOriginalLMS,
                        DataHoraAgendamento = agenda.DataHoraAgendamento,
                        TipoSemanaSimulacao = agenda.TipoSemanaSimulacao.ConvertToEnum(),
                        ParametrizacaoAgenda = agenda.ParametrizacaoAgenda == null ? null : new ParametrizacaoAgendaDTO()
                        {
                            Codigo = agenda.ParametrizacaoAgenda.Codigo,
                            MediaInicialSimulacao = agenda.ParametrizacaoAgenda.MediaInicialSimulacao,
                            QuantidadeRodadas = agenda.ParametrizacaoAgenda.QuantidadeRodadas,
                            VariacaoMaximaSimulacao = agenda.ParametrizacaoAgenda.VariacaoMaximaSimulacao,
                            IndicadorSimulacaoWEB = agenda.ParametrizacaoAgenda.TipoModoSimulacao == TipoModoSimulacao.Web ? true : false
                        }
                    };

                    if (agenda.AgendaSimulacaoRodadas != null)
                    {
                        var _agendaNaoConcluida = (agenda.AgendaSimulacaoRodadas.Where(ag => ag.IndicadorSimulacaoConcluida == false).FirstOrDefault<AgendaSimulacaoRodadas>());
                        if (_agendaNaoConcluida == null)//Se for null, siginifica que todas as rodadas de simulação foram concluídadas
                            _agendaGrupoEscolar.IndicadorSimulacaoConcluida = true;
                    }
                    _agendamentosGrupoEscolar.Add(_agendaGrupoEscolar);
                }
            }
            #endregion*/

            #region Grupos Escolares
            return entity == null ? null : new GrupoEscolarDTO()
            {
                Codigo = entity.Codigo,
                CodigoOriginalLMS = entity.CodigoOriginalLMS,
                NomeGrupo = entity.NomeGrupo,
                ValorInvestimentoInicial = entity.ValorInvestimentoInicial,
                Alunos = entity.Alunos.TranslateToDTO(),
                Professor = entity.Professor.TranslateToDTO(),
                //AgendaSimulacao = _agendamentosGrupoEscolar,
                IndicadorDesclassificado = entity.IndicadorGrupoDesclassificado
            };
            #endregion
        }

        #endregion

        #region TranslatorDTO<Aluno,AlunoDTO> Members

        public static List<Aluno> TranslateFromDTO(this List<AlunoDTO> entityDTO)
        {
            List<Aluno> _returnEntities = entityDTO == null ? null : new List<Aluno>();
            foreach (AlunoDTO entity in entityDTO)
            {
                _returnEntities.Add(entity.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static Aluno TranslateFromDTO(this AlunoDTO entityDTO)
        {
            return entityDTO == null ? null : new Aluno()
            {
                CodigoOriginalLMS = entityDTO.CodigoOriginalLMS,
                EmailContato = entityDTO.EmailContato,
                Nome = entityDTO.Nome,
                Documentos = entityDTO.Documentos.TranslateFromDTO(),
                Telefones = entityDTO.Telefones.TranslateFromDTO()
            };
        }

        public static List<AlunoDTO> TranslateToDTO(this List<Aluno> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<AlunoDTO>();
            foreach (Aluno et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static AlunoDTO TranslateToDTO(this Aluno entity)
        {
            return entity == null ? null : new AlunoDTO()
            {
                Codigo = entity.Codigo,
                CodigoOriginalLMS = entity.CodigoOriginalLMS,
                EmailContato = entity.EmailContato,
                Nome = entity.Nome,
                Documentos = entity.Documentos.TranslateToDTO(),
                Telefones = entity.Telefones.TranslateToDTO()
            };
        }

        #endregion

        #region TranslatorDTO<Telefone,TelefoneDTO> Members

        public static List<Telefone> TranslateFromDTO(this List<TelefoneDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<Telefone>();
            foreach (TelefoneDTO entity in entityDTO)
            {
                _returnEntities.Add(entity.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static Telefone TranslateFromDTO(this TelefoneDTO entityDTO)
        {
            return entityDTO == null ? null : new Telefone()
            {
                NomeContato = entityDTO.NomeContato,
                Numero = entityDTO.Numero,
                TipoTelefone = entityDTO.TipoTelefone.ConvertToEnum()
            };
        }

        public static List<TelefoneDTO> TranslateToDTO(this List<Telefone> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<TelefoneDTO>(); 
            foreach (Telefone et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static TelefoneDTO TranslateToDTO(this Telefone entity)
        {
            return entity == null ? null : new TelefoneDTO()
            {
                NomeContato = entity.NomeContato,
                Numero = entity.Numero,
                TipoTelefone = entity.TipoTelefone.ConvertToEnum()
            };
        }

        #endregion

        #region TranslatorDTO<Documento,DocumentoDTO> Members

        public static List<Documento> TranslateFromDTO(this List<DocumentoDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<Documento>(); 
            foreach (DocumentoDTO entity in entityDTO)
            {
                _returnEntities.Add(entity.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static Documento TranslateFromDTO(this DocumentoDTO entityDTO)
        {
            return entityDTO == null ? null : new Documento()
            {
                NumeroDocumento = entityDTO.NumeroDocumento,
                TipoDocumento = entityDTO.TipoDocumento.ConvertToEnum()
            };
        }

        public static List<DocumentoDTO> TranslateToDTO(this List<Documento> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<DocumentoDTO>(); 
            foreach (Documento et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static DocumentoDTO TranslateToDTO(this Documento entity)
        {
            return entity == null ? null : new DocumentoDTO()
            {
                NumeroDocumento = entity.NumeroDocumento,
                TipoDocumento = entity.TipoDocumento.ConvertToEnum()
            };
        }

        #endregion

        #region TranslatorDTO<Professor,ProfessorDTO> Members

        public static List<Professor> TranslateFromDTO(this List<ProfessorDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<Professor>();
            foreach (ProfessorDTO entity in entityDTO)
            {
                _returnEntities.Add(entity.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static Professor TranslateFromDTO(this ProfessorDTO entityDTO)
        {
            return entityDTO == null ? null : new Professor()
            {
                CodigoOriginalLMS = entityDTO.CodigoOriginalLMS,
                EmailContato = entityDTO.EmailContato,
                Nome = entityDTO.Nome,
                Documentos = entityDTO.Documentos.TranslateFromDTO(),
                Telefones = entityDTO.Telefones.TranslateFromDTO()
            };
        }

        public static List<ProfessorDTO> TranslateToDTO(this List<Professor> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<ProfessorDTO>();
            foreach (Professor et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static ProfessorDTO TranslateToDTO(this Professor entity)
        {
            return entity == null ? null : new ProfessorDTO()
            {
                Codigo = entity.Codigo,
                CodigoOriginalLMS = entity.CodigoOriginalLMS,
                EmailContato = entity.EmailContato,
                Nome = entity.Nome,
                Documentos = entity.Documentos.TranslateToDTO(),
                Telefones = entity.Telefones.TranslateToDTO(),
                CodigoGrupoEscolar = entity.GrupoEscolar.Codigo
            };
        }

        #endregion

        #region TranslatorDTO<PapelCarteira,PapelCarteiraDTO> Members

        public static List<PapelCarteira> TranslateFromDTO(this List<PapelCarteiraDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<PapelCarteira>();
            foreach (PapelCarteiraDTO et in entityDTO)
            {
                _returnEntities.Add(et.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static PapelCarteira TranslateFromDTO(this PapelCarteiraDTO entityDTO)
        {
            return entityDTO == null ? null : new PapelCarteira()
            {
                Codigo = entityDTO.Codigo,
                NomeAbreviado = entityDTO.NomeAbreviado,
                NomeCompleto = entityDTO.NomeCompleto,
                PrecoCompraInicial = entityDTO.PrecoCompraInicial,
                TipoSemanaSimulacao = entityDTO.TipoSemanaSimulacao.ConvertToEnum()
            };
        }

        public static List<PapelCarteiraDTO> TranslateToDTO(this List<PapelCarteira> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<PapelCarteiraDTO>();
            foreach (PapelCarteira et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static PapelCarteiraDTO TranslateToDTO(this PapelCarteira entity)
        {
            return entity == null ? null : new PapelCarteiraDTO()
            {
                Codigo = entity.Codigo,
                NomeAbreviado = entity.NomeAbreviado,
                NomeCompleto = entity.NomeCompleto,
                PrecoCompraInicial = entity.PrecoCompraInicial,
                TipoSemanaSimulacao = entity.TipoSemanaSimulacao.ConvertToEnum()
            };
        }

        #endregion

        #region TranslatorDTO<ParametrizacaoAgenda,ParametrizacaoAgendaDTO> Members

        public static List<ParametrizacaoAgenda> TranslateFromDTO(this List<ParametrizacaoAgendaDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<ParametrizacaoAgenda>();
            foreach (ParametrizacaoAgendaDTO et in entityDTO)
            {
                _returnEntities.Add(et.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static ParametrizacaoAgenda TranslateFromDTO(this ParametrizacaoAgendaDTO entityDTO)
        {
            return new ParametrizacaoAgenda()
            {
                Codigo = entityDTO.Codigo,
                QuantidadeRodadas = entityDTO.QuantidadeRodadas,
                TipoModoSimulacao = entityDTO.IndicadorSimulacaoWEB == true ? TipoModoSimulacao.Web : TipoModoSimulacao.Presencial,
                MediaInicialSimulacao = entityDTO.MediaInicialSimulacao,
                VariacaoMaximaSimulacao = entityDTO.VariacaoMaximaSimulacao,
                MaximaTentativaContigencia = entityDTO.MaximaTentativaContingencia
            };
        }

        public static List<ParametrizacaoAgendaDTO> TranslateToDTO(this List<ParametrizacaoAgenda> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<ParametrizacaoAgendaDTO>();
            foreach (ParametrizacaoAgenda et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static ParametrizacaoAgendaDTO TranslateToDTO(this ParametrizacaoAgenda entity)
        {
            return new ParametrizacaoAgendaDTO()
            {
                Codigo = entity.Codigo,
                QuantidadeRodadas = entity.QuantidadeRodadas,
                IndicadorSimulacaoWEB = entity.TipoModoSimulacao == TipoModoSimulacao.Web ? true : false,
                MediaInicialSimulacao = entity.MediaInicialSimulacao,
                VariacaoMaximaSimulacao = entity.VariacaoMaximaSimulacao,
                MaximaTentativaContingencia = entity.MaximaTentativaContigencia
            };
        }

        #endregion

        #region TranslatorDTO<ParametrizacaoRodada,ParametrizacaoRodadaDTO> Members

        public static List<ParametrizacaoRodada> TranslateFromDTO(this List<ParametrizacaoRodadaDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<ParametrizacaoRodada>();
            foreach (ParametrizacaoRodadaDTO et in entityDTO)
            {
                _returnEntities.Add(et.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static ParametrizacaoRodada TranslateFromDTO(this ParametrizacaoRodadaDTO entityDTO)
        {
            return new ParametrizacaoRodada()
            {
                Codigo = entityDTO.Codigo,
                IndicadorCenarioRandomico = entityDTO.IndicadorCenarioRandomico,
                QuantidadeCenariosContingencia = entityDTO.QuantidadeCenariosContingencia,
                TempoIntervaloRodadas = entityDTO.TempoIntervaloRodadas,
                TempoRodada = entityDTO.TempoRodada,
                TempoTelaInicialRodada = entityDTO.TempoTelaInicialRodada,
                ValorPercentualMinimoAcoes = entityDTO.ValorPercentualMinimoAcoes,
                ValorPercentualMinimoOutros = entityDTO.ValorPercentualMinimoOutros,
                ValorPercentualPenalidadeRodada = entityDTO.ValorPercentualPenalidadeRodada,
                TipoModoSimulacao = entityDTO.IndicadorSimulacaoWEB == true ? TipoModoSimulacao.Web : TipoModoSimulacao.Presencial,
                DataCriacao = entityDTO.DataCriacao,
                IndicadorParametroAtivo = entityDTO.IndicadorParametroAtivo,
                ValorPercentualOscilacao = entityDTO.ValorPercentualOscilacao
            };
        }

        public static List<ParametrizacaoRodadaDTO> TranslateToDTO(this List<ParametrizacaoRodada> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<ParametrizacaoRodadaDTO>();
            foreach (ParametrizacaoRodada et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static ParametrizacaoRodadaDTO TranslateToDTO(this ParametrizacaoRodada entity)
        {
            return new ParametrizacaoRodadaDTO()
            {
                Codigo = entity.Codigo,
                IndicadorCenarioRandomico = entity.IndicadorCenarioRandomico,
                QuantidadeCenariosContingencia = entity.QuantidadeCenariosContingencia,
                TempoIntervaloRodadas = entity.TempoIntervaloRodadas,
                TempoRodada = entity.TempoRodada,
                TempoTelaInicialRodada = entity.TempoTelaInicialRodada,
                ValorPercentualMinimoAcoes = entity.ValorPercentualMinimoAcoes,
                ValorPercentualMinimoOutros = entity.ValorPercentualMinimoOutros,
                ValorPercentualPenalidadeRodada = entity.ValorPercentualPenalidadeRodada,
                IndicadorSimulacaoWEB = entity.TipoModoSimulacao == TipoModoSimulacao.Web ? true : false,
                DataCriacao = entity.DataCriacao,
                IndicadorParametroAtivo = entity.IndicadorParametroAtivo,
                ValorPercentualOscilacao = entity.ValorPercentualOscilacao
            };
        }

        #endregion

        #region TranslatorDTO<CondicoesTermoAceite,CondicoesTermoAceiteDTO> Members

        public static List<CondicoesTermoAceite> TranslateFromDTO(this List<CondicoesTermoAceiteDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<CondicoesTermoAceite>();
            foreach (CondicoesTermoAceiteDTO et in entityDTO)
            {
                _returnEntities.Add(et.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static CondicoesTermoAceite TranslateFromDTO(this CondicoesTermoAceiteDTO entityDTO)
        {
            var _condicaoTermoAceiteSimulacao = new CondicoesTermoAceite()
            {
                Codigo = entityDTO.Codigo,
                Descricao = entityDTO.Descricao,
                TermoAceiteSimulacao = entityDTO.TermoAceiteSimulacao.TranslateFromDTO()
            };
            return _condicaoTermoAceiteSimulacao;
        }

        public static List<CondicoesTermoAceiteDTO> TranslateToDTO(this List<CondicoesTermoAceite> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<CondicoesTermoAceiteDTO>();
            foreach (CondicoesTermoAceite et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static CondicoesTermoAceiteDTO TranslateToDTO(this CondicoesTermoAceite entity)
        {
            var _condicaoTermoAceiteSimulacao = new CondicoesTermoAceiteDTO()
            {
                Codigo = entity.Codigo,
                Descricao = entity.Descricao,
                TermoAceiteSimulacao = entity.TermoAceiteSimulacao.TranslateToDTO()
            };
            return _condicaoTermoAceiteSimulacao;
        }

        #endregion

        #region TranslatorDTO<TermoAceiteSimulacao,TermoAceiteSimulacaoDTO> Members

        public static List<TermoAceiteSimulacao> TranslateFromDTO(this List<TermoAceiteSimulacaoDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<TermoAceiteSimulacao>();
            foreach (TermoAceiteSimulacaoDTO et in entityDTO)
            {
                _returnEntities .Add(et.TranslateFromDTO());
            }
            return _returnEntities ;
        }

        public static TermoAceiteSimulacao TranslateFromDTO(this TermoAceiteSimulacaoDTO entityDTO)
        {
            var _termoAceiteSimulacao = entityDTO == null ? null : new TermoAceiteSimulacao()
            {
                Codigo = entityDTO.Codigo,
                Descricao = entityDTO.Descricao,
                TipoModoSimulacao = entityDTO.TipoModoSimulacaoDTO == TipoModoSimulacaoDTO.Web ? TipoModoSimulacao.Web : TipoModoSimulacao.Presencial,
                IndicadorTermoAceito = entityDTO.IndicadorTermoAceito,
                AgendaSimulacao = entityDTO.GrupoEscolar == null ? null : new AgendaSimulacao()
                {
                    Codigo = entityDTO.GrupoEscolar.AgendaSimulacao[0].Codigo,
                    GrupoEscolar = new List<GrupoEscolar>() { new GrupoEscolar() { Codigo = entityDTO.GrupoEscolar.Codigo } }
                }
            };
            return _termoAceiteSimulacao;
        }

        public static List<TermoAceiteSimulacaoDTO> TranslateToDTO(this List<TermoAceiteSimulacao> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<TermoAceiteSimulacaoDTO>();
            foreach (TermoAceiteSimulacao et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static TermoAceiteSimulacaoDTO TranslateToDTO(this TermoAceiteSimulacao entity)
        {
            var _termoAceiteSimulacaoDTO = entity == null ? null : new TermoAceiteSimulacaoDTO()
            {
                Codigo = entity.Codigo,
                Descricao = entity.Descricao,
                TipoModoSimulacaoDTO = entity.TipoModoSimulacao == TipoModoSimulacao.Web ? TipoModoSimulacaoDTO.Web : TipoModoSimulacaoDTO.Presencial,
                IndicadorTermoAceito = entity.IndicadorTermoAceito,
                GrupoEscolar = entity.AgendaSimulacao == null ? null : new GrupoEscolarDTO()
                {
                    Codigo = entity.AgendaSimulacao.GrupoEscolar[0].Codigo,
                    AgendaSimulacao = new List<AgendaSimulacaoDTO>() { new AgendaSimulacaoDTO() { Codigo = entity.AgendaSimulacao.Codigo } }
                }
            };
            return _termoAceiteSimulacaoDTO;
        }

        #endregion

        #region TranslatorDTO<TaxaLucratividadeCenario,TaxaLucratividadeCenarioDTO> Members

        public static List<TaxaLucratividadeCenario> TranslateFromDTO(this List<TaxaLucratividadeCenarioDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<TaxaLucratividadeCenario>();
            foreach (TaxaLucratividadeCenarioDTO et in entityDTO)
            {
                _returnEntities.Add(et.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static TaxaLucratividadeCenario TranslateFromDTO(this TaxaLucratividadeCenarioDTO entityDTO)
        {
            return new TaxaLucratividadeCenario()
            {
                ValorPercentualLucratividade = entityDTO.ValorPercentualLucratividade,
                ValorPercentualOscilacao = entityDTO.ValorPercentualOscilacao,
                CenarioSimulacao = new CenarioSimulacao() { Codigo = entityDTO.CenarioSimulacao.Codigo },
                PapelCarteira = new PapelCarteira() { Codigo = entityDTO.PapelCarteira.Codigo }
            };
        }

        public static List<TaxaLucratividadeCenarioDTO> TranslateToDTO(this List<TaxaLucratividadeCenario> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<TaxaLucratividadeCenarioDTO>();
            foreach (TaxaLucratividadeCenario et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static TaxaLucratividadeCenarioDTO TranslateToDTO(this TaxaLucratividadeCenario entity)
        {
            return new TaxaLucratividadeCenarioDTO()
            {
                ValorPercentualLucratividade = entity.ValorPercentualLucratividade,
                ValorPercentualOscilacao = entity.ValorPercentualOscilacao,
                CenarioSimulacao = new CenarioSimulacaoDTO()
                {
                    Codigo = entity.CenarioSimulacao.Codigo,
                    NumeracaoCenario = entity.CenarioSimulacao.NumeracaoCenario
                },
                PapelCarteira = new PapelCarteiraDTO()
                {
                    Codigo = entity.PapelCarteira.Codigo,
                    NomeAbreviado = entity.PapelCarteira.NomeAbreviado, 
                    NomeCompleto = entity.PapelCarteira.NomeCompleto
                }
            };
        }

        #endregion

        #region TranslatorDTO<GraficoCenario,GraficoCenarioDTO> Members

        public static List<GraficoCenario> TranslateFromDTO(this List<GraficoCenarioDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<GraficoCenario>();
            foreach (GraficoCenarioDTO et in entityDTO)
            {
                _returnEntities.Add(et.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static GraficoCenario TranslateFromDTO(this GraficoCenarioDTO entityDTO)
        {
            return entityDTO == null ? null : new GraficoCenario()
            {
                BufferImagem = entityDTO.BufferImagem,
                CaminhoFisico = entityDTO.CaminhoFisico,
                DataCriacao = entityDTO.DataCriacao,
                Descricao = entityDTO.Descricao,
                Nome = entityDTO.Nome,
                Codigo = entityDTO.Codigo,
                CenarioSimulacao = new CenarioSimulacao() { Codigo = entityDTO.CenarioSimulacao.Codigo }
            };
        }

        public static List<GraficoCenarioDTO> TranslateToDTO(this List<GraficoCenario> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<GraficoCenarioDTO>();
            foreach (GraficoCenario et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static GraficoCenarioDTO TranslateToDTO(this GraficoCenario entity)
        {
            return entity == null ? null : new GraficoCenarioDTO()
            {
                BufferImagem = entity.BufferImagem,
                CaminhoFisico = entity.CaminhoFisico,
                DataCriacao = entity.DataCriacao,
                Descricao = entity.Descricao,
                Nome = entity.Nome,
                Codigo = entity.Codigo,
                CenarioSimulacao = entity.CenarioSimulacao == null ? null : new CenarioSimulacaoDTO()
                {
                    Codigo = entity.CenarioSimulacao.Codigo,
                    NumeracaoCenario = entity.CenarioSimulacao.NumeracaoCenario,
                }
            };
        }
        #endregion

        #region TranslatorDTO<FatoRelevante,FatoRelevanteDTO> Members

        public static List<FatoRelevante> TranslateFromDTO(this List<FatoRelevanteDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<FatoRelevante>();
            foreach (FatoRelevanteDTO et in entityDTO)
            {
                _returnEntities.Add(et.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static FatoRelevante TranslateFromDTO(this FatoRelevanteDTO entityDTO)
        {
            return entityDTO == null ? null : new FatoRelevante()
            {
                Codigo = entityDTO.Codigo,
                Descricao = entityDTO.DescricaoFato,
                CenarioSimulacao = entityDTO.CenarioSimulacao == null ? null : new CenarioSimulacao() { Codigo = entityDTO.CenarioSimulacao.Codigo },
                Papel = entityDTO.PapelCarteira == null ? null : new PapelCarteira() { Codigo = entityDTO.PapelCarteira.Codigo }
            };
        }

        public static List<FatoRelevanteDTO> TranslateToDTO(this List<FatoRelevante> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<FatoRelevanteDTO>();
            foreach (FatoRelevante et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static FatoRelevanteDTO TranslateToDTO(this FatoRelevante entity)
        {
            return entity == null ? null : new FatoRelevanteDTO()
            {
                Codigo = entity.Codigo,
                DescricaoFato = entity.Descricao,
                CenarioSimulacao = entity.CenarioSimulacao == null ? null : new CenarioSimulacaoDTO()
                {
                    Codigo = entity.CenarioSimulacao.Codigo,
                    NumeracaoCenario = entity.CenarioSimulacao.NumeracaoCenario
                },
                PapelCarteira = entity.Papel.TranslateToDTO()
            };
        }

        #endregion

        #region TranslatorDTO<CenarioSimulacao,CenarioSimulacaoDTO> Members

        public static List<CenarioSimulacao> TranslateFromDTO(this List<CenarioSimulacaoDTO> entityDTO)
        {
            if (entityDTO == null) return null;

            var _returnEntities = new List<CenarioSimulacao>();
            foreach (CenarioSimulacaoDTO et in entityDTO)
            {
                _returnEntities.Add(et.TranslateFromDTO());
            }
            return _returnEntities;
        }

        public static CenarioSimulacao TranslateFromDTO(this CenarioSimulacaoDTO entityDTO)
        {
            return entityDTO == null ? null : new CenarioSimulacao()
            {
                Codigo = entityDTO.Codigo,
                DataHoraCriacao = entityDTO.DataCriacao,
                MacroCenario = new MacroCenarioEconomico() { Codigo = entityDTO.CodigoMacroCenario, Nome = entityDTO.TituloMacroCenario, Descricao = entityDTO.DescricaoMacroCenario },
                ValorRentabilidadeMedia = entityDTO.ValorRentabilidadeMedia,
                AnoReferencia = entityDTO.AnoReferencia,
                MesReferencia = entityDTO.MesReferencia,
                NumeracaoCenario = entityDTO.NumeracaoCenario
            };
        }

        public static List<CenarioSimulacaoDTO> TranslateToDTO(this List<CenarioSimulacao> entity)
        {
            if (entity == null) return null;

            var _returnEntities = new List<CenarioSimulacaoDTO>();
            foreach (CenarioSimulacao et in entity)
            {
                _returnEntities.Add(et.TranslateToDTO());
            }
            return _returnEntities;
        }

        public static CenarioSimulacaoDTO TranslateToDTO(this CenarioSimulacao entity)
        {
            return entity == null ? null : new CenarioSimulacaoDTO()
            {
                Codigo = entity.Codigo,
                DataCriacao = entity.DataHoraCriacao,
                TituloMacroCenario = entity.MacroCenario == null ? string.Empty : entity.MacroCenario.Nome,
                DescricaoMacroCenario = entity.MacroCenario == null ? string.Empty : entity.MacroCenario.Descricao,
                ValorRentabilidadeMedia = entity.ValorRentabilidadeMedia,
                AnoReferencia = entity.AnoReferencia,
                MesReferencia = entity.MesReferencia,
                NumeracaoCenario = entity.NumeracaoCenario,
                CodigoMacroCenario = entity.MacroCenario == null ? 0 : entity.MacroCenario.Codigo
            };
        }
        #endregion
    }
}
