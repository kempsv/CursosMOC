﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bcl.Core.Domain.Enum;
using Desafio.Simulador.Bsl.Comum.Dto;

namespace Desafio.Simulador.Bsl.Comum.Extensions
{
    public static partial class TranslatorHelperExtensions
    {
        #region Conversores de Enumeradores

        public static TipoSemanaSimulacaoDTO ConvertToEnum(this TipoSemanaSimulacao tipoSemanaSimulacao)
        {
            switch (tipoSemanaSimulacao)
            {
                case TipoSemanaSimulacao.PrimeiraSemana:
                    return TipoSemanaSimulacaoDTO.PrimeiraSemana;
                case TipoSemanaSimulacao.SegundaSemana:
                    return TipoSemanaSimulacaoDTO.SegundaSemana;
                case TipoSemanaSimulacao.TerceiraSemana:
                    return TipoSemanaSimulacaoDTO.TerceiraSemana;
                case TipoSemanaSimulacao.QuartaSemana:
                    return TipoSemanaSimulacaoDTO.QuartaSemana;
                default:
                    return TipoSemanaSimulacaoDTO.PrimeiraSemana;
            }
        }

        public static TipoSemanaSimulacao ConvertToEnum(this TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO)
        {
            switch (tipoSemanaSimulacaoDTO)
            {
                case TipoSemanaSimulacaoDTO.PrimeiraSemana:
                    return TipoSemanaSimulacao.PrimeiraSemana;
                case TipoSemanaSimulacaoDTO.SegundaSemana:
                    return TipoSemanaSimulacao.SegundaSemana;
                case TipoSemanaSimulacaoDTO.TerceiraSemana:
                    return TipoSemanaSimulacao.TerceiraSemana;
                case TipoSemanaSimulacaoDTO.QuartaSemana:
                    return TipoSemanaSimulacao.QuartaSemana;
                default:
                    return TipoSemanaSimulacao.PrimeiraSemana;
            }
        }

        public static TipoTelefone ConvertToEnum(this TipoTelefoneDTO tipoTelefoneDTO)
        {
            switch (tipoTelefoneDTO)
            {
                case TipoTelefoneDTO.Celular:
                    return TipoTelefone.Celular;
                case TipoTelefoneDTO.Comercial:
                    return TipoTelefone.Comercial;
                case TipoTelefoneDTO.Fax:
                    return TipoTelefone.Fax;
                case TipoTelefoneDTO.Residencial:
                    return TipoTelefone.Residencial;
                default:
                    return TipoTelefone.Celular;
            }
        }

        public static TipoTelefoneDTO ConvertToEnum(this TipoTelefone tipoTelefone)
        {
            switch (tipoTelefone)
            {
                case TipoTelefone.Celular:
                    return TipoTelefoneDTO.Celular;
                case TipoTelefone.Comercial:
                    return TipoTelefoneDTO.Comercial;
                case TipoTelefone.Fax:
                    return TipoTelefoneDTO.Fax;
                case TipoTelefone.Residencial:
                    return TipoTelefoneDTO.Residencial;
                default:
                    return TipoTelefoneDTO.Celular;
            }
        }

        public static TipoDocumento ConvertToEnum(this TipoDocumentoDTO tipoDocumentoDTO)
        {
            switch (tipoDocumentoDTO)
            {
                case TipoDocumentoDTO.CPF:
                    return TipoDocumento.CPF;
                case TipoDocumentoDTO.Passaporte:
                    return TipoDocumento.Passaporte;
                case TipoDocumentoDTO.RG:
                    return TipoDocumento.RG;
                default:
                    return TipoDocumento.CPF;
            }
        }

        public static TipoDocumentoDTO ConvertToEnum(this TipoDocumento tipoDocumento)
        {
            switch (tipoDocumento)
            {
                case TipoDocumento.CPF:
                    return TipoDocumentoDTO.CPF;
                case TipoDocumento.Passaporte:
                    return TipoDocumentoDTO.Passaporte;
                case TipoDocumento.RG:
                    return TipoDocumentoDTO.RG;
                default:
                    return TipoDocumentoDTO.CPF;
            }
        }

        #endregion
    }
}
