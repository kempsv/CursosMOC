﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;


namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class AgendaSimulacaoDTO
    {
        [DataMember]
        public int Codigo { get; set; }

        [DataMember]
        public int CodigoOriginalLMS { get; set; }

        [DataMember]
        public DateTime DataHoraAgendamento { get; set; }

        [DataMember]
        public ParametrizacaoAgendaDTO ParametrizacaoAgenda { get; set; }

        [DataMember(EmitDefaultValue=false)]
        public TipoSemanaSimulacaoDTO TipoSemanaSimulacao { get; set; }

        [DataMember]
        public List<AgendaSimulacaoRodadasDTO> AgendaSimulacaoRodadas { get; set; }

        [DataMember]
        public bool IndicadorSimulacaoConcluida { get; set; }

        [DataMember]
        public TermoAceiteSimulacaoDTO TermoAceiteSimulacao { get; set; }
    }
}
