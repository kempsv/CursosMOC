﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;



namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class AgendaSimulacaoRodadasDTO
    {
        /// <summary>
        /// Indicador de Simulação concluída por cada grupo
        /// </summary>
        [DataMember]
        public bool IndicadorSimulacaoConcluida { get; set; }

        [DataMember]
        public short ContadorRodadaContingencia { get; set; }

        [DataMember]
        public RodadaSimulacaoDTO Rodada { get; set; }

        [DataMember]
        public GrupoEscolarDTO GrupoEscolar { get; set; }

        [DataMember]
        public List<RodadaCenarioDTO> RodadaCenario { get; set; }

        [DataMember]
        public AgendaSimulacaoDTO AgendaSimulacao { get; set; }
    }
}
