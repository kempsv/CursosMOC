﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class AtivosCarteiraDTO
    {
        [DataMember]
        public int Codigo { get; set; }

        [DataMember]
        public decimal ValorInvestido { get; set; }

        [DataMember]
        public decimal ValorInvestidoFinal { get; set; }

        [DataMember]
        public int Quantidade { get; set; }
    }
}
