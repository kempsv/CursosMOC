﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    public class AtivosCarteiraOutrosDTO: AtivosCarteiraDTO
    {
        [DataMember]
        public decimal ValorPercentualRendimento { get; set; }

        [DataMember]
        public string NomeAtivo { get; set; }
    }
}
