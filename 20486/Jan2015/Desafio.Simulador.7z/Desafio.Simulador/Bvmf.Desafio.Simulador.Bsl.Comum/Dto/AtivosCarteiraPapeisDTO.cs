﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;


namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class AtivosCarteiraPapeisDTO: AtivosCarteiraDTO
    {
        [DataMember]
        public decimal ValorPrecoCompra { get; set; }

        [DataMember]
        public decimal ValorPrecoFinal { get; set; }

        [DataMember]
        public decimal ValorRentabilidade { get; set; }

        [DataMember]
        public PapelCarteiraDTO PapelCarteira { get; set; }
    }
}
