﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class CarteiraInvestimentoDTO
    {
        [DataMember]
        public int Codigo { get; set; }

        [DataMember]
        public decimal ValorRentabilidadePeriodo { get; set; }

        [DataMember]
        public decimal ValorRentabilidadeAcumulada { get; set; }

        [DataMember]
        public decimal ValorSaldoAtual { get; set; }

        [DataMember]
        public List<AtivosCarteiraPapeisDTO> AtivosCarteiraPapeis { get; set; }

        [DataMember]
        public List<AtivosCarteiraOutrosDTO> AtivosCarteiraOutros { get; set; }

        [DataMember]
        public RodadaSimulacaoDTO RodadaSimulacao { get; set; }

        [DataMember]
        public RodadaSimulacaoDTO RodadaSimulacaoAnterior { get; set; }
    }
}
