﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class CenarioSimulacaoDTO
    {
        [DataMember]
        public int Codigo { get; set; }

        [DataMember]
        public int CodigoMacroCenario { get; set; }

        [DataMember]
        public int AnoReferencia { get; set; }

        [DataMember]
        public int MesReferencia { get; set; }

        [DataMember]
        public short NumeracaoCenario { get; set; }

        [DataMember]
        public decimal ValorRentabilidadeMedia { get; set; }

        [DataMember]
        public DateTime DataCriacao { get; set; }

        [DataMember]
        public string TituloMacroCenario { get; set; }

        [DataMember]
        public string DescricaoMacroCenario { get; set; }
    }
}
