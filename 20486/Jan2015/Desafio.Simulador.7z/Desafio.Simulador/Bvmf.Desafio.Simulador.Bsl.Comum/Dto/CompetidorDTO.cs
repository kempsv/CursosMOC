﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class CompetidorDTO
    {
        [DataMember]
        public int Codigo { get; set; }
        [DataMember]
        public int CodigoOriginalLMS { get; set; }
        [DataMember]
        public string EmailContato { get; set; }
        [DataMember]
        public string Nome { get; set; }
        [DataMember]
        public List<TelefoneDTO> Telefones { get; set; }
        [DataMember]
        public List<DocumentoDTO> Documentos { get; set; }
    }
}
