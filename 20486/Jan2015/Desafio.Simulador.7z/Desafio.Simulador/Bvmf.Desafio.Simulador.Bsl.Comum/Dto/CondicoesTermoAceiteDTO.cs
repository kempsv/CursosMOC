﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class CondicoesTermoAceiteDTO
    {
        [DataMember]
        public int Codigo { get; set; }
        [DataMember]
        public string Descricao { get; set; }
        [DataMember]
        public List<TermoAceiteSimulacaoDTO> TermoAceiteSimulacao { get; set; }
    }
}
