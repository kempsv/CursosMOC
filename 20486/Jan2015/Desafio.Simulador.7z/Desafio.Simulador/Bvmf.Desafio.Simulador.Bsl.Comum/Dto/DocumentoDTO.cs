﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class DocumentoDTO
    {
        [DataMember]
        public int Codigo { get; set; }
        
        [DataMember]
        public string NumeroDocumento { get; set; }
        
        [DataMember(EmitDefaultValue = false)]
        public TipoDocumentoDTO TipoDocumento { get; set; }

    }
}