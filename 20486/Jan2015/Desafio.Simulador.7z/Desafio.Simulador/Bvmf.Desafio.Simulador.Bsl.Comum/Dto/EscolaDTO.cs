﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class EscolaDTO
    {
        [DataMember]
        public int Codigo { get; set; }
        
        [DataMember]
        public int CodigoOriginalLMS { get; set; }
        
        [DataMember]
        public string Nome { get; set; }
        [DataMember]
        public string CNPJ { get; set; }
        
        [DataMember]
        public string Email { get; set; }
        
        [DataMember]
        public bool IndicadorEscolaPrivada { get; set; }
        
        [DataMember]
        public List<TelefoneDTO> Telefones { get; set; }
        
        [DataMember]
        public DiretorDTO Diretor { get; set; }
        
        [DataMember]
        public List<GrupoEscolarDTO> GruposEscolares { get; set; }

        [DataMember(EmitDefaultValue = false)]
        public TipoStatusSorteioCenariosDTO TipoStatusSorteioCenariosDTO { get; set; }
        
        [DataMember]
        public CidadeDTO Cidade { get; set; }
    }
}
