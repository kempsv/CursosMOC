﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class FatoRelevanteDTO
    {
        [DataMember]
        public int Codigo { get; set; }
        [DataMember]
        public string DescricaoFato { get; set; }
        [DataMember]
        public CenarioSimulacaoDTO CenarioSimulacao { get; set; }
        [DataMember]
        public PapelCarteiraDTO PapelCarteira { get; set; }
    }
}
