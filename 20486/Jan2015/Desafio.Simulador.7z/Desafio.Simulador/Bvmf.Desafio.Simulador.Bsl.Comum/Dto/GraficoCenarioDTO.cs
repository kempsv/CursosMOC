﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class GraficoCenarioDTO
    {
        [DataMember]
        public int Codigo { get; set; }
        [DataMember]
        public byte[] BufferImagem { get; set; }
        [DataMember]
        public string CaminhoFisico { get; set; }
        [DataMember]
        public DateTime DataCriacao { get; set; }
        [DataMember]
        public string Descricao { get; set; }
        [DataMember]
        public string Nome { get; set; }
        [DataMember]
        public CenarioSimulacaoDTO CenarioSimulacao { get; set; }
    }
}
