﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;


namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class GrupoEscolarDTO
    {
        [DataMember]
        public int Codigo { get; set; }
        [DataMember]
        public int CodigoOriginalLMS { get; set; }
        [DataMember]
        public string NomeGrupo { get; set; }
        [DataMember]
        public decimal ValorInvestimentoInicial { get; set; }
        [DataMember]
        public bool IndicadorDesclassificado { get; set; }
        [DataMember]
        public EscolaDTO Escola { get; set; }
        [DataMember]
        public List<AlunoDTO> Alunos { get; set; }
        [DataMember]
        public ProfessorDTO Professor { get; set; }
        [DataMember]
        public List<AgendaSimulacaoDTO> AgendaSimulacao { get; set; }
    }
}
