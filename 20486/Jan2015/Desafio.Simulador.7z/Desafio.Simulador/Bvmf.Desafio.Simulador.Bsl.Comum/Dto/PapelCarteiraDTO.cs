﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class PapelCarteiraDTO
    {
        [DataMember]
        public int Codigo { get; set; }
        [DataMember]
        public string NomeAbreviado { get; set; }
        [DataMember]
        public string NomeCompleto { get; set; }
        [DataMember]
        public decimal PrecoCompraInicial { get; set; }
        
        /// <summary>
        /// Cada Papel Carteira, representa um preço inicial na 
        /// semana de simulação
        /// </summary>
        [DataMember(EmitDefaultValue = false)]
        public TipoSemanaSimulacaoDTO TipoSemanaSimulacao { get; set; }
    }
}
