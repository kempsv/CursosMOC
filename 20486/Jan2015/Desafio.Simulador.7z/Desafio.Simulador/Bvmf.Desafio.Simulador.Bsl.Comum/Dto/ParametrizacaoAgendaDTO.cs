﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    public class ParametrizacaoAgendaDTO : ParametrizacaoDTO
    {
        [DataMember]
        public int QuantidadeRodadas { get; set; }
        [DataMember]
        public short MediaInicialSimulacao { get; set; }
        [DataMember]
        public short VariacaoMaximaSimulacao { get; set; }
        [DataMember]
        public int MaximaTentativaContingencia { get; set; }
    }
}
