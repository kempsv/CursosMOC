﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public abstract class ParametrizacaoDTO
    {
        [DataMember]
        public int Codigo { get; set; }

        private string _nomeModoSimulacao = string.Empty;
        [DataMember]
        public string NomeModoSimulacao
        {
            get
            {
                return this.IndicadorSimulacaoWEB == true ? "Simulação Web" : "Simulação Presencial";
            }
            set { this._nomeModoSimulacao = value; }
        }
        [DataMember]
        public DateTime DataCriacao { get; set; }
        [DataMember]
        public bool IndicadorSimulacaoWEB { get; set; }
        [DataMember]
        public bool IndicadorParametroAtivo { get; set; }
    }
}
