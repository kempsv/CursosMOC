﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    public class ParametrizacaoRodadaDTO : ParametrizacaoDTO
    {
        [DataMember]
        public bool IndicadorCenarioRandomico { get; set; }
        [DataMember]
        public int QuantidadeCenariosContingencia { get; set; }
        [DataMember]
        public int TempoIntervaloRodadas { get; set; }
        [DataMember]
        public int TempoRodada { get; set; }
        [DataMember]
        public int TempoTelaInicialRodada { get; set; }
        [DataMember]
        public decimal ValorPercentualMinimoAcoes { get; set; }
        [DataMember]
        public decimal ValorPercentualMinimoOutros { get; set; }
        [DataMember]
        public decimal ValorPercentualPenalidadeRodada { get; set; }
        [DataMember]
        public decimal ValorPercentualOscilacao { get; set; }
    }
}
