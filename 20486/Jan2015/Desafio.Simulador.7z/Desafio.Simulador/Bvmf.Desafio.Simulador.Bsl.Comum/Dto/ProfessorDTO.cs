﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    public class ProfessorDTO: CompetidorDTO
    {
        //public GrupoEscolarDTO GrupoEscolar { get; set; }
        [DataMember]
        public int CodigoGrupoEscolar { get; set; }
    }
}
