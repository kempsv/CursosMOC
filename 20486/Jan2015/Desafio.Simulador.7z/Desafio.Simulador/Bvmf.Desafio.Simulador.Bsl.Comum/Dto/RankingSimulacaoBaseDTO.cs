﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public abstract class RankingSimulacaoBaseDTO
    {
        [DataMember]
        public int Codigo { get; set; }
        [DataMember]
        public int Classificacao { get; set; }
        [DataMember]
        public string Nome { get; set; }
        [DataMember]
        public decimal RentabilidadeAcumulada { get; set; }
        
        //public string DecimalToString() 
        //{
        //    return String.Format("{0:C2}", this.RentabilidadeAcumulada);
        //}
    }
}
