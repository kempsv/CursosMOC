﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    public class RankingSimulacaoEscolaDTO: RankingSimulacaoBaseDTO
    {
        [DataMember]
        public string TipoEscola { get; set; }

        [DataMember]
        public List<RankingSimulacaoGrupoEscolarDTO> RankingSimulacaoGrupoEscolar { get; set; }
    }
}
