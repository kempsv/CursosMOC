﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;


namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class RodadaCenarioDTO
    {
        [DataMember]
        public bool IndicadorCenarioContingencia { get; set; }

        [DataMember]
        public CenarioSimulacaoDTO CenarioSimulacao { get; set; }

        [DataMember]
        public RodadaSimulacaoDTO RodadaSimulacao { get; set; }

        [DataMember]
        public List<GraficoCenarioDTO> GraficosCenario { get; set; }

        [DataMember]
        public List<FatoRelevanteDTO> FatosRelevante { get; set; }
    }
}
