﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class RodadaSimulacaoDTO
    {
        [DataMember]
        public int Codigo { get; set; }

        [DataMember]
        public CarteiraInvestimentoDTO CarteiraInvestimento { get; set; }

        [DataMember]
        public short IdentificadorRodada { get; set; }

        [DataMember]
        public ParametrizacaoRodadaDTO ParametrizacaoRodada { get; set; }

        [DataMember]
        public GrupoEscolarDTO GrupoEscolar { get; set; }

        [DataMember]
        public CenarioSimulacaoDTO CenarioSimulacao { get; set; }
    }
}
