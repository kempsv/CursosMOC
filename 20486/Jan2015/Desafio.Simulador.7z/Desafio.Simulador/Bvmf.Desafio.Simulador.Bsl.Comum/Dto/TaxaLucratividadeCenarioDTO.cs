﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class TaxaLucratividadeCenarioDTO
    {
        [DataMember]
        public decimal ValorPercentualLucratividade { get; set; }

        [DataMember]
        public decimal ValorPercentualOscilacao { get; set; }

        [DataMember]
        public CenarioSimulacaoDTO CenarioSimulacao { get; set; }

        [DataMember]
        public PapelCarteiraDTO PapelCarteira { get; set; }
    }
}
