﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class TelefoneDTO
    {
        [DataMember]
        public string NomeContato { get; set; }

        [DataMember]
        public string Numero { get; set; }

        [DataMember(EmitDefaultValue = false)]
        public TipoTelefoneDTO TipoTelefone { get; set; }
    }
}
