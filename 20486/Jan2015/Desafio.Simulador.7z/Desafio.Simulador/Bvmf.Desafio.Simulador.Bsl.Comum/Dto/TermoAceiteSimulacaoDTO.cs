﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public class TermoAceiteSimulacaoDTO
    {
        [DataMember]
        public int Codigo { get; set; }

        [DataMember]
        public string Descricao { get; set; }

        [DataMember]
        public bool IndicadorTermoAceito { get; set; }

        [DataMember(EmitDefaultValue = false)]
        public TipoModoSimulacaoDTO TipoModoSimulacaoDTO { get; set; }

        [DataMember]
        public GrupoEscolarDTO GrupoEscolar { get; set; }
    }
}
