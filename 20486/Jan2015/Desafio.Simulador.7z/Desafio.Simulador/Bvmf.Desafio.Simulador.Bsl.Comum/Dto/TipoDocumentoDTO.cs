﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public enum TipoDocumentoDTO
    {
        [EnumMember]
        RG = 1,

        [EnumMember]
        Passaporte = 2,

        [EnumMember]
        CPF = 3
    }
}
