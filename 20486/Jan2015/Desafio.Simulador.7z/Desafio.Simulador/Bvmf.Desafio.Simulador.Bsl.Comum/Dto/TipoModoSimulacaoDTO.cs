﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public enum TipoModoSimulacaoDTO
    {
        [EnumMember]
        Web = 1,

        [EnumMember]
        Presencial = 2
    }//end TipoModoSimulacao
}
