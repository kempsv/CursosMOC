﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public enum TipoSemanaSimulacaoDTO
    {
        [EnumMember]
        PrimeiraSemana = 1,

        [EnumMember]
        SegundaSemana = 2,

        [EnumMember]
        TerceiraSemana = 3,

        [EnumMember]
        QuartaSemana = 4
    }
}
