﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public enum TipoStatusSorteioCenariosDTO
    {
        [EnumMember]
        OK = 1,

        [EnumMember]
        Pendente = 2,

        [EnumMember]
        Todos = 3,
    }
}
