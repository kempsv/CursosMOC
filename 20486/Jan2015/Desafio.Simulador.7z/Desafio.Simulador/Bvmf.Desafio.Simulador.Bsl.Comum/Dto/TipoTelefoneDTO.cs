﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Bsl.Comum.Dto
{
    [DataContract]
    public enum TipoTelefoneDTO
    {
        [EnumMember]
        Residencial = 1,

        [EnumMember]
        Celular = 2,

        [EnumMember]
        Comercial = 3,

        [EnumMember]
        Fax = 4
    }
}
