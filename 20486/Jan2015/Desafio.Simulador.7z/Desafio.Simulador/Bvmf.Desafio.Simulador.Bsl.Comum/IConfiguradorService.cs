﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Desafio.Simulador.Bsl.Comum.Interfaces
{
    [ServiceContract()]
    public interface IConfiguradorService<TEntity>
    {
        [OperationContract]
        void AdicionarConfiguracao(TEntity entity);

        [OperationContract]
        void AtualizarConfiguracao(TEntity entity);

        [OperationContract]
        void ExcluirConfiguracao(TEntity entity);

        [OperationContract]
        TEntity ObterConfiguracao(int codigo);

        [OperationContract]
        List<TEntity> ListarTodasConfiguracoes();

    }
}
