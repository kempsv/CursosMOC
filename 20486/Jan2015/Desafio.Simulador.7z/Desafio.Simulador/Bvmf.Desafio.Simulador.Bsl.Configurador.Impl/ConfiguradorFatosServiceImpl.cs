﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Activation;
using Desafio.Simulador.Bsl.Configurador.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Configuracao.Fatos.Interfaces;
using System.ServiceModel;
using Desafio.Simulador.Util.Logger;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Interfaces;

using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Cenario.Interfaces;
using Microsoft.Practices.Unity;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Bsl.Comum.Extensions;

namespace Desafio.Simulador.Bsl.Configurador.Impl
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(TransactionIsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted)]
    public class ConfiguradorFatosServiceImpl : IConfiguradorFatosService
    {
        private BCConfiguracaoFatos _bcPersistence = null;

        [Dependency]
        public BCConfiguracaoCenarios BCConfiguracaoCenarios { get; set; }

        public ConfiguradorFatosServiceImpl(BCConfiguracaoFatos bcPersistence)
        {
            //Dependencia injetada pela mecanismo de Dependecy Injection do Unity
            _bcPersistence = bcPersistence;
        }

        #region IConfiguradorService<FatoRelevante> Members

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AdicionarConfiguracao", "AdicionarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void AdicionarConfiguracao(FatoRelevanteDTO entity)
        {
            try
            {
                _bcPersistence.Create(entity.TranslateFromDTO());
            }
            catch (Exception ex) 
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AtualizarConfiguracao", "AtualizarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void AtualizarConfiguracao(FatoRelevanteDTO entity)
        {
            try
            {
                _bcPersistence.Update(entity.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-ExcluirConfiguracao", "ExcluirConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void ExcluirConfiguracao(FatoRelevanteDTO entity)
        {
            try
            {
                _bcPersistence.Delete(entity.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [LogSistema()]
        public List<FatoRelevanteDTO> ListarTodasConfiguracoes()
        {
            var _fatosRelevantes = _bcPersistence.FindAll();
            this.PreencherCenarioSimulacao(_fatosRelevantes);

            return _fatosRelevantes.TranslateToDTO();
        }

        [LogSistema()]
        public FatoRelevanteDTO ObterConfiguracao(int codigo)
        {
            var _fatoRelevante = _bcPersistence.FindByKey(codigo);
            this.PreencherCenarioSimulacao(_fatoRelevante);

            return _fatoRelevante.TranslateToDTO();
        }
        
        [LogSistema()]
        public List<FatoRelevanteDTO> ListarFatosCenarios(int codigoCenario)
        {
            var _fatosRelevantes = _bcPersistence.ListarFatosByCenario(codigoCenario);
            this.PreencherCenarioSimulacao(_fatosRelevantes);

            return _fatosRelevantes.TranslateToDTO();

        }

        private void PreencherCenarioSimulacao(List<FatoRelevante> fatosRelevantes) 
        {
            foreach (FatoRelevante fato in fatosRelevantes) 
            {
                this.PreencherCenarioSimulacao(fato);
            }
        }

        private void PreencherCenarioSimulacao(FatoRelevante fatoRelevante) 
        {
            BCConfiguracaoCenarios.LazyData = true;
            fatoRelevante.CenarioSimulacao = BCConfiguracaoCenarios.FindByKey(fatoRelevante.CenarioSimulacao.Codigo);
        }

        #endregion
    }
}
