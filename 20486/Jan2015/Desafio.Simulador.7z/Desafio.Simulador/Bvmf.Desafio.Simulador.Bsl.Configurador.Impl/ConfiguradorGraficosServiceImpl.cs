﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Activation;
using Desafio.Simulador.Bsl.Configurador.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Grafico.Interfaces;
using System.ServiceModel;
using Desafio.Simulador.Util.Logger;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Interfaces;

using Desafio.Simulador.Bcl.Comum.Interfaces;
using Microsoft.Practices.Unity;
using Desafio.Simulador.Bcl.Configuracao.Cenario.Interfaces;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Bsl.Comum.Extensions;

namespace Desafio.Simulador.Bsl.Configurador.Impl
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(TransactionIsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted)]
    public class ConfiguradorGraficosServiceImpl : IConfiguradorGraficosService
    {
        private BCConfiguracaoGraficos _bcPersistence = null;

        [Dependency]
        public BCConfiguracaoCenarios BCConfiguracaoCenarios { get; set; }

        public ConfiguradorGraficosServiceImpl(BCConfiguracaoGraficos bcPersistence)
        {
            //Dependencia injetada pela mecanismo de Dependecy Injection do Unity
            _bcPersistence = bcPersistence;
        }

        #region IConfiguradorService<GraficoCenario> Members

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AdicionarConfiguracao", "AdicionarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void AdicionarConfiguracao(GraficoCenarioDTO entity)
        {
            try
            {
                _bcPersistence.Create(entity.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AtualizarConfiguracao", "AtualizarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void AtualizarConfiguracao(GraficoCenarioDTO entity)
        {
            try
            {
                _bcPersistence.Update(entity.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-ExcluirConfiguracao", "ExcluirConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void ExcluirConfiguracao(GraficoCenarioDTO entity)
        {
            try
            {
                _bcPersistence.Delete(entity.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [LogSistema()]
        public List<GraficoCenarioDTO> ListarTodasConfiguracoes()
        {
            var _graficos = _bcPersistence.FindAll();
            this.PreencherCenarioSimulacao(_graficos);

            return _graficos.TranslateToDTO();
        }

        [LogSistema()]
        public GraficoCenarioDTO ObterConfiguracao(int codigo)
        {
            var _grafico = _bcPersistence.FindByKey(codigo);
            this.PreencherCenarioSimulacao(_grafico);

            return _grafico.TranslateToDTO();
        }

        [LogSistema()]
        public List<GraficoCenarioDTO> ListarGraficosCenarios(int codigoCenario)
        {
            var _graficos = this.ListarTodasConfiguracoes();

            return _graficos.Where(grf => grf.Codigo.Equals(codigoCenario)).ToList<GraficoCenarioDTO>();
        }

        private void PreencherCenarioSimulacao(List<GraficoCenario> graficosCenario)
        {
            foreach (GraficoCenario fato in graficosCenario)
            {
                this.PreencherCenarioSimulacao(fato);
            }
        }

        private void PreencherCenarioSimulacao(GraficoCenario graficoCenario)
        {
            BCConfiguracaoCenarios.LazyData = true;
            graficoCenario.CenarioSimulacao = BCConfiguracaoCenarios.FindByKey(graficoCenario.CenarioSimulacao.Codigo);
        }
        #endregion
    }
}
