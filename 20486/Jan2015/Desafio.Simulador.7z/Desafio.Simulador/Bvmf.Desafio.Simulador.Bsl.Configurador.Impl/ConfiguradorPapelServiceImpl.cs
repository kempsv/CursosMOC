﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Activation;

using Desafio.Simulador.Bsl.Configurador.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Papel.Interfaces;
using System.ServiceModel;
using Desafio.Simulador.Util.Logger;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Interfaces;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Bsl.Comum.Extensions;


namespace Desafio.Simulador.Bsl.Configurador.Impl
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(TransactionIsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted)]
    public class ConfiguradorPapelServiceImpl : IConfiguradorPapelService
    {
        private BCConfiguracaoPapel _bcPersistence = null;

        public ConfiguradorPapelServiceImpl(BCConfiguracaoPapel bcPersistence)
        {
            //Dependencia injetada pela mecanismo de Dependecy Injection do Unity
            _bcPersistence = bcPersistence;
        }

        #region IConfiguradorService<PapelCarteira> Members

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AdicionarConfiguracao", "AdicionarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void AdicionarConfiguracao(PapelCarteiraDTO entity)
        {
            try
            {
                _bcPersistence.Create(entity.TranslateFromDTO());
            }
            catch (Exception ex) 
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AtualizarConfiguracao", "AtualizarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void AtualizarConfiguracao(PapelCarteiraDTO entity)
        {
            try
            {
                _bcPersistence.Update(entity.TranslateFromDTO());
            }
            catch (Exception ex) 
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, 
            TransactionAutoComplete = true)]
        [LogAuditor("Tx-ExcluirConfiguracao", "ExcluirConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void ExcluirConfiguracao(PapelCarteiraDTO entity)
        {
            try
            {
                _bcPersistence.Delete(entity.TranslateFromDTO());
            }
            catch (ViolacaoDeChaveEstrangeiraException vFx)
            {
                GerenciadorExcecao.TratarExcecao(vFx);
            }
            catch (Exception ex) 
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }


        [LogSistema()]
        public List<PapelCarteiraDTO> ListarTodasConfiguracoes()
        {
            return _bcPersistence.FindAll().TranslateToDTO();
        }

        [LogSistema()]
        public PapelCarteiraDTO ObterConfiguracao(int codigo)
        {
            return _bcPersistence.FindByKey(codigo).TranslateToDTO();
        }

        #endregion

        #region IConfiguradorPapelService Members

        [LogSistema()]
        public List<PapelCarteiraDTO> ListarPapeisByCarteira(int codigoCarteira)
        {
            return _bcPersistence.ListarPapeisByCarteira(codigoCarteira).TranslateToDTO();
        }

        #endregion

    }
}
