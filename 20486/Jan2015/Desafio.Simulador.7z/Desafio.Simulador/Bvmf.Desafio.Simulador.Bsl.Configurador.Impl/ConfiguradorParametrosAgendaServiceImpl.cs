﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Activation;
using Desafio.Simulador.Bsl.Configurador.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Comum.Interfaces;

using Desafio.Simulador.Bcl.Core.Domain.Enum;
using System.ServiceModel;
using Desafio.Simulador.Util.Logger;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Interfaces;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bcl.Configuracao.Parametros.Interfaces;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Bsl.Comum.Extensions;

namespace Desafio.Simulador.Bsl.Configurador.Impl
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(TransactionIsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted)]
    public class ConfiguradorParametrosAgendaServiceImpl : IConfiguradorParametrosAgendaService
    {
        private BCConfiguracaoParametroAgenda _bcPersistence = null;

        public ConfiguradorParametrosAgendaServiceImpl(BCConfiguracaoParametroAgenda bcPersistence)
        {
            //Dependencia injetada pela mecanismo de Dependecy Injection do Unity
            _bcPersistence = bcPersistence;
        }

        #region IConfiguradorService<ParametrizacaoAgenda> Members

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AdicionarConfiguracao", "AdicionarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void AdicionarConfiguracao(ParametrizacaoAgendaDTO entity)
        {
            try
            {
                _bcPersistence.Create(entity.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AdicionarConfiguracao", "AdicionarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void AtualizarConfiguracao(ParametrizacaoAgendaDTO entity)
        {
            try
            {
                _bcPersistence.Update(entity.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AdicionarConfiguracao", "AdicionarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void ExcluirConfiguracao(ParametrizacaoAgendaDTO entity)
        {
            try
            {
                _bcPersistence.Delete(entity.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [LogSistema()]
        public List<ParametrizacaoAgendaDTO> ListarTodasConfiguracoes()
        {
            return _bcPersistence.FindAll().TranslateToDTO();
        }

        [LogSistema()]
        public ParametrizacaoAgendaDTO ObterConfiguracao(int codigo)
        {
            return _bcPersistence.FindByKey(codigo).TranslateToDTO();
        }

        #endregion
    }
}
