﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Activation;
using Desafio.Simulador.Bsl.Configurador.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using System.ServiceModel;
using Desafio.Simulador.Bcl.Comum.Interfaces;

using Desafio.Simulador.Bcl.Core.Domain.Enum;
using Desafio.Simulador.Util.Logger;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Interfaces;
using Desafio.Simulador.Bcl.Configuracao.Parametros.Interfaces;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Bsl.Comum.Extensions;

namespace Desafio.Simulador.Bsl.Configurador.Impl
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(TransactionIsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted)]
    public class ConfiguradorParametrosRodadasServiceImpl : IConfiguradorParametrosRodadasService
    {
        private BCConfiguracaoParametroRodada _bcPersistence = null;

        public ConfiguradorParametrosRodadasServiceImpl(BCConfiguracaoParametroRodada bcPersistence)
        {
            //Dependencia injetada pela mecanismo de Dependecy Injection do Unity
            _bcPersistence = bcPersistence;
        }

        #region IConfiguradorService<ParametrizacaoRodada> Members

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AdicionarConfiguracao", "AdicionarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void AdicionarConfiguracao(ParametrizacaoRodadaDTO entity)
        {
            try
            {
                _bcPersistence.Create(entity.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AdicionarConfiguracao", "AdicionarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void AtualizarConfiguracao(ParametrizacaoRodadaDTO entity)
        {
            try
            {
                _bcPersistence.Update(entity.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AdicionarConfiguracao", "AdicionarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void ExcluirConfiguracao(ParametrizacaoRodadaDTO entity)
        {
            try
            {
                _bcPersistence.Delete(entity.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [LogSistema()]
        public List<ParametrizacaoRodadaDTO> ListarTodasConfiguracoes()
        {
            return _bcPersistence.FindAll().TranslateToDTO();
        }

        [LogSistema()]
        public ParametrizacaoRodadaDTO ObterConfiguracao(int codigo)
        {
            return _bcPersistence.FindByKey(codigo).TranslateToDTO();
        }

        #endregion
    }
}
