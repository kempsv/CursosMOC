﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Activation;
using Desafio.Simulador.Bsl.Configurador.Interfaces;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Bsl.Comum.Extensions;
using System.ServiceModel;
using Desafio.Simulador.Util.Logger;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Interfaces;
using Desafio.Simulador.Util.Excecao;

namespace Desafio.Simulador.Bsl.Configurador.Impl
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(TransactionIsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted)]
    public class ConfiguradorPrecoIncialPapelServiceImpl : IConfiguradorPrecoIncialPapelService
    {
        private BCAgendaSimulacao _bcPersistence = null;

        public ConfiguradorPrecoIncialPapelServiceImpl(BCAgendaSimulacao bcPersistence)
        {
            //Dependencia injetada pela mecanismo de Dependecy Injection do Unity
            _bcPersistence = bcPersistence;
        }

        #region IConfiguradorPrecoIncialPapelService Members

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AtualizarPrecoInicialSimulacao", "AtualizarPrecoInicialSimulacao")]
        [NotNullParam()]
        [LogSistema()]
        [ValidarRodadaSimulacaoAndamento()]
        public void AtualizarPrecoInicialSimulacao(PapelCarteiraDTO papelCarteiraDTO)
        {
            try 
            {
                _bcPersistence.AtualizarPrecoInicialSimulacao(papelCarteiraDTO.TranslateFromDTO());
            }
            catch (Exception ex) 
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [LogSistema()]
        public List<PapelCarteiraDTO> ListarPrecosInicaisSimulacao(TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO)
        {
            return _bcPersistence.ListarPrecosIniciaisSimulacao(tipoSemanaSimulacaoDTO.ConvertToEnum()).TranslateToDTO();
        }

        #endregion
    }
}
