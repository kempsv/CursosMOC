﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bsl.Configurador.Interfaces;
using System.ServiceModel.Activation;
using System.ServiceModel;
using Desafio.Simulador.Util.Logger;

using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Interfaces;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Bsl.Comum.Extensions;
using Desafio.Simulador.Bcl.Core.Domain.Enum;

namespace Desafio.Simulador.Bsl.Configurador.Impl
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(TransactionIsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted)]
    public class ConfiguradorTermoAceiteServiceImpl:IConfiguradorTermoAceiteService
    {
        private BCTermoAceiteSimulacao _bcPersistence = null;

        public ConfiguradorTermoAceiteServiceImpl(BCTermoAceiteSimulacao bcPersistence)
        {
            //Dependencia injetada pela mecanismo de Dependecy Injection do Unity
            _bcPersistence = bcPersistence;
        }

        #region IConfiguradorService<TermoAceiteSimulacaoDTO> Members

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AdicionarConfiguracao", "AdicionarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        public void AdicionarConfiguracao(CondicoesTermoAceiteDTO entity)
        {
            try
            {
                _bcPersistence.Create(entity.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AdicionarConfiguracao", "AdicionarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        public void AtualizarConfiguracao(CondicoesTermoAceiteDTO entity)
        {
            try
            {
                _bcPersistence.Update(entity.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AdicionarConfiguracao", "AdicionarConfiguracao")]
        [NotNullParam()]
        [LogSistema()]
        public void ExcluirConfiguracao(CondicoesTermoAceiteDTO entity)
        {
            try
            {
                _bcPersistence.Delete(entity.TranslateFromDTO());
            }
            catch (ViolacaoDeChaveEstrangeiraException vFx)
            {
                GerenciadorExcecao.TratarExcecao(vFx);
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        [LogSistema()]
        public List<CondicoesTermoAceiteDTO> ListarTodasConfiguracoes()
        {
            return _bcPersistence.FindAll().TranslateToDTO();
        }

        [LogSistema()]
        public CondicoesTermoAceiteDTO ObterConfiguracao(int codigo)
        {
            return _bcPersistence.FindByKey(codigo).TranslateToDTO();
        }

        #endregion

        #region IConfiguradorTermoAceiteService Members

        [LogSistema()]
        public List<CondicoesTermoAceiteDTO> ListarCondicoesTermoWEB()
        {
            try 
            {
                var _condicoesTermo = this.ListarTodasConfiguracoes();

                _condicoesTermo.ForEach(delegate(CondicoesTermoAceiteDTO condicao) 
                {
                    var _termoWeb = condicao.TermoAceiteSimulacao.Where(trm => trm.TipoModoSimulacaoDTO == TipoModoSimulacaoDTO.Web).FirstOrDefault<TermoAceiteSimulacaoDTO>();
                    if (_termoWeb == null)
                        _condicoesTermo.Remove(condicao);
                });

                return _condicoesTermo;

            }
            catch (Exception ex) 
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }
        
        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-AceitarTermoAceite", "AceitarTermoAceite")]
        [NotNullParam()]
        [LogSistema()]
        public void AceitarTermoAceite(TermoAceiteSimulacaoDTO termoAceite)
        {
           try
            {
                _bcPersistence.AceitarTermoSimulacao(termoAceite.TranslateFromDTO());
            }
            catch (ViolacaoDeChaveEstrangeiraException vFx)
            {
                GerenciadorExcecao.TratarExcecao(vFx);
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        #endregion
    }
}
