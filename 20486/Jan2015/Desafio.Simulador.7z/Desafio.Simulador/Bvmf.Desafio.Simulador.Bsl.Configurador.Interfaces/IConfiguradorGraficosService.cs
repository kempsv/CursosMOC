﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Bsl.Comum.Interfaces;

namespace Desafio.Simulador.Bsl.Configurador.Interfaces
{
    [ServiceContract()]
    public interface IConfiguradorGraficosService : IConfiguradorService<GraficoCenarioDTO>
    {
        [OperationContract]
        List<GraficoCenarioDTO> ListarGraficosCenarios(int codigoCenario);
    }
}
