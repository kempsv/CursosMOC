﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;
using System.ServiceModel.Activation;

using Desafio.Simulador.Bsl.Comum.Interfaces;
using Desafio.Simulador.Bsl.Comum.Dto;

namespace Desafio.Simulador.Bsl.Configurador.Interfaces
{
    [ServiceContract]
    public interface IConfiguradorPapelService : 
        IConfiguradorService<PapelCarteiraDTO> 
    {
        [OperationContract]
        List<PapelCarteiraDTO> ListarPapeisByCarteira(int codigoCarteira);
    }
}
