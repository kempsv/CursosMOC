﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bsl.Comum.Interfaces;
using Desafio.Simulador.Bsl.Comum.Dto;
using System.ServiceModel;

namespace Desafio.Simulador.Bsl.Configurador.Interfaces
{
    [ServiceContract]
    public interface IConfiguradorPrecoIncialPapelService
    {
        [OperationContract]
        List<PapelCarteiraDTO> ListarPrecosInicaisSimulacao(TipoSemanaSimulacaoDTO TipoSemanaSimulacaoDTO);

        [OperationContract]
        void AtualizarPrecoInicialSimulacao(PapelCarteiraDTO papelCarteiraDTO);
    }
}
