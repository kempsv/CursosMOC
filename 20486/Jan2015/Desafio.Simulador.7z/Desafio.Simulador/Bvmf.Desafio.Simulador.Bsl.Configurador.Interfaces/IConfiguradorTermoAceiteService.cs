﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Desafio.Simulador.Bsl.Comum.Interfaces;
using Desafio.Simulador.Bsl.Comum.Dto;

namespace Desafio.Simulador.Bsl.Configurador.Interfaces
{
    [ServiceContract()]
    public interface IConfiguradorTermoAceiteService : IConfiguradorService<CondicoesTermoAceiteDTO>
    {
        [OperationContract]
        List<CondicoesTermoAceiteDTO> ListarCondicoesTermoWEB();

        [OperationContract]
        void AceitarTermoAceite(TermoAceiteSimulacaoDTO termoAceite);
    }
}
