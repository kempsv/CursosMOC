﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Desafio.Simulador.Bsl.Comum.Dto;


namespace Desafio.Simulador.Bsl.Integrador.Interfaces
{
    [ServiceContract]
    public interface IIntegradorEscolasService
    {
        [OperationContract]
        void AdicionarEscolasClassificadas(List<EscolaDTO> escolasDTO);
    }
}
