﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bsl.Comum.Dto;
using System.ServiceModel;

namespace Desafio.Simulador.Bsl.Integrador.Interfaces
{
    [ServiceContract]
    public interface IIntegradorRankingEscolasService
    {
        [OperationContract(Name = "ListarRankingAcumuladoGeral")]
        List<RankingSimulacaoEscolaDTO> ListarRankingAcumuladoGeral();

        [OperationContract(Name = "ListarRankingAcumuladoGeralByNome")]
        List<RankingSimulacaoEscolaDTO> ListarRankingAcumuladoGeral(string nomeEscola);
    }
}
