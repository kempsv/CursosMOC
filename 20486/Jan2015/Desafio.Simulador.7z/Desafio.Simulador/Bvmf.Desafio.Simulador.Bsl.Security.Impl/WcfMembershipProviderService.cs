﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Security;
using Desafio.Simulador.Bsl.Security.Interface;
using System.ServiceModel.Activation;
using System.ServiceModel;

namespace Desafio.Simulador.Bsl.Security.Impl
{
    /// <summary>
    /// 
    /// </summary>
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class WcfMembershipProviderService : IWcfMembershipProviderService
    {
        private readonly MembershipProvider _membershipProvider;

        #region Constructors

        public WcfMembershipProviderService()
            : this(null)
        {
        }

        public WcfMembershipProviderService(MembershipProvider membershipProvider)
        {
            _membershipProvider = membershipProvider ?? Membership.Provider;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Changes the password.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="oldPassword">The old password.</param>
        /// <param name="newPassword">The new password.</param>
        /// <returns></returns>
        public bool ChangePassword(string username, string oldPassword, string newPassword)
        {
            return _membershipProvider.ChangePassword(username, oldPassword, newPassword);
        }

        /// <summary>
        /// Changes the password question and answer.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="password">The password.</param>
        /// <param name="newPasswordQuestion">The new password question.</param>
        /// <param name="newPasswordAnswer">The new password answer.</param>
        /// <returns></returns>
        public bool ChangePasswordQuestionAndAnswer(string username, string password, string newPasswordQuestion,
                                                    string newPasswordAnswer)
        {
            return _membershipProvider.ChangePasswordQuestionAndAnswer(username, password, newPasswordQuestion,
                                                                       newPasswordAnswer);
        }

        /// <summary>
        /// Creates the user.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="password">The password.</param>
        /// <param name="email">The email.</param>
        /// <param name="passwordQuestion">The password question.</param>
        /// <param name="passwordAnswer">The password answer.</param>
        /// <param name="isApproved">if set to <c>true</c> [is approved].</param>
        /// <param name="providerUserKey">The provider user key.</param>
        /// <param name="status">The status.</param>
        /// <returns></returns>
        public MembershipUser CreateUser(string username, string password, string email, string passwordQuestion,
                                         string passwordAnswer, bool isApproved, object providerUserKey,
                                         out MembershipCreateStatus status)
        {
            return _membershipProvider.CreateUser(username, password, email, passwordQuestion, passwordAnswer,
                                                  isApproved, providerUserKey, out status);
        }

        /// <summary>
        /// Deletes the user.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="deleteAllRelatedData">if set to <c>true</c> [delete all related data].</param>
        /// <returns></returns>
        public bool DeleteUser(string username, bool deleteAllRelatedData)
        {
            return _membershipProvider.DeleteUser(username, deleteAllRelatedData);
        }

        /// <summary>
        /// Finds the users by email.
        /// </summary>
        /// <param name="emailToMatch">The email to match.</param>
        /// <param name="pageIndex">Index of the page.</param>
        /// <param name="pageSize">Size of the page.</param>
        /// <param name="totalRecords">The total records.</param>
        /// <returns></returns>
        public IList<MembershipUser> FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize,
                                                      out int totalRecords)
        {
            return _membershipProvider.FindUsersByEmail(emailToMatch, pageIndex, pageSize, out totalRecords).ToList();
        }

        /// <summary>
        /// Finds the name of the users by.
        /// </summary>
        /// <param name="usernameToMatch">The username to match.</param>
        /// <param name="pageIndex">Index of the page.</param>
        /// <param name="pageSize">Size of the page.</param>
        /// <param name="totalRecords">The total records.</param>
        /// <returns></returns>
        public IList<MembershipUser> FindUsersByName(string usernameToMatch, int pageIndex, int pageSize,
                                                     out int totalRecords)
        {
            return _membershipProvider.FindUsersByName(usernameToMatch, pageIndex, pageSize, out totalRecords).ToList();
        }

        /// <summary>
        /// Gets all users.
        /// </summary>
        /// <param name="pageIndex">Index of the page.</param>
        /// <param name="pageSize">Size of the page.</param>
        /// <param name="totalRecords">The total records.</param>
        /// <returns></returns>
        public IList<MembershipUser> GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
        {
            return _membershipProvider.GetAllUsers(pageIndex, pageSize, out totalRecords).ToList();
        }

        /// <summary>
        /// Gets the number of users online.
        /// </summary>
        /// <returns></returns>
        public int GetNumberOfUsersOnline()
        {
            return _membershipProvider.GetNumberOfUsersOnline();
        }

        /// <summary>
        /// Gets the password.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="answer">The answer.</param>
        /// <returns></returns>
        public string GetPassword(string username, string answer)
        {
            return _membershipProvider.GetPassword(username, answer);
        }

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <param name="providerUserKey">The provider user key.</param>
        /// <param name="userIsOnline">if set to <c>true</c> [user is online].</param>
        /// <returns></returns>
        public MembershipUser GetUserWithKey(object providerUserKey, bool userIsOnline)
        {
            return _membershipProvider.GetUser(providerUserKey, userIsOnline);
        }

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="userIsOnline">if set to <c>true</c> [user is online].</param>
        /// <returns></returns>
        public MembershipUser GetUser(string username, bool userIsOnline)
        {
            return _membershipProvider.GetUser(username, userIsOnline);
        }

        /// <summary>
        /// Gets the user name by email.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <returns></returns>
        public string GetUserNameByEmail(string email)
        {
            return _membershipProvider.GetUserNameByEmail(email);
        }

        /// <summary>
        /// Resets the password.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="answer">The answer.</param>
        /// <returns></returns>
        public string ResetPassword(string username, string answer)
        {
            return _membershipProvider.ResetPassword(username, answer);
        }

        /// <summary>
        /// Unlocks the user.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <returns></returns>
        public bool UnlockUser(string userName)
        {
            return _membershipProvider.UnlockUser(userName);
        }

        /// <summary>
        /// Updates the user.
        /// </summary>
        /// <param name="user">The user.</param>
        public void UpdateUser(MembershipUser user)
        {
            _membershipProvider.UpdateUser(user);
        }

        /// <summary>
        /// Validates the user.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="password">The password.</param>
        /// <returns></returns>
        //[OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public bool ValidateUser(string username, string password)
        {
            return _membershipProvider.ValidateUser(username, password);
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the name of the application.
        /// </summary>
        /// <returns></returns>
        public string GetApplicationName()
        {
            return _membershipProvider.ApplicationName;
        }

        /// <summary>
        /// Sets the name of the application.
        /// </summary>
        /// <param name="applicationName">Name of the application.</param>
        public void SetApplicationName(string applicationName)
        {
            _membershipProvider.ApplicationName = applicationName;
        }

        /// <summary>
        /// Gets the enable password reset.
        /// </summary>
        /// <returns></returns>
        public bool GetEnablePasswordReset()
        {
            return _membershipProvider.EnablePasswordReset;
        }

        /// <summary>
        /// Gets the enable password retrieval.
        /// </summary>
        /// <returns></returns>
        public bool GetEnablePasswordRetrieval()
        {
            return _membershipProvider.EnablePasswordRetrieval;
        }

        /// <summary>
        /// Gets the max invalid password attempts.
        /// </summary>
        /// <returns></returns>
        public int GetMaxInvalidPasswordAttempts()
        {
            return _membershipProvider.MaxInvalidPasswordAttempts;
        }

        /// <summary>
        /// Gets the min required non alphanumeric characters.
        /// </summary>
        /// <returns></returns>
        public int GetMinRequiredNonAlphanumericCharacters()
        {
            return _membershipProvider.MinRequiredNonAlphanumericCharacters;
        }

        /// <summary>
        /// Gets the length of the min required password.
        /// </summary>
        /// <returns></returns>
        public int GetMinRequiredPasswordLength()
        {
            return _membershipProvider.MinRequiredPasswordLength;
        }

        /// <summary>
        /// Gets the password attempt window.
        /// </summary>
        /// <returns></returns>
        public int GetPasswordAttemptWindow()
        {
            return _membershipProvider.PasswordAttemptWindow;
        }

        /// <summary>
        /// Gets the password format.
        /// </summary>
        /// <returns></returns>
        public MembershipPasswordFormat GetPasswordFormat()
        {
            return _membershipProvider.PasswordFormat;
        }

        /// <summary>
        /// Gets the password strength regular expression.
        /// </summary>
        /// <returns></returns>
        public string GetPasswordStrengthRegularExpression()
        {
            return _membershipProvider.PasswordStrengthRegularExpression;
        }

        /// <summary>
        /// Gets the requires question and answer.
        /// </summary>
        /// <returns></returns>
        public bool GetRequiresQuestionAndAnswer()
        {
            return _membershipProvider.RequiresQuestionAndAnswer;
        }

        /// <summary>
        /// Gets the requires unique email.
        /// </summary>
        /// <returns></returns>
        public bool GetRequiresUniqueEmail()
        {
            return _membershipProvider.RequiresUniqueEmail;
        }

        #endregion
    }
}