﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Web.Security;
using Desafio.Simulador.Bsl.Security.Interface;
using System.ServiceModel.Activation;

namespace Desafio.Simulador.Bsl.Security.Impl
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class WcfRoleProviderService : IWcfRoleProviderService
    {
        private readonly RoleProvider _roleProvider;

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="WcfRoleProviderService"/> class.
        /// </summary>
        public WcfRoleProviderService()
            :this(null)
        {}

        /// <summary>
        /// Initializes a new instance of the <see cref="WcfRoleProviderService"/> class.
        /// </summary>
        /// <param name="roleProvider">The role provider.</param>
        public WcfRoleProviderService(RoleProvider roleProvider)
        {
            _roleProvider = roleProvider ?? Roles.Provider;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Adds the users to roles.
        /// </summary>
        /// <param name="usernames">The usernames.</param>
        /// <param name="roleNames">The role names.</param>
        public void AddUsersToRoles(string[] usernames, string[] roleNames)
        {
            _roleProvider.AddUsersToRoles(usernames, roleNames);
        }

        /// <summary>
        /// Creates the role.
        /// </summary>
        /// <param name="roleName">Name of the role.</param>
        public void CreateRole(string roleName)
        {
            _roleProvider.CreateRole(roleName);
        }

        /// <summary>
        /// Deletes the role.
        /// </summary>
        /// <param name="roleName">Name of the role.</param>
        /// <param name="throwOnPopulatedRole">if set to <c>true</c> [throw on populated role].</param>
        /// <returns></returns>
        public  bool DeleteRole(string roleName, bool throwOnPopulatedRole)
        {
            return _roleProvider.DeleteRole(roleName, throwOnPopulatedRole);
        }

        /// <summary>
        /// Finds the users in role.
        /// </summary>
        /// <param name="roleName">Name of the role.</param>
        /// <param name="usernameToMatch">The username to match.</param>
        /// <returns></returns>
        public  string[] FindUsersInRole(string roleName, string usernameToMatch)
        {
            return _roleProvider.FindUsersInRole(roleName, usernameToMatch);
        }

        /// <summary>
        /// Gets all roles.
        /// </summary>
        /// <returns></returns>
        public  string[] GetAllRoles()
        {
            return _roleProvider.GetAllRoles();
        }

        /// <summary>
        /// Gets the roles for user.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <returns></returns>
        public  string[] GetRolesForUser(string username)
        {
            return _roleProvider.GetRolesForUser(username);
        }

        /// <summary>
        /// Gets the users in role.
        /// </summary>
        /// <param name="roleName">Name of the role.</param>
        /// <returns></returns>
        public  string[] GetUsersInRole(string roleName)
        {
            return _roleProvider.GetUsersInRole(roleName);
        }

        /// <summary>
        /// Determines whether [is user in role] [the specified username].
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="roleName">Name of the role.</param>
        /// <returns>
        /// 	<c>true</c> if [is user in role] [the specified username]; otherwise, <c>false</c>.
        /// </returns>
        public  bool IsUserInRole(string username, string roleName)
        {
            return _roleProvider.IsUserInRole(username, roleName);
        }

        /// <summary>
        /// Removes the users from roles.
        /// </summary>
        /// <param name="usernames">The usernames.</param>
        /// <param name="roleNames">The role names.</param>
        public  void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
        {
            _roleProvider.RemoveUsersFromRoles(usernames, roleNames);
        }

        /// <summary>
        /// Roles the exists.
        /// </summary>
        /// <param name="roleName">Name of the role.</param>
        /// <returns></returns>
        public  bool RoleExists(string roleName)
        {
            return _roleProvider.RoleExists(roleName);
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the name of the application.
        /// </summary>
        /// <returns></returns>
        public string GetApplicationName()
        {
            return _roleProvider.ApplicationName;
        }

        /// <summary>
        /// Sets the name of the application.
        /// </summary>
        /// <param name="applicationName">Name of the application.</param>
        public void  SetApplicationName(string applicationName)
        {
            _roleProvider.ApplicationName = applicationName;
        }

        #endregion

    }
}
