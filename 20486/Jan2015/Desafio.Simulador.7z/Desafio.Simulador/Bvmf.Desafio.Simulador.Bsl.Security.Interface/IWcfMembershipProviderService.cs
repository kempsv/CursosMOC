﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.ServiceModel;
using System.Web.Security;

namespace Desafio.Simulador.Bsl.Security.Interface
{
    /// <summary>
    /// 
    /// </summary>
    [ServiceContract]
    public interface IWcfMembershipProviderService 
    {
        /// <summary>
        /// Changes the password.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="oldPassword">The old password.</param>
        /// <param name="newPassword">The new password.</param>
        /// <returns></returns>
        [OperationContract]
        bool ChangePassword(string username, string oldPassword, string newPassword);

        /// <summary>
        /// Changes the password question and answer.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="password">The password.</param>
        /// <param name="newPasswordQuestion">The new password question.</param>
        /// <param name="newPasswordAnswer">The new password answer.</param>
        /// <returns></returns>
        [OperationContract]
        bool ChangePasswordQuestionAndAnswer(string username, string password, string newPasswordQuestion,
                                             string newPasswordAnswer);

        /// <summary>
        /// Creates the user.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="password">The password.</param>
        /// <param name="email">The email.</param>
        /// <param name="passwordQuestion">The password question.</param>
        /// <param name="passwordAnswer">The password answer.</param>
        /// <param name="isApproved">if set to <c>true</c> [is approved].</param>
        /// <param name="providerUserKey">The provider user key.</param>
        /// <param name="status">The status.</param>
        /// <returns></returns>
        [OperationContract]
        MembershipUser CreateUser(string username, string password, string email, string passwordQuestion,
                                  string passwordAnswer, bool isApproved, object providerUserKey,
                                  out MembershipCreateStatus status);

        /// <summary>
        /// Deletes the user.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="deleteAllRelatedData">if set to <c>true</c> [delete all related data].</param>
        /// <returns></returns>
        [OperationContract]
        bool DeleteUser(string username, bool deleteAllRelatedData);

        /// <summary>
        /// Finds the users by email.
        /// </summary>
        /// <param name="emailToMatch">The email to match.</param>
        /// <param name="pageIndex">Index of the page.</param>
        /// <param name="pageSize">Size of the page.</param>
        /// <param name="totalRecords">The total records.</param>
        /// <returns></returns>
        [OperationContract]
        IList<MembershipUser> FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize,
                                               out int totalRecords);

        /// <summary>
        /// Finds the name of the users by.
        /// </summary>
        /// <param name="usernameToMatch">The username to match.</param>
        /// <param name="pageIndex">Index of the page.</param>
        /// <param name="pageSize">Size of the page.</param>
        /// <param name="totalRecords">The total records.</param>
        /// <returns></returns>
        [OperationContract]
        IList<MembershipUser> FindUsersByName(string usernameToMatch, int pageIndex, int pageSize,
                                              out int totalRecords);

        /// <summary>
        /// Gets all users.
        /// </summary>
        /// <param name="pageIndex">Index of the page.</param>
        /// <param name="pageSize">Size of the page.</param>
        /// <param name="totalRecords">The total records.</param>
        /// <returns></returns>
        [OperationContract]
        IList<MembershipUser> GetAllUsers(int pageIndex, int pageSize, out int totalRecords);

        /// <summary>
        /// Gets the number of users online.
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        int GetNumberOfUsersOnline();

        /// <summary>
        /// Gets the password.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="answer">The answer.</param>
        /// <returns></returns>
        [OperationContract]
        string GetPassword(string username, string answer);

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <param name="providerUserKey">The provider user key.</param>
        /// <param name="userIsOnline">if set to <c>true</c> [user is online].</param>
        /// <returns></returns>
        [OperationContract]
        MembershipUser GetUserWithKey(object providerUserKey, bool userIsOnline);

        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="userIsOnline">if set to <c>true</c> [user is online].</param>
        /// <returns></returns>
        [OperationContract]
        MembershipUser GetUser(string username, bool userIsOnline);

        /// <summary>
        /// Gets the user name by email.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <returns></returns>
        [OperationContract]
        string GetUserNameByEmail(string email);

        /// <summary>
        /// Resets the password.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="answer">The answer.</param>
        /// <returns></returns>
        [OperationContract]
        string ResetPassword(string username, string answer);

        /// <summary>
        /// Unlocks the user.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <returns></returns>
        [OperationContract]
        bool UnlockUser(string userName);

        /// <summary>
        /// Updates the user.
        /// </summary>
        /// <param name="user">The user.</param>
        [OperationContract]
        void UpdateUser(MembershipUser user);

        /// <summary>
        /// Validates the user.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="password">The password.</param>
        /// <returns></returns>
        [OperationContract]
        bool ValidateUser(string username, string password);

        /// <summary>
        /// Gets the name of the application.
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        string GetApplicationName();

        /// <summary>
        /// Sets the name of the application.
        /// </summary>
        /// <param name="applicationName">Name of the application.</param>
        [OperationContract]
        void SetApplicationName(string applicationName);

        /// <summary>
        /// Gets the enable password reset.
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        bool GetEnablePasswordReset();

        /// <summary>
        /// Gets the enable password retrieval.
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        bool GetEnablePasswordRetrieval();

        /// <summary>
        /// Gets the max invalid password attempts.
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        int GetMaxInvalidPasswordAttempts();

        /// <summary>
        /// Gets the min required non alphanumeric characters.
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        int GetMinRequiredNonAlphanumericCharacters();

        /// <summary>
        /// Gets the length of the min required password.
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        int GetMinRequiredPasswordLength();

        /// <summary>
        /// Gets the password attempt window.
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        int GetPasswordAttemptWindow();

        /// <summary>
        /// Gets the password format.
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        MembershipPasswordFormat GetPasswordFormat();

        /// <summary>
        /// Gets the password strength regular expression.
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        string GetPasswordStrengthRegularExpression();

        /// <summary>
        /// Gets the requires question and answer.
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        bool GetRequiresQuestionAndAnswer();

        /// <summary>
        /// Gets the requires unique email.
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        bool GetRequiresUniqueEmail();
    }
}
