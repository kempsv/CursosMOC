﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Security;

namespace Desafio.Simulador.Bsl.Security.Interface
{
    public static class MembershipUserCollectionExtensions
    {
        public static IList<MembershipUser> ToList(this MembershipUserCollection collection)
        {
            if (collection == null)
                throw new ArgumentException("collection");

            List<MembershipUser> users = new List<MembershipUser>();

            foreach (MembershipUser user in collection)
                users.Add(user);

            return users;
        }

        public static MembershipUserCollection ToCollection (this IList<MembershipUser> users)
        {
            if (users == null) 
                throw new ArgumentNullException("users");

            MembershipUserCollection collection = new MembershipUserCollection();

            foreach (MembershipUser user in users)
                collection.Add(user);

            return collection;
        }
    }
}
