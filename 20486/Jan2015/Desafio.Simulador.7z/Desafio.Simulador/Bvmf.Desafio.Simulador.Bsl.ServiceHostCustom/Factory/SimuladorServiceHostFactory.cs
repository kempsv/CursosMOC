﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Activation;
using System.ServiceModel;

namespace Desafio.Simulador.Bsl.ServiceHostCustom.Factory
{
    public class SimuladorServiceHostFactory : ServiceHostFactory
    {
        protected override ServiceHost CreateServiceHost(Type serviceType, Uri[] baseAddresses)
        {
            return new SimuladorServiceHost(serviceType, baseAddresses);
        }
    }
}
