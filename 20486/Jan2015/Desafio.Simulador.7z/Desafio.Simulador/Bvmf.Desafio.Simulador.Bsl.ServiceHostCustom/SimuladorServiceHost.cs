﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ServiceModel;
using System.ServiceModel.Description;

namespace Desafio.Simulador.Bsl.ServiceHostCustom
{
    public sealed class SimuladorServiceHost : ServiceHost
    {
        public SimuladorServiceHost() : base() { }
        public SimuladorServiceHost(Type serviceType, params Uri[] baseAddresses) : base(serviceType, baseAddresses) { }

        protected override void OnOpening()
        {
            this.Description.Behaviors.Add(new SimuladorServiceBehavior());
            base.OnOpening();
        }

        protected override ServiceDescription CreateDescription(out IDictionary<string, ContractDescription> implementedContracts)
        {
            return base.CreateDescription(out implementedContracts);
        }
    }
}
