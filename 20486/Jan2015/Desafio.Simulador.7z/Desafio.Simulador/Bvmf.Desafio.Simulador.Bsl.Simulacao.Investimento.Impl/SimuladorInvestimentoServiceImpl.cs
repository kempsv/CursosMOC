﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bsl.Simulacao.Investimento.Interfaces;

using System.ServiceModel.Activation;
using System.ServiceModel;
using Desafio.Simulador.Util.Logger;
using Desafio.Simulador.Bcl.Comum.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;

using Desafio.Simulador.Bcl.Simulacao.Investimento.Interfaces;
using Desafio.Simulador.Util.Excecao;
using Microsoft.Practices.Unity;
using Desafio.Simulador.Bcl.Configuracao.Rodada.Interfaces;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Bsl.Comum.Extensions;


namespace Desafio.Simulador.Bsl.Simulacao.Investimento.Impl
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(TransactionIsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted)]
    public class SimuladorInvestimentoServiceImpl : ISimuladorInvestimentoService 
    {


        private BCSimulacaoInvestimento _bcPersistence;

        public SimuladorInvestimentoServiceImpl(BCSimulacaoInvestimento bcPersistence) 
        {
            _bcPersistence = bcPersistence;
        }

        #region ISimuladorInvestimentoService Members

        [LogSistema()]
        public CarteiraInvestimentoDTO ObterCarteiraInvestimentoRodadaAtualizada(RodadaSimulacaoDTO rodadaSimulacaoDTO)
        {
            CarteiraInvestimentoDTO _returnEntity = null;
            try
            {
                CarteiraInvestimento _carteira = _bcPersistence.ObterCarteiraInvestimentoRodada(rodadaSimulacaoDTO.TranslateFromDTO());

                if (null != _carteira)
                    _returnEntity = _carteira.TranslateToDTO();
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return _returnEntity;
        }

        [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
        [LogAuditor("Tx-SalvarCarteiraInvestimento", "SalvarCarteiraInvestimento")]
        [NotNullParam()]
        [LogSistema()]
        public void SalvarCarteiraInvestimento(CarteiraInvestimentoDTO carteiraInvestimentoDTO)
        {
            try
            {
                _bcPersistence.SalvarCarteiraInvestimento(carteiraInvestimentoDTO.TranslateFromDTO());
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
        }

        #endregion

        
    }
}
