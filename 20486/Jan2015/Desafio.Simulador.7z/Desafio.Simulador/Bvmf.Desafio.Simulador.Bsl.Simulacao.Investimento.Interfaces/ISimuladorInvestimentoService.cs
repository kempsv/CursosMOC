﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Desafio.Simulador.Bsl.Comum.Dto;

namespace Desafio.Simulador.Bsl.Simulacao.Investimento.Interfaces
{
    [ServiceContract()]
    public interface ISimuladorInvestimentoService
    {
        ///// <summary>
        ///// Lista as rodadas de simulação de um determinar Grupo Escolar e Agendamento
        ///// </summary>
        ///// <param name="codigoRodada"></param>
        ///// <returns></returns>
        //[OperationContract]
        //List<RodadaSimulacaoDTO> ListarRodadasSimulacaoGrupoEscolar(GrupoEscolarDTO grupoEscolarDTO);

        ///// <summary>
        ///// Lista o Cenário Principal de uma rodada de Simulacao
        ///// </summary>
        ///// <param name="rodadaSimulacao"></param>
        ///// <returns></returns>
        //[OperationContract]
        //RodadaCenarioDTO ObterCenarioPrincipalRodadaSimulacao(RodadaSimulacaoDTO rodadaSimulacaoDTO);

        ///// <summary>
        ///// Lista todos os cenários principais para cada Rodada de Simulação
        ///// </summary>
        ///// <param name="rodadaSimulacao"></param>
        ///// <returns></returns>
        //[OperationContract]
        //List<RodadaCenarioDTO> ListarCenariosRodadaSimulacao(RodadaSimulacaoDTO rodadaSimulacao, bool? somenteCenarioPrincipal);

        ///// <summary>
        ///// Lista todos os cenários de contingência de uma Rodada de Simulação
        ///// </summary>
        ///// <param name="rodadaSimulacao"></param>
        ///// <returns></returns>
        //[OperationContract]
        //List<RodadaCenarioDTO> ListarCenariosContingenciaRodadaSimulacao(RodadaSimulacaoDTO rodadaSimulacao);

        ///// <summary>
        ///// GDEM-RNG05.16.18 - Exibir Histórico Carteira 
        ///// Descrição: Exibir, durante a Simulação de Investimento Web, os investimentos realizados, 
        ///// pelo Grupo, nas rodadas anteriores daquele simulado apenas. Não mostrar as 
        ///// rentabilidades obtidas, apenas os papéis, quantidades e valores.
        ///// Benefício Esperado: Permitir que o Grupo veja a evolução de sua 
        ///// carteira durante a Simulação de Investimento Web, possibilitando a conferência 
        ///// e análise de suas decisões de investimento.
        ///// </summary>
        ///// <param name="agendaSimulacaoGrupoEscolar"></param>
        ///// <returns>Histórico das carteiras de investimento da rodadas executadas</returns>
        //[OperationContract]
        //List<RodadaSimulacaoDTO> ListarHistoricoCarteiraInvestimento(RodadaSimulacaoDTO rodadaSimulacaoDTO);
       
        /// <summary>
        /// GDEM-RNG05.16.12 - Enviar Carteira de Investimento
        /// Descrição: Permitir que os Grupos possam indicar suas decisões de investimento, 
        /// formando sua própria carteira de investimento e enviar para registro no Simulador de Investimento Web.
        /// Benefício Esperado: Registrar a decisão tomada de investimento para realização de 
        /// cálculo de rentabilidade
        /// </summary>
        /// <param name="codigoRodada"></param>
        /// <param name="carteiraInvestimento"></param>
        [OperationContract]
        void SalvarCarteiraInvestimento(CarteiraInvestimentoDTO carteiraInvestimentoDTO);

        /// <summary>
        /// GDEM-RNG05.16.11 - Exibir Carteira de Investimento
        /// Descrição: Exibir os papéis disponíveis para investimento, indicando a quantidade 
        /// de cada um e o valor que o Grupo já tenha investido. Exibir durante o tempo disponível para investir.
        /// Benefício Esperado: Auxiliar os Participantes na tomada decisão de investimento virtual, 
        /// aproximando à realidade do dia-a-dia do mercado
        /// </summary>
        /// <param name="codigoRodada"></param>
        /// <returns></returns>
        [OperationContract]
        CarteiraInvestimentoDTO ObterCarteiraInvestimentoRodadaAtualizada(RodadaSimulacaoDTO rodadaSimulacaoDTO);

        ///// <summary>
        ///// GDEM-RNG005.16.16 - Exibir Rentabilidade Rodada 
        ///// Descrição: Ao fim de cada rodada deverá ser exibido para o Grupo a rentabilidade da carteira.
        ///// Benefício Esperado: Informar quanto que o investimento decidido rendeu
        ///// </summary>
        ///// <param name="codigoRodada"></param>
        ///// <returns>Carteira de investimento atualizada</returns>
        //[OperationContract]
        //CarteiraInvestimentoDTO ObterRentabilidadeCarteiraRodada(RodadaSimulacaoDTO rodadaSimulacao);
    }
}
