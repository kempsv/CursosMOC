﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Activation;
using Microsoft.Practices.Unity;

using Desafio.Simulador.Bcl.Competidor.Interfaces;
using Desafio.Simulador.Bsl.Simulacao.Ranking.Interfaces;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Bcl.Core.Domain.Enum;
using Desafio.Simulador.Bsl.Comum.Extensions;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bcl.Agendamento.Simulacao.Interfaces;
using Desafio.Simulador.Bcl.Simulacao.Investimento.Interfaces;
using Desafio.Simulador.Bsl.Integrador.Interfaces;
using System.ServiceModel;

namespace Desafio.Simulador.Bsl.Simulacao.Ranking.Impl
{

    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class RankingSimulacaoServiceImpl : IRankingSimulacaoService, IIntegradorRankingEscolasService
    {
        private BCEscolasSimulador _bcPersistence = null;
        private static List<Escola> _escolasCadastradas = null;

        #region Propriedade Injetadas
        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCGrupoEscolarSimulador BCGrupoEscolarSimulador { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCAgendaSimulacao BCAgendaSimulacao { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCSimulacaoInvestimento BCSimulacaoInvestimento { get; set; }

        /// <summary>
        /// Injetado através do Mecanimos do Unity App. Blocks
        /// </summary>
        [Dependency]
        public BCEscolasSimulador BCEscolasSimulador { get; set; }

        #endregion

        #region Construtores
        public RankingSimulacaoServiceImpl(BCEscolasSimulador bcPersistence)
        {
            //Dependencia injetada pela mecanismo de Dependecy Injection do Unity
            _bcPersistence = bcPersistence;
        }
        #endregion

        private List<RankingSimulacaoGrupoEscolarDTO> ListarRankingGruposEscolarByCarteiraInvestimento(List<GrupoEscolar> grupoEscolares)
        {
            var _rankingGruposEscolares = new List<RankingSimulacaoGrupoEscolarDTO>();

            grupoEscolares.ForEach(delegate(GrupoEscolar grupoEscolar)
            {
                grupoEscolar.AgendaSimulacao.ForEach(delegate(AgendaSimulacao agenda)
                {
                    //Obtêma a Ultima Rodada de Simulação
                    var _agendaRodada = agenda.AgendaSimulacaoRodadas.Where(rd => rd.Rodada.IdentificadorRodada == agenda.ParametrizacaoAgenda.QuantidadeRodadas).FirstOrDefault<AgendaSimulacaoRodadas>();
                    var _carteiraInvestimento = this.BCSimulacaoInvestimento.ObterCarteiraInvestimentoRodada(_agendaRodada.Rodada);
                    //if (_carteiraInvestimento != null)
                    _rankingGruposEscolares.GerarRanking(grupoEscolar, _carteiraInvestimento);
                });
            });
            return _rankingGruposEscolares;
        }

        #region IRankingSimulacaoService Members

        public List<RankingSimulacaoEscolaDTO> ListarRankingAcumuladoGeral(TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO)
        {
            try
            {
                if (_escolasCadastradas == null)
                    _escolasCadastradas = this.BCEscolasSimulador.FindAll();

                var _listaRankingEscolas = new List<RankingSimulacaoEscolaDTO>();
                _escolasCadastradas.ForEach(delegate(Escola escola)
                {
                    if (escola.GruposEscolares == null)
                        escola.GruposEscolares = this.BCGrupoEscolarSimulador.ListarGruposEscolaresByEscola(escola.Codigo);

                    escola.GruposEscolares.ForEach(delegate(GrupoEscolar grupoEscolar)
                    {
                        grupoEscolar.AgendaSimulacao = this.BCAgendaSimulacao.ListarAgendaSimulacaoGrupoEscolar(grupoEscolar.Codigo);
                    });
                    var _grupoEscolares = escola.GruposEscolares.ListarAgendaByPeriodoSemana(tipoSemanaSimulacaoDTO.ConvertToEnum());

                    var _listaRankingGrupoEscolaresRetorno = this.ListarRankingGruposEscolarByCarteiraInvestimento(_grupoEscolares);
                    //if (_listaRankingGrupoEscolaresRetorno.Count > 0)
                    _listaRankingEscolas.GerarRanking(escola, _listaRankingGrupoEscolaresRetorno);
                });
                return _listaRankingEscolas.ClassificarRanking();
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        public List<RankingSimulacaoGrupoEscolarDTO> ListarRankingPorEscola(EscolaDTO escola, TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO)
        {
            try
            {
                /*var _grupoEscolares = this.BCGrupoEscolarSimulador.ListarGruposEscolaresByEscola(escola.Codigo);

                _grupoEscolares.ForEach(delegate(GrupoEscolar grupoEscolar)
                {
                    grupoEscolar.AgendaSimulacao = this.BCAgendaSimulacao.ListarAgendaSimulacaoGrupoEscolar(grupoEscolar.Codigo);
                });

                _grupoEscolares = _grupoEscolares.ListarAgendaByPeriodoSemana(tipoSemanaSimulacaoDTO.ConvertToEnum());
                return this.ListarRankingGruposEscolarByCarteiraInvestimento(_grupoEscolares).ClassificarRanking();*/

                var _rankingGeral = this.ListarRankingAcumuladoGeral(tipoSemanaSimulacaoDTO);
                
                if (_rankingGeral == null) return null;
                
                var _rankingEscola = _rankingGeral.Where(_escola =>
                                                         _escola.Codigo == escola.Codigo).FirstOrDefault<RankingSimulacaoEscolaDTO>();

                return _rankingEscola == null ? null : _rankingEscola.RankingSimulacaoGrupoEscolar;
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        public List<RankingSimulacaoGrupoEscolarDTO> ListarRankingPorEscola(EscolaDTO escola)
        {
            try 
            {
                var _rankingGeral = this.ListarRankingAcumuladoGeral();
                return _rankingGeral.Where(esc => esc.Codigo.Equals(escola.Codigo))
                                    .FirstOrDefault<RankingSimulacaoEscolaDTO>().RankingSimulacaoGrupoEscolar;
            }
            catch (Exception ex) 
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        #endregion

        #region IIntegradorRankingEscolasService Members

        public List<RankingSimulacaoEscolaDTO> ListarRankingAcumuladoGeral(string nomeEscola)
        {
            try
            {
                var _rankingGeral = this.ListarRankingAcumuladoGeral();
                var _escolasPorNome = _rankingGeral.Where(esc => esc.Nome.Trim().ToUpper().Equals(nomeEscola.ToUpper()) ||
                                                                 esc.Nome.Trim().ToUpper().Contains(nomeEscola.ToUpper()))
                                                                 .ToList<RankingSimulacaoEscolaDTO>();
                return _escolasPorNome;
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;
        }

        public List<RankingSimulacaoEscolaDTO> ListarRankingAcumuladoGeral()
        {
            try
            {
                var _rankingEscolas = new List<RankingSimulacaoEscolaDTO>();

                var _ranking4Semana = this.ListarRankingAcumuladoGeral(TipoSemanaSimulacaoDTO.QuartaSemana);
                if (_ranking4Semana !=null)
                    _rankingEscolas.AddRange(_ranking4Semana);
                else
                {
                    var _ranking3Semana = this.ListarRankingAcumuladoGeral(TipoSemanaSimulacaoDTO.TerceiraSemana);
                    if (_ranking3Semana !=null)
                        _rankingEscolas.AddRange(_ranking3Semana);
                    else
                    {
                        var _ranking2Semana = this.ListarRankingAcumuladoGeral(TipoSemanaSimulacaoDTO.SegundaSemana);
                        if (_ranking3Semana != null)
                        {
                            _rankingEscolas.AddRange(_ranking2Semana);
                        }
                        else
                            _rankingEscolas.AddRange(this.ListarRankingAcumuladoGeral(TipoSemanaSimulacaoDTO.PrimeiraSemana));
                    }
                }
                return _rankingEscolas;
            }
            catch (Exception ex)
            {
                GerenciadorExcecao.TratarExcecao(ex);
            }
            return null;

        }

        #endregion
    }
}
