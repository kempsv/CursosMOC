﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Desafio.Simulador.Bsl.Comum.Dto;

namespace Desafio.Simulador.Bsl.Simulacao.Ranking.Interfaces
{
    [ServiceContract]
    public interface IRankingSimulacaoService
    {
        [OperationContract(Name = "ListarRankingPorEscolaParams")]
        List<RankingSimulacaoGrupoEscolarDTO> ListarRankingPorEscola(EscolaDTO escola, TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO);

        [OperationContract(Name = "ListarRankingPorEscola")]
        List<RankingSimulacaoGrupoEscolarDTO> ListarRankingPorEscola(EscolaDTO escola);

        [OperationContract(Name = "ListarRankingAcumuladoGeralByEnum")]
        List<RankingSimulacaoEscolaDTO> ListarRankingAcumuladoGeral(TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO);
    }
}
