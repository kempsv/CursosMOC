﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Dispatcher;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Globalization;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using System.Configuration;

namespace Desafio.Simulador.Bsl.UnityContainerCustom
{
    public sealed class SimuladorContainerProvider<T> : IInstanceProvider
    {
        //private static IUnityContainer _container;

        private static IUnityContainer _unityContainer;
        private static object _lockSync = new object();

        private static IUnityContainer GetUnityContainer()
        {
            if (_unityContainer == null)
            {
                lock (_lockSync)
                {
                    if (_unityContainer == null)
                    {
                        _unityContainer = new UnityContainer();
                        UnityConfigurationSection _section = 
                            (UnityConfigurationSection)ConfigurationManager
                            .GetSection("unity");
                        _section.Configure(_unityContainer);
                    }
                }
            }
            return _unityContainer;
        }

        public object GetInstance(InstanceContext instanceContext)
        {
            return GetInstance(instanceContext, null);
        }

        public object GetInstance(InstanceContext instanceContext, Message message)
        {
            return SimuladorContainerProvider<T>.GetInstance();
        }

        public static T GetInstance() 
        {
            T _result = default(T);

            try
            {
                /*_unityContainer = new UnityContainer();
                UnityConfigurationSection _section = (UnityConfigurationSection)ConfigurationManager.GetSection("unity");
                _section.Configure(_unityContainer);*/

                _result = SimuladorContainerProvider<T>.GetUnityContainer().Resolve<T>();
                //_result = _unityContainer.Resolve<T>();

                if (_result == null)
                {
                    throw new Exception(
                        string.Format(
                        CultureInfo.InvariantCulture,
                        "Não foi possível encontrar configuração para o Type=" + typeof(T),
                        "")
                        );
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _result;
        }

        public void ReleaseInstance(System.ServiceModel.InstanceContext instanceContext, object instance) { }
    }
}
