﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using Framework.Excecao;
using System.Runtime.Serialization;
//using Framework.Globalization;
using System.Collections;
using System.Text.RegularExpressions;
using System.Globalization;

namespace Desafio.Simulador.Util.Excecao
{
    [Serializable]
    public class ApplicationWcfServicesException : FxApplicationException
    {
        private string _businessMessage;

        public override string BusinessMessage
        {
            get
            {
                return this._businessMessage;
            }
        }
        
        ~ApplicationWcfServicesException()
        {

        }

        public ApplicationWcfServicesException() { }

        public ApplicationWcfServicesException(string businessMessage)
        {
            _businessMessage = businessMessage;
        }

        /// 
        /// <param name="info"></param>
        /// <param name="context"></param>
        public ApplicationWcfServicesException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            this._businessMessage = info.GetString("_businessMessage");
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
            info.AddValue("_businessMessage", this._businessMessage);
        }

    }
}
