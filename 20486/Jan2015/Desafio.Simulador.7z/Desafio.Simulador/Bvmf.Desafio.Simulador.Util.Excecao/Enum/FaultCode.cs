using System;
using System.Collections.Generic;
using System.Text;

namespace Desafio.Simulador.Util.Excecao.Enum
{

    public enum FaultCode
    {
        Client , Server 
    }
}
