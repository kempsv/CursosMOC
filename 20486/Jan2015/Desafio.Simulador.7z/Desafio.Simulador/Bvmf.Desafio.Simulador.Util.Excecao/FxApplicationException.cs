﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Util.Excecao
{
    [Serializable]
    public class FxApplicationException: Exception
    {
        public virtual string BusinessMessage
        {
            get { return string.Empty; }
        }

        public FxApplicationException()
        {
        }

        public FxApplicationException(string constanteMessage, string message)
        {
        }

        public FxApplicationException(string message, Object[] parms)
        {
        }

        public FxApplicationException(string message, Exception innerException, Object[] parms)
        {
        }

        protected FxApplicationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
