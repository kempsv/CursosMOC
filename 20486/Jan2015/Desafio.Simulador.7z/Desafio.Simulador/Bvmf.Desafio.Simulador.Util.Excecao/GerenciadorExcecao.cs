using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//using Framework.Excecao;
//using Framework.Log;
using System.Data.SqlClient;
using System.Xml;
using System.Web.Services.Protocols;
using System.ServiceModel;
using System.Threading;
using Desafio.Simulador.Util.Logger;

namespace Desafio.Simulador.Util.Excecao
{
    public static class GerenciadorExcecao
    {
        static GerenciadorExcecao()
        {
        }

        #region Constantes para Tratamento das Exce��es de SQL Sever

        //Esse erro ocorre quando:
        //1 - Se tenta Inserir ou Alterar um Registro e uma das colunas � uma chave 
        //    estrangiera para outra tabela e o valor especificado n�o est� cadastrado 
        //    na tabela pai
        private const string ErroDeChaveEstrangiera = "FOREIGN KEY";

        //Esse erro ocorre quando:
        //1 - Se tenta Inserir ou Alterar um Registro e uma das colunas possui
        //    uma Constraint definida no Banco de Dados
        private const string ErroDeValidacaoDeRegra = "CHECK";

        //Esse erro ocorre quando:
        //1 - Se tenta Excluir um Registro de um Tabela e uma ou mais colunas
        //    delas s�o chave estrangeira em outras tabelas filhas.
        private const string ErroDeValidacaoDeReferencia = "REFERENCE";

        //Esse erro ocorre quando:
        //1 - Se tenta Incluir um novo registro numa Tabela e j� existe
        //    um outro registro armazenado com a mesma chave prim�ria
        private const string ErroDeChavePrimaria = "PRIMARY KEY";

        //Esse erro ocorre quando:
        //1 - Se tenta Incluir um novo registro numa Tabela e j� existe
        //    um outro registro armazenado onde um dos campos possui um �ndice
        //    UNICO (IE - Index Entry) associado
        private const string ErroDeIndiceUnico = "INSERT DUPLICATE KEY ROW";

        //Esse erro ocorre quando:
        //1 - Se tenta incluir um novo registro numa tabela e j� exsite
        //    um outro registro armazenado onde um dos campo possui uma chave
        //    ALTERNATIVA (AK - Alternative Key) associada
        private const string ErroDeChaveAlternativa = "VIOLATION OF UNIQUE KEY";

        //Esse erro ocorre quando:
        //
        private const string ErroParametroInvalidoProcedimentoBancoDados = "ERR_PAR_INV_PROC_BD";

        private enum ErrosSqlServer
        {
            ErroDeConstraint = 547,
            ViolacaoDeIndiceUnico = 2601,
            ViolacaoDeChavePrimaria = 2627,
            ErroGenerico = 50000
        }

        #endregion

        #region Constantes gerais

        private const string CHAVE_EX_JA_LANCADA = "CHAVE_EX_JA_LANCADA";

        #endregion

        private static void LancarExcecao(Exception ex)
        {
            // Verifica se a exce��o j� foi lan�ada anteriormente ou n�o
            // para grava��o do log de erro

            if (!ex.Data.Contains(CHAVE_EX_JA_LANCADA))
            {
                ex.Data.Add(CHAVE_EX_JA_LANCADA, true);
            }

            throw ex;
            //ExceptionManager.Rethrow(ex);
        }

        private static void LancarExcecao(string mensagem, Exception ex)
        {
            // Verifica se a exce��o j� foi lan�ada anteriormente ou n�o
            // para grava��o do log de erro

            if (!ex.Data.Contains(CHAVE_EX_JA_LANCADA))
            {
                LogManager.Error(mensagem);

                ex.Data.Add(CHAVE_EX_JA_LANCADA, true);
            }

            throw ex;
            //ExceptionManager.Rethrow(ex);
        }

        /// <summary>
        /// Sobrecarga do m�todo para receber uma Exce��o de Neg�cio e apenas lan�ar a Exce��o novamente.
        /// </summary>
        /// <param name="fxBmfApplicationException">Exce��o de Neg�cio</param>
        public static void TratarExcecao(FxApplicationException fxBmfApplicationException)
        {

            if (fxBmfApplicationException != null)
            {
                if (fxBmfApplicationException is ApplicationWcfServicesException)
                    GerenciadorExcecao.LancarExcecao((ApplicationWcfServicesException)fxBmfApplicationException);
                else
                {
                    //N�o dever�o existir tratamentos espec�ficos para Exce��es de Neg�cio
                    //pois o erro em quest�o j� foi devidamente tratado. Nesse caso vamos
                    //apenas lan�ar a Exce��o Original novamente

                    //LogManager.Error(String.Format("Foi recebida uma exce��o de neg�cio. Como se trata de um erro j� tratado vamos apenas repass�-lo. >>> {0} <<<", fxBmfApplicationException.BusinessExceptionCode));
                    GerenciadorExcecao.LancarExcecao(fxBmfApplicationException);
                }
            }
            else
            {
                //GerenciadorExcecao.LancarExcecao("Foi passado um Objeto Nulo como Par�metro para Tratamento da Exce��o", new ArgumentNullException("fxBmfApplicationException"));
            }
        }

        /// <summary>
        /// Trata as principais Exce��es do SQL Server e retornando uma Exce��o de N�g�cio. Caso n�o exista um tratamento espec�fico, a SqlException Original � lan�ada novamente.
        /// </summary>
        /// <param name="exception">Exce��o</param>
        public static void TratarExcecao(SqlException sqlException)
        {
            if (sqlException != null)
            {
                foreach (SqlError erroSql in sqlException.Errors)
                {
                    if (erroSql.Number == (int) ErrosSqlServer.ErroDeConstraint)
                    {
                        #region Erro de Constraint
                        if (erroSql.Message.ToUpper(Thread.CurrentThread.CurrentCulture).Contains(ErroDeChaveEstrangiera))
                        {
                            //GerenciadorExcecao.LancarExcecao(String.Format("A Exce��o >>> {0} {1} <<< foi Tratada e uma Exce��o de Neg�cio ViolacaoDeChaveEstrangeiraException foi lan�ada", erroSql.Number, erroSql.Message), new ViolacaoDeChaveEstrangeiraException(sqlException));
                        }
                        else if (erroSql.Message.ToUpper(Thread.CurrentThread.CurrentCulture).Contains(ErroDeValidacaoDeRegra))
                        {
                            //GerenciadorExcecao.LancarExcecao(String.Format("A Exce��o >>> {0} {1} <<< foi Tratada e uma Exce��o de Neg�cio ViolacaoDeRegraException foi lan�ada", erroSql.Number, erroSql.Message), new ViolacaoDeRegraException(sqlException));
                        }
                        else if (erroSql.Message.ToUpper(Thread.CurrentThread.CurrentCulture).Contains(ErroDeValidacaoDeReferencia))
                        {
                            //GerenciadorExcecao.LancarExcecao(String.Format("A Exce��o >>> {0} {1} <<< foi Tratada e uma Exce��o de Neg�cio ViolacaoDeReferenciaException foi lan�ada", erroSql.Number, erroSql.Message), new ViolacaoDeReferenciaException(sqlException));
                        }
                        else
                        {
                            //GerenciadorExcecao.LancarExcecao(String.Format("N�o foi poss�vel tratar a Exce��o >>> {0} {1} <<<. A Exce��o Original foi lan�ada novamente", erroSql.Number, erroSql.Message), sqlException);
                        }
                        #endregion
                    }
                    else if (erroSql.Number == (int) ErrosSqlServer.ViolacaoDeChavePrimaria)
                    {
                        #region Erro de Chave Prim�ria
                        if (erroSql.Message.ToUpper(Thread.CurrentThread.CurrentCulture).Contains(ErroDeChavePrimaria))
                        {
                            //GerenciadorExcecao.LancarExcecao(String.Format("A Exce��o >>> {0} {1} <<< foi Tratada [Erro de Chave Prim�ria] e uma Exce��o de Neg�cio ViolacaoChavePrimariaException foi lan�ada", erroSql.Number, erroSql.Message), new ViolacaoChavePrimariaException(sqlException));
                        }
                        else if (erroSql.Message.ToUpper(Thread.CurrentThread.CurrentCulture).Contains(ErroDeChaveAlternativa))
                        {
                            //GerenciadorExcecao.LancarExcecao(String.Format("A Exce��o >>> {0} {1} <<< foi Tratada [Viola��o de �ndice �nico] e uma Exce��o de Neg�cio ViolacaoChavePrimariaException foi lan�ada", erroSql.Number, erroSql.Message), new ViolacaoChavePrimariaException(sqlException));
                        }
                        else
                        {
                            //GerenciadorExcecao.LancarExcecao(String.Format("N�o foi poss�vel tratar a Exce��o >>> {0} {1} <<<. A Exce��o Original foi lan�ada novamente", erroSql.Number, erroSql.Message), sqlException);
                        }
                        #endregion
                    }
                    else if (erroSql.Number == (int)ErrosSqlServer.ViolacaoDeIndiceUnico)
                    {
                        #region Erro de �ndice �nico
                        if (erroSql.Message.ToUpper(Thread.CurrentThread.CurrentCulture).Contains(ErroDeIndiceUnico))
                        {
                            //GerenciadorExcecao.LancarExcecao(String.Format("A Exce��o >>> {0} {1} <<< foi Tratada e uma Exce��o de Neg�cio ViolacaoChavePrimariaException foi lan�ada", erroSql.Number, erroSql.Message), new ViolacaoChavePrimariaException(sqlException));
                        }
                        else
                        {
                            //GerenciadorExcecao.LancarExcecao(String.Format("N�o foi poss�vel tratar a Exce��o >>> {0} {1} <<<. A Exce��o Original foi lan�ada novamente", erroSql.Number, erroSql.Message), sqlException);
                        }
                        #endregion
                    }
                    else if (erroSql.Number == (int)ErrosSqlServer.ErroGenerico)
                    {
                        #region Erro Gen�rico
                        if (erroSql.Message.ToUpper(Thread.CurrentThread.CurrentCulture).Contains(ErroParametroInvalidoProcedimentoBancoDados))
                        {
                            //GerenciadorExcecao.LancarExcecao(String.Format("A Exce��o >>> {0} {1} <<< foi Tratada e uma Exce��o de Neg�cio ParametroInvalidoProcedimentoBancoDadosException foi lan�ada", erroSql.Number, erroSql.Message), new ParametroInvalidoProcedimentoBancoDadosException(sqlException));
                        }
                        else
                        {
                            //GerenciadorExcecao.LancarExcecao(String.Format("N�o foi poss�vel tratar a Exce��o >>> {0} {1} <<<. A Exce��o Original foi lan�ada novamente", erroSql.Number, erroSql.Message), sqlException);
                        }
                        #endregion
                    }
                    else
                    {
                        //GerenciadorExcecao.LancarExcecao(String.Format("N�o foi poss�vel tratar a Exce��o >>> {0} {1} <<<. A Exce��o Original foi lan�ada novamente", erroSql.Number, erroSql.Message), sqlException);
                    }
                }
            }
            else
            {
                //GerenciadorExcecao.LancarExcecao(String.Format("Foi passado um Objeto Nulo como Par�metro para Tratamento da Exce��o"), new ArgumentNullException("sqlException", sqlException));
            }
            return;
        }

        /// <summary>
        /// Trata as principais Exce��es e retornar Exce��es de Neg�cio para situa��es pr�-definidas
        /// </summary>
        /// <param name="exception">Exce��o</param>
        public static void TratarExcecao(Exception exception)
        {
            if (exception != null)
            {
                FxApplicationException fxEx = (exception as FxApplicationException);
                if (fxEx != null)
                {
                    //Tratamento das Exce��es de Neg�cio
                    GerenciadorExcecao.TratarExcecao(fxEx);
                }
                else
                {
                    SqlException sqlEx = (exception as SqlException);
                    if (sqlEx != null)
                    {
                        //Tratamento das Exce��es do SQL Server
                        GerenciadorExcecao.TratarExcecao(sqlEx);
                    }
                    else
                    {
                        GerenciadorExcecao.LancarExcecao(String.Format("N�o existe um tratamento espec�fico para a Excecao informada. A Exce��o Original foi lan�ada novamente >>>> {0} - {1} <<<<", exception.Message, exception.ToString()), exception);
                    }
                }
            }
            else
            {
                GerenciadorExcecao.LancarExcecao(String.Format("Foi passado um Objeto Nulo como Par�metro para Tratamento da Exce��o"), new ArgumentNullException("exception", exception));
            }
            return;
        }

    }
}
