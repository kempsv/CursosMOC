﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using Framework.Excecao;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Util.Excecao
{
    /// <summary>
    /// Exceção de Parametro Inválido para uma Stored Procedure do Banco de Dados
    /// </summary>
    [Serializable]
    public class ParametroInvalidoProcedimentoBancoDadosException: FxApplicationException
    {
        private const string ConstanteMensagem = "ERR_PAR_INV_PROC_BD";

        /// <summary>
        /// Construtor da Classe
        /// </summary>
        public ParametroInvalidoProcedimentoBancoDadosException()
            : base(ConstanteMensagem, new Object[] { String.Empty })
        {
        }

        /// <summary>
        /// Construtor da classe
        /// </summary>
        /// <param name="innerException">Exceção para incluir na pilha</param>
        public ParametroInvalidoProcedimentoBancoDadosException(Exception innerException)
            : base(ConstanteMensagem, innerException, new Object[] { String.Empty })
        {
        }

        /// <summary>
        /// Construtor da classe
        /// </summary>
        /// <param name="info">Informações para Serialização</param>
        /// <param name="context">Contexto para Serialização</param>
        protected ParametroInvalidoProcedimentoBancoDadosException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
