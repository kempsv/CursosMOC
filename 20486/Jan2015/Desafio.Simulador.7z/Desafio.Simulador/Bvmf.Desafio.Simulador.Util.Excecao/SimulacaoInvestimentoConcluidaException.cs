﻿using System;
using System.Collections;
using System.Runtime.Serialization;
//using Framework.Excecao;

namespace Desafio.Simulador.Util.Excecao
{
    /// <summary>
    /// Classe de Exception para cálculo de Saldo Insuficiente
    /// </summary>
    [Serializable]
    public class SimulacaoInvestimentoConcluidaException : ApplicationWcfServicesException
    {

        public SimulacaoInvestimentoConcluidaException() { }

        public SimulacaoInvestimentoConcluidaException(string businessMessage)
            : base(businessMessage)
        {
        }
        
        /// 
        /// <param name="info"></param>
        /// <param name="context"></param>
        public SimulacaoInvestimentoConcluidaException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

    }//end ExclusaoCategoriaFornecedorException

}//end namespace Fornecedor