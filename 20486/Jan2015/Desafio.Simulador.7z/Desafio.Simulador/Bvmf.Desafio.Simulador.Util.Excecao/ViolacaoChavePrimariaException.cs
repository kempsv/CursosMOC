﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using Framework.Excecao;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Util.Excecao
{
    [Serializable]
    public class ViolacaoChavePrimariaException : FxApplicationException 
    {
        private const string ConstanteMensagem = "ERR_VIOLACAO_PK";

		~ViolacaoChavePrimariaException(){

		}
		public ViolacaoChavePrimariaException()
            : base(ConstanteMensagem, new Object[] { String.Empty })
        {
		}

		/// 
		/// <param name="innerException"></param>
		public ViolacaoChavePrimariaException(Exception innerException)
            : base(ConstanteMensagem,innerException, new Object[] { String.Empty })
        {
		}

		/// 
		/// <param name="info"></param>
		/// <param name="context"></param>
        public ViolacaoChavePrimariaException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
		}

    }
}
