﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using Framework.Excecao;
using System.Runtime.Serialization;
namespace Desafio.Simulador.Util.Excecao
{
    [Serializable]
    public class ViolacaoDeReferenciaException : FxApplicationException
    {
        private const string ConstanteMensagem = "ERR_VIOLACAO_REFERENCIA";

        public ViolacaoDeReferenciaException()
            : base(ConstanteMensagem, new Object[] { String.Empty })
        {
        }

        public ViolacaoDeReferenciaException(Exception innerException)
            : base(ConstanteMensagem, innerException, new Object[] { String.Empty })
        {
        }

        protected ViolacaoDeReferenciaException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}

