﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using Framework.Excecao;
using System.Runtime.Serialization;

namespace Desafio.Simulador.Util.Excecao
{
    [Serializable]
    public class ViolacaoDeRegraException : FxApplicationException
    {
        private const string ConstanteMensagem = "ERR_VIOLACAO_REGRA";

        public ViolacaoDeRegraException()
            : base(ConstanteMensagem, new Object[] { String.Empty })
        {
        }

        public ViolacaoDeRegraException(Exception innerException)
            : base(ConstanteMensagem, innerException, new Object[] { String.Empty })
        {
        }

        protected ViolacaoDeRegraException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
