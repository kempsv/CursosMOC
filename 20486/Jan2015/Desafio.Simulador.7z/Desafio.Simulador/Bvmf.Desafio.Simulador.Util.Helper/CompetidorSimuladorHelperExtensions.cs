﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Xml.Linq;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Bsl.Simulacao.Agenda.Interfaces;
using System.Collections.Generic;

namespace Desafio.Simulador.Util.Helper
{
    /// <summary>
    /// Extension class for the types List Of EscolaDTO and GrupoEscolarDTO
    /// </summary>
    public static partial class CompetidorSimuladorHelperExtensions
    {
        
        public static List<AgendaSimulacaoDTO> ListarAgendaSimulacaoGrupoEscolar(this List<GrupoEscolarDTO> gruposEscolares, TipoSemanaSimulacaoDTO tipoSemanaSimulacao)
        {
            var _listaGruposEscolaresAgenda = new List<AgendaSimulacaoDTO>();
            foreach (GrupoEscolarDTO grupo in gruposEscolares)
            {
                var listaTemporariaAgendamentos = grupo.ListarAgendaSimulacaoGrupoEscolar().Where(dt => dt.TipoSemanaSimulacao == tipoSemanaSimulacao).ToList<AgendaSimulacaoDTO>();

                foreach (AgendaSimulacaoDTO agenda in listaTemporariaAgendamentos)
                {
                    foreach (AgendaSimulacaoRodadasDTO agendaSimulacaoRodadas in agenda.AgendaSimulacaoRodadas)
                    {
                        agendaSimulacaoRodadas.GrupoEscolar = grupo;
                    }
                }
                _listaGruposEscolaresAgenda.AddRange(listaTemporariaAgendamentos);
            }

            return _listaGruposEscolaresAgenda;
        }

        private static List<AgendaSimulacaoDTO> ListarAgendaSimulacaoGrupoEscolar(this GrupoEscolarDTO grupoEscolar)
        {
            //var _serviceAgenda = ServiceLocator.GetInstance<ISimuladorAgendamentoService>();
            //return _serviceAgenda.ListarAgendaSimulacaoGrupoEscolar(grupoEscolar.Codigo);
            return null;
        }

        public static AgendaSimulacaoDTO Match(this List<AgendaSimulacaoDTO> agendaSimulacao, int codigoAgenda)
        {
            return agendaSimulacao.Where(ag => ag.Codigo == codigoAgenda).FirstOrDefault<AgendaSimulacaoDTO>();
        }
        
        public static List<RodadaCenarioDTO> ListarRodadasCenariosSimulacaoGrupoEscolar(this GrupoEscolarDTO grupoEscolar)
        {
            var _agendaSimulacao = grupoEscolar.ListarAgendaSimulacaoGrupoEscolar().Match(grupoEscolar.AgendaSimulacao[0].Codigo);

            var _rodadasCenarios = new List<RodadaCenarioDTO>();
            _agendaSimulacao.AgendaSimulacaoRodadas.ForEach(delegate(AgendaSimulacaoRodadasDTO agendaRodadas)
            {
                _rodadasCenarios.AddRange(agendaRodadas.RodadaCenario);
            });
            return _rodadasCenarios.OrderBy(ord => ord.RodadaSimulacao.IdentificadorRodada).
                                    OrderBy(ord => ord.IndicadorCenarioContingencia).ToList<RodadaCenarioDTO>();
        }
    }
}
