﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Desafio.Simulador.Util.Helper
{
    public static class DataTimeHelperExtensions
    {
        private static int _h = 00;
        private static int _m = 00;
        private static int _s = 60;
        private static bool _tempoSimulacaoExpired;

        static DataTimeHelperExtensions()
        {
            _tempoSimulacaoExpired = false;
        }

        public static void ResetTempoSimulacao(this DateTime date)
        {
            _h = 00;
            _m = 00;
            _s = 00;
            _tempoSimulacaoExpired = false;
        }

        //public static DateTime TesteKemps(this DateTime date, int hour, int minute, int second) 
        /// <summary>
        /// Tempo de simulação em minutos
        /// </summary>
        /// <param name="date"></param>
        /// <param name="tempoSimulacao"></param>
        /// <returns></returns>
        public static DateTime SetTempoSimulacao(this DateTime date, int tempoSimulacao)
        {
            DateTime t = new DateTime(2000, 1, 1, 0, 0, 0);

            t = t.AddMinutes(tempoSimulacao);
            t = t.AddSeconds(-1);

            _h = t.Hour;
            _m = t.Minute;
            _s = t.Second;


            return new DateTime(date.Year, date.Month, date.Day, _h, _m, _s);

        }

        //public static DateTime TesteKemps(this DateTime date, int hour, int minute, int second) 
        /// <summary>
        /// Tempo de simulação em minutos
        /// </summary>
        /// <param name="date"></param>
        /// <param name="tempoSimulacao"></param>
        /// <returns></returns>
        public static DateTime SetTempoSimulacao(this DateTime date)
        {
            DateTime t = new DateTime(2000, 1, 1, _h, _m, _s);

            t = t.AddSeconds(-1);


            if (t.Year == 1999)
            {
                _h = 0;
                _m = 0;
                _s = 0;
                _tempoSimulacaoExpired = true;
            }
            else
            {
                _tempoSimulacaoExpired = false;
                _h = t.Hour;
                _m = t.Minute;
                _s = t.Second;
            }

            return new DateTime(date.Year, date.Month, date.Day, _h, _m, _s);
        }

        public static bool GetTempoSimulacaoExpirada(this DateTime date)
        {
            return _tempoSimulacaoExpired;
        }
    }

    //public static class DataTimeHelperExtensions
    //{
    //    private static int _h = 00;
    //    private static int _m = 00;
    //    private static int _s = 60;
    //    private static bool _tempoSimulacaoExpired;

    //    static DataTimeHelperExtensions()
    //    {
    //        _tempoSimulacaoExpired = false;
    //    }

    //    public static void ResetTempoSimulacao(this DateTime date)
    //    {
    //        _h = 00;
    //        _m = 00;
    //        _s = 60;
    //        _tempoSimulacaoExpired = false;
    //    }

    //    //public static DateTime TesteKemps(this DateTime date, int hour, int minute, int second) 
    //    /// <summary>
    //    /// Tempo de simulação em minutos
    //    /// </summary>
    //    /// <param name="date"></param>
    //    /// <param name="tempoSimulacao"></param>
    //    /// <returns></returns>
    //    public static DateTime SetTempoSimulacao(this DateTime date, int tempoSimulacao)
    //    {
    //        _s -= 1;

    //        if (_s == -1)
    //        {
    //            _s = 59;
    //            _m -= 1;
    //        }

    //        if (_m < 0)
    //        {
    //            _m = tempoSimulacao - 1;
    //            _tempoSimulacaoExpired = true;
    //        }
    //        else
    //            _tempoSimulacaoExpired = false;

    //        //if (m == -1) m = tempoSimulacao - 1;

    //        return new DateTime(date.Year, date.Month, date.Day, _h, _m, _s);
    //    }

    //    public static bool GetTempoSimulacaoExpirada(this DateTime date)
    //    {
    //        return _tempoSimulacaoExpired;
    //    }
    //}
}
