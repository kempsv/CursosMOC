﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity.InterceptionExtension;
using System.Reflection;

namespace Desafio.Simulador.Util.Helper
{
    public static class MethodInvocationExtensions
    {
        public static string ObterParametrosEntrada(this IMethodInvocation data, IParameterCollection input)
        {
            StringBuilder linha = new StringBuilder();
            string _params = string.Empty;

            linha.Append("Parâmetros Entrada: ");
            linha.Append("(");
            for (int i = 0; i < input.Count; i++)
            {
                object target = input[i];

                ParameterInfo parameterInfo = input.GetParameterInfo(i);
                _params = parameterInfo.ParameterType + " - " + parameterInfo.Name + "<" + target + ">";
            }
            linha.Append(_params);
            linha.Append(")");

            return linha.ToString();
        }
    }
}
