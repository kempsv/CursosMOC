﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Xml.Linq;
using Desafio.Simulador.Bsl.Comum.Dto;

namespace Desafio.Simulador.Util.Helper
{
    public static partial class TranslatorHelperExtensions
    {
        public static TipoSemanaSimulacaoDTO GetEnumTipoSemanaSimulacao(this int periodoSemana)
        {
            switch (periodoSemana)
            {
                case 1:
                    return TipoSemanaSimulacaoDTO.PrimeiraSemana;
                case 2:
                    return TipoSemanaSimulacaoDTO.SegundaSemana;
                case 3:
                    return TipoSemanaSimulacaoDTO.TerceiraSemana;
                case 4:
                    return TipoSemanaSimulacaoDTO.QuartaSemana;
                default:
                    return TipoSemanaSimulacaoDTO.PrimeiraSemana;
            }
        }

        public static TipoStatusSorteioCenariosDTO GetEnumTipoStatusSorteioCenarios(this int cenarioSorteado)
        {
            switch (cenarioSorteado)
            {
                case 1:
                    return TipoStatusSorteioCenariosDTO.OK;
                case 2:
                    return TipoStatusSorteioCenariosDTO.Pendente;
                default:
                    return TipoStatusSorteioCenariosDTO.Todos;
            }
        }

        public static string ToStringEnum(this TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO) 
        {
            switch (tipoSemanaSimulacaoDTO)
            {
                case TipoSemanaSimulacaoDTO.PrimeiraSemana:
                    return "1º Semana";
                case TipoSemanaSimulacaoDTO.SegundaSemana:
                    return "2º Semana";
                case TipoSemanaSimulacaoDTO.TerceiraSemana:
                    return "3º Semana";
                case TipoSemanaSimulacaoDTO.QuartaSemana:
                    return "4º Semana";
                default:
                    return "1º Semana";
            }
        }

        public static string ToStringEnum(this TipoSemanaSimulacaoDTO tipoSemanaSimulacaoDTO, int periodoSemana) 
        {
            switch (periodoSemana)
            {
                case 1:
                    return "1º Semana";
                case 2:
                    return "2º Semana";
                case 3:
                    return "3º Semana";
                case 4:
                    return "4º Semana";
                default:
                    return "1º Semana";
            }        
        }

        public static string ToStringEnum(this TipoStatusSorteioCenariosDTO tipoStatusSorteioCenariosDTO)
        {
            switch (tipoStatusSorteioCenariosDTO)
            {
                case TipoStatusSorteioCenariosDTO.OK:
                    return "OK";
                case TipoStatusSorteioCenariosDTO.Pendente:
                    return "Pendente";
                default:
                    return "OK";
            }
        }
    }
}
