﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Desafio.Simulador.Util.Logger.Entidade
{
    [Serializable]
    public class TOLogFuncionalidade
    {
        public string NomeFuncionalidade { get; set; }
        public DateTime DataHora { get; set; }

        public string GetXmlSchema()
        {
            StringBuilder _sbXmls = new StringBuilder();
            _sbXmls.AppendLine("<?xml version='1.0' encoding='iso-8859-1'?>");
            _sbXmls.AppendLine("<Log>");
            _sbXmls.AppendLine("  <Crud>");
            _sbXmls.AppendLine("    <Func>");
            _sbXmls.AppendLine("      <nome>" + this.NomeFuncionalidade + "</nome>");
            _sbXmls.AppendLine("      <codigo></codigo>");
            _sbXmls.AppendLine("      <data>" + this.DataHora + "</data>");
            _sbXmls.AppendLine("      <hora>" + this.DataHora.ToString("HH:mm:ss") + "</hora>");
            _sbXmls.AppendLine("    </Func>");
            _sbXmls.AppendLine("  </Crud>");
            _sbXmls.AppendLine("</Log>");

            return _sbXmls.ToString();
        }

    }
}
