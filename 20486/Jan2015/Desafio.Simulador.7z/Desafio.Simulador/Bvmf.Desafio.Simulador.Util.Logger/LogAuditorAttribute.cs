﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity.InterceptionExtension;
using Microsoft.Practices.Unity;
using Desafio.Simulador.Util.Logger.Entidade;

namespace Desafio.Simulador.Util.Logger
{
    /// <summary>
    /// Faz o log de Auditoria:
    /// Transction Name, Funcionalidade executada, Data e Hora da execução e usuário executor
    /// </summary>
    public class LogAuditorAttribute : HandlerAttribute
    {
        private string _tranctionName = string.Empty;
        private string _nomeFuncionalidade = string.Empty;

        public LogAuditorAttribute(string tranctionName, string nomeFuncionalidade)
        {
            _tranctionName = tranctionName;
            _nomeFuncionalidade = nomeFuncionalidade; 
        }

        public LogAuditorAttribute() { }

        public override ICallHandler CreateHandler(IUnityContainer container)
        {
            if (_tranctionName == string.Empty)
                return new LogAuditorHandler();

            return new LogAuditorHandler(_tranctionName, new TOLogFuncionalidade() { DataHora = DateTime.Now, NomeFuncionalidade = _nomeFuncionalidade });
        }
    }
}
