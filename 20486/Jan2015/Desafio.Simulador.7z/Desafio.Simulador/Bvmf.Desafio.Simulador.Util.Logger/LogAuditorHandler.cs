﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity.InterceptionExtension;
using System.Transactions;
using Desafio.Simulador.Util.Logger.Entidade;
using System.Threading;

namespace Desafio.Simulador.Util.Logger
{
    public class LogAuditorHandler : ICallHandler
    {
       private string _tranctionName = string.Empty;
       private TOLogFuncionalidade _toLogFuncionalidade = null;
       private Thread thread = null;

       public LogAuditorHandler(string tranctionName, TOLogFuncionalidade toLogFuncionalidade) 
        {
            _tranctionName = tranctionName;
            _toLogFuncionalidade = toLogFuncionalidade;
        }

        public LogAuditorHandler() { }


        #region ICallHandler Members

        public IMethodReturn Invoke(IMethodInvocation input, GetNextHandlerDelegate getNext)
        {
            LogManager.Trace("Log Auditor: Assembly [ " + ((System.Reflection.MemberInfo)input.MethodBase).ReflectedType.FullName + "." + input.MethodBase.Name + "() ] ",
                    " - [ TRANSACTION Name = {0}, Distributed TRANSACTION ID= {1}, LOCAL TRANSACTION ID= {2}, Data e Hora= {3}, Nome Funcionalidade= {4}, XML={5}",
                    _tranctionName,
                    Transaction.Current != null ? Transaction.Current.TransactionInformation.DistributedIdentifier.ToString() : "Transaction.Current==null",
                    Transaction.Current != null ? Transaction.Current.TransactionInformation.LocalIdentifier.ToString() : "Transaction.Current==null",
                    _toLogFuncionalidade.DataHora,
                    _toLogFuncionalidade.NomeFuncionalidade,
                    _toLogFuncionalidade.GetXmlSchema());

            /*thread = new Thread(new ThreadStart(GravarLogAuditor));
            thread.Start();*/

            return getNext()(input, getNext);
        }

        private void GravarLogAuditor()
        {
            using (TransactionScope _scope = new TransactionScope(TransactionScopeOption.RequiresNew))
            {
                //Bmf.Framework.LogNegocio.Util.CarregaInfo();
                //Bmf.Framework.Log.LogManager.Business("LOG_AUDITOR", _toLogFuncionalidade.GetXmlSchema());

                _scope.Complete();
            }

            if (thread.IsAlive) thread.Abort();
        }

        public int Order { get; set; }
        
        #endregion
    }
}
