﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Desafio.Simulador.Util.Logger
{
    public static class LogManager
    {
        public static void Trace(string nomeMetodo, string mensagem)
        {
            string texto = nomeMetodo + ": " + mensagem;

            //Bmf.Framework.Log.LogManager.Trace(texto);

            TextLog.Trace(texto);
        }

        public static void Trace(string nomeMetodo, string mensagem, params object[] parametros) 
        {
            List<string> _parametrosSeguros = new List<string>();

            foreach (object objeto in parametros)
            {
                if (objeto == null)
                {
                    _parametrosSeguros.Add("null");
                }
                else
                {
                    _parametrosSeguros.Add(objeto.ToString());
                }
            }
            mensagem = string.Format(mensagem, _parametrosSeguros.ToArray());

            string _texto = nomeMetodo + ": " + mensagem;

            //Bmf.Framework.Log.LogManager.Trace(_texto);

            TextLog.Trace(_texto);
        }

        public static void Error(string nomeMetodo, string mensagem, Exception ex)
        {
            string _texto = nomeMetodo + ": " + mensagem;

            //Bmf.Framework.Log.LogManager.Error(_texto, ex);

            TextLog.Error(_texto, ex);
        }

        public static void Error(string mensagem) 
        {
            //Bmf.Framework.Log.LogManager.Error(_texto);

            TextLog.Error(mensagem);
        }
        public static void Error(string nomeMetodo, Exception ex)
        {
            string _texto = nomeMetodo;

            //Bmf.Framework.Log.LogManager.Error(_texto, ex);

            TextLog.Error(_texto, ex);
        }

        public static void Error(string nomeMetodo, string mensagem)
        {
            string _texto = nomeMetodo + ": " + mensagem;

            //Bmf.Framework.Log.LogManager.Error(_texto);

            TextLog.Error(_texto);
        }

        public static void Error(Exception ex) 
        {
            //Bmf.Framework.Log.LogManager.Error("", ex);
            TextLog.WriteErrorWeb(ex);
        }

        public static void InicioMetodo(string nomeMetodo, params object[] parametros)
        {
            string _retorno = " (";
            foreach (object objeto in parametros)
            {
                if (objeto == null)
                    _retorno += "null" + ",";
                else
                    _retorno += objeto.ToString() + ",";
            }
            _retorno = (_retorno.TrimEnd(',') + ")");

            string _texto = "Inicio metodo " + nomeMetodo + " parametros " + _retorno;

            //Bmf.Framework.Log.LogManager.Trace(_texto);

            TextLog.TraceIn(nomeMetodo, _retorno);
        }

        public static void InicioMetodo(string nomeMetodo) 
        {
            string _texto = "Inicio do metodo " + nomeMetodo;
            
            //Bmf.Framework.Log.LogManager.Trace(_texto);

            TextLog.TraceIn(nomeMetodo);
        }

        public static void FimMetodo(string nomeMetodo)
        {
            string texto = "Fim do metodo " + nomeMetodo;

            //Bmf.Framework.Log.LogManager.Trace(texto);

            TextLog.TraceOut(nomeMetodo);
        }
        
        public static void FimMetodo(string nomeMetodo, params object[] parametros) 
        {
            string _retorno = " (";
            foreach (object objeto in parametros)
            {
                if (objeto == null)
                    _retorno += "null" + ",";
                else
                    _retorno += objeto.ToString() + ",";
            }
            _retorno = (_retorno.TrimEnd(',') + ")");

            string _texto = "Fim do metodo " + nomeMetodo + " retorno " + _retorno;

            //Bmf.Framework.Log.LogManager.Trace(_texto);

            TextLog.TraceOut(nomeMetodo, _retorno);
        }
    }
}
