﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity.InterceptionExtension;
using Microsoft.Practices.Unity;

namespace Desafio.Simulador.Util.Logger
{
    /// <summary>
    /// Faz o log do Sistema:
    /// Início e Fim Método
    /// </summary>
    public class LogSistemaAttribute : HandlerAttribute
    {
        private string _message = string.Empty;

        public LogSistemaAttribute(string message) 
        {
            _message = message;
        }

        public LogSistemaAttribute() { }

        public override ICallHandler CreateHandler(IUnityContainer container)
        {
            if (_message == string.Empty)
                return new LogSistemaHandler();

            return new LogSistemaHandler(_message);
        }
    }

}
