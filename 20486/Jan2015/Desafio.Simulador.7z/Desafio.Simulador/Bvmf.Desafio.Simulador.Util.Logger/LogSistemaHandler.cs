﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity.InterceptionExtension;
using System.Reflection;
//using Framework.Excecao;

using Desafio.Simulador.Util.Helper;

namespace Desafio.Simulador.Util.Logger
{
    public class LogSistemaHandler : ICallHandler
    {
        private string _message = string.Empty;

        public LogSistemaHandler(string message) : this() 
        {
            _message = message;
        }

        public LogSistemaHandler() { }

        public int Order { get; set; }

        public IMethodReturn Invoke(IMethodInvocation input, GetNextHandlerDelegate getNext)
        {
            /////////////////////////////////////////////////////////////////////////////////////////////////
            //Inicio Método e Parêmtros de Entrada
            //long _initTime = System.DateTime.Now.Ticks;
            string _methodName = input.MethodBase.Name;

            LogManager.InicioMetodo(_methodName, input.ObterParametrosEntrada(input.Inputs));
            /////////////////////////////////////////////////////////////////////////////////////////////////
            
            //return getNext()(input, getNext);
            IMethodReturn _msg = getNext()(input, getNext);

            if (_msg.Exception != null)
            {
                LogManager.Error(_methodName, _msg.Exception);
                return input.CreateExceptionMethodReturn(_msg.Exception);
            }

            //long _endTime = System.DateTime.Now.Ticks; 
            LogManager.FimMetodo(_methodName);

            return _msg;
        }
    }
}
