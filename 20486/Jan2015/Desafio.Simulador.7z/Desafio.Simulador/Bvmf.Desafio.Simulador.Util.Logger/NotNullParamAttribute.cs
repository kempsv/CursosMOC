﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity.InterceptionExtension;
using Microsoft.Practices.Unity;

namespace Desafio.Simulador.Util.Logger
{
    /// <summary>
    /// Faz a verificação de NULL dos parâmetros de entrada
    /// </summary>
    public class NotNullParamAttribute: HandlerAttribute
    {
        public override ICallHandler CreateHandler(IUnityContainer container)
        {
            return new NotNullParamHandler();
        }
    }
}
