﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Unity.InterceptionExtension;
using System.Reflection;

namespace Desafio.Simulador.Util.Logger
{
    public class NotNullParamHandler: ICallHandler
    {
        #region ICallHandler Members

        public IMethodReturn Invoke(IMethodInvocation input, GetNextHandlerDelegate getNext)
        {
            for (int i = 0; i < input.Inputs.Count; i++)
            {
                object target = input.Inputs[i];
                if (target == null)
                {
                    ParameterInfo parameterInfo = input.Inputs.GetParameterInfo(i);
                    ArgumentNullException ex = new ArgumentNullException(parameterInfo.Name, "Parâmetro de entrada não pode ser Nulo");

                    LogManager.Error("Assembly [ " + ((System.Reflection.MemberInfo)input.MethodBase).ReflectedType.FullName + "." + input.MethodBase.Name + "() ] ", ex.Message.Replace("\r\n", ". "));

                    return input.CreateExceptionMethodReturn(ex);
                }
            }
            return getNext()(input, getNext);
        }

        public int Order
        {
            get;
            set;
        }

        #endregion
    }
}
