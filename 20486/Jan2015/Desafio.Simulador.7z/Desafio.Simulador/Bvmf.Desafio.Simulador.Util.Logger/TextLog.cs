﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Configuration;
using System.Diagnostics;
//using Framework.Excecao;
using System.Globalization;

namespace Desafio.Simulador.Util.Logger
{
    internal static class TextLog
    {
        private static StreamWriter _streamWriter;
        private static int _contadorTabulacao = 0;
        private static Dictionary<int, Stopwatch> _cronometros = new Dictionary<int, Stopwatch>();
        private static bool _logHabilitado;

        static TextLog()
        {
            if (ConfigurationManager.AppSettings["TextLogArquivo"].ToString() != string.Empty)
            {
                _streamWriter = System.IO.File.AppendText(ConfigurationManager.AppSettings["TextLogArquivo"]);
                _streamWriter.AutoFlush = true;
                _logHabilitado = true;
            }
        }

        public static void Trace(string mensagem)
        {
            if (_logHabilitado)
            {
                EscreveLog("- " + mensagem);
            }
        }

        public static void TraceIn(string mensagem)
        {
            if (_logHabilitado)
            {
                TraceIn(mensagem, string.Empty);
            }
        }

        public static void TraceIn(string mensagem, string parametros)
        {
            if (_logHabilitado)
            {
                EscreveLog(mensagem + parametros);
                if (_cronometros.ContainsKey(_contadorTabulacao))
                {
                    _cronometros[_contadorTabulacao].Reset();
                }
                else
                {
                    _cronometros.Add(_contadorTabulacao, new Stopwatch());
                }
                _cronometros[_contadorTabulacao].Start();
                _contadorTabulacao++;
            }
        }

        public static void TraceOut(string mensagem, string retorno)
        {
            if (_logHabilitado)
            {
                _contadorTabulacao--;
                _cronometros[_contadorTabulacao].Stop();
                string _contagem = "(" + _cronometros[_contadorTabulacao].ElapsedMilliseconds.ToString() + " ms / " + _cronometros[_contadorTabulacao].ElapsedTicks.ToString() + " ticks)";
                _cronometros.Remove(_contadorTabulacao);
                EscreveLog(mensagem + retorno + _contagem);
            }
        }

        public static void TraceOut(string mensagem)
        {
            if (_logHabilitado)
            {
                TraceOut(mensagem, string.Empty);
            }
        }

        public static void Error(string mensagem)
        {
            if (_logHabilitado)
            {
                EscreveLog("[Erro] " + mensagem);
            }
        }

        public static void Error(string mensagem, Exception ex)
        {
            if (_logHabilitado)
            {

                StringBuilder _mensagemMontada = new StringBuilder();

                _mensagemMontada.Append(" - [Erro] - ");
                _mensagemMontada.Append(mensagem);

                /*if (ex is FxBmfApplicationException)
                {
                    _mensagemMontada.Append("- [BusinessMessage= ");
                    _mensagemMontada.Append(((FxBmfApplicationException)ex).BusinessMessage);
                    _mensagemMontada.Append("] -");
                }*/
                _mensagemMontada.Append(System.Environment.NewLine);
                _mensagemMontada.Append("\t");
                _mensagemMontada.Append(ex.StackTrace);


                //captura inners
                Exception innerEx = ex;
                string _inners = string.Empty;

                while (innerEx != null)
                {
                    _mensagemMontada.Append("\t");
                    _mensagemMontada.Append(innerEx.Message);
                    _mensagemMontada.Append(System.Environment.NewLine);
                    innerEx = innerEx.InnerException;
                }

                _mensagemMontada.Append(new string('-', 50));

                EscreveLog(_mensagemMontada.ToString());
            }
        }

        public static void WriteErrorWeb(Exception ex)
        {
            try
            {
                string path = "~/LogErro/" + DateTime.Today.ToString("dd-MM-yy") + ".txt";
                if (!File.Exists(System.Web.HttpContext.Current.Server.MapPath(path)))
                {
                    File.Create(System.Web.HttpContext.Current.Server.MapPath(path)).Close();
                }
                using (StreamWriter w = File.AppendText(System.Web.HttpContext.Current.Server.MapPath(path)))
                {
                    StringBuilder str = new StringBuilder();

                    str.AppendLine(" Data/Hora        : " + DateTime.Now.ToString(CultureInfo.InvariantCulture));
                    str.AppendLine(" Erro em          : " + System.Web.HttpContext.Current.Request.Url.ToString());

                    //if (ex is FxBmfApplicationException)
                    //    str.AppendLine(" Mensagem de erro : " + ((FxBmfApplicationException)ex).BusinessMessage);
                    //else
                        str.AppendLine(" Mensagem de erro : " + ex.Message);

                    str.AppendLine(" TARGETSITE       : " + ex.TargetSite);
                    str.AppendLine(" STACKTRACE       : " + ex.TargetSite);
                    str.AppendLine("--------------------------------------------------------------------------------");

                    w.WriteLine(str.ToString());
                    w.Flush();
                    w.Close();
                }
            }
            catch (Exception exInterna)
            {
                WriteErrorWeb(exInterna);
            }
        }

        private static void EscreveLog(string mensagem)
        {
            _streamWriter.WriteLine(DateTime.Now.ToString("yyyyMMddhhmmss") + " T[" + System.Threading.Thread.CurrentThread.ManagedThreadId.ToString("00000") + "] " + new string(' ', _contadorTabulacao) + mensagem);
        }
    }

}