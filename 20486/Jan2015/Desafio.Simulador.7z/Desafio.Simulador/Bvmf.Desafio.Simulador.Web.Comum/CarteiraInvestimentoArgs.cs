﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Desafio.Simulador.Web.Comum
{
    public class CarteiraInvestimentoArgs : EventArgs
    {
        public CarteiraInvestimentoArgs()
        {
            this.CarteiraInvestimento = new List<CarteiraInvestimentoViewHelper>();
            this.OutrosInvestimentos = 0;
        }

        public List<CarteiraInvestimentoViewHelper> CarteiraInvestimento { get; set; }
        public decimal OutrosInvestimentos { get; set; }
    }
}
