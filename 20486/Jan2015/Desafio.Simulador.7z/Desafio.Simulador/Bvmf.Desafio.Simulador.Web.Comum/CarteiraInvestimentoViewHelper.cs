﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Desafio.Simulador.Web.Comum
{
    public sealed class CarteiraInvestimentoViewHelper
    {
        public int CodigoPapel { get; set; }
        public int Quantidade { get; set; }
        public decimal Preco { get; set; }
    }
}
