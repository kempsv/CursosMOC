﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Web.Security;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bsl.ServiceLocator;
using Desafio.Simulador.Bsl.Configurador.Interfaces;
using Desafio.Simulador.Bsl.Competidor.Interfaces;
using Desafio.Simulador.Bsl.Simulacao.Agenda.Interfaces;
using System.Globalization;
using Desafio.Simulador.Bsl.Simulacao.Investimento.Interfaces;

namespace Desafio.Simulador.Web.Comum
{
    internal static class RodadaCenarioDTOExtension
    {
        private static IConfiguradorCenarioSimulacaoService _service;
        private static IConfiguradorFatosService _service2;
        private static IConfiguradorGraficosService _service3;

        internal static void ListarInformacoesCenariosSimulacao(this List<RodadaCenarioDTO> rodadasCenario) 
        {
            if (_service==null)
            _service = ServiceLocator.GetInstance<IConfiguradorCenarioSimulacaoService>();

            if (_service2 == null)
                _service2 = ServiceLocator.GetInstance<IConfiguradorFatosService>();

            if (_service3 == null)
                _service3 = ServiceLocator.GetInstance<IConfiguradorGraficosService>();

            rodadasCenario.ForEach(delegate(RodadaCenarioDTO rodada)
            {
                //Obtêm dados completo do cenário
                rodada.CenarioSimulacao = _service.ObterConfiguracao(rodada.CenarioSimulacao.Codigo);
                //Obtêm dados completo dos Fatos Relevantes
                rodada.FatosRelevante = _service2.ListarFatosCenarios(rodada.CenarioSimulacao.Codigo);
                //Obtêm dados completo dos Gráficos
                rodada.GraficosCenario = _service3.ListarGraficosCenarios(rodada.CenarioSimulacao.Codigo);
            });
        }
    }
    public class SimuladorBaseMasterPage : System.Web.UI.MasterPage
    {
        /// <summary>
        /// Session para armenar o erro da aplicação e mostra na página ErroAplicacao.aspx
        /// </summary>
        public string ErrorDescriptionApplication
        {
            get
            {
                if (null == Session["ErrorDescriptionApplication"])
                    Session.Add("ErrorDescriptionApplication", string.Empty);


                return (string)Session["ErrorDescriptionApplication"];
            }
            set
            {
                Session["ErrorDescriptionApplication"] = value;
            }
        }
        /// <summary>
        /// Session para contralar a contingência de Rodadas
        /// </summary>
        public int ContadorContingencia
        {
            get
            {
                if (null == Session["ContadorContingencia"])
                    Session.Add("ContadorContingencia", (int)-1);


                return (int)Session["ContadorContingencia"];
            }
            set
            {
                Session["ContadorContingencia"] = value;
            }
        }

        /// <summary>
        /// Session para contralar as rodadas de simulação
        /// </summary>
        public short CurrentView
        {
            get
            {
                if (null == Session["CurrentView"])
                    Session.Add("CurrentView", (short)-1);


                return (short)Session["CurrentView"];
            }
            set
            {
                Session["CurrentView"] = value;
            }
        }

        /// <summary>
        /// Session para controlar e identificar o grupo escolar logado no Simulador
        /// </summary>
        public GrupoEscolarDTO GrupoEscolar
        {
            get { return (GrupoEscolarDTO)Session["GrupoEscolarDTO"]; }
            set { Session["GrupoEscolarDTO"] = value; }
        }

        /// <summary>
        /// Session que armazena a lista de condições do termo de aceite da simulação
        /// </summary>
        public List<CondicoesTermoAceiteDTO> CondicoesTermoAceiteSimulacao
        {
            get { return (List<CondicoesTermoAceiteDTO>)(Session["CondicoesTermoAceiteSimulacao"]); }
            set { Session["CondicoesTermoAceiteSimulacao"] = value; }
        }

        /// <summary>
        /// Session para controlar a conta de usuário logado no simulador
        /// </summary>
        public UserAccount UserAccount
        {
            get
            {
                if (null == Session["UserAccount"])
                    Session.Add("UserAccount", null);

                return (UserAccount)Session["UserAccount"];
            }
            set { Session["UserAccount"] = value; }
        }

        protected void FinalizarSessoes()
        {
            this.UserAccount = null;
            this.GrupoEscolar = null;
            this.ContadorContingencia = int.MinValue;
            this.CondicoesTermoAceiteSimulacao = null;
            this.CurrentView = -1;
            this.ErrorDescriptionApplication = string.Empty;
        }

        protected GrupoEscolarDTO ObterGrupoEscolarSimulacao(LMSUserAccount userAccount)
        {
            //TODO: Identificar de onde vem o código do grupo escolar do aluno logado
            ICompetidorSimuladorService _competidorSimuladorService = ServiceLocator.GetInstance<ICompetidorSimuladorService>();
            //
            //Obtêm grupo grupos do usuário logado.
            //
            var _grupoEscolarSimulador = _competidorSimuladorService.ObterGrupoEscolarSimulacao(userAccount.CodigoOrigem);

            if (_grupoEscolarSimulador != null)
                return _grupoEscolarSimulador;
            else
            {
                StringBuilder _sb = new StringBuilder();
                _sb.AppendLine("Código LMS Grupo Escolar= " + userAccount.CodigoOrigem);
                _sb.AppendLine("Erro: Grupo Escolar LMS não existente no Simulador");
                throw new ApplicationWcfServicesException(_sb.ToString());
            }
        }

        protected void VincularAgendaSimulacaoGrupoEscolar(GrupoEscolarDTO grupoEscolar)
        {
            //Busca dados completos da simulação agendada
            ISimuladorAgendamentoService _agendamentoSimuladorService = ServiceLocator.GetInstance<ISimuladorAgendamentoService>();
            DateTime _dataAtual = DateTime.Parse(DateTime.Now.ToString(), new CultureInfo("pt-BR", false)); //DateTime.Now;// DateTime.Parse("01/09/2009 15:32:00");
            var _agenda = _agendamentoSimuladorService.ObterAgendaSimulacaoGrupoEscolar(_dataAtual, grupoEscolar.Codigo);

            if (_agenda != null)
            {
                grupoEscolar.AgendaSimulacao = new List<AgendaSimulacaoDTO>();
                grupoEscolar.AgendaSimulacao.Add(_agenda);

                if (grupoEscolar.AgendaSimulacao[0].AgendaSimulacaoRodadas != null)
                {
                    //
                    //Seta o objeto Grupo Escolar vinculando às Rodadas de Simulação
                    //
                    grupoEscolar.AgendaSimulacao[0].AgendaSimulacaoRodadas.ForEach(delegate(AgendaSimulacaoRodadasDTO agendaDTO)
                    {
                        agendaDTO.RodadaCenario.ListarInformacoesCenariosSimulacao();
                        
                        agendaDTO.Rodada.CarteiraInvestimento = this.ObterCarteiraInvestimentoRodada(agendaDTO.Rodada);
                        agendaDTO.Rodada.GrupoEscolar = new GrupoEscolarDTO()
                        {
                            Codigo = grupoEscolar.Codigo,
                            ValorInvestimentoInicial = grupoEscolar.ValorInvestimentoInicial
                        };
                    });
                }
                else
                {
                    StringBuilder _sb = new StringBuilder();
                    _sb.AppendLine("Código Grupo Escolar= " + grupoEscolar.Codigo);
                    _sb.AppendLine("Código LMS Grupo Escolar= " + grupoEscolar.CodigoOriginalLMS);
                    _sb.AppendLine("Erro: Não existe rodadas de simulação vinculadas à data e hora de agendamento: " + _agenda.DataHoraAgendamento.ToString());
                    throw new ApplicationWcfServicesException(_sb.ToString());
                }
            }
            else
            {
                StringBuilder _sb = new StringBuilder();
                _sb.AppendLine("Código Grupo Escolar= " + grupoEscolar.Codigo);
                _sb.AppendLine("Código LMS Grupo Escolar= " + grupoEscolar.CodigoOriginalLMS);
                _sb.AppendLine("Erro: Não existe agenda de simulação para data e hora: " + _dataAtual.ToString());
                throw new ApplicationWcfServicesException(_sb.ToString());
            }
        }

        public void InicializarSessoes(LMSUserAccount userAccount)
        {
            //
            //Cria Session com o UserAccount
            //
            this.UserAccount = userAccount;

            //
            //Cria Session Agenda de Simulação do GrupoEscolar Logado
            //
            this.GrupoEscolar = this.ObterGrupoEscolarSimulacao(userAccount);

            //
            //Faz vínculo, caso exista, da agenda de simulação do grupo escolar para a data e hora atual do sistema
            //
            this.VincularAgendaSimulacaoGrupoEscolar(this.GrupoEscolar);

            //Regras abaixo somente se o usário logado for competidor
            if (userAccount.AccountType == TipoAccountType.Competidor)
            {

                //Obtêm todas as Rodadas Concluídas
                var _rodadasConcluidas = this.GrupoEscolar.AgendaSimulacao[0].AgendaSimulacaoRodadas.Where(ag => ag.IndicadorSimulacaoConcluida == true).ToList<AgendaSimulacaoRodadasDTO>();
                //Se não existir
                if (_rodadasConcluidas.Count == 0)
                {
                    this.CurrentView = -1;
                    this.ContadorContingencia = -1;
                }
                else
                {
                    var _rodadaNaoConcluida = this.GrupoEscolar.AgendaSimulacao[0].AgendaSimulacaoRodadas.Where(ag => ag.IndicadorSimulacaoConcluida == false).FirstOrDefault<AgendaSimulacaoRodadasDTO>();
                    ///Se não existir
                    if (_rodadaNaoConcluida == null)
                    {
                        this.ErrorDescriptionApplication = "Simulação de investimento já concluída!";
                        throw new SimulacaoInvestimentoConcluidaException("Simulação de investimento já concluída!");
                    }
                    else
                    {
                        //Obtêm o Max do Identificador de Rodadas e soma 1 para identificar a rodada atual da simulação
                        this.CurrentView = (short)(_rodadasConcluidas.Max(mx => mx.Rodada.IdentificadorRodada) + 1);

                        //Adicionar na Session a somatória do contador de contingência
                        this.ContadorContingencia = this.GrupoEscolar.AgendaSimulacao[0].AgendaSimulacaoRodadas.Sum(sm => sm.ContadorRodadaContingencia);
                    }
                }

                //
                //Atualiza o contado de rodadas de simulação
                //
                this.IncrementarContadorContingencia();


                //
                //Cria a Sessão com as condições do termo de aceite da Simulação
                //
                if (this.CondicoesTermoAceiteSimulacao == null)
                {
                    var _servicoTermoAceite = ServiceLocator.GetInstance<IConfiguradorTermoAceiteService>();
                    this.CondicoesTermoAceiteSimulacao = _servicoTermoAceite.ListarCondicoesTermoWEB();
                }
            }
        }

        public CarteiraInvestimentoDTO ObterCarteiraInvestimentoRodada(RodadaSimulacaoDTO rodadaSimulacao)
        {
            //Atualiza os dados salvos da carteira e preco dos papeis para proxima rodada
            ISimuladorInvestimentoService _investimentoService = ServiceLocator.GetInstance<ISimuladorInvestimentoService>();
            return _investimentoService.ObterCarteiraInvestimentoRodadaAtualizada(rodadaSimulacao);
        }

        private void IncrementarContadorContingencia()
        {
            AgendaSimulacaoRodadasDTO agendaRodadaSimulacao = this.SelecionarRodadaSimulacao(this.GrupoEscolar.AgendaSimulacao[0], this.CurrentView, false);

            ISimuladorAgendamentoService _agendamentoSimuladorService = ServiceLocator.GetInstance<ISimuladorAgendamentoService>();
            this.ContadorContingencia += 1; 
            agendaRodadaSimulacao.ContadorRodadaContingencia += 1;
            _agendamentoSimuladorService.IncrementarContadorContingencia(agendaRodadaSimulacao);         
        }

        public AgendaSimulacaoRodadasDTO SelecionarRodadaSimulacao(AgendaSimulacaoDTO agendaSimulacao, short numeroRodada, bool indicadorSimulacaoConcluida)
        {
            AgendaSimulacaoRodadasDTO _returnEntity = null;

            _returnEntity = (from r in agendaSimulacao.AgendaSimulacaoRodadas
                             where
                             r.IndicadorSimulacaoConcluida == indicadorSimulacaoConcluida
                             && r.Rodada.IdentificadorRodada == (numeroRodada <= 0 ? 1 : numeroRodada)
                             select r).FirstOrDefault<AgendaSimulacaoRodadasDTO>();

            return _returnEntity;
        }
        
    }
}
