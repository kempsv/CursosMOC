﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using Desafio.Simulador.Bsl.Comum.Dto;
using Desafio.Simulador.Bsl.Competidor.Interfaces;
using Desafio.Simulador.Bsl.ServiceLocator;
using Desafio.Simulador.Web.Security;
using Desafio.Simulador.Bsl.Simulacao.Agenda.Interfaces;

namespace Desafio.Simulador.Web.Comum
{
    public class SimuladorBasePage: Page
    {
        public void FinalizarRodadaSimulacao(AgendaSimulacaoRodadasDTO agendaRodadaSimulacao)
        {
            //Chama o serviço para finalizar a rodada
            ISimuladorAgendamentoService _agendamentoService = ServiceLocator.GetInstance<ISimuladorAgendamentoService>();
            agendaRodadaSimulacao.IndicadorSimulacaoConcluida = true;
            _agendamentoService.FinalizarRodada(agendaRodadaSimulacao); // Finaliza rodada
        }

        public void DesclassificarGrupoEscolar(GrupoEscolarDTO grupoEscolar) 
        {
            ICompetidorSimuladorService _competidorSimuladorService = ServiceLocator.GetInstance<ICompetidorSimuladorService>();
            _competidorSimuladorService.DesclassificarGrupoEscolar(grupoEscolar);
        }
    }
}
