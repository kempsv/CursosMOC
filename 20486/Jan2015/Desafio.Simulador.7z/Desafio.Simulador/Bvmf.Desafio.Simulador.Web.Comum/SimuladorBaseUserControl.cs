﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using Desafio.Simulador.Bsl.Comum.Dto;
using System.Web.UI.WebControls;
//using Framework.Globalization;
using Desafio.Simulador.Bsl.Configurador.Interfaces;
using Desafio.Simulador.Bsl.ServiceLocator;
using Desafio.Simulador.Bsl.Simulacao.Investimento.Interfaces;


namespace Desafio.Simulador.Web.Comum
{
    public class SimuladorBaseUserControl : UserControl
    {
        protected bool IndicadorRodadaEnviada
        {
            get { return Convert.ToBoolean(ViewState["RodadaEnviada"]); }
            set { ViewState["RodadaEnviada"] = value; }
        }

        protected bool IndicadorTempoRodadaTerminado
        {
            get { return Convert.ToBoolean(ViewState["TempoRodadaTerminado"]); }
            set { ViewState["TempoRodadaTerminado"] = value; }
        }

        protected decimal ValorSaldoAtual
        {
            get { return Convert.ToDecimal(Session["ValorSaldoAtual"]); }
            set { Session["ValorSaldoAtual"] = value; }
        }

        protected int QuantidadeRodadas
        {
            get { return Convert.ToInt32(Session["QuantidadeRodadas"]); }
            set { Session["QuantidadeRodadas"] = value; }
        }

        protected bool IndicadorTermoAceite
        {
            get
            {
                if (null == ViewState["IndicadorTermoAceite"])
                    ViewState.Add("IndicadorTermoAceite", false);

                return (bool)ViewState["IndicadorTermoAceite"];
            }
            set { ViewState["IndicadorTermoAceite"] = value; }
        }

        protected AgendaSimulacaoDTO AgendaSimulacao
        {
            get { return (AgendaSimulacaoDTO)Session["AgendaSimulacao"]; }
            set { Session["AgendaSimulacao"] = value; }
        }

        protected AgendaSimulacaoRodadasDTO RodadaSimulacao
        {
            get { return (AgendaSimulacaoRodadasDTO)Session["RodadaSimulacao"]; }
            set { Session["RodadaSimulacao"] = value; }
        }

        protected bool IsValidContadorContingnecia()
        {
            return (((SimuladorBaseMasterPage)Page.Master).ContadorContingencia <= this.AgendaSimulacao.ParametrizacaoAgenda.MaximaTentativaContingencia);
        }

        protected bool IsValidAgendaSimulacao()
        {
            if (((SimuladorBaseMasterPage)Page.Master).GrupoEscolar.AgendaSimulacao != null)
            {
                this.AgendaSimulacao = ((SimuladorBaseMasterPage)Page.Master).GrupoEscolar.AgendaSimulacao[0];
                this.SetarDescricaoSemana(this.AgendaSimulacao.TipoSemanaSimulacao);
                this.QuantidadeRodadas = this.AgendaSimulacao.ParametrizacaoAgenda.QuantidadeRodadas;

                if (this.AgendaSimulacao.TermoAceiteSimulacao != null)
                    this.IndicadorTermoAceite = this.AgendaSimulacao.TermoAceiteSimulacao.IndicadorTermoAceito;

                return true;
            }
            else
                return false;
        }

        protected void SetarDescricaoSemana(TipoSemanaSimulacaoDTO tipoSemana)
        {
            switch (tipoSemana)
            {
                case TipoSemanaSimulacaoDTO.PrimeiraSemana:
                    ((Image)Page.Master.FindControl("imgSimulacaoAtual")).Visible = true;
                    ((Label)Page.Master.FindControl("lblSimulacao")).Visible = true;
                    ((Label)Page.Master.FindControl("lblSimulacao")).Text = "";//GlobalizationManager.GetText("MSG0005");
                    break;

                case TipoSemanaSimulacaoDTO.SegundaSemana:
                    ((Image)Page.Master.FindControl("imgSimulacaoAtual")).Visible = true;
                    ((Label)Page.Master.FindControl("lblSimulacao")).Visible = true;
                    ((Label)Page.Master.FindControl("lblSimulacao")).Text = "";//GlobalizationManager.GetText("MSG0006");
                    break;

                case TipoSemanaSimulacaoDTO.TerceiraSemana:
                    ((Image)Page.Master.FindControl("imgSimulacaoAtual")).Visible = true;
                    ((Label)Page.Master.FindControl("lblSimulacao")).Visible = true;
                    ((Label)Page.Master.FindControl("lblSimulacao")).Text = "";//GlobalizationManager.GetText("MSG0007");
                    break;

                case TipoSemanaSimulacaoDTO.QuartaSemana:
                    ((Image)Page.Master.FindControl("imgSimulacaoAtual")).Visible = true;
                    ((Label)Page.Master.FindControl("lblSimulacao")).Visible = true;
                    ((Label)Page.Master.FindControl("lblSimulacao")).Text = "";//GlobalizationManager.GetText("MSG0008");
                    break;
            }
        }

        protected RodadaCenarioDTO SelecionarCenarioRodada(AgendaSimulacaoRodadasDTO agendaSimulacaoRodadas, bool indicadorCenarioContingencia)
        {
            return agendaSimulacaoRodadas.RodadaCenario
                                        .Where(cenario => cenario.IndicadorCenarioContingencia == indicadorCenarioContingencia)
                                        .FirstOrDefault<RodadaCenarioDTO>();
        }

        protected AgendaSimulacaoRodadasDTO SelecionarRodadaSimulacao(AgendaSimulacaoDTO agendaSimulacao, short numeroRodada) 
        {
            return this.SelecionarRodadaSimulacao(agendaSimulacao, numeroRodada, false);
        }

        protected AgendaSimulacaoRodadasDTO SelecionarRodadaSimulacao(AgendaSimulacaoDTO agendaSimulacao, short numeroRodada, bool indicadorSimulacaoConcluida)
        {
            return ((SimuladorBaseMasterPage)Page.Master).SelecionarRodadaSimulacao(agendaSimulacao, numeroRodada, indicadorSimulacaoConcluida);
        }

        protected void AceitarTermoSimulacao() 
        {
            this.IndicadorTermoAceite = true;
            this.AgendaSimulacao.TermoAceiteSimulacao.IndicadorTermoAceito = this.IndicadorTermoAceite;
            IConfiguradorTermoAceiteService _termoAceite = ServiceLocator.GetInstance<IConfiguradorTermoAceiteService>();
            _termoAceite.AceitarTermoAceite(this.AgendaSimulacao.TermoAceiteSimulacao);

        }

        protected void EnviarCarteiraInvestimento(CarteiraInvestimentoArgs carteiraInvestimentoArgs) 
        {
            CarteiraInvestimentoDTO _carteira = new CarteiraInvestimentoDTO();
            _carteira.AtivosCarteiraPapeis = new List<AtivosCarteiraPapeisDTO>();

            foreach (CarteiraInvestimentoViewHelper _carteiraDados in carteiraInvestimentoArgs.CarteiraInvestimento)
            {
                _carteira.AtivosCarteiraPapeis.Add(new AtivosCarteiraPapeisDTO()
                {
                    PapelCarteira = new PapelCarteiraDTO()
                    {
                        Codigo = _carteiraDados.CodigoPapel
                    },
                    Quantidade = _carteiraDados.Quantidade,
                    ValorPrecoCompra = _carteiraDados.Preco
                });
            }

            //	UC0011 - RN 9 >> Penalidade por nao enviar durante o tempo da rodada de simulacao
            //	O valor de -5% estará sendo enviado pelo site no campo ValorRentabilidadePeriodo
            if (this.IndicadorTempoRodadaTerminado && !this.IndicadorRodadaEnviada)
                _carteira.ValorRentabilidadePeriodo = this.RodadaSimulacao.Rodada.ParametrizacaoRodada.ValorPercentualPenalidadeRodada * -1;


            _carteira.AtivosCarteiraOutros = null;
            if (((SimuladorBaseMasterPage)Page.Master).CurrentView > 1)
            {
                var _agendaSimulacaoRodadasAnterior = this.SelecionarRodadaSimulacao(this.AgendaSimulacao, (short)(((SimuladorBaseMasterPage)Page.Master).CurrentView - 1), true);
                _carteira.RodadaSimulacaoAnterior = _agendaSimulacaoRodadasAnterior.Rodada;
                _carteira.RodadaSimulacaoAnterior.CenarioSimulacao = new CenarioSimulacaoDTO() { Codigo = this.SelecionarCenarioRodada(_agendaSimulacaoRodadasAnterior, false).CenarioSimulacao.Codigo };
                _carteira.RodadaSimulacaoAnterior.GrupoEscolar = _carteira.RodadaSimulacaoAnterior.GrupoEscolar;
            }
            else
            {
                _carteira.RodadaSimulacaoAnterior = null;
            }

            _carteira.RodadaSimulacao = this.RodadaSimulacao.Rodada;
            _carteira.RodadaSimulacao.CenarioSimulacao = new CenarioSimulacaoDTO() { Codigo = this.SelecionarCenarioRodada(this.RodadaSimulacao, false).CenarioSimulacao.Codigo };
            _carteira.RodadaSimulacao.GrupoEscolar = this.RodadaSimulacao.Rodada.GrupoEscolar;


            _carteira.AtivosCarteiraOutros = new List<AtivosCarteiraOutrosDTO>();
            _carteira.AtivosCarteiraOutros.Add(new AtivosCarteiraOutrosDTO()
            {
                Codigo = 0,
                ValorInvestido = carteiraInvestimentoArgs.OutrosInvestimentos
            });
            this.IndicadorRodadaEnviada = true;

            ISimuladorInvestimentoService _investimentoService = ServiceLocator.GetInstance<ISimuladorInvestimentoService>();
            _investimentoService.SalvarCarteiraInvestimento(_carteira);


        }
    }
}
