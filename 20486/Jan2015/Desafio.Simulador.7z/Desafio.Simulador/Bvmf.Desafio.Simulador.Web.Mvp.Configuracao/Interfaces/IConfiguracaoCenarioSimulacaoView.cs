﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Web.Mvp.Interfaces;

namespace Desafio.Simulador.Web.Mvp.Configuracao.Interfaces
{
    public interface IConfiguracaoCenarioSimulacaoView<T>:IView
    {
        List<T> DataBind { get; set; }
    }
}
