﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Web.Mvp.Interfaces;

namespace Desafio.Simulador.Web.Mvp.Configuracao.Interfaces
{
    public interface IConfiguracaoMacroCenarioView<T>: IView
    {
        List<T> DataBind { get; set; }
    }
}
