﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Web.Mvp.Interfaces;

namespace Desafio.Simulador.Web.Mvp.Configuracao.Interfaces
{
    public interface IConfiguracaoPapeisView<T>: IView
    {
        int CodigoPapel { get; set; }
        string NomePapel { get; set; }
        string DescricaoPapel { get; set; }
  
        List<T> DataBind { get; set; }
    }
}
