﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Web.Mvp.Presenters;
using Desafio.Simulador.Web.Mvp.Configuracao.Interfaces;
using Desafio.Simulador.Bsl.Configurador.Interfaces;
using Desafio.Simulador.Web.Mvp.Interfaces;
using Desafio.Simulador.Bsl.Comum.Dto;


namespace Desafio.Simulador.Web.Mvp.Configuracao.Presenters
{
    public class ConfiguracaoCenarioSimulacaoPresenter : Presenter
    {
        private readonly IConfiguracaoCenarioSimulacaoView<CenarioSimulacaoDTO> _cadastroView;
        //TODO: Alterar para a interface WCF de Cenários
        private readonly IConfiguradorCenarioSimulacaoService _service;

        public ConfiguracaoCenarioSimulacaoPresenter(IConfiguracaoCenarioSimulacaoView<CenarioSimulacaoDTO> view)
            : this(view, null)
        {

        }

        public ConfiguracaoCenarioSimulacaoPresenter(IConfiguracaoCenarioSimulacaoView<CenarioSimulacaoDTO> view, ISessionProvider session)
            : base(view, session)
        {
            _cadastroView = base.GetView<IConfiguracaoCenarioSimulacaoView<CenarioSimulacaoDTO>>();
            _cadastroView.OnSalvar += new EventHandler(_cadastroView_OnSalvar);
            _cadastroView.OnAtualizar += new EventHandler(_cadastroView_OnAtualizar);
            _cadastroView.OnExcluir += new EventHandler(_cadastroView_OnExcluir);
            _cadastroView.OnLoadView += new EmptyEventHandlerDelegate(_cadastroView_OnLoadView);
            _cadastroView.OnObterEntidadeView += new EmptyEventHandlerDelegate(_cadastroView_OnObterEntidadeView);
            //Obtêm instância do Serviço WCF
            _service = Presenter.GetService<IConfiguradorCenarioSimulacaoService>();
        }

        void _cadastroView_OnObterEntidadeView()
        {
            throw new NotImplementedException();
        }

        void _cadastroView_OnLoadView()
        {
            throw new NotImplementedException();
        }

        void _cadastroView_OnExcluir(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        void _cadastroView_OnAtualizar(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        void _cadastroView_OnSalvar(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }
    }
}
