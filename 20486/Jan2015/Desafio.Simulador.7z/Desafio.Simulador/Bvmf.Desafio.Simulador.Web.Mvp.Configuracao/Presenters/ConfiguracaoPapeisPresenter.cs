﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//using Framework.Excecao;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bsl.Configurador.Interfaces;
using Desafio.Simulador.Web.Mvp.Presenters;
using Desafio.Simulador.Web.Mvp.Configuracao.Interfaces;
using Desafio.Simulador.Web.Mvp.Interfaces;
using Desafio.Simulador.Bsl.Comum.Dto;


namespace Desafio.Simulador.Web.Mvp.Configuracao.Presenters
{
    public class ConfiguracaoPapeisPresenter : Presenter
    {
        private readonly IConfiguracaoPapeisView<PapelCarteiraDTO> _cadastroView;
        private readonly IConfiguradorPapelService _service;

        public ConfiguracaoPapeisPresenter(IConfiguracaoPapeisView<PapelCarteiraDTO> view)
            : this(view, null)
        {}

        public ConfiguracaoPapeisPresenter(IConfiguracaoPapeisView<PapelCarteiraDTO> view, ISessionProvider session)
            : base(view, session)
        {
            _cadastroView = base.GetView<IConfiguracaoPapeisView<PapelCarteiraDTO>>();
            _cadastroView.OnSalvar +=new EventHandler(_cadastroView_OnSalvar);
            _cadastroView.OnAtualizar += new EventHandler(_cadastroView_OnAtualizar);
            _cadastroView.OnExcluir += new EventHandler(_cadastroView_OnExcluir);
            _cadastroView.OnLoadView += new EmptyEventHandlerDelegate(_cadastroView_OnLoadView);
            _cadastroView.OnObterEntidadeView += new EmptyEventHandlerDelegate(_cadastroView_OnObterEntidadeView);
            //Obtêm instância do Serviço WCF
            _service = Presenter.GetService<IConfiguradorPapelService>();

        }

        void _cadastroView_OnObterEntidadeView()
        {
            try
            {
                _service.ObterConfiguracao(_cadastroView.CodigoPapel);
            }
            catch (FxApplicationException fEx)
            {
                GerenciadorExcecao.TratarExcecao(fEx);
            }
        }

        void _cadastroView_OnExcluir(object sender, EventArgs e)
        {
            try
            {
                _service.ExcluirConfiguracao(new PapelCarteiraDTO() { Codigo = _cadastroView.CodigoPapel });
            }
            catch (FxApplicationException fEx)
            {
                GerenciadorExcecao.TratarExcecao(fEx);
            }
        }

        void _cadastroView_OnAtualizar(object sender, EventArgs e)
        {
            try
            {
                _service.AtualizarConfiguracao(new PapelCarteiraDTO()
                {
                    Codigo = _cadastroView.CodigoPapel, 
                    NomeAbreviado = _cadastroView.NomePapel, 
                    NomeCompleto = _cadastroView.DescricaoPapel });
            }
            catch (FxApplicationException fEx)
            {
                GerenciadorExcecao.TratarExcecao(fEx);
            }
        }

        void _cadastroView_OnLoadView()
        {
            try
            {
                _cadastroView.DataBind = _service.ListarTodasConfiguracoes();
            }
            catch (FxApplicationException fEx)
            {
                GerenciadorExcecao.TratarExcecao(fEx);
            }
        }

        void _cadastroView_OnSalvar(object sender, EventArgs e)
        {
            try
            {
                // Example of managing state without referencing System.Web
                //if(this.Session != null && Session["userName"] == null)
                if (_cadastroView.NomePapel != string.Empty && _cadastroView.DescricaoPapel !=string.Empty)
                {
                    _service.AdicionarConfiguracao(new PapelCarteiraDTO()
                    {
                        NomeAbreviado = _cadastroView.NomePapel, 
                        NomeCompleto = _cadastroView.DescricaoPapel });
                }
                else
                    throw new ApplicationWcfServicesException("Nome do Papel não informado");
            }
            catch (FxApplicationException fEx)
            {
                GerenciadorExcecao.TratarExcecao(fEx);
            }
        }
   
    }
}
