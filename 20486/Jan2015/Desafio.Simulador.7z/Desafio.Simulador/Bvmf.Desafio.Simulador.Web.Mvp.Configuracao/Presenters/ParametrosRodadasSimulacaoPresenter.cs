﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Web.Mvp.Presenters;
using Desafio.Simulador.Web.Mvp.Configuracao.Interfaces;
using Desafio.Simulador.Bsl.Configurador.Interfaces;
using Desafio.Simulador.Web.Mvp.Interfaces;
using Desafio.Simulador.Bsl.Comum.Dto;


namespace Desafio.Simulador.Web.Mvp.Configuracao.Presenters
{
    public class ParametrosRodadasSimulacaoPresenter : Presenter
    {
        private readonly IParametrosRodadasSimulacaoView<ParametrizacaoRodadaDTO> _cadastroView;
        private readonly IConfiguradorParametrosRodadasService _service;

        public ParametrosRodadasSimulacaoPresenter(IParametrosRodadasSimulacaoView<ParametrizacaoRodadaDTO> view)
            : this(view, null)
        { 

        }

        public ParametrosRodadasSimulacaoPresenter(IParametrosRodadasSimulacaoView<ParametrizacaoRodadaDTO> view, ISessionProvider session)
            : base(view, session)
        {
            _cadastroView = base.GetView<IParametrosRodadasSimulacaoView<ParametrizacaoRodadaDTO>>();
            _cadastroView.OnSalvar += new EventHandler(_cadastroView_OnSalvar);
            _cadastroView.OnAtualizar += new EventHandler(_cadastroView_OnAtualizar);
            _cadastroView.OnExcluir += new EventHandler(_cadastroView_OnExcluir);
            _cadastroView.OnLoadView += new EmptyEventHandlerDelegate(_cadastroView_OnLoadView);
            _cadastroView.OnObterEntidadeView += new EmptyEventHandlerDelegate(_cadastroView_OnObterEntidadeView);
            //Obtêm instância do Serviço WCF
            _service = Presenter.GetService<IConfiguradorParametrosRodadasService>();
        }

        void _cadastroView_OnObterEntidadeView()
        {
            throw new NotImplementedException();
        }

        void _cadastroView_OnLoadView()
        {
            throw new NotImplementedException();
        }

        void _cadastroView_OnExcluir(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        void _cadastroView_OnAtualizar(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        void _cadastroView_OnSalvar(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }
    }
}
