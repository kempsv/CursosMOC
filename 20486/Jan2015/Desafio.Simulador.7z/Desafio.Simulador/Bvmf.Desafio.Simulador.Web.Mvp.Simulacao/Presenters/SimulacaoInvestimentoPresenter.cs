﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Web.Mvp.Presenters;
using Desafio.Simulador.Bcl.Core.Domain;
using Desafio.Simulador.Web.Mvp.Simulacao.Interfaces;
using Desafio.Simulador.Web.Mvp.Interfaces;
using Desafio.Simulador.Bsl.Configurador.Interfaces;

namespace Desafio.Simulador.Web.Mvp.Simulacao.Presenters
{
    public class SimulacaoInvestimentoPresenter : Presenter
    {
        private readonly ISimulacaoInvestimentoView<RodadaSimulacao> _simulacaoView;
        private readonly IConfiguradorCenarioSimulacaoService _service;

        public SimulacaoInvestimentoPresenter(ISimulacaoInvestimentoView<RodadaSimulacao> view)
            : this(view, null)
        {

        }

        public SimulacaoInvestimentoPresenter(ISimulacaoInvestimentoView<RodadaSimulacao> view, ISessionProvider session)
            : base(view, session)
        {
            _simulacaoView = base.GetView<ISimulacaoInvestimentoView<RodadaSimulacao>>();
            _simulacaoView.OnSalvar += new EventHandler(_simulacaoView_OnSalvar);
            _simulacaoView.OnAtualizar += new EventHandler(_simulacaoView_OnAtualizar);
            _simulacaoView.OnExcluir += new EventHandler(_simulacaoView_OnExcluir);
            _simulacaoView.OnLoadView += new EmptyEventHandlerDelegate(_simulacaoView_OnLoadView);
            _simulacaoView.OnObterEntidadeView += new EmptyEventHandlerDelegate(_simulacaoView_OnObterEntidadeView);
            ////Obtêm instância do Serviço WCF
            _service = Presenter.GetService<IConfiguradorCenarioSimulacaoService>();
        }

        void _simulacaoView_OnObterEntidadeView()
        {
            throw new NotImplementedException();
        }

        void _simulacaoView_OnLoadView()
        {
            throw new NotImplementedException();
        }

        void _simulacaoView_OnExcluir(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        void _simulacaoView_OnAtualizar(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        void _simulacaoView_OnSalvar(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

    }
}
