﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Desafio.Simulador.Web.Mvp.Interfaces
{
    public interface ICadastroCarteiraView<T> : IView
    {
        string NomeCarteira { get; set; }
        List<T> DataBind { get; set; }
    }
}
