using System;
using System.Collections.Generic;
using System.Text;

namespace Desafio.Simulador.Web.Mvp.Interfaces
{
    // This interface abstracts session state so ASP.NET, WinForms, or any other
    // view-based project can use state management without forcing this project
    // to have a direct reference to System.Web.
    public interface ISessionProvider
    {
        object this[string name] { get;set;}
        object this[int index] { get;set;}
    }
}
