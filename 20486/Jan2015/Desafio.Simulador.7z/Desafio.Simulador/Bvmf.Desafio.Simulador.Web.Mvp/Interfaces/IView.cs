﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Web.Mvp.Presenters;

namespace Desafio.Simulador.Web.Mvp.Interfaces
{
    public interface IView
    {
        //List<object> DataBind { get; set; }
        event EmptyEventHandlerDelegate OnLoadView;
        event EmptyEventHandlerDelegate OnObterEntidadeView;
        event EventHandler OnSalvar;
        event EventHandler OnAtualizar;
        event EventHandler OnExcluir;
    }
}
