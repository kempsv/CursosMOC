using System;

using Desafio.Simulador.Web.Mvp.Interfaces;
using Desafio.Simulador.Web.Mvp;
using Desafio.Simulador.Web.Mvp.Presenters;
using System.Web.UI;
using System.Globalization;

namespace Desafio.Simulador.Web
{
    public class MVPBasePage : Page, IView
    {
        protected CultureInfo CurrentCulture
        {
            get { return (CultureInfo)ViewState["CurrentCulture"]; }
            set { ViewState["CurrentCulture"] = value; }
        }

        protected override void  InitializeCulture()
        {
            
            string idioma = Convert.ToString(this.Request.QueryString["id"]);

            if (idioma != string.Empty)
            {
                if (idioma == "1")
                    this.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture("pt-BR");
                else
                    this.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture("en-US");
            }
            else
                this.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture("pt-BR");

            System.Threading.Thread.CurrentThread.CurrentUICulture = this.CurrentCulture;
            System.Threading.Thread.CurrentThread.CurrentCulture = this.CurrentCulture;

            base.InitializeCulture();
        }

        protected T RegisterView<T>() where T : Presenter
        {
            return PresentationManager.RegisterView<T>(typeof(T), this, new WebSessionProvider());
        }

        protected void SelfRegister(Page page)
        {
            if (page != null && page is IView)
            {
                object[] attributes = page.GetType().GetCustomAttributes(typeof(PresenterTypeAttribute), true);

                if (attributes != null && attributes.Length > 0)
                {
                    foreach (Attribute viewAttribute in attributes)
                    {
                        if (viewAttribute is PresenterTypeAttribute)
                        {
                            PresentationManager.RegisterView((viewAttribute as PresenterTypeAttribute).PresenterType, page as IView, new WebSessionProvider());
                            break;
                        }
                    }
                }
            }
        }

        #region IView Members

        public event EmptyEventHandlerDelegate OnLoadView;
        public event EmptyEventHandlerDelegate OnObterEntidadeView;

        public event EventHandler OnSalvar;
        public event EventHandler OnAtualizar;
        public event EventHandler OnExcluir;

        #endregion

    }
}