using System;
using System.Collections.Generic;
using System.Text;
using Desafio.Simulador.Web.Mvp.Interfaces;
using Desafio.Simulador.Bsl.ServiceLocator;
//using Framework.Excecao;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bsl.Configurador.Interfaces;
using Desafio.Simulador.Bsl.Comum.Dto;


namespace Desafio.Simulador.Web.Mvp.Presenters
{
    public class CadastroCarteiraPresenter : Presenter
    {
        private readonly ICadastroCarteiraView<PapelCarteiraDTO> _cadastroView;
        private readonly IConfiguradorPapelService _service;

        public CadastroCarteiraPresenter(ICadastroCarteiraView<PapelCarteiraDTO> view)
            : this(view, null)
        {}

        public CadastroCarteiraPresenter(ICadastroCarteiraView<PapelCarteiraDTO> view, ISessionProvider session)
            : base(view, session)
        {
            _cadastroView = base.GetView<ICadastroCarteiraView<PapelCarteiraDTO>>();
            _cadastroView.OnSalvar += new EventHandler(_cadastroView_OnSalvar);
            _cadastroView.OnLoadView += new EmptyEventHandlerDelegate(_cadastroView_OnLoadView);

            //Obt�m inst�ncia do Servi�o WCF
            _service = Presenter.GetService<IConfiguradorPapelService>();
        }

        void _cadastroView_OnLoadView()
        {
            try
            {
                _cadastroView.DataBind = _service.ListarTodasConfiguracoes();
            }
            catch (FxApplicationException fEx) 
            {
                GerenciadorExcecao.TratarExcecao(fEx);
            }
        }

        void _cadastroView_OnSalvar(object sender, EventArgs e)
        {
            try
            {
                // Example of managing state without referencing System.Web
                //if(this.Session != null && Session["userName"] == null)
                if (_cadastroView.NomeCarteira != string.Empty)
                {
                    //_service.AdicionarNovaCarteira(new TOCarteira() { NomeCarteira = _cadastroView.NomeCarteira });
                }
                else
                    throw new ApplicationWcfServicesException("Nome da Carteira n�o informado");
            }
            catch (FxApplicationException fEx) 
            {
                GerenciadorExcecao.TratarExcecao(fEx);
            }
        }
    }
}
