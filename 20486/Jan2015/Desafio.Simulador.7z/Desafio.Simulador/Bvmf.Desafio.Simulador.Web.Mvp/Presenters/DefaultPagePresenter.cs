﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Desafio.Simulador.Web.Mvp.Interfaces;
using Desafio.Simulador.Bsl.ServiceLocator;
//using Framework.Excecao;
using Desafio.Simulador.Util.Excecao;
using Desafio.Simulador.Bsl.Configurador.Interfaces;

namespace Desafio.Simulador.Web.Mvp.Presenters
{
    public class DefaultPagePresenter: Presenter
    {
        private readonly IDefaultPageView _defaultView;
        private readonly IConfiguradorPapelService _service;

        public DefaultPagePresenter(IDefaultPageView view)
            : this(view, null)
        { }

        public DefaultPagePresenter(IDefaultPageView view, ISessionProvider session)
            : base(view, session)
        {
            _defaultView = base.GetView<IDefaultPageView>();
            _defaultView.OnLoadView += new EmptyEventHandlerDelegate(_defaultView_OnLoadView);

            //Obtêm instância do Serviço WCF
            _service = Presenter.GetService<IConfiguradorPapelService>(); 
        }

        void _defaultView_OnLoadView()
        {
            try
            {
                //_service.ListarTodasCarteiras();
            }
            catch (FxApplicationException fEx) 
            {
                GerenciadorExcecao.TratarExcecao(fEx);
            }
        }
    }
}
