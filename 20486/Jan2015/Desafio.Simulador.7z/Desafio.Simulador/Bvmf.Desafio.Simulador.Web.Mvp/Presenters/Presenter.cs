using System;
using System.Collections.Generic;
using System.Text;
using Desafio.Simulador.Web.Mvp.Interfaces;
using Desafio.Simulador.Bsl.ServiceLocator;
using Desafio.Simulador.Util.Excecao;
//using Framework.Excecao;

namespace Desafio.Simulador.Web.Mvp.Presenters
{
    /// <summary>
    /// Base functionality all Presenters should support
    /// </summary>
    public abstract class Presenter
    {
        #region Declarations
        protected readonly IView _view;
        #endregion

        #region Constructor
        protected Presenter(IView view, ISessionProvider session)
        {
            _view = view;

            if (session != null)
            {
                SessionManager.Current = session;
            }
        }
        #endregion

        protected static T GetService<T>() 
        {
            try 
            {
                //Obt�m inst�ncia do Servi�o WCF
                return ServiceLocator.GetInstance<T>();
            }
            catch (FxApplicationException fEx) 
            {
                GerenciadorExcecao.TratarExcecao(fEx);
            }
            return default(T);
        }
        /// <summary>
        /// Converts an object from IView to the type of view the Presenter expects
        /// </summary>
        /// <typeparam name="T">Type of view to return (i.e. ILoginView)</typeparam>
        protected T GetView<T>() where T : class, IView
        {
            return _view as T;
        }
        /// <summary>
        /// Returns an object responsible for providing user session state
        /// </summary>
        protected ISessionProvider Session
        {
            get { return SessionManager.Current; }
        }
    }

    public delegate void EmptyEventHandlerDelegate();
}
