using System;
using System.Collections;
using System.Web;
using System.Web.SessionState;
using Desafio.Simulador.Web.Mvp.Interfaces;

namespace Desafio.Simulador.Web
{
    /// <summary>
    /// WebSessionProvider wraps asp.net's session object for use with the MVP
    /// pattern.  The presentation library shouldn't know about anything "downstram," 
    /// which means no references to System.Web etc.  Because the class implements
    /// ISessionProvider (in the Presentation project), state can still be maintained 
    /// using the HttpSessionState object. 
    /// </summary>
    public class WebSessionProvider : ISessionProvider
    {
        private HttpSessionState Session
        {
            get { return HttpContext.Current.Session; }
        }

        public void Add(string name, object value)
        {
            Session.Add(name, value);
        }

        public void Clear()
        {
            Session.Clear();
        }

        public bool Contains(string name)
        {
            return Session[name] != null;
        }

        #region ISessionProvider Members

        object ISessionProvider.this[string name]
        {
            get
            {
                return Session[name];
            }
            set
            {
                Session[name] = value;
            }
        }

        object ISessionProvider.this[int index]
        {
            get
            {
                return Session[index];
            }
            set
            {
                Session[index] = value;
            }
        }

        #endregion
    }
}