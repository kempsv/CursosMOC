﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Security;

namespace Desafio.Simulador.Web.Security
{
    public class AccountMembershipService : IMembershipService
    {
        private MembershipProvider _provider;

        public AccountMembershipService()
            : this(null)
        {
        }

        public AccountMembershipService(MembershipProvider provider)
        {
            _provider = provider ?? Membership.Provider;
        }

        #region IMembershipService Members

        public int MinPasswordLength
        {
            get
            {
                return _provider.MinRequiredPasswordLength;
            }
        }

        public bool ValidateUser(string userName, string password)
        {
            return _provider.ValidateUser(userName, password);
        }

        public bool ValidateUser(UserAccount userAccount)
        {
            if (_provider.GetType() == typeof(LMSMembershipProvider))
                return ((LMSMembershipProvider)_provider).ValidateUser(userAccount);
            else
                return _provider.ValidateUser(userAccount.UserName, userAccount.Password);
        }

        public MembershipCreateStatus CreateUser(UserAccount userAccount)
        {
            MembershipCreateStatus status;
            _provider.CreateUser(userAccount.UserName, userAccount.Password, userAccount.Email, null, null, true, null, out status);
            return status;
        }

        public bool ChangePassword(string userName, string oldPassword, string newPassword)
        {
            MembershipUser currentUser = _provider.GetUser(userName, true /* userIsOnline */);
            return currentUser.ChangePassword(oldPassword, newPassword);
        }

        public bool ExistUserByEmail(string email)
        {
            var _user = _provider.GetUserNameByEmail(email);
            if (_user != string.Empty)
                return true;
            else
                return false;
        }

        public bool ExistUserByName(string userName)
        {
            var _user = _provider.GetUser(userName, false);
            if (_user != null)
                return true;
            else
                return false;
        }

        #endregion
    }
}
