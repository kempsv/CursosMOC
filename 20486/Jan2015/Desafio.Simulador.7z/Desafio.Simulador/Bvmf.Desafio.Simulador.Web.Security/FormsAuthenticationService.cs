﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Security;
using System.Web;

namespace Desafio.Simulador.Web.Security
{
    public class FormsAuthenticationService : IFormsAuthentication
    {
        public HttpCookie HttpCookie { get; set; }

        public void SignIn(string userName, bool createPersistentCookie)
        {
            FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1,
              userName,
              DateTime.Now,
              //TODO: Código provisório, mudar para ConfigurationManager
              DateTime.Now.AddMinutes(30),
              createPersistentCookie,
              userName,
              FormsAuthentication.FormsCookiePath);

            // Encrypt the ticket.
            string encTicket = FormsAuthentication.Encrypt(ticket);

            // Create the cookie.
            this.HttpCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encTicket);

            FormsAuthentication.SetAuthCookie(userName, createPersistentCookie);
        }
        public static void SignOut()
        {
            FormsAuthentication.SignOut();
        }
    }
}
