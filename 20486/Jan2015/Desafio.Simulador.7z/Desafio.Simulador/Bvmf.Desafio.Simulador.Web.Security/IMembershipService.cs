﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Security;

namespace Desafio.Simulador.Web.Security
{
    public interface IMembershipService
    {
        int MinPasswordLength { get; }

        /// <summary>
        /// Método para autenticação do usuário do Sistema
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns>Retorna o bool</returns>
        bool ValidateUser(string userName, string password);

        /// <summary>
        /// Método para autenticação do usuário do sistema
        /// </summary>
        /// <param name="sessionId"></param>
        /// <returns>Retorna o objeto UserAccount</returns>
        bool ValidateUser(UserAccount userAccount);

        MembershipCreateStatus CreateUser(UserAccount userAccount);

        bool ChangePassword(string userName, string oldPassword, string newPassword);

        bool ExistUserByEmail(string email);

        bool ExistUserByName(string userName);
    }

}
