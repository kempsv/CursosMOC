﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Desafio.Simulador.Web.Security
{
    public enum TipoAccountType { Competidor, Professor }

    public class LMSUserAccount: UserAccount
    {
        /// <summary>
        /// Código Origem no Sistema LMS
        /// </summary>
        public int CodigoOrigem { get; set; }

        /// <summary>
        /// Token de Validação do Usuário no LMS
        /// </summary>
        public string Token { get; set; }

        /// <summary>
        /// Representa o tipo de usuário
        /// </summary>
        /// example: C=Competidor
        /// example: P=Professor
        public TipoAccountType AccountType { get; set; }

        /// <summary>
        /// Valor do SessionID gerado pelo LMS
        /// </summary>
        public string SessionId { get; set; }
    }
}
